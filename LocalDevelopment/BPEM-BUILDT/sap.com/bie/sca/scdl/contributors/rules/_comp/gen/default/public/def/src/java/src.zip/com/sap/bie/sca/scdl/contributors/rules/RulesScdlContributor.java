package com.sap.bie.sca.scdl.contributors.rules;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sap.bie.sca.scdl.adapter.IAttributeValue;
import com.sap.bie.sca.scdl.adapter.IBinding;
import com.sap.bie.sca.scdl.adapter.IComponent;
import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;
import com.sap.bie.sca.scdl.adapter.IInterface;
import com.sap.bie.sca.scdl.adapter.IScdlContributor;
import com.sap.bie.sca.scdl.adapter.IService;
import com.sap.bie.sca.scdl.adapter.ScdlContributorException;
import com.sap.bie.sca.scdl.adapter.impl.AttributeValue;
import com.sap.bie.sca.scdl.adapter.impl.Binding;
import com.sap.bie.sca.scdl.adapter.impl.Component;
import com.sap.bie.sca.scdl.adapter.impl.Composite;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.adapter.impl.Implementation;
import com.sap.bie.sca.scdl.adapter.impl.Interface;
import com.sap.bie.sca.scdl.adapter.impl.Service;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.moin.repository.Connection;
/**
 * Rules SCDL Contributor. Parses IComposite from design time artifact "application.rulesscdl" located under src/brms/ws folder if available
 * and returns. Uses DOM Parser for reading "application.rulesscdl".
 *  
 * @author I047255
 */
public class RulesScdlContributor implements IScdlContributor {
	
	// Constants
	
	// File System
	private static final String SRC_FOLDER = "src"; //$NON-NLS-1$
	private static final String BRMS_FOLDER = "brms"; //$NON-NLS-1$
	private static final String WS_FOLDER = "ws"; //$NON-NLS-1$
	private static final String RULES_SCDL_FILE_NAME = "application.rulesscdl"; //$NON-NLS-1$
	
	private static final String BRMS_IMPLEMENTATION = "implementation.brm"; //$NON-NLS-1$
	private static final String BINDGING_WS = "binding.ws"; //$NON-NLS-1$
	private static final String INTERFACE_WSDL = "interface.wsdl"; //$NON-NLS-1$
	
	// Attribute Names
	private static final String NAME_ATTR_NAME = "name"; //$NON-NLS-1$
	private static final String HELPER_CONTEXT_MANAGEMENT_ATTR_NAME = "helperContextManagement"; //$NON-NLS-1$
	
	// Element Names
	private static final String COMPONENT_ELEM_NAME = "component"; //$NON-NLS-1$
	private static final String SERVICE_ELEM_NAME = "service"; //$NON-NLS-1$
	private static final String SAP_EXTENSIONS_ELEM_NAME = "sapextensions"; //$NON-NLS-1$
	
	
	
	public IComposite getComposite(Connection conn, IGlobalPluginUtil globlaPlugInUtil,	IPluginBuildInfo plugInBuildInfo) throws ScdlContributorException{
		IComposite composite = null;
		
		File brmsWsDir = getWsDir(plugInBuildInfo);
		if(brmsWsDir != null && brmsWsDir.exists()){
			File rulesScdlFile = new File(brmsWsDir, RULES_SCDL_FILE_NAME);
			if(rulesScdlFile.exists()){
				composite = parseComposite(rulesScdlFile);
			}
		}
		
		return composite;
	}
	
	/**
	 * Returns "src/brms/ws" folder.
	 * @param plugInBuildInfo
	 * @return
	 */
	private File getWsDir(IPluginBuildInfo plugInBuildInfo){
		List<File> srcDirs = plugInBuildInfo.getSourceDirsAsFiles();
		Iterator<File> srcDirsIt = srcDirs.iterator();
		
		File brmsWsDir = null;
		
		while(srcDirsIt.hasNext()){
			File srcDir = srcDirsIt.next();
			if(srcDir.isDirectory()){
				String dirName = srcDir.getName();
				if(dirName.equals(SRC_FOLDER)){
					brmsWsDir = new File(srcDir, BRMS_FOLDER+File.separator+WS_FOLDER);
					break;
				}
			}
		}
		
		return brmsWsDir;
	}
	
	/**
	 * Parses IComposite from "application.rulesscdl".
	 * @param rulesscdlFile
	 * @return IComposite
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */
	private IComposite parseComposite(File rulesscdlFile) throws ScdlContributorException{
		InputStream in = null;
		try{
			in = new FileInputStream(rulesscdlFile);
			
			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
			builderFactory.setNamespaceAware(true);
			DocumentBuilder builder = builderFactory.newDocumentBuilder();
			
			Document doc = builder.parse(in);
			
			Element rootElement = doc.getDocumentElement();
			Map<String, Attr> attsMap = getAttributesMap(rootElement);
			Attr nameAttr = attsMap.get(NAME_ATTR_NAME);
			String compositrName = nameAttr.getValue();
			
			Composite composite = new Composite(new QName(compositrName));
			
			List<Element> compElements = getElementsOfName(rootElement, COMPONENT_ELEM_NAME);
			for(int i=0;i<compElements.size();i++){
				Element compElement = compElements.get(i);
				IComponent component = parseComponent(compElement);
				if(component != null){
					composite.addComponent(component);
				}
			}
			
			return composite;
		}catch (IOException ioe) {
			throw new ScdlContributorException("IOException during parseComposite", ioe);
		} catch (ParserConfigurationException pce) {
			throw new ScdlContributorException("ParserConfigurationException during parseComposite", pce);
		} catch (SAXException se) {
			throw new ScdlContributorException("SAXException during parseComposite", se);
		}finally{
			if(in != null){
				try{
					in.close();
				}catch(IOException ioe){
					Log.warn("IOException during in.close");
				}
			}
		}
		
	}
	
	/**
	 * Parses IComponent from component DOM Element.
	 * @param componentElement
	 * @return 
	 */
	private IComponent parseComponent(Element componentElement) throws ScdlContributorException{
		List<Element> implElements = getElementsOfName(componentElement, BRMS_IMPLEMENTATION);
		// Check if brm implementation element is present and only one element exists
		if(implElements != null && implElements.size()==1){
			Element implElement = implElements.get(0);
			Implementation impl = new Implementation(BRMS_IMPLEMENTATION);
			
			ICustomScdlElement implCustomElement = convert(implElement);
			impl.addCustomElement(implCustomElement);
			
			Map<String, Attr> attsMap = getAttributesMap(componentElement);
			
			String componentName = attsMap.get(NAME_ATTR_NAME).getValue();
			Component component = new Component(componentName, impl);
			
			Attr helperContextAttr = attsMap.get(HELPER_CONTEXT_MANAGEMENT_ATTR_NAME);
			if(helperContextAttr != null){
				CustomScdlAttribute helperContextScdlAttr = createCustomizableAttributesForDomAttr(helperContextAttr);
				component.addAttribute(helperContextScdlAttr);
			}
			
			List<Element> serviceElements = getElementsOfName(componentElement, SERVICE_ELEM_NAME);
			//each component will have only one service
			if(serviceElements != null && serviceElements.size()==1){
				Element serviceElement = serviceElements.get(0);
				IService service = parseService(serviceElement);
				component.addService(service);
			}else{
				throw new ScdlContributorException("More than one service element in  application.rulesscdl"); //$NON-NLS-1$
			}
		
			
			return component;
		}else{
			throw new ScdlContributorException("No or more than one implementation.brm element in  application.rulesscdl"); //$NON-NLS-1$
		}
		
	}
	
	/**
	 * Parses IService from service DOM Element.
	 * @param serviceElement
	 * @return
	 */
	private IService parseService(Element serviceElement) throws ScdlContributorException{
		Map<String, Attr> serviceElementAttrs = getAttributesMap(serviceElement);
		Attr nameAttr = serviceElementAttrs.get(NAME_ATTR_NAME);
		String serviceName = nameAttr.getValue();
		
		Service service = new Service(serviceName, false);
		
		// Interface
		List<Element> interfaceElements = getElementsOfName(serviceElement, INTERFACE_WSDL);
		
		// Check if interface.wsdl element is present and only one element exists
		if(interfaceElements!=null && interfaceElements.size()==1){
			Element interfaceElement = interfaceElements.get(0);
			IInterface scdlInterface = parseInterface(interfaceElement);
			service.setScainterface(scdlInterface);
		}else{
			throw new ScdlContributorException("No or more than one interface.wsdl element in application.rulesscdl"); //$NON-NLS-1$
		}
		
		// Binding
		List<Element> bindingElements = getElementsOfName(serviceElement, BINDGING_WS);
		
		// Check if binding.ws  element is present and only one element exists
		if(bindingElements!=null && bindingElements.size()==1){
			Element bindingElement = bindingElements.get(0);
			IBinding binding = parseBinding(bindingElement);
			service.setBinding(binding);
		}else{
			throw new ScdlContributorException("No or more than one binding.ws element in application.rulesscdl"); //$NON-NLS-1$
		}
		
		// Sap Extensions
		List<Element> sapExtensionElements = getElementsOfName(serviceElement, SAP_EXTENSIONS_ELEM_NAME);
		
		// Check if sapextensions element is present and only one element exists
		if(sapExtensionElements!=null && sapExtensionElements.size()==1){
			Element sapExtensionElement = sapExtensionElements.get(0);
			ICustomScdlElement customElement = convert(sapExtensionElement);
			service.addCustomElement(customElement);
			return service;
		}else{
			throw new ScdlContributorException("No or more than one sapextensions element in application.rulesscdl"); //$NON-NLS-1$
		}
	}
	
	/**
	 * Parses IInterface from interface DOM Element.
	 * @param interfaceElement
	 * @return
	 */
	private IInterface parseInterface(Element interfaceElement){
		Interface scdlInterface = new Interface(INTERFACE_WSDL);
		ICustomScdlElement scdlElement = convert(interfaceElement);
		scdlInterface.addCustomElement(scdlElement);
		return scdlInterface;
	}
	
	/**
	 * Parses IBinding from binding DOM Element.
	 * @param bindingElement
	 * @return
	 */
	private IBinding parseBinding(Element bindingElement){
		Binding binding = new Binding(BINDGING_WS);
		ICustomScdlElement scdlElement = convert(bindingElement);
		binding.addCustomElement(scdlElement);
		return binding;
	}
	

	private ICustomScdlElement convert(Element element){
		CustomScdlElement scdlElement = createCustomScdlElementForDomElement(element);
		convertChildren(scdlElement, element);
		return scdlElement;
	}
	
	private void convertChildren(CustomScdlElement scdlElement, Element element){
		List<Element> children = getChildElements(element);
		Iterator<Element> childrenIt = children.iterator();
		while(childrenIt.hasNext()){
			Element child = childrenIt.next();
			CustomScdlElement childScdlElement = createCustomScdlElementForDomElement(child);
			scdlElement.addChild(childScdlElement);
			convertChildren(childScdlElement, child);
		}
	}
	
	private CustomScdlElement createCustomScdlElementForDomElement(Element element){
		String elementName = getElementNameWithoutPrefix(element);
		String nameSpace = element.getNamespaceURI();
		String prefix = element.getPrefix();
		QName qName = createQNameUsingAppropriateConstructor(elementName, nameSpace, prefix);
		CustomScdlElement scdlElement = new CustomScdlElement(qName);
		List<Attr> attributes = getAttributes(element);
		Iterator<Attr> attributesIt = attributes.iterator();
		while(attributesIt.hasNext()){
			Attr attr = attributesIt.next();
			ICustomScdlAttribute scdlAttr = createCustomizableAttributesForDomAttr(attr);
			scdlElement.addAttribute(scdlAttr);
		}
		
		return scdlElement;
	}
	
	private CustomScdlAttribute createCustomizableAttributesForDomAttr(Attr attr){
		String elementName = getAttributeWithoutPrefix(attr);
		String nameSpace = attr.getNamespaceURI();
		String prefix = attr.getPrefix();
		String value = attr.getValue();
		
		// Replace space(' ') with tilde('~') in 'location' attribute value
		if(elementName.equals("location") && nameSpace.equals("http://www.sap.com/xmlns/sapsca/1.0")){
			int index = value.lastIndexOf("gen_bpm/brms2/ws/");
			if(index>0){
				String wsdlFileFolder = value.substring(0, index);
				String wsdlFileName = value.substring(index, value.length());
				wsdlFileName = wsdlFileName.replace(' ' ,'~');
				value = wsdlFileFolder+wsdlFileName;
			}
		}
		
		QName qName = createQNameUsingAppropriateConstructor(elementName, nameSpace, prefix);
		QName valueQName = createQNameUsingAppropriateConstructor(value, null, null);
		IAttributeValue scdlValue = new AttributeValue(valueQName);
		CustomScdlAttribute scdlAttr = new CustomScdlAttribute(qName, scdlValue);
		return scdlAttr;
	}
	
	private List<Element> getChildElements(Element element){
		List<Element> childElements = new ArrayList<Element>();
		NodeList children = element.getChildNodes();
		
		for(int i=0;i<children.getLength();i++){
			Node child = children.item(i);
			if(child instanceof Element){
				Element childElem = (Element)child;
				childElements.add(childElem);
			}
			
		}
		return childElements;
	}
	
	private List<Attr> getAttributes(Element elem){
		
		List<Attr> attrsList = new ArrayList<Attr>();
		NamedNodeMap atts = elem.getAttributes();
		
		for(int i=0;i<atts.getLength();i++){
			Node node = atts.item(i);
			if(node instanceof Attr){
				Attr att = (Attr)node;
				attrsList.add( att);
			}
		}
		return attrsList;
	}
	
	private List<Element> getElementsOfName(Element element, String elemName){
		List<Element> reqElements = new ArrayList<Element>();
		NodeList children = element.getChildNodes();
		
		for(int i=0;i<children.getLength();i++){
			Node child = children.item(i);
			if(child instanceof Element){
				Element childElem = (Element)child;
				String currElemName = getElementNameWithoutPrefix(childElem);
				
				if(elemName.equals(currElemName)){
					reqElements.add(childElem);
				}
			}
			
		}
		return reqElements;
		
	}
	
	private Map<String, Attr> getAttributesMap(Element elem){
		
		Map<String, Attr> attrsMap = new HashMap<String, Attr>();
		NamedNodeMap atts = elem.getAttributes();
		
		for(int i=0;i<atts.getLength();i++){
			Node node = atts.item(i);
			if(node instanceof Attr){
				Attr att = (Attr)node;
				String name = getAttributeWithoutPrefix(att);
				attrsMap.put(name, att);
			}
		}
		return attrsMap;
	}
	
	private String getElementNameWithoutPrefix(Element element){
		String elemName = null;
		String prefix = element.getPrefix();
		if(prefix != null){
			elemName = element.getLocalName();
		}else{
			elemName = element.getTagName();
		}
		return elemName;
	}
	
	private String getAttributeWithoutPrefix(Attr attr){
		String attrName = null;
		String prefix = attr.getPrefix();
		if(prefix != null){
			attrName = attr.getLocalName();
		}else{
			attrName = attr.getName();
		}
		return attrName;
	}
	
	private QName createQNameUsingAppropriateConstructor(String name, String nameSpace, String prefix){
		if(name == null){
			throw new IllegalArgumentException("name can not be null"); //$NON-NLS-1$
		}
		QName qName = null;
		if(nameSpace == null){
			qName = new QName(name);
		}else{
			if(prefix == null){
				qName = new QName(nameSpace, name);
			}else{
				qName = new QName(nameSpace, name, prefix);
			}
		}
		return qName;
	}
	
}
