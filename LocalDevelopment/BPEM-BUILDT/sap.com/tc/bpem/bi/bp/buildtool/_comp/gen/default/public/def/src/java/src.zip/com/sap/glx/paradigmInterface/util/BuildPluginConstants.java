package com.sap.glx.paradigmInterface.util;

import com.sap.glx.constants.SharedCompilerConstants;

public class BuildPluginConstants{

	// Constants for metamodel version check
	public static final String METAMODEL_ATTRIBUTE_VERSION = "v";
	public static final String METAMODEL_ATTRIBUTE_NAME = "n";
	public static final String METAMODEL_NAME = "sap.com/glx/ide";
	public static final String TAG_NAME = "C";
	public static final String BUILDPLUGIN_VERSION = "2.0.0";
	public static final String PROPERTY_ORIGINAL_DC_VENDOR = "OriginalDCVendor";
	public static final String PROPERTY_ORIGINAL_DC_NAME = "OriginalDCName";
    
	// Directory constants
	public static final String RESOURCES_FOLDER = "resources/";
	public static final String TMP_DIR = "tmp";
	public static final String GEN_BPEM_DIR = "gen_bpm";
	public static final String DEF_DIR = "def";
	public static final String SRC_DIR = "src";
	public static final String SDA_TMP_DIR = "ctx";
	public static final String META_INF_DIR = "META-INF";
	
	
	public static final String TARGET_DIR_SOURCEVERSIONER = "";
	public static final String TARGET_DIR_BPMN2CSVCOMPILER = "gen_bpm";
	public static final String TARGET_DIR_XLFFACTORY = "gen_bpm" + System.getProperty("file.separator") + "text"; 
	public static final String TARGET_DIR_DIAGRAMTOXMLCONVERTER = "gen_bpm" + System.getProperty("file.separator") + "pv";
	public static final String TARGET_DIR_TYPECOMPILER = "gen_bpm" + System.getProperty("file.separator") + "types";
	public static final String TARGET_DIR_EXCEPTIONCOMPILER = "gen_bpm" + System.getProperty("file.separator") + "exceptions";
	public static final String TARGET_DIR_INTERFACECOMPILER = "gen_bpm" + System.getProperty("file.separator") + "endpoints";
	public static final String TARGET_DIR_RULESCOMPILER = "gen_bpm" + System.getProperty("file.separator") + "brms2";
	public static final String TARGET_DIR_REPORTINGDEFINITIONCOMPILER = "gen_bpm" + System.getProperty("file.separator") + "analytics";
	
	public static final String ARTIFACT_PATH_TASK = "tasks" + System.getProperty("file.separator");
	public static final String ARTIFACT_PATH_COLLABORATION = "bpmn" + System.getProperty("file.separator");
	public static final String ARTIFACT_PATH_PV = "pv" + System.getProperty("file.separator");
	public static final String ARTIFACT_PATH_XLIFF = "text" + System.getProperty("file.separator");
	public static final String ARTIFACT_PATH_WSDL = "wsdls" + System.getProperty("file.separator");
	public static final String ARTIFACT_PATH_TYPES = "types" + System.getProperty("file.separator");
	public static final String ARTIFACT_PATH_BRMS = "brms" + System.getProperty("file.separator");
	public static final String ARTIFACT_PATH_BRMSTESTS = "brmstests" + System.getProperty("file.separator");	
	public static final String ARTIFACT_PATH_ANALYTICS = "analytics" + System.getProperty("file.separator");
	public static final String ARTIFACT_PATH_EVENT_DEFINITION = "triggers" + System.getProperty("file.separator");
	public static final String ARTIFACT_PATH_OTHER_ARTIFACT = "";
		
	// File constants
	public static final String SDA_EXTENSION = ".sda";
	public static final String BPEM_ARCHIVE_EXTENSION = ".bpem";	
	public static final String TASK_EXTENSION = ".task";
	public static final String COLLABORATION_EXTENSION = ".bpmn";
	public static final String COLLABORATION_EXTENSION_OLD = ".workflow";
	public static final String EVENTDEF_EXTENSION = ".eventdef";	
	public static final String MASS_CONF_EXTENSION = ".cfgar";
	public static final String WORKFLOW_DIRECTORY_OLD = "workflows\\";
	public static final String BPEM_FILE_KEY = "bpem.file";
	public static final String REFERENCES_KEY = "references";
	public static final String REFERENCED_DC_VENDOR_KEY = "depend_vendor";
	public static final String REFERENCED_DC_NAME_KEY = "depend_name";
	public static final String APPLICATION_XML_FILE = "application.xml";
	public static final String APPLICATION_J2EE_ENGINE_XML_FILE = "application-j2ee-engine.xml";
	public static final String SDA_DD_XML_FILE = "sda-dd.xml";
	public static final String CONTENT_TOC_FILE = "content.toc";
	public static final String CONTENT_META_FILE = "content.meta";
	public static final String SCDL_OUTPUT = "/scdl_output";
	public static final String XLF_OUT = "/xlf_out";
	public static final String SCA_RESOURCES = "/META-INF/sca-resources";
	
	// Object types
	public static final String EVENT_DEFINITION = "EventDefinition";
	public static final String COLLABORATION = "Collaboration";
	public static final String COLLABORATION_CLASS = "CollaborationWrapper";
	public static final String TASK_CLASS = "StandaloneTaskWrapper";
	public static final String TASK = "Task";
	public static final String XLIFF = "XLIFF";
	public static final String PV = "PV";
	public static final String WSDL = "WSDL";
	public static final String TYPES = "TYPES";
	public static final String ANALYTICS = "Analytics";
	public static final String OTHER_ARTIFACT = "Other Artifact";

	// Name of build task
	public static final String BPEM_TASK = "BpemTask";
	
	public static final String ENCODING_UTF8 = SharedCompilerConstants.UTF_8;
	public static final String FILE_SEPARATOR = System.getProperty("file.separator");
	public static final String LINE_SEPARATOR = System.getProperty("line.separator");
	
	// BRMS file constants
	public static final String BRMS = "brms";
	public static final String BRMSTESTS = "brmstests";
	public static final String WS = "ws";
	public static final String DIAGRAMS = "diagrams";

	// BRMS rule files extensions
	public static final String PROJECT_EXT = ".ruleprj";
	public static final String RULESET_EXT = ".ruleset";
	public static final String ALIASSET_EXT = ".aliasset";
	public static final String SHAREDRES_EXT = ".sharedres";
	public static final String SHAREDRES_ALIASSET_SUFFIX = "_sharedres";
	public static final String VALIDATION_MSGS_FILE_NAME = "validationmessages.xml";
	public static final String CSDL_EXT = ".csdl";
	public static final String RULESSCDL_EXT = ".rulesscdl";
	public static final String DIAGRAM_EXT = ".diagram";
	
	public static final String RUNTIME_REFERENCE_XML = "<reference reference-type=\"hard\"><reference-target provider-name=\"${depend_vendor}\" target-type=\"application\">${depend_name}</reference-target></reference>";
	public static final String VERSION_EXCEPTION_MESSAGE = "DC cannot be built. Version of used metamodel is higher than the version of the build plugin.";
}