/**
 * 
 */
package com.sap.glx.paradigmInterface.util;

/**
 * @author I045302
 * 
 */
public class BuildPluginLogConstants {

    public static final String CSN_COMPONENT_NAME = "BC-BMT-BPM-SRV";    

}
