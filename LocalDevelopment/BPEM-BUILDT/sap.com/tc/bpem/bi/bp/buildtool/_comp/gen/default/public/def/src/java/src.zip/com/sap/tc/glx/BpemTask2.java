package com.sap.tc.glx;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.apache.tools.ant.BuildException;

import com.sap.glx.paradigmInterface.buildapi.IArtifact;
import com.sap.glx.paradigmInterface.buildapi.ICompiler2;
import com.sap.glx.paradigmInterface.buildapi.IPostProcessor2;
import com.sap.glx.paradigmInterface.buildapi.ISeedProvider;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.paradigmInterface.triggernet.assembler.AssemblerException;
import com.sap.glx.paradigmInterface.util.BuildPluginConstants;
import com.sap.glx.paradigmInterface.util.GenerateSDA;
import com.sap.glx.paradigmInterface.util.TmpDirUtil;
import com.sap.sdm.ant.api.JarSAPException;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.moin.ant.instance.MoinTaskData;
import com.sap.tc.moin.ant.task.MoinAntTask;
import com.sap.tc.moin.repository.CRI;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.PRI;
import com.sap.tc.moin.repository.ocl.OclRegistryService;
import com.sap.tc.moin.repository.ocl.metamodel.OclMetamodelConstraintRegistry;
import com.sap.tc.moin.repository.ocl.notification.DeferredConstraintViolationListener;
import com.sap.tc.moin.repository.ocl.notification.OclManagerException;
import com.sap.tc.moin.repository.ocl.registry.OclRegistrationCategory;

public class BpemTask2 extends MoinAntTask {
	
	HashSet<IArtifact<?>> compedObjects;
	BuilderHostImpl2 builder;
	MoinTaskData td;
	boolean isConstraintCheckDone;
	Set<PRI> priSet;
	
    @Override
    public void execute() throws BuildException {
        Log.info("BpemTask2.execute");
        
        isConstraintCheckDone = false;
        priSet = new HashSet<PRI>();
        td = getTaskData();
        Connection conn = td.getConnection();
        
        // Getting name, vendor and root directory
        IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class
                .getName());
        IGlobalPluginUtil gpu = (IGlobalPluginUtil) BuildSessionManager.getFromBuildSession(IGlobalPluginUtil.class.getName());
        
    	String dcName = pbi.getDCName();
    	String dcVendor = pbi.getDCVendor();
    	File dcRoot = pbi.getRootDir();
    	
    	try {
			gpu.createTempDir(BuildPluginConstants.GEN_BPEM_DIR + BuildPluginConstants.FILE_SEPARATOR + CompilerRegistry2.ARTIFACT_DIRS.get(BuildPluginConstants.COLLABORATION));
			gpu.createTempDir(BuildPluginConstants.GEN_BPEM_DIR + BuildPluginConstants.FILE_SEPARATOR + CompilerRegistry2.ARTIFACT_DIRS.get(BuildPluginConstants.TASK));
		} catch (IOException ioE) {
			Log.error(ioE);
			throw new BuildException(ioE);
		}
        
		CRI cri = createCRI(dcName, dcVendor);
		builder = new BuilderHostImpl2(conn, cri);
		TmpDirUtil tmpUtil = new TmpDirUtil(dcRoot); 
		compedObjects = new HashSet<IArtifact<?>>();
		
		// Execute constraint check before normal compilation
        if (System.getProperty("com.glx.checkconstraint")==null ||  
                !(System.getProperty("com.glx.checkconstraint").equals("false"))){
        	HashSet<PRI> hSet = new HashSet<PRI>();
        	for (PRI colItem: conn.getSession().getInnerPartitions(cri))
        			{
        				hSet.add(colItem);
        			}
        	 
            //constraintCheck(conn, (HashSet<PRI>)conn.getSession().getInnerPartitions(cri));
        }
		
		try{
			ICompiler2<?,?> currentCompiler = (ICompiler2<?,?>)Class.forName(CompilerRegistry2.COMPILERS[0].getClassString()).newInstance();
			currentCompiler.compile(builder, null); // No artifact is needed to be passed to this dummy compiler
		}
		catch(Exception e){
			Log.error(e);
			throw new BuildException(e);
		}
		
		ArrayList<IArtifact<?>> seeds = new ArrayList<IArtifact<?>>();
		try{
			// Getting seeds from each seed provider
			for (String seedProvString: CompilerRegistry2.SEEDPROVIDERS){
				ISeedProvider<?,?> seedProv = (ISeedProvider<?,?>)Class.forName(seedProvString).newInstance();
				Iterable<?> seedIter = seedProv.getSeed(builder);
				if (seedIter!=null){
					for (Object seed: seedIter){
						seeds.add((IArtifact<?>)seed);
						Log.info("SeedProvider:" + seedProvString + "Seed added: " + seed.toString());
					}
				}
			}
		    
			// Compile seeds
			for (IArtifact<?> seedToCompile : seeds) {
				compileArtifact(seedToCompile);
			}
			// PostProcess
			postProcess();
		}
		catch (Exception e){
			Log.error(e);
			throw new BuildException(e);
		}
		
		// Getting and compiling brms rules
//		Log.info("Entering Process to compile rules");
//		CompilerRegistry.setArtifactType(BuildPluginConstants.BRMS);
//		try{
//			//callCompilersForRules(pbi);
//			RulesArtifactsCompilationManager2 manager = new RulesArtifactsCompilationManager2(pbi, builder, compedObjects);
//			manager.manageCompilation();
//		}
//		catch (Exception e){
//			Log.error(e);
//			throw new BuildException(e);
//		}
		        
		//Generating SDA
    	GenerateSDA generateSDA = new GenerateSDA(pbi.getGenDirDeploy());
    	try{
    		
    		File tmpRoot = tmpUtil.getTmpDir();
    		builder.createTocFile(new File(tmpUtil.getTmpGenDir(),BuildPluginConstants.CONTENT_TOC_FILE));
    		generateSDA.generateOutOfBoundsArchives(builder.getArchiveRegistry());
    		generateSDA.generateContentMetaFile(new File(tmpUtil.getTmpGenDir(),BuildPluginConstants.CONTENT_META_FILE),pbi.getCBSLocation(), pbi.getCBSCounter(), System.currentTimeMillis());
    		generateSDA.copyMcArchive(pbi.getGenDirPublic());
    		generateSDA.execute(dcName, dcVendor, pbi.getCBSLocation(), pbi.getCBSCounter(), tmpRoot);
    	}
    	catch(java.io.IOException e){
        	Log.error("IOException during SDA generation: " + e.getMessage());
        	Log.error(e);
        	throw new BuildException(e);
        }
    	catch(JarSAPException e){
        	Log.error("IOException during SDA generation: " + e.getMessage());
        	Log.error(e);
        	throw new BuildException(e);
        }
    	
    }

    private void postProcess() throws Exception{
		Log.info("Entering postProcess()");
		for(String comp: CompilerRegistry2.POSTPROCESSORS){
			IPostProcessor2 postProc = (IPostProcessor2)Class.forName(comp).newInstance();
			postProc.postProcess(builder);
		}
		
	}
   
    private void compileArtifact(IArtifact<?> art) throws Exception
    {
    	Log.info("compileArtifact(): ", art.getIdentifier() + " // " + art.getObject().toString());
    	//if the IArtifact object was already compiled, skip it
    	if (compedObjects.contains(art)) return; 
    	
    	CompilerType comp = art.handledBy();
    	ICompiler2<?,IArtifact<?>> currentCompiler = (ICompiler2<?,IArtifact<?>>)Class.forName(CompilerRegistry2.getCompilerClass(comp)).newInstance();
    	
    	IArtifact<?>[] deps = currentCompiler.getDependencies(builder, art);
    	if (deps!=null){
    		for (IArtifact<?> dep : deps){
    			Log.info("dep: " + dep.getIdentifier() + " // " + dep.getObject().toString() + " of: " + art.getIdentifier() + " // " + art.getObject().toString());
    			compileArtifact(dep);
    		}
    	}
    	currentCompiler.compile(builder, art);
    	compedObjects.add(art);
    	
    }

    private CRI createCRI(String name, String vendor){
    	return td.getMoin().createCri("PF", "DefaultDataArea", vendor + "/" + name);
    }
    
    private boolean constraintCheck(Connection conn, Set<PRI> priSet) {
        boolean result1=false;

        OclRegistryService regService = conn.getOclRegistryService();
        OclMetamodelConstraintRegistry reg = regService.getMetamodelConstraintRegistry();

        DeferredConstraintViolationListener list = new OclListener();
        reg.registerPartitionBasedConstraintViolationListener(OclRegistrationCategory.deferred.name(), list);
        // reg.registerPartitionBasedConstraintViolationListener(OclRegistrationCategory.immediate.name(), list);

        try {
            result1 = regService.analyzeModelPartitions(OclRegistrationCategory.deferred.name(), priSet);
            // result2 = regService.analyzeModelPartitions(OclRegistrationCategory.immediate.name(), prisToCheck);
        } catch (OclManagerException e) {
            throw new BuildException("OclManagerException in constraint checking");
        }
        
        Log.info("Constraint check is done");

        return result1;
    }

}
