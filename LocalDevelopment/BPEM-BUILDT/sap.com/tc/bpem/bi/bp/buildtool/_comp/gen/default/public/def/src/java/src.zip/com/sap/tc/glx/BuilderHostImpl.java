package com.sap.tc.glx;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.tools.ant.BuildException;

import com.sap.glx.constants.SharedCompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.Warnable;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.INormalizedTypeFileWriter;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.paradigmInterface.facades.IEsmpFacade;
import com.sap.glx.paradigmInterface.facades.impl.EsmpFacadeImpl;
import com.sap.glx.paradigmInterface.util.BuildPluginConstants;
import com.sap.glx.paradigmInterface.util.BuildPluginLogConstants;
import com.sap.glx.paradigmInterface.util.WarnableImpl;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.pp.api.IComponentDependencies;
import com.sap.tc.buildplugin.pp.api.IComponentDependency;
import com.sap.tc.moin.repository.CRI;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.PRI;
import com.sap.tc.moin.repository.Partitionable;

/**
 * This class manages the VersionRegistry which contains all information about the compilers.
 * 
 * @author I044123
 * 
 */
public class BuilderHostImpl implements IBuilderHost {

    private IEsmpFacade esmp;
    private Vector<VersionRegistry> pluginMap = null;
    private Hashtable<String, File> archiveRegistry = null;
    private HashMap<CompilerType, HashMap<Object, List<Object>>> postProcessorData = null;
    private File tmpRoot;
    private CRI localDc;
    private IPluginBuildInfo pbi;
    private String rulesBuildId;
    private String logPrefix = BuildPluginLogConstants.CSN_COMPONENT_NAME + " " + BuilderHostImpl.class.getName();

    /**
     * New VersionRegistry is created in the constructor and dcRoot is determined.
     */
    public BuilderHostImpl(Connection conn, CRI cri) {
        super();
        esmp = new EsmpFacadeImpl(conn);
        pluginMap = new Vector<VersionRegistry>();
        archiveRegistry = new Hashtable<String, File>();
        postProcessorData = new HashMap<CompilerType, HashMap<Object, List<Object>>>();
        pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
        tmpRoot = pbi.getTempDir();
        localDc = cri;
    }

    public IEsmpFacade getEsmpFacade() {
        return esmp;
    }

    /**
     * This method creates a new Stream where to write the result of the compiler.
     */
    public OutputStream createVersionedTargetFile(String relativePath, Object sourceArtifact) throws Exception {
        File file = createTargetFile(relativePath, sourceArtifact);
        OutputStream outStream = new VersionedStream(relativePath, file, sourceArtifact, this);

        Log.debug(logPrefix + " createVersionedTargetFile(String relativePath, Object sourceArtifact) - exiting. ");
        return outStream;
    }
    
    public INormalizedTypeFileWriter getNormalizedTypeFileWriter(String relativePath, Object sourceArtifact) throws Exception {
        File file = createTargetFile(relativePath, sourceArtifact);
        Log.debug(logPrefix + " getNormalizedTypeFileWriter(String relativePath, Object sourceArtifact) - exiting. ");
        return new NormalizedTypeFileWriter(relativePath, file, sourceArtifact, this);
    }
    
    private File createTargetFile(String relativePath, Object sourceArtifact) {
        Log.debug(logPrefix + " createTargetFile(String relativePath, Object sourceArtifact) - entering. ");

        // Full path of the output file
        String fileName = tmpRoot + BuildPluginConstants.FILE_SEPARATOR + BuildPluginConstants.TMP_DIR
                + BuildPluginConstants.FILE_SEPARATOR + CompilerRegistry.COMPILERS[CompilerRegistry.getIndex()].getTargetDir().getPath()
                + BuildPluginConstants.FILE_SEPARATOR + getArtifactPath(sourceArtifact) + BuildPluginConstants.FILE_SEPARATOR
                + relativePath;

        File full = new File(fileName);
        Log.debug(logPrefix + " fileName:" + fileName);

        full.getParentFile().mkdirs();
        return full;
    }

    /**
     * This method is used by the CSV compiler because it needs to have a row in the VersionRegistry from the beginning. When the file is
     * written this row will be updated.
     */
    public void calculateVersionId(Object artifact) {
        String curVersionId = getVersionId(artifact);
        if (curVersionId.equals("")) {
            String versionId = String.valueOf(artifact.hashCode());
            int compilerIndex = CompilerRegistry.getIndex();
            VersionRegistry vr = new VersionRegistry(artifact, CompilerRegistry.COMPILERS[compilerIndex].getCompiler(), versionId, "", "",
                    false);
            // addVersionRegistry(vr);
        }
    }

    /**
     * This method checks whether the artifact is in the VersionRegistry with the current compiler or not.
     */
    public String getVersionId(Object artifact) {
        int compilerIndex = CompilerRegistry.getIndex();
        return getVersionId(artifact, CompilerRegistry.COMPILERS[compilerIndex].getCompiler());
    }

    /**
     * This method checks whether the artifact is in the VersionRegistry with the given compiler or not.
     */
    public String getVersionId(Object artifact, CompilerType compilerType) {
        if (pluginMap.size() > 0) {
            int i = 0;
            while ((i < pluginMap.size())
                    && (!(artifact.equals(pluginMap.get(i).getArtifact())) || !(compilerType == (pluginMap.get(i).getCompilerId())))) {
                i++;
            }
            if ((i < pluginMap.size()) && (artifact.equals(pluginMap.get(i).getArtifact()))) {
                return pluginMap.get(i).getVersionId();
            } else {
                return "";
            }
        } else {
            return "";
        }
    }

    /**
     * This method returns the application name of the current development component. It concatenate the vendor and the name of a
     * development component. As a separator between the vendor and name a '/' is used. All '/' in the DC name are replaced with '~'
     * character.
     * 
     */
    public String getApplicationName() {
        String dcVendor = pbi.getDCVendor();
        String dcName = pbi.getDCName().replace('/', '~');
        return dcVendor + '/' + dcName;
    }

    /**
     * This method returns the application name of another DC
     */
    public String getApplicationName(Object artifact) {
        if (artifact instanceof Partitionable) {
            return appNameEscaped(((Partitionable) artifact).get___Mri().getContainerName());
        } else
            return "";
    }

    /**
     * This method adds a new row into the VersionRegistry with the given artifact and versionID to the current compiler. If the row exists
     * then nothing happens.
     */
    public void setVersionId(Object artifact, String versionId) {
        String curVersionId = getVersionId(artifact);
        if (curVersionId.equals("")) {
            int compilerIndex = CompilerRegistry.getIndex();
            VersionRegistry vr = new VersionRegistry(artifact, CompilerRegistry.COMPILERS[compilerIndex].getCompiler(), versionId, "", "",
                    false);
            addVersionRegistry(vr);
        }
    }

    /**
     * This method gives back a PRI where the artifact is situated.
     */
    public PRI getDCIdentifier(Object artifact) {
        if (artifact instanceof Partitionable) {
            return ((Partitionable) artifact).get___Mri().getPri();
        } else
            return null;

    }

    /**
     * This method returns true if the artifact resides in the current DC.
     */
    public boolean isFromLocalDC(Object artifact) {
        // if Object is not a moin object or the moin object is local, return true
        if (!(artifact instanceof Partitionable) || getDCIdentifier(artifact).getCri().equals(localDc)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * This method gives back the current size of the VersionRegistry.
     * 
     * @return
     */
    public int getVersionRegistrySize() {
        return pluginMap.size();
    }

    /**
     * This method gives back a row from the VersionRegistry which is situated in the given index.
     * 
     * @param rowIndex
     * @return
     */
    public VersionRegistry getVersionRegistryRow(int rowIndex) {
        return pluginMap.get(rowIndex);
    }

    /**
     * This method changes the VersionRegistry on the given rowIndex with the given row.
     * 
     * @param rowIndex
     * @param vr
     */
    public void setVersionRegistryRow(int rowIndex, VersionRegistry vr) {
        pluginMap.set(rowIndex, vr);
    }

    /**
     * This method writes every information into a content.toc file from the VersionRegistry.
     */
    public boolean createTocFile(File tocLocation) throws IOException {
        Log.debug(logPrefix + " createTocFile(File tocLocation) - entering. ");

        tocLocation.getParentFile().mkdirs();
        Writer tocFile = createUtf8File(tocLocation);
        for (int i = 0; i < pluginMap.size(); i++) {
            if (pluginMap.get(i) != null && pluginMap.get(i).isToPackage() && !isDuplicate(i)) {
                tocFile.write(pluginMap.get(i).getTargetPath());
                tocFile.write("\t");
                tocFile.write(pluginMap.get(i).getVersionId());
                tocFile.write("\n");
            }
        }
        tocFile.close();

        Log.debug(logPrefix + " createTocFile(File tocLocation) - exiting. ");
        return true;
    }

    private Writer createUtf8File(File file) throws IOException {
        FileOutputStream fileStream = null;
        Writer writer = null;
        try {
            fileStream = new FileOutputStream(file);
            OutputStreamWriter characterStream = new OutputStreamWriter(fileStream, SharedCompilerConstants.UTF_8);
            writer = new BufferedWriter(characterStream);
        } finally {
            if (writer == null && fileStream != null) {
                fileStream.close();
            }
        }
        return writer;
    }

    /**
     * This gives back a new Warnable implementation.
     */
    public Warnable getWarnable() {
        return new WarnableImpl();
    }

    /**
     * Adding data to store for the specific CompilerType and artifact.
     */
    public void addPostProcessorData(Object artifact, Object data) {
        Log.debug(logPrefix + " addPostProcessorData(Object artifact, Object data) - entering. ");

        // get current CompilerType
        int compilerIndex = CompilerRegistry.getIndex();
        CompilerType currentComp = CompilerRegistry.COMPILERS[compilerIndex].getCompiler();

        // add it to store
        List<Object> list;
        HashMap<Object, List<Object>> hm = postProcessorData.get(currentComp);

        if (hm == null)
            hm = new HashMap<Object, List<Object>>();

        list = hm.get(artifact);

        if (list == null)
            list = new ArrayList<Object>();

        // If data is not yet contained in the list, update it
        if (!(list.contains(data))) {
            list.add(data); // update list
            hm.put(artifact, list); // update HashMap of artifacts with their lists
            postProcessorData.put(currentComp, hm); // update the HashMap of CompilerTypes with their HashMaps
        }
        Log.debug(logPrefix + " addPostProcessorData(Object artifact, Object data) - exiting. ");

    }

    /**
     * Gives back the stored data for the specific CompilerType.
     */
    public Map<Object, List<Object>> getPostProcessorData() {
        Log.debug(logPrefix + " getPostProcessorData() - entering. ");

        int compilerIndex = CompilerRegistry.getIndex();
        CompilerType currentComp = CompilerRegistry.COMPILERS[compilerIndex].getCompiler();

        Log.debug(logPrefix + " getPostProcessorData() - exiting. ");
        return postProcessorData.get(currentComp);
    }

    /**
     * Low-level method to create a (non-versioned) file in an extra archive (beside the BPEM archive).
     */
    public OutputStream createOutOfBoundsFile(String rootArchive, String filename) throws Exception {
        Log.debug(logPrefix + " createOutOfBoundsFile(String rootArchive, String filename) - entering. ");

        Log.debug(logPrefix + " rootArchive:" + rootArchive + " filename:" + filename);
        IGlobalPluginUtil gpu = (IGlobalPluginUtil) BuildSessionManager.getFromBuildSession(IGlobalPluginUtil.class.getName());
        File tmpDir = null;

        // if this archive is not yet inserted in the list, create a temporary directory for
        // storing all the files for it
        if (!archiveRegistry.containsKey(rootArchive)) {
            // Creating temporary directory
            try {
                tmpDir = gpu.createTempDir(rootArchive);
                archiveRegistry.put(rootArchive, tmpDir);
            } catch (IOException e) {
                Log.error(logPrefix + " createOutOfBoundsFile(rootArchive, filename) - ", e);
                throw new BuildException(e);
            }
        } else {
            tmpDir = archiveRegistry.get(rootArchive);
        }

        File outFile = new File(tmpDir, filename);
        outFile.getParentFile().mkdirs();
        Log.debug(logPrefix + " outOfBoundsFile: " + outFile.toString());

        Log.debug(logPrefix + " createOutOfBoundsFile(String rootArchive, String filename) - exiting. ");
        return new FileOutputStream(outFile);
    }

    /**
     * This method adds a new row into the VersionRegistry.
     * 
     * @param vr
     */
    void addVersionRegistry(final VersionRegistry vr) {
        pluginMap.add(vr);
    }

    Hashtable<String, File> getArchiveRegistry() {
        return archiveRegistry;
    }

    /**
     * 
     * @param index
     * @return
     */
    boolean isDuplicate(int index) {
        // Check if it has the same filename and versionId in the versionRegistry as an earlier entry
        // cycles only on the previous entries! (i<index)
        for (int i = 0; i < index; i++) {
            if (pluginMap.get(i).getSourcePath().equals(pluginMap.get(index).getSourcePath())
                    && pluginMap.get(i).getVersionId().equals(pluginMap.get(index).getVersionId())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 
     * @param art
     * @return
     */
    String getArtifactPath(Object art) {
        String cl = art.getClass().getSimpleName();
        if (cl.equals(BuildPluginConstants.COLLABORATION_CLASS)) {
            return CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.COLLABORATION);
        } else if (cl.equals(BuildPluginConstants.TASK_CLASS)) {
            return CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.TASK);
        } else
            return CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.OTHER_ARTIFACT);
    }

    String appNameEscaped(String appName) {
        // Replace all '/' to '~' but the first one, because that is the delimiter for vendor name
        String ret = appName.replace('/', '~');
        ret = ret.replaceFirst("~", "/");
        return ret;
    }

    public Boolean isDependencyAvailable(String dcVendor, String dcName, IBuilderHost.DEP_TYPES depType) {
        Log.debug(logPrefix + " isDependencyAvailable(String dcVendor, String dcName, IBuilderHost.DEP_TYPES depType) - entering. ");

        IComponentDependencies dependencies = pbi.getDependencies();
        IComponentDependency dep = null;

        if (dependencies != null) {
            for (int i = 0; i < dependencies.size(); i++) {
                dep = (IComponentDependency) dependencies.get(i);

                // check if the dependency is for the given dcName and dcVendor
                if (dep.getName().equals(dcName) && dep.getVendor().equals(dcVendor)) {

                    // if yes, then check if it's the given type of dependency
                    if (depType.equals(IBuilderHost.DEP_TYPES.BUILDTIME)) {
                        if (dep.isAtBuild()) {
                            return true;
                        }
                    } else if (depType.equals(IBuilderHost.DEP_TYPES.DESIGNTIME)) {
                        if (dep.isAtDesign()) {
                            return true;
                        }
                    } else if (depType.equals(IBuilderHost.DEP_TYPES.DEPLOYTIME)) {
                        if (dep.isAtDeploy()) {
                            return true;
                        }
                    } else if (depType.equals(IBuilderHost.DEP_TYPES.RUNTIME)) {
                        if (dep.isAtRuntime()) {
                            return true;
                        }
                    }
                }
            }
        }
        Log.debug(logPrefix + " isDependencyAvailable(String dcVendor, String dcName, IBuilderHost.DEP_TYPES depType) - exiting. ");
        return false;
    }

    public String getRulesBuildId() {
        return rulesBuildId;
    }

    public void setRulesBuildId(String rulesBuildId) {
        this.rulesBuildId = rulesBuildId;
    }

}
