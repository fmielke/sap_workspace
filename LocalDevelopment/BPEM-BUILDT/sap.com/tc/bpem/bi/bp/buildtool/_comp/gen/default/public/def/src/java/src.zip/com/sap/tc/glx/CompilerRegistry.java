package com.sap.tc.glx;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.tools.ant.BuildException;

import com.sap.glx.paradigmInterface.buildapi.CompilerTypes;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.paradigmInterface.util.BuildPluginConstants;
import com.sap.glx.paradigmInterface.util.BuildPluginLogConstants;
import com.sap.tc.buildplugin.log.Log;

public class CompilerRegistry {

    private static volatile int index = 0;
    private static volatile String artifactType = "";
    private static String logPrefix = BuildPluginLogConstants.CSN_COMPONENT_NAME + " " + CompilerRegistry.class.getName();

    public static final HashMap<String, String> ARTIFACT_DIRS = new HashMap<String, String>() {

        private static final long serialVersionUID = -7351045145219201803L;

        {
            put(BuildPluginConstants.TASK, BuildPluginConstants.ARTIFACT_PATH_TASK);
            put(BuildPluginConstants.COLLABORATION, BuildPluginConstants.ARTIFACT_PATH_COLLABORATION);
            put(BuildPluginConstants.PV, BuildPluginConstants.ARTIFACT_PATH_PV);
            put(BuildPluginConstants.XLIFF, BuildPluginConstants.ARTIFACT_PATH_XLIFF);
            put(BuildPluginConstants.WSDL, BuildPluginConstants.ARTIFACT_PATH_WSDL);
            put(BuildPluginConstants.TYPES, BuildPluginConstants.ARTIFACT_PATH_TYPES);
            put(BuildPluginConstants.BRMS, BuildPluginConstants.ARTIFACT_PATH_BRMS);
            put(BuildPluginConstants.BRMSTESTS, BuildPluginConstants.ARTIFACT_PATH_BRMSTESTS);
            put(BuildPluginConstants.ANALYTICS, BuildPluginConstants.ARTIFACT_PATH_ANALYTICS);
            put(BuildPluginConstants.EVENT_DEFINITION, BuildPluginConstants.ARTIFACT_PATH_EVENT_DEFINITION);
            put(BuildPluginConstants.OTHER_ARTIFACT, BuildPluginConstants.ARTIFACT_PATH_OTHER_ARTIFACT);
        }
    };

    public static final CompDirs[] COMPILERS = new CompDirs[] {
            new CompDirs(CompilerTypes.CompilerType.SOURCEVERSIONER, BuildPluginConstants.TARGET_DIR_SOURCEVERSIONER,
                    "com.sap.tc.glx.SourceVersioner", false),
            new CompDirs(CompilerTypes.CompilerType.BPMN2CSVCOMPILER, BuildPluginConstants.TARGET_DIR_BPMN2CSVCOMPILER,
                    "com.sap.glx.paradigmInterface.bpmn.compiler.BPMN2CSVCompiler", false),
            new CompDirs(CompilerTypes.CompilerType.XLFFACTORY, BuildPluginConstants.TARGET_DIR_XLFFACTORY,
                    "com.sap.glx.generator.XLFFactory", true),
            new CompDirs(CompilerTypes.CompilerType.DIAGRAMTOXMLCONVERTER, BuildPluginConstants.TARGET_DIR_DIAGRAMTOXMLCONVERTER,
                    "com.sap.glx.generator.PVCompiler", false),
            new CompDirs(CompilerTypes.CompilerType.TYPECOMPILER, BuildPluginConstants.TARGET_DIR_TYPECOMPILER,
                    "com.sap.glx.paradigmInterface.bpmn.compiler.type.TypeCompiler", false),
            new CompDirs(CompilerTypes.CompilerType.EXCEPTIONCOMPILER, BuildPluginConstants.TARGET_DIR_EXCEPTIONCOMPILER,
                    "com.sap.glx.paradigmInterface.bpmn.compiler.exception.ExceptionCompiler", false),
            new CompDirs(CompilerTypes.CompilerType.INTERFACECOMPILER, BuildPluginConstants.TARGET_DIR_INTERFACECOMPILER,
                    "com.sap.glx.paradigmInterface.bpmn.compiler.endpoint.InterfaceCompiler", false),
            new CompDirs(CompilerTypes.CompilerType.RULESCOMPILER, BuildPluginConstants.TARGET_DIR_RULESCOMPILER,
                    "com.sap.glx.paradigmInterface.brms.compiler.RulesCompiler", false),
            new CompDirs(CompilerTypes.CompilerType.REPORTINGDEFINITIONCOMPILER, BuildPluginConstants.TARGET_DIR_REPORTINGDEFINITIONCOMPILER,
                    "com.sap.glx.paradigmInterface.bpmn.compiler.reportingdefinition.ReportingDefinitionCompiler", false) };

    public static final ArrayList<String> POSTPROCESSORS = new ArrayList<String>() {

        private static final long serialVersionUID = 662108158029055701L;

        {
            add(new String("com.sap.glx.paradigmInterface.postprocessor.ws.WSProvisioningPostProcessor"));
        }
    };

    public static final ArrayList<String> SEEDPROVIDERS = new ArrayList<String>() {

        private static final long serialVersionUID = 8097444250863704129L;

        {
            add(new String("com.sap.glx.paradigmInterface.buildapi.TypeSeedProvider"));
            add(new String("com.sap.glx.paradigmInterface.buildapi.TaskSeedProvider"));
            add(new String("com.sap.glx.paradigmInterface.buildapi.CollaborationSeedProvider"));
            add(new String("com.sap.glx.paradigmInterface.brms.compiler.RulesSeedProvider"));
        }
    };

    public static void resetIndex() {
        index = 0;
    }

    public static void incrementIndex() {
        index++;
    }

    public static int getIndex() {
        return index;
    }

    public static void setIndex(int i) {
        index = i;
    }

    public static String getArtifactType() {
        return artifactType;
    }

    public static void setArtifactType(String art) {
        artifactType = art;
    }

    /**
     * 
     * @param c
     * @return
     * @throws BuildException
     */
    public static int getIndexOfCompiler(CompilerType c) throws BuildException {
        int i = 0;
        for (CompDirs compD : CompilerRegistry.COMPILERS) {
            if (compD.getCompiler() == c)
                return i;
            i++;
        }
        Log.error(" \"BPM.bp.000012\"  " + logPrefix + "  getIndexOfCompiler(c) - " + c.toString()
                + " compiler is not listed in the Registry.");
        throw new BuildException(c.toString() + " compiler is not listed in the Registry.");
    }

    /**
     * 
     * @param comp
     * @return
     * @throws BuildException
     */
    public static String getCompilerClass(CompilerType comp) throws BuildException {
        for (CompDirs compDir : COMPILERS) {
            if (compDir.getCompiler().equals(comp)) {
                return compDir.getClassString();
            }
        }
        Log.error(" \"BPM.bp.000013\"  " + logPrefix + "  getCompilerClass(comp) - " + comp.toString()
                + "  compiler is not found in Compiler Registry(Class).");
        throw new BuildException(comp + " compiler is not found in Compiler Registry");
    }

    /**
     * 
     * @param comp
     * @return
     * @throws BuildException
     */
    public static File getCompilerTargetDir(CompilerType comp) throws BuildException {
        for (CompDirs compDir : COMPILERS) {
            if (compDir.getCompiler().equals(comp)) {
                return compDir.getTargetDir();
            }
        }
        Log.error(" \"BPM.bp.000014\"  " + logPrefix + "  getCompilerTargetDir(comp) - " + comp.toString()
                + "  compiler is not found in Compiler Registry(Targetdir).");
        throw new BuildException(comp + " compiler is not found in Compiler Registry");
    }

}
