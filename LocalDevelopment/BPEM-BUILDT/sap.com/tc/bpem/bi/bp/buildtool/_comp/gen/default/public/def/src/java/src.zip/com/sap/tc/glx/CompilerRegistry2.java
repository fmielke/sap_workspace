package com.sap.tc.glx;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.tools.ant.BuildException;

import com.sap.glx.paradigmInterface.buildapi.CompilerTypes;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.paradigmInterface.util.BuildPluginConstants;

public class CompilerRegistry2{
	
	private static volatile int index = 0;
	private static volatile String artifactType = "";
	
	public static final HashMap<String, String> ARTIFACT_DIRS = new HashMap<String, String>(){
		{
			put(BuildPluginConstants.TASK,"tasks\\");
			put(BuildPluginConstants.COLLABORATION,"bpmn\\");
			put(BuildPluginConstants.PV,"pv\\");
			put(BuildPluginConstants.XLIFF,"text\\");
			put(BuildPluginConstants.WSDL,"wsdl\\");
			put(BuildPluginConstants.TYPES,"types\\");
			put(BuildPluginConstants.BRMS,"brms\\");
			put(BuildPluginConstants.BRMSTESTS,"brmstests\\");
			put(BuildPluginConstants.ANALYTICS,"analytics\\");
			put(BuildPluginConstants.OTHER_ARTIFACT,"");
		}
	};
	
	public static final CompDirs[] COMPILERS = new CompDirs[]{
		new CompDirs(CompilerTypes.CompilerType.SOURCEVERSIONER, "", "com.sap.tc.glx.SourceVersioner", false),
		new CompDirs(CompilerTypes.CompilerType.BPMN2CSVCOMPILER, "gen_bpm\\", "com.sap.glx.paradigmInterface.bpmn.compiler.BPMN2CSVCompiler", false),
		new CompDirs(CompilerTypes.CompilerType.XLFFACTORY, "gen_bpm\\text\\", "com.sap.glx.generator.XLFFactory", true),
		new CompDirs(CompilerTypes.CompilerType.DIAGRAMTOXMLCONVERTER, "gen_bpm\\pv\\", "com.sap.glx.generator.PVCompiler", false),
		new CompDirs(CompilerTypes.CompilerType.TYPECOMPILER, "gen_bpm\\types\\", "com.sap.glx.paradigmInterface.bpmn.compiler.type.TypeCompiler2", false),
		new CompDirs(CompilerTypes.CompilerType.EXCEPTIONCOMPILER, "gen_bpm\\exceptions\\", "com.sap.glx.paradigmInterface.bpmn.compiler.exception.ExceptionCompiler", false),
		new CompDirs(CompilerTypes.CompilerType.INTERFACECOMPILER, "gen_bpm\\interfaces\\", "com.sap.glx.paradigmInterface.bpmn.compiler.endpoint.InterfaceCompiler", false),
		new CompDirs(CompilerTypes.CompilerType.RULESCOMPILER, "gen_bpm\\brms", "com.sap.glx.paradigmInterface.brms.compiler.RulesCompiler", false),
		new CompDirs(CompilerTypes.CompilerType.REPORTINGDEFINITIONCOMPILER, "gen_bpm\\analytics", "com.sap.glx.paradigmInterface.bpmn.compiler.reportingdefinition.ReportingDefinitionCompiler", false)
	};
	
	public static final ArrayList<String> POSTPROCESSORS = new ArrayList<String>(){
		{
			add(new String("com.sap.glx.paradigmInterface.postprocessor.ws.WSProvisioningPostProcessor"));
		}
	};
	
	public static final ArrayList<String> SEEDPROVIDERS = new ArrayList<String>(){
		{
			add(new String("com.sap.glx.paradigmInterface.brms.compiler.RulesSeedProvider"));
			add(new String("com.sap.glx.paradigmInterface.bpmn.compiler.type.TypeSeedProvider"));
			add(new String("com.sap.glx.paradigmInterface.bpmn.compiler.ModelElementSeedProvider"));
			//add(new String("com.sap.glx.paradigmInterface.bpmn.compiler.ScopeSeedProvider"));
			//add(new String("com.sap.glx.paradigmInterface.bpmn.compiler.TaskSeedProvider"));
			//add(new String("com.sap.glx.paradigmInterface.bpmn.compiler.CollaborationSeedProvider"));
		}
	};
	
	public static void resetIndex(){
		index = 0;
	}
	
	public static void incrementIndex(){
		index++;
	}
	
	public static int getIndex(){
		return index;
	}
	
	public static void setIndex(int i){
		index = i;
	}
	
	public static String getArtifactType(){
		return artifactType;
	}
	
	public static void setArtifactType(String art){
		artifactType = art;
	}
	
	public static int getIndexOfCompiler(CompilerType c) throws BuildException{
		int i = 0;
		for(CompDirs compD: CompilerRegistry.COMPILERS){
			if (compD.getCompiler() == c) return i;
			i++;
		}
		
		throw new BuildException(c.toString() + " compiler is not listed in the Registry");
	}
	
    public static String getCompilerClass(CompilerType comp) throws BuildException{
    	for (CompDirs compDir : COMPILERS){
    		if (compDir.getCompiler().equals(comp)){
    			return compDir.getClassString();
    		}
    	}
    	throw new BuildException("Compiler is not found in Compiler Registry");
    }
    
    public static File getCompilerTargetDir(CompilerType comp) throws BuildException{
    	for (CompDirs compDir : COMPILERS){
    		if (compDir.getCompiler().equals(comp)){
    			return compDir.getTargetDir();
    		}
    	}
    	throw new BuildException("Compiler is not found in Compiler Registry");
    }
	
	
}
