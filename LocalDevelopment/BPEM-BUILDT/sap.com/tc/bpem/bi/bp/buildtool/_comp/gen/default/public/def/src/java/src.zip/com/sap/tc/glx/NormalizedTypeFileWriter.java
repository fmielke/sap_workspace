package com.sap.tc.glx;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

import com.sap.glx.paradigmInterface.buildapi.INormalizedTypeFileWriter;
import com.sap.glx.paradigmInterface.util.BuildPluginConstants;
import com.sap.glx.util.TypeIdCalculator;

public class NormalizedTypeFileWriter extends BaseVersionedStream implements INormalizedTypeFileWriter {

    private static final String SPACE_SEPARATOR = " ";
    private static final String LINE_SEPARATOR = "\n";
    private final TypeIdCalculator typeIdCalculator;

    public NormalizedTypeFileWriter(final String fileName, final File file, final Object artifact, final BuilderHostImpl builderHost)
            throws FileNotFoundException, NoSuchAlgorithmException {
        super(fileName, file, artifact, builderHost);
        typeIdCalculator = new TypeIdCalculator();
    }

    public void write(final String string) throws java.io.IOException {
        writeStringBytes(string);
    }

    public void writeln(final String string) throws java.io.IOException {
        writeStringBytes(string + LINE_SEPARATOR);
    }

    public void writelnXsd(final String rootId, final String schemaLocation, final String targetNamespace, final String xsdSchema)
            throws Exception {
        final String oneLineXsd = removeLineBreaks(xsdSchema);
        final byte[] bytes = convertToBytes(oneLineXsd + LINE_SEPARATOR);
        super.write(bytes);

        typeIdCalculator.addTypeEntry(rootId, schemaLocation, targetNamespace, xsdSchema);
    }

    private byte[] convertToBytes(final String input) throws UnsupportedEncodingException {
        return input.getBytes(BuildPluginConstants.ENCODING_UTF8);
    }

    private void writeStringBytes(final String input) throws java.io.IOException {
        final byte[] bytes = convertToBytes(input);
        super.write(bytes);
    }

    private String removeLineBreaks(final String input) {
        return input.replaceAll(LINE_SEPARATOR, SPACE_SEPARATOR);
    }

    /**
     * The close method saves the file and creates a new row into VersionRegistry.
     * 
     * @throws IOException
     */
    @Override
    public void close() throws IOException {
        if (!closeInvoked) {
            super.close();
            createFile(typeIdCalculator.calculateId());
            closeInvoked = true;
        }
    }
}
