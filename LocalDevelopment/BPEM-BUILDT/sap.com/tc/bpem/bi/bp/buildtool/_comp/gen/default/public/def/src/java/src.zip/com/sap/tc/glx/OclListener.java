package com.sap.tc.glx;

import java.util.List;

import org.apache.tools.ant.BuildException;

import com.sap.glx.paradigmInterface.util.BuildPluginLogConstants;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.moin.repository.ocl.notification.DeferredConstraintViolationListener;
import com.sap.tc.moin.repository.ocl.notification.DeferredConstraintViolationStatus;
import com.sap.tc.moin.repository.ocl.notification.DeferredConstraintViolationStatusItem;
import com.sap.tc.moin.repository.ocl.notification.EventBasedConstraintViolationStatus;
import com.sap.tc.moin.repository.ocl.notification.EventBasedConstraintViolationStatusItem;
import com.sap.tc.moin.repository.ocl.notification.ImmediateConstraintViolationListener;

public class OclListener implements DeferredConstraintViolationListener, ImmediateConstraintViolationListener {

    private static String logPrefix = BuildPluginLogConstants.CSN_COMPONENT_NAME + " " + OclListener.class.getName();

    public void notify(DeferredConstraintViolationStatus violationStatus) {
        List<DeferredConstraintViolationStatusItem> list = violationStatus.getErrors();

        if (!list.isEmpty()) {
            for (DeferredConstraintViolationStatusItem item : list) {
                Log.error(logPrefix + "  notify(DeferredConstraintViolationStatus violationStatus) - Constraint checker:"
                        + item.getConstraintViolationMessage());
            }
            Log.error(logPrefix + "  notify(DeferredConstraintViolationStatus violationStatus) -  Constraint checking failed. ");
            throw new BuildException("Constraint checking failed.");
        }

        list = violationStatus.getWarnings();

        if (!list.isEmpty()) {
            for (DeferredConstraintViolationStatusItem item : list) {
                Log.warn(logPrefix + "  notify(DeferredConstraintViolationStatus violationStatus) - Constraint checker:"
                        + item.getConstraintViolationMessage());
            }
        }
    }

    public void notify(EventBasedConstraintViolationStatus violationStatus) {
        List<EventBasedConstraintViolationStatusItem> list = violationStatus.getErrors();

        if (!list.isEmpty()) {
            for (EventBasedConstraintViolationStatusItem item : list) {
                Log.error(logPrefix + "  notify(EventBasedConstraintViolationStatus violationStatus) - Constraint checker:"
                        + item.getConstraintViolationMessage());
            }
            Log.error(logPrefix + "  notify(EventBasedConstraintViolationStatus violationStatus) -  Constraint checking failed. ");
            throw new BuildException("Constraint checking failed.");
        }

        list = violationStatus.getWarnings();

        if (!list.isEmpty()) {
            for (EventBasedConstraintViolationStatusItem item : list) {
                Log.warn(logPrefix + "  notify(EventBasedConstraintViolationStatus violationStatus) - Constraint checker:"
                        + item.getConstraintViolationMessage());
            }
        }
    }

}
