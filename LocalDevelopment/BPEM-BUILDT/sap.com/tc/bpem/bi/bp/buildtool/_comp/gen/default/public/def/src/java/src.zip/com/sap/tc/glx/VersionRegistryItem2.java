package com.sap.tc.glx;

import com.sap.glx.paradigmInterface.buildapi.CompilerTypes;
import com.sap.glx.paradigmInterface.buildapi.IArtifact;

/**
 * This class represents a row in the VersionRegistry.
 * @author I044123
 *
 */
public class VersionRegistryItem2 {
	private IArtifact<?> artifact;
	private String versionId;
	private String sourcePath;
	private String targetPath;
	private boolean toPackage;
	
	VersionRegistryItem2(IArtifact<?> pArtifact, String pVersionId, String pSourcePath, String pTargetPath, boolean pToPackage){
		artifact = pArtifact;
		versionId = pVersionId;
		sourcePath = pSourcePath;
		targetPath = pTargetPath;
		toPackage = pToPackage;
	}

	public IArtifact<?> getArtifact() {
		return artifact;
	}

	public String getVersionId() {
		return versionId;
	}

	public String getSourcePath() {
		return sourcePath;
	}

	public String getTargetPath() {
		return targetPath;
	}

	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}

	public void setSourcePath(String sourcePath) {
		this.sourcePath = sourcePath;
	}

	public void setTargetPath(String targetPath) {
		this.targetPath = targetPath;
	}

	public boolean isToPackage() {
		return toPackage;
	}

	public void setToPackage(boolean toPackage) {
		this.toPackage = toPackage;
	}
	
}
