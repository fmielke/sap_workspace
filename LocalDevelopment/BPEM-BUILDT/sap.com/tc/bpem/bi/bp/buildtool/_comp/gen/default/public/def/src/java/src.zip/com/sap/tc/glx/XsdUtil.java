package com.sap.tc.glx;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.namespace.QName;

import com.sap.tc.esmp.mm.xsd1.XsdAttributeDeclaration;
import com.sap.tc.esmp.mm.xsd1.XsdAttributeGroupContent;
import com.sap.tc.esmp.mm.xsd1.XsdAttributeGroupDefinition;
import com.sap.tc.esmp.mm.xsd1.XsdAttributeUse;
import com.sap.tc.esmp.mm.xsd1.XsdComplexTypeContent;
import com.sap.tc.esmp.mm.xsd1.XsdComplexTypeDefinition;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import com.sap.tc.esmp.mm.xsd1.XsdFeature;
import com.sap.tc.esmp.mm.xsd1.XsdModelGroup;
import com.sap.tc.esmp.mm.xsd1.XsdModelGroupDefinition;
import com.sap.tc.esmp.mm.xsd1.XsdParticle;
import com.sap.tc.esmp.mm.xsd1.XsdParticleContent;
import com.sap.tc.esmp.mm.xsd1.XsdTypeDefinition;

public class XsdUtil {
	
	public static final String COMPLEX_TYPES_KEY = "ComplexTypes";
	public static final String COMPLEX_SUB_TYPES_KEY = "ComplexSubTypes";
	
	
	public static Map<String,Collection<XsdComplexTypeDefinition>> collectTypesAndSubTypes(Collection<XsdElementDeclaration> elements){
	    	
	    	Map<String, Collection<XsdComplexTypeDefinition>> map = new HashMap<String, Collection<XsdComplexTypeDefinition>>();
	    	
	    	Collection<XsdComplexTypeDefinition> complexTypes = new ArrayList<XsdComplexTypeDefinition>();
	    	Collection<QName> processedComplexTypes = new ArrayList<QName>();
	    	// Getting all complex types
	    	for(XsdElementDeclaration element : elements){
	    		XsdTypeDefinition typeDef = element.getTypeDefinition();
	    		if(typeDef instanceof XsdComplexTypeDefinition){
	    			XsdComplexTypeDefinition complexTypeDef = (XsdComplexTypeDefinition)typeDef;
	    			String complexTypeName = complexTypeDef.getName();
	    			String complexTypeNS = complexTypeDef.getNamespace();
	    			
	    			// skip XML Schema types
	    			if(complexTypeNS != null && complexTypeNS.equals(XMLConstants.W3C_XML_SCHEMA_NS_URI)){
	    				continue;
	    			}
	    			
	    			// complex type name can be null when an element is declared like below,
	    			//   <xsd:element name="..."><xsd:complexType>....</xsd:complexType><xsd:element>
	    			if(complexTypeName != null){
		    			QName complexTypeQName = new QName(complexTypeNS, complexTypeName);
		    			// check if already processed
		    			if(!processedComplexTypes.contains(complexTypeQName)){
		    				complexTypes.add(complexTypeDef);
		    				processedComplexTypes.add(complexTypeQName);
							// process the content
		    				addComplexTypes(complexTypeDef, complexTypes, processedComplexTypes);
		    			}
	    			}else{
						complexTypes.add((XsdComplexTypeDefinition)typeDef);
						// process the content 
						addComplexTypes((XsdComplexTypeDefinition)typeDef, complexTypes, processedComplexTypes);
					}
	    		}
	    	}
	    	map.put(COMPLEX_TYPES_KEY,complexTypes);
	    	
	    	// getting all sub-types
	    	Collection<XsdComplexTypeDefinition> complexSubTypes = new ArrayList<XsdComplexTypeDefinition>();
	    	for(XsdComplexTypeDefinition complexTypeDef : complexTypes){
	    		Collection<XsdComplexTypeDefinition> subTypes = new ArrayList<XsdComplexTypeDefinition>();
	    		addSubTypes(complexTypeDef, subTypes, processedComplexTypes);
	    		complexSubTypes.addAll(subTypes);
	    	}
	    	map.put(COMPLEX_SUB_TYPES_KEY, complexSubTypes);
	    	
	    	return map;
	    }
	    
	private static void addComplexTypes(XsdComplexTypeDefinition complexTypeDef, Collection<XsdComplexTypeDefinition> complexTypes, Collection<QName> processed){
		XsdFeature[] content = getContent(complexTypeDef);
		for(XsdFeature feature : content){
			if(feature instanceof XsdElementDeclaration){
				XsdElementDeclaration xsdElemDecl = (XsdElementDeclaration)feature;
				XsdTypeDefinition typeDef = xsdElemDecl.getTypeDefinition();
				if(typeDef instanceof XsdComplexTypeDefinition){
					// Add only top level complex types
		    		if(typeDef.getContainer()!=null){
		    			continue;
		    		}
					String name = typeDef.getName();
					String nameSpace = typeDef.getNamespace();
					
	    			// skip XML Schema types
	    			if(nameSpace != null && nameSpace.equals(XMLConstants.W3C_XML_SCHEMA_NS_URI)){
	    				continue;
	    			}
					
	    			// complex type name can be null when an element is declared like below,
	    			//   <xsd:element name="..."><xsd:complexType>....</xsd:complexType><xsd:element>
					if(name != null){
						QName qName = new QName(nameSpace,name);
		    			// check if already processed
						if(!processed.contains(qName)){
							processed.add(qName);
							complexTypes.add((XsdComplexTypeDefinition)typeDef);
							// process the content
							addComplexTypes((XsdComplexTypeDefinition)typeDef, complexTypes, processed);
						}
					}else{
						complexTypes.add((XsdComplexTypeDefinition)typeDef);
						// process the content 
						addComplexTypes((XsdComplexTypeDefinition)typeDef, complexTypes, processed);
					}
				}
			}
		}
	}
	
	private  static void addSubTypes(XsdComplexTypeDefinition complexTypeDef, Collection<XsdComplexTypeDefinition> complexTypes, Collection<QName> processed){
		Collection<XsdComplexTypeDefinition> subTypes = complexTypeDef.getComplexTypeDefinitions();
		if(subTypes!=null && subTypes.size()>0){
    		for(XsdComplexTypeDefinition subType : subTypes){
    			// Add only top level complex types
	    		if(subType.getContainer()!=null){
	    			continue;
	    		}
				String name = subType.getName();
				String nameSpace = subType.getNamespace();
				
				// skip XML Schema types
    			if(nameSpace != null && nameSpace.equals(XMLConstants.W3C_XML_SCHEMA_NS_URI)){
    				continue;
    			}
				
				// complex type name can be null when an element is declared like below,
				//   <xsd:element name="..."><xsd:complexType>....</xsd:complexType><xsd:element>
				if(name != null){
					QName qName = new QName(nameSpace,name);
					if(!processed.contains(qName)){
						processed.add(qName);
						complexTypes.add((XsdComplexTypeDefinition)subType);
						addSubTypes((XsdComplexTypeDefinition)subType, complexTypes, processed);
					}
				}else{
					// As there is no name, there can be no further sub-types
					complexTypes.add((XsdComplexTypeDefinition)subType);
				}
    		}
		}
	}
	
	/**
     * Gets ComplexType content( attributes and elements )
     * @param complexTypeDefinition
     * @return
     */
    private static XsdFeature[] getContent( XsdComplexTypeDefinition complexTypeDefinition) {
    	List<XsdFeature> featuresList = new ArrayList<XsdFeature>();    	
    	XsdTypeDefinition baseTypeDefinition = complexTypeDefinition.getBaseType();
    	if(baseTypeDefinition!=null && baseTypeDefinition instanceof XsdComplexTypeDefinition){
    		XsdFeature[] parentFeatures = getContent((XsdComplexTypeDefinition) baseTypeDefinition);
    		if(parentFeatures!=null && parentFeatures.length>0){
    			featuresList.addAll( Arrays.asList(parentFeatures) );
    		}
    	}

    	//attributes
    	Collection<XsdAttributeGroupContent> attrContent = complexTypeDefinition.getAttributeContents();
        if (attrContent!=null && !attrContent.isEmpty()) {
            for (Iterator<XsdAttributeGroupContent> iterator = attrContent.iterator(); iterator.hasNext();) {
            	featuresList.addAll(getAttributeGroupContent(iterator.next()));
            }
        }
        
        //elements
        List<XsdParticle> contents = getContentAsList(complexTypeDefinition);
        if(contents!=null){
        	for (XsdParticle content : contents) {
        		XsdParticleContent pc = content.getContent();
        		if(pc instanceof XsdFeature){
        			featuresList.add( (XsdFeature) content.getContent() );
        		}else if (pc instanceof XsdModelGroup){
        			XsdModelGroup modelgroup = (XsdModelGroup)pc;
        		    List<XsdParticle> groupParticles = modelgroup.getContents();
        		    for(XsdParticle groupParticle: groupParticles){
        		    	if(groupParticle.getContent() instanceof XsdFeature){
        		    		featuresList.add((XsdFeature)groupParticle.getContent());
        		    	}
        		    }        			
        		}else if(pc instanceof XsdModelGroupDefinition){
        			XsdModelGroupDefinition def = (XsdModelGroupDefinition)pc;
        			def = def.resolve();        		  
        			if(def.getModelGroup()!= null){
        				List<XsdParticle> groupParticles = def.getModelGroup().getContents();;
        				for(XsdParticle groupParticle: groupParticles){
        					if(groupParticle.getContent() instanceof XsdFeature){
        						featuresList.add((XsdFeature)groupParticle.getContent());
        					}
        				}        		
        			}
        		}
			}
        }
        return featuresList.toArray( new XsdFeature[0]);    
     }
    
    /**
     * Method to get a list with all complex type fields.
     * The method return reference to original List associated with the MOIN object 
     * so modifying the list affects the typeDefinition( add, remove content ) 
     * @param complexTypeDefinition
     * @return
     */
    private static List<XsdParticle> getContentAsList(XsdComplexTypeDefinition complexTypeDefinition) {

    	XsdComplexTypeContent ctContent = complexTypeDefinition.getContent();
        
        if (!(ctContent instanceof XsdParticle)) {
            return null;
        }
        XsdParticle xsdParticle = (XsdParticle) ctContent;
        if (xsdParticle == null) {
            return null;
        }

        // 4. Model group
        //Changed Code from what is there in XsdUtil of MOIN
        XsdParticleContent particleContent = xsdParticle.getContent();
        List<XsdParticle> contents = null;
        XsdModelGroup anonymousModelGroup = null;
        
        if(particleContent instanceof XsdModelGroup){
        	anonymousModelGroup = (XsdModelGroup) xsdParticle.getContent();        	
        }else if(particleContent instanceof XsdModelGroupDefinition){
        	XsdModelGroupDefinition anonymousModelGroupDef = (XsdModelGroupDefinition) xsdParticle.getContent();
        	if (anonymousModelGroupDef == null) {
        		return null;
        	}
        	anonymousModelGroup =  anonymousModelGroupDef.getModelGroup();
        	if(anonymousModelGroup == null){
        		XsdModelGroupDefinition def = anonymousModelGroupDef.resolve();
        		anonymousModelGroup = def.getModelGroup();
        	}
        }        
        if (anonymousModelGroup == null) {
    		return null;
    	}
    	contents = anonymousModelGroup.getContents();        
        return contents;
    }
    
    private static List<XsdFeature> getAttributeGroupContent(XsdAttributeGroupContent groupContent){
    	List<XsdFeature> featuresList = new ArrayList<XsdFeature>();
    	XsdAttributeGroupContent obj = (XsdAttributeGroupContent) groupContent;
        if (obj instanceof XsdAttributeUse) {
            XsdAttributeUse xsdAttributeUse = (XsdAttributeUse) obj;
            XsdAttributeDeclaration attrDeclaration = xsdAttributeUse.getContent();
            
            XsdTypeDefinition attrTD = attrDeclaration.getTypeDefinition();
            if(attrTD==null){
            	attrTD = attrDeclaration.getAnonymousTypeDefinition();
            }
            featuresList.add( attrDeclaration );
        }else if(obj instanceof XsdAttributeGroupDefinition){
        	XsdAttributeGroupDefinition groupDef = (XsdAttributeGroupDefinition)obj;
        	Collection<XsdAttributeGroupContent> attrContent = groupDef.getContents();        	
            if (attrContent!=null && !attrContent.isEmpty()) {
                for (Iterator<XsdAttributeGroupContent> iterator = attrContent.iterator(); iterator.hasNext();) {
                	featuresList.addAll(getAttributeGroupContent(iterator.next()));
                }
            }
            XsdAttributeGroupDefinition groupDefRef = groupDef.getReferencedAttributeGroupDefinition();
            attrContent = groupDefRef.getContents();        	
            if (attrContent!=null && !attrContent.isEmpty()) {
                for (Iterator<XsdAttributeGroupContent> iterator = attrContent.iterator(); iterator.hasNext();) {
                	featuresList.addAll(getAttributeGroupContent(iterator.next()));
                }
            }        	
        }       
        return featuresList;
    }
	
}
