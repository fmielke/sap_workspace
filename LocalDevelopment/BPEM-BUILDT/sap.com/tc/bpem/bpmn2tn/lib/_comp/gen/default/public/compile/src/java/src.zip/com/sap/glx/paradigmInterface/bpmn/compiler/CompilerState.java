package com.sap.glx.paradigmInterface.bpmn.compiler;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.sap.glx.ide.model.classes.Attribute;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.workflow.CatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.DataObject;
import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.ide.model.galaxy.workflow.ProcessRole;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.ScopeObject;
import com.sap.glx.ide.model.galaxy.workflow.ScopeReference;
import com.sap.glx.ide.model.galaxy.workflow.SequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.StartEvent;
import com.sap.glx.ide.model.galaxy.workflow.View;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.LocalSource;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.RemoteSource;
import com.sap.glx.ide.model.triggernet.Switch;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SunbeamHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WorkflowHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.DonFrame;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.FrameNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;
import com.sap.glx.paradigmInterface.bpmn.compiler.stage.CollectArtifactsStage.CollectArtifactsResult;
import com.sap.glx.paradigmInterface.bpmn.compiler.stage.LabelEdgesStage.LabelEdgesResult;
import com.sap.mapping.base.compiler.IMappingCompiler.Summary;

/**
 * Represents the compiler's current state.
 * 
 * @author Thilo-Alexander Ginkel
 * @author Philipp Sommer
 * 
 * @version $Id:
 *          //bpem/bpem.bp/NW720_SP_COR/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2tn/lib/_comp/src/com/sap/glx/paradigmInterface
 *          /bpmn/compiler/CompilerState.java#1 $
 */
public class CompilerState {

    /**
     * The compiler context this state is associated with.
     */
    private final CompilerContext ctx;

    // Holds the result of the corresponding stage
    private CollectArtifactsResult collectArtifactsResult;
    private LabelEdgesResult labelEdgesResult;

    // frame
    private DonFrame donFrame;

    // data objects
    private final Map<FrameNode, Set<DataContainer>> frame2data = new HashMap<FrameNode, Set<DataContainer>>();
    // needed in case there are only views in the process -> DataObject.postprocess will not be called
    private boolean contextCascadeCreated = false;

    /**
     * Holds a reference to the global context join network.
     */
    private Node globalContextJoinNetwork = null;

    /**
     * Holds an index for the global context.
     */
    private final Map<DataContainer, Integer> globalContextIndex = new HashMap<DataContainer, Integer>();

    /**
     * Holds a pre-calculated script variable name for each object in the global context.
     */
    private final Map<DataContainer, ScriptVariable> globalContextVariables = new HashMap<DataContainer, ScriptVariable>();
    private final Map<DataContainer, String> globalContextVarNames = new HashMap<DataContainer, String>();

    /**
     * Maps a intermediate events of the inner task flow with a message trigger to the respective event, subscription classes.
     */
    public Map<MessageFlowObject, Pair<GalaxyClass, GalaxyClass>> control2subscription_event = new HashMap<MessageFlowObject, Pair<GalaxyClass, GalaxyClass>>();

    /**
     * Maps subscription attributes to their compiled expression
     */
    private final Map<Attribute, String> correlationExtraction = new HashMap<Attribute, String>();
    private final Map<Attribute, LinkedHashSet<DataContainer>> correlationContext = new HashMap<Attribute, LinkedHashSet<DataContainer>>();

    /**
     * Standard source nodes
     */
    private LocalSource tokenSource, instanceSource, taskSource, listenerSource;
    private RemoteSource responseSource, ucRequestSource, bpmnRequestSource;

    private final Pair<String, String> clsExit = new Pair<String, String>(CompilerConstants.ADAPTER_BPMN, CompilerConstants.GALAXY_EXIT);
    private final Pair<String, String> clsController = new Pair<String, String>(CompilerConstants.ADAPTER_EXCEPTION,
            CompilerConstants.GALAXY_CONTROLLER);

    private Join tokenInstanceJoin;
    private Switch tokenSwitch;
    private Switch tokenSwitchWithoutSuspend;
    private Join instanceTaskJoin;

    private GalaxyClass clsInstance;
    private GalaxyClass clsToken;
    private GalaxyClass clsBridge;
    private GalaxyClass clsFlightRecorder;
    private GalaxyClass clsGroupLocalityHandler;
    private GalaxyClass clsReferenceProxy;
    private GalaxyClass clsEventLogger;
    private GalaxyClass resendRequestGalaxyClass;

    /**
     * Holds the information of event and subscriptions, used for the compilation of start and intermediate events
     */
    private final Map<String, GalaxyClass> clsEvents = new HashMap<String, GalaxyClass>();

    private final Map<CatchEvent, GalaxyClass> eventMap = new HashMap<CatchEvent, GalaxyClass>();

    private final Map<String, GalaxyClass> clsSubscriptions = new HashMap<String, GalaxyClass>();
    
    private GenericOperator sharedPersistentJoin = null;

    /**
     * Holds information of message trigger & related intermediate message events used when compiled for Sunbeam
     */
    private final SunbeamHelper sunbeamHelper = new SunbeamHelper();
    /**
     * Holds the information about view mappings and dependencies, which is needed for the optimized view update
     */
    private final Map<View, Pair<Summary, String>> viewMappingMap = new HashMap<View, Pair<Summary, String>>();
    private final Map<DataContainer, SortedSet<View>> viewDependencyMap = new HashMap<DataContainer, SortedSet<View>>();
    private final Map<View, SortedSet<DataContainer>> reverseViewDependencyMap = new HashMap<View, SortedSet<DataContainer>>();
    public DataContainerComparator dataContainerComparator = new DataContainerComparator();

    public CompilerState(final CompilerContext compilerContext) throws BPMNCompilerException {
        this.ctx = compilerContext;
        this.dataContainerComparator = new DataContainerComparator();
    }

    protected void initialize() throws BPMNCompilerException {
        clsInstance = ctx.getReplicator().generateInstanceClass();
        instanceSource = ctx.getSourceFactory().getSource4Class(clsInstance);
        ctx.getConfigFactory().generateWorkflowConfiguration(clsInstance, ctx.getRootScope());

        clsToken = ctx.getReplicator().generateTokenClass(clsInstance);
        tokenSource = ctx.getSourceFactory().getSource4Class(clsToken);

        // delete tokens if instance has gone and vice versa
        tokenInstanceJoin = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "token_instance", "0/0/0", "1/0/-1");
        NodeFactory.connectNodes(tokenSource, 0, tokenInstanceJoin, 0);
        NodeFactory.connectNodes(instanceSource, 0, tokenInstanceJoin, 1);
        NodeFactory.connectNodes(tokenInstanceJoin, 1, ctx.getReplicator().getBlackHole(), 0);
        NodeFactory.connectNodes(tokenInstanceJoin, 2, ctx.getReplicator().getBlackHole(), 0);

        clsFlightRecorder = ctx.getReplicator().generateFlightRecorder(clsInstance);
        
        clsEventLogger = ctx.getReplicator().generateEventLoggerClass();
    }


    public Node getGlobalContextJoinNetwork() {
        return globalContextJoinNetwork;
    }

    public void setGlobalContextJoinNetwork(final Node node) {
        this.globalContextJoinNetwork = node;
    }

    public int getContextElementIndex(final DataContainer obj) {
        return globalContextIndex.get(obj);
    }

    public String getContextVariableName(final DataContainer obj) {
        final String result = globalContextVarNames.get(obj);
        if (result == null) {
            throw new IllegalStateException("No variable name known for DataObject " + obj); //$NON-NLS-1$
        }
        return result;
    }

    public ScriptVariable getContextVariable(final DataContainer obj) {
        final ScriptVariable result = globalContextVariables.get(obj);
        if (result == null) {
            throw new IllegalStateException("No variable name known for DataObject " + obj); //$NON-NLS-1$
        }
        return result;
    }

    public String assignContextVariableName(final DataContainer container) {
        int runningIndex = globalContextVarNames.size();
        runningIndex++;
        final String name = WorkflowHelper.isTaskStatusDataObject(ctx, container) ? "task" : (container instanceof DataObject ? "context"
                : container instanceof ProcessRole ? "role" : "view")
                + "_" + runningIndex;
        globalContextVarNames.put(container, name);
        globalContextVariables.put(container, new ScriptVariable(name));
        return name;
    }
    

    public Join getTokenInstanceJoin() {
        return tokenInstanceJoin;
    }

    public Switch getTokenSwitch() {
        return tokenSwitch;
    }

    public Switch getTokenSwitchWithoutSuspend() {
        return tokenSwitchWithoutSuspend;
    }

    public void setLabelEdgesResult(final LabelEdgesResult result) {
        this.labelEdgesResult = result;
    }

    public int getNumberOfTokenLabels() {
        return labelEdgesResult.getNumberOfTokenLabels();
    }

    public int getTokenLabel(final SequenceConnector connector) throws BPMNCompilerException {
        return labelEdgesResult.getTokenLabel(connector);
    }

    public int getTokenSwitchExit(final SequenceConnector connector) throws BPMNCompilerException {
        ctx.getValidator().validate(true, "BPM.rt_c_bpmn.000070", //$NON-NLS-1$
                "Token switch has no output channel for sequence connector '%s'.", connector.getOriginalName()); //$NON-NLS-1$
        return labelEdgesResult.getTokenLabel(connector);
    }

    public int getTokenLabel(final ScopeReference reference) throws BPMNCompilerException {
        return labelEdgesResult.getTokenLabel(reference);
    }

    public int getTokenSwitchExit(final ScopeReference reference) throws BPMNCompilerException {
        ctx.getValidator().validate(true, "BPM.rt_c_bpmn.000072", //$NON-NLS-1$
                "Token switch has no output channel for scope reference '%s'.", reference.getOriginalName()); //$NON-NLS-1$
        return labelEdgesResult.getTokenLabel(reference);
    }

    public int getTokenLabel(final EndEvent endEvent) throws BPMNCompilerException {
        return labelEdgesResult.getTokenLabel(endEvent);
    }

    public int getTokenSwitchExit(final EndEvent endEvent) throws BPMNCompilerException {
        ctx.getValidator().validate(true, "BPM.rt_c_bpmn.000082", //$NON-NLS-1$
                "Token switch has no output channel for event '%s'.", endEvent.getOriginalName()); //$NON-NLS-1$
        return labelEdgesResult.getTokenLabel(endEvent);
    }

    public Integer getTokenLabelFrameEnd(final Scope scope) throws BPMNCompilerException {
        return labelEdgesResult.getTokenLabelFrameEnd(scope);
    }

    public Integer getTokenLabelLoopCycleWaiting(final Scope scope) throws BPMNCompilerException {
        return labelEdgesResult.getTokenLabelLoopCycleWaiting(scope);
    }

    public Integer getTokenSwitchExitLabelFrameEnd(final Scope scope) throws BPMNCompilerException {
        return labelEdgesResult.getTokenLabelFrameEnd(scope);
    }

    public Integer getTokenSwitchExitLabelLoopCycleWaiting(final Scope scope) throws BPMNCompilerException {
        return labelEdgesResult.getTokenLabelLoopCycleWaiting(scope);
    }

    public int getBeforeTokenLabel(final ScopeObject scopeObject) throws BPMNCompilerException {
        return getBeforeTokenSwitchExit(scopeObject);
    }

    /**
     * Returns the index of the token switch exit of the incoming sequence connector from a scope object.
     * 
     * @param object
     *            the scope object with only one incoming sequence connector.
     * @return exit of the token switch for the incoming sequence connector.
     * @throws BPMNCompilerException
     */
    public int getBeforeTokenSwitchExit(final ScopeObject scopeObject) throws BPMNCompilerException {
        ctx.getValidator().validate(scopeObject.getIncomingConnectors() != null && scopeObject.getIncomingConnectors().size() == 1,
                "BPM.rt_c_bpmn.000073", //$NON-NLS-1$
                "Scope object '%s' is expected to have exactly one incoming sequence connector.", scopeObject.getOriginalName()); //$NON-NLS-1$
        final SequenceConnector incoming = scopeObject.getIncomingConnectors().iterator().next();
        return getTokenSwitchExit(incoming);
    }

    public int getAfterTokenLabel(final ScopeObject scopeObject) throws BPMNCompilerException {
        return getAfterTokenSwitchExit(scopeObject);
    }

    /**
     * Returns the index of the token switch exit of the outgoing sequence connector from a scope object.
     * 
     * @param object
     *            the scope object with only one outgoing sequence connector.
     * @return exit of the token switch for the outgoing sequence connector.
     * @throws BPMNCompilerException
     */
    public int getAfterTokenSwitchExit(final ScopeObject scopeObject) throws BPMNCompilerException {
        ctx.getValidator().validate(scopeObject.getOutgoingConnectors() != null && scopeObject.getOutgoingConnectors().size() == 1,
                "BPM.rt_c_bpmn.000074", //$NON-NLS-1$
                "Scope object '%s' is expected to have exactly one outgoing sequence connector."); //$NON-NLS-1$
        final SequenceConnector outgoing = scopeObject.getOutgoingConnectors().get(0);
        return (getTokenSwitchExit(outgoing));
    }

    public void setCollectArtifactsResult(final CollectArtifactsResult result) {
        this.collectArtifactsResult = result;
    }

    public StartEvent getStartEvent() {
        return collectArtifactsResult.getStartEvent();
    }

    public boolean isSharedStart() {
        return collectArtifactsResult.isSharedStart();
    }

    public boolean isSynchronouslyProvisioned() {
        return collectArtifactsResult.isSynchronouslyProvisioned();
    }

    public boolean isSynchronousEndEvent(final EndEvent endEvent) {
        return collectArtifactsResult.isSynchronousEndEvent(endEvent);
    }

    public Collection<String> getServices() {
        return clsEvents.keySet();
    }

    public GalaxyClass getEvent(final String service) {
        return clsEvents.get(service);
    }

    public GalaxyClass getEvent(final CatchEvent catchEvent) {
        return eventMap.get(catchEvent);
    }

    public void addEvent(final CatchEvent catchEvent, GalaxyClass eventGalaxyClass) {
        eventMap.put(catchEvent, eventGalaxyClass);
    }

    public GalaxyClass getSubscription(final String service) {
        return clsSubscriptions.get(service);
    }

    public void addEventSubscription(final String service, final GalaxyClass clsEvent, final GalaxyClass clsSubscription) {
        if (clsEvents.put(service, clsEvent) != null) {
            throw new IllegalStateException("Multiple event classes for the the same endpoint."); //$NON-NLS-1$
        }
        clsSubscriptions.put(service, clsSubscription);
    }

    public void setSharedPersistentJoin(final GenericOperator sharedPersistentJoin) {
        this.sharedPersistentJoin = sharedPersistentJoin;
    }

    public GenericOperator getSharedPersistentJoin() {
        return sharedPersistentJoin;
    }

    public void addCorrelationAttribute(final Attribute attribute, final String extractionId, final LinkedHashSet<DataContainer> context) {
        correlationExtraction.put(attribute, extractionId);
        correlationContext.put(attribute, context);
    }

    public String getCorrelationExtraction(final Attribute attribute) {
        return correlationExtraction.get(attribute);
    }

    public LinkedHashSet<DataContainer> getCorrelationContext(final Attribute attribute) {
        return correlationContext.get(attribute);
    }

    public synchronized RemoteSource getResponseSource() {
        if (responseSource == null) {
            responseSource = ctx.getSourceFactory().generateSource(CompilerConstants.ADAPTER_BPMN, CompilerConstants.GALAXY_RESPONSE);
        }

        return responseSource;
    }

    public LocalSource getListenerSource() throws BPMNCompilerException {
        if (listenerSource == null) {
            final GalaxyClass listener_class = ctx.getReplicator().generateListenerClass(ctx.getRootScope());
            listenerSource = ctx.getSourceFactory().getSource4Class(listener_class);
        }
        return listenerSource;
    }

    public void setTokenSwitch(final Switch tokenSwitch) {
        this.tokenSwitch = tokenSwitch;
    }

    public void setTokenSwitchWithoutSuspend(final Switch tokenSwitchWithoutSuspend) {
        this.tokenSwitchWithoutSuspend = tokenSwitchWithoutSuspend;
    }

    public RemoteSource getUCRequest() {
        return ucRequestSource;
    }
    

    public GalaxyClass getResendRequest() {
        return resendRequestGalaxyClass;
    }
    
    public void setResendRequest(final GalaxyClass request) {
        this.resendRequestGalaxyClass = request;
    }

    public RemoteSource getBPMNRequest() {
        return bpmnRequestSource;
    }

    public void setUCRequest(final RemoteSource request) {
        this.ucRequestSource = request;
    }

    public void setBPMNRequest(final RemoteSource request) {
        this.bpmnRequestSource = request;
    }

    public LocalSource getTokenSource() {
        return tokenSource;
    }

    public LocalSource getInstanceSource() {
        return instanceSource;
    }

    public Pair<String, String> getExitClass() {
        return clsExit;
    }

    public Pair<String, String> getControllerClass() {
        return clsController;
    }

    public GalaxyClass getInstanceClass() {
        return clsInstance;
    }

    public GalaxyClass getTokenClass() {
        return clsToken;
    }
    
    public GalaxyClass getEventLoggerClass() {
        return clsEventLogger;
    }

    public void setBridgeClass(final GalaxyClass clsBridge) {
        this.clsBridge = clsBridge;
    }

    public GalaxyClass getBridgeClass() {
        return clsBridge;
    }

    public void setTaskSource(final LocalSource task_source) {
        this.taskSource = task_source;
    }

    public LocalSource getTaskSource() {
        return taskSource;
    }

    public GalaxyClass getFlightRecorderClass() {
        return clsFlightRecorder;
    }

    public void setInstanceTaskJoin(final Join join) {
        instanceTaskJoin = join;
    }

    public Join getInstanceTaskJoin() {
        return instanceTaskJoin;
    }

    public void setDonFrame(final DonFrame derDon) {
        this.donFrame = derDon;
    }

    public DonFrame getDonFrame() {
        return donFrame;
    }

    public void addDataContainer4Frame(final FrameNode frame, final DataContainer dataContainer) {
        Set<DataContainer> doSet = frame2data.get(frame);
        if (doSet == null) {
            doSet = new HashSet<DataContainer>();
            frame2data.put(frame, doSet);
        }
        doSet.add(dataContainer);
    }

    public Set<DataContainer> getDataContainer4Frame(final FrameNode frame) {
        final Set<DataContainer> result = frame2data.get(frame);
        return (result == null) ? new HashSet<DataContainer>() : result;
    }

    public boolean isContextCascadeCreated() {
        return contextCascadeCreated;
    }

    public void contextCascadeIsCreated() {
        contextCascadeCreated = true;
    }

    public void addViewMapping(final View view, final Pair<Summary, String> viewMapping) {
        viewMappingMap.put(view, viewMapping);
    }

    public Pair<Summary, String> getViewMapping(final View view) {
        return viewMappingMap.get(view);
    }

    public void addDependingView(final DataContainer dataContainer, final View view) {
        SortedSet<View> viewDependencySet = viewDependencyMap.get(dataContainer);

        if (viewDependencySet == null) {
            viewDependencySet = new TreeSet<View>(dataContainerComparator);
        }

        viewDependencySet.add(view);
        viewDependencyMap.put(dataContainer, viewDependencySet);
    }

    public SortedSet<View> getDependingViews(final DataContainer dataContainer) {
        return viewDependencyMap.get(dataContainer);
    }

    public void addReverseViewDependencies(final View view, final SortedSet<DataContainer> dataContainers) {
        final SortedSet<DataContainer> reverseViewDependencySet = reverseViewDependencyMap.get(view);

        // only add reverse view dependencies, if they are not already calculated for this view
        if (reverseViewDependencySet == null) {
            reverseViewDependencyMap.put(view, dataContainers);
        }
    }

    public SortedSet<DataContainer> getReverseViewDependencies(final View view) {
        return reverseViewDependencyMap.get(view);
    }

    public SortedSet<DataContainer> getAllViewDependencies(final Set<DataContainer> used_output_context) {
        final SortedSet<DataContainer> allDependencies = new TreeSet<DataContainer>(dataContainerComparator);
        for (final DataContainer dataContainer : used_output_context) {
            final SortedSet<View> dependingViews = getDependingViews(dataContainer);
            if (dependingViews != null) {
                allDependencies.addAll(dependingViews);

                // add also all other source data containers of depending views
                for (final View view : dependingViews) {
                    final SortedSet<DataContainer> reverseViewDependencies = getReverseViewDependencies(view);
                    if (reverseViewDependencies != null) {
                        allDependencies.addAll(reverseViewDependencies);
                    }

                    // traverse also views depending on this view
                    final SortedSet<DataContainer> viewSet = new TreeSet<DataContainer>(dataContainerComparator);
                    viewSet.add(view);
                    final SortedSet<DataContainer> traverseDependencies = getAllViewDependencies(viewSet);
                    if (traverseDependencies != null) {
                        allDependencies.addAll(traverseDependencies);
                    }
                }
            }
        }
        return allDependencies;
    }

    public void setGroupLocalityHandler(final GalaxyClass clsGroupLocalityHandler) {
        this.clsGroupLocalityHandler = clsGroupLocalityHandler;
    }

    public GalaxyClass getGroupLocalityHandler() {
        return clsGroupLocalityHandler;
    }

    public SunbeamHelper getSunbeamHelper() {
        return sunbeamHelper;
    }

    public GalaxyClass getReferenceProxyClass() {
        return clsReferenceProxy;
    }

    public void setReferenceProxyClass(GalaxyClass clsReferenceProxy) {
        this.clsReferenceProxy = clsReferenceProxy;
    }

    private class DataContainerComparator implements Comparator<DataContainer> {
        @Override
        public int compare(final DataContainer o1, final DataContainer o2) {
            final String mofId1 = o1.get___Mri().getMofId();
            final String mofId2 = o2.get___Mri().getMofId();
            return Integer.signum(mofId1.compareToIgnoreCase(mofId2));
        }
    }
}
