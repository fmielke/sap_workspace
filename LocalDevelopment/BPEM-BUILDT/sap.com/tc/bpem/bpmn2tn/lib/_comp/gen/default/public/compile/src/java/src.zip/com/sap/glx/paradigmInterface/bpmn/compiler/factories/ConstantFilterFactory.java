package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.configuration.AttributeSpecification;
import com.sap.glx.ide.model.configuration.ConstantPredicate;
import com.sap.glx.ide.model.configuration.ConstantTerm;
import com.sap.glx.ide.model.configuration.TypedConstant;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.AbstractVersioningCallback;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;

public class ConstantFilterFactory extends NodeFactory {

    private final CompilerContext ctx;

    public ConstantFilterFactory(ITriggernetFacade facade, Subnet subnet, CompilerContext ctx) {
        super(facade, subnet);
        this.ctx = ctx;
    }

    @Override
    protected String getNodePrefix() {
        return "CONSTANT_FILTER"; //$NON-NLS-1$
    }

    @Override
    protected int getInputCount() {
        return 1;
    }

    @Override
    protected int getOutputCount() {
        return 2;
    }

    private ConstantFilter generateFilter() {
        ConstantFilter filter = createElement(ConstantFilter.class);
        ConstantPredicate predicate = createElement(ConstantPredicate.class);
        filter.setConstantPredicate(predicate);
        return filter;
    }

    public ConstantFilter generateFilter(ModelElement artifact, String name) {
        ConstantFilter filter = generateFilter();
        prepareNode(filter, artifact, name);
        return filter;
    }

    public ConstantFilter generateFilter(ModelElement artifact, String name, String operands, String constants, String comparators)
            throws BPMNCompilerException {
        ConstantFilter filter = generateFilter(artifact, name);
        addFilterTerm(filter, operands, constants, comparators);
        return filter;
    }

    public ConstantFilter generateFilter(GalaxyClass cls, String name, String operands, String constants, String comparators)
            throws BPMNCompilerException {
        ConstantFilter filter = generateFilter();
        prepareNode(filter, cls, name);
        addFilterTerm(filter, operands, constants, comparators);
        return filter;
    }

    public void addFilterTerm(ConstantFilter filter, String operands, String constants, String comparators) throws BPMNCompilerException {
        AttributeSpecification[] left_operands = parseOperands(operands);
        TypedConstant[] right_constants = parseConstants(constants);
        String[] operators = comparators.split("&"); //$NON-NLS-1$
        for (int i = 0; i < left_operands.length; i++) {
            ConstantTerm term = createElement(ConstantTerm.class);
            term.setComparator(operators[i].trim());
            term.setLeftOperand(left_operands[i]);
            term.setRightOperand(right_constants[i]);
            if (right_constants[i].getValue() != null && right_constants[i].getValue().contains(CompilerConstants.SCRIPT_VALUE_VERSION))
                ctx.getVersioningHelper().registerVersioningCallback(
                        new AbstractVersioningCallback<TypedConstant>(null, right_constants[i]) {

                            public void incorporateVersionIdentifier(String version_id) {
                                anchor.setValue(anchor.getValue().replace(CompilerConstants.SCRIPT_VALUE_VERSION, version_id));
                            }

                        });
            filter.getConstantPredicate().getConstantTerm().add(term);
        }
    }
}
