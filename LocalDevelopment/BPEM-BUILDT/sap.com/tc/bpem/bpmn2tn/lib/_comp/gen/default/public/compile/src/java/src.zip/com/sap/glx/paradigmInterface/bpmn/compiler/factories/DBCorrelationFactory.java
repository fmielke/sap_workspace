package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import java.util.List;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.AbstractVersioningCallback;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;

public class DBCorrelationFactory extends NodeFactory {

    private static final String JAVA_CLASS = "com.sap.glx.core.kernel.trigger.node.PersistentJoinNode"; //$NON-NLS-1$

    private CompilerContext ctx;

    public DBCorrelationFactory(CompilerContext ctx, ITriggernetFacade facade, Subnet subnet) {
        super(facade, subnet);
        this.ctx = ctx;
    }

    @Override
    protected String getNodePrefix() {
        return "PERSISTENT_JOIN"; //$NON-NLS-1$
    }

    @Override
    protected int getInputCount() {
        return 2;
    }

    @Override
    protected int getOutputCount() {
        return 3;
    }

    public GenericOperator generateCorrelationJoin(GalaxyClass cls, String nodeId, String name) {
        GenericOperator generic = createElement(GenericOperator.class);
        prepareNode(generic, cls, name);
        generic.setImplementationClass(JAVA_CLASS);
        generic.getParameters().add("");
        generic.getParameters().add("");
        generic.getParameters().add(nodeId);

        ctx.getVersioningHelper().registerVersioningCallback(new AbstractVersioningCallback<List<String>>(ctx, generic.getParameters()) {
            public void incorporateVersionIdentifier(String versionId) {
                String serviceId = anchor.get(anchor.size() - 1);
                anchor.set(anchor.size() - 1, versionId + serviceId);
            }

        });
        return generic;
    }

    public void addConjuction(GenericOperator join, String left, String right) {
        StringBuilder confLeft = new StringBuilder(join.getParameters().get(0));
        StringBuilder confRight = new StringBuilder(join.getParameters().get(1));
        if (confLeft.length() > 0) {
            confLeft.append("|");
            confRight.append("|");
        }
        confLeft.append(left);
        confRight.append(right);
        join.getParameters().set(0, confLeft.toString());
        join.getParameters().set(1, confRight.toString());
    }

}
