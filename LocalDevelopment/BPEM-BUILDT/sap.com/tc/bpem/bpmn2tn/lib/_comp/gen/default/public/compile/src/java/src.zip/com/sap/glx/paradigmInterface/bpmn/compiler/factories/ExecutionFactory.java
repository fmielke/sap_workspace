package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.AbstractVersioningCallback;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Script;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;

/**
 * Convenience to create (synchronous) "direct execution" nodes.
 * 
 * @author d046672
 * 
 */
public class ExecutionFactory extends TargetFactory {

    private static final String JAVA_CLASS = "com.sap.glx.core.kernel.trigger.node.DirectExecute"; //$NON-NLS-1$
    private static final String EDGE_TRIGGERED_FALSE = "edgetriggered=false";

    public ExecutionFactory(ITriggernetFacade facade, Subnet subnet, CompilerContext ctx) {
        super(facade, subnet, ctx);
    }

    @Override
    protected String getNodePrefix() {
        return "DIRECT_EXECUTION"; //$NON-NLS-1$
    }

    @Override
    protected int getInputCount() {
        return 1;
    }

    @Override
    protected int getOutputCount() {
        return 0;
    }

    public GenericOperator generateExecution(ModelElement artifact, String name) {
        GenericOperator generic = createElement(GenericOperator.class);
        prepareNode(generic, artifact, name);
        generic.setImplementationClass(JAVA_CLASS);
        return generic;
    }

    public void setScript(GenericOperator generic, String header, String body) {
        String script = "<% " + header + " " + body + " %>"; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
        generic.getParameters().add(script);

        // amend class entries (tx signature, new commands) with version identifier
        ctx.getVersioningHelper().registerVersioningCallback(new AbstractVersioningCallback<GenericOperator>(ctx, generic) {

            public void incorporateVersionIdentifier(String version_id) {
                // not exactly elegant...
                String script = anchor.getParameters().get(0);
                String revisedScript = script.replace(CompilerConstants.SCRIPT_VALUE_VERSION, version_id);
                anchor.getParameters().set(0, revisedScript);
            }
        });
    }

    public void setScript(GenericOperator generic, Script script) {
        setScript(generic, script.getHeader(), "{" + script.getBody() + "}");
    }

    public void setEdgeTriggeredToFalse(GenericOperator generic) {
        generic.getParameters().add(EDGE_TRIGGERED_FALSE);
    }
}
