package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.configuration.AttributeSpecification;
import com.sap.glx.ide.model.configuration.JoinPredicate;
import com.sap.glx.ide.model.configuration.JoinTerm;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;

public class JoinFactory extends NodeFactory {

    public JoinFactory(ITriggernetFacade facade, Subnet subnet) {
        super(facade, subnet);
    }

    @Override
    protected String getNodePrefix() {
        return "JOIN"; //$NON-NLS-1$
    }

    @Override
    protected int getInputCount() {
        return 2;
    }

    @Override
    protected int getOutputCount() {
        return 3;
    }

    private Join generateJoin(ModelElement artifact, String name) {
        Join join = createElement(Join.class);
        prepareNode(join, artifact, name);
        JoinPredicate predicate = createElement(JoinPredicate.class);
        join.setJoinPredicate(predicate);
        return join;
    }

    private Join generateJoin(GalaxyClass cls, String name) {
        Join join = createElement(Join.class);
        prepareNode(join, cls, name);
        JoinPredicate predicate = createElement(JoinPredicate.class);
        join.setJoinPredicate(predicate);
        return join;
    }

    public Join generateJoin(ModelElement artifact, String leftOperands, String rightOperands) {
        Join join = generateJoin(artifact, null);
        addJoinTerm(join, leftOperands, rightOperands);
        return join;
    }

    public Join generateJoin(ModelElement artifact, String name, String leftOperands, String rightOperands) {
        Join join = generateJoin(artifact, name);
        addJoinTerm(join, leftOperands, rightOperands);
        return join;
    }

    public Join generateJoin(ModelElement artifact, String name, String[] leftOperands, String[] rightOperands) {
        Join join = generateJoin(artifact, name);
        for (int i = 0; i < leftOperands.length; i++) {
            addJoinTerm(join, leftOperands[i], rightOperands[i]);
        }
        return join;
    }

    public Join generateJoin(GalaxyClass cls, String name, String leftOperands, String rightOperands) {
        Join join = generateJoin(cls, name);
        addJoinTerm(join, leftOperands, rightOperands);
        return join;
    }

    public void addJoinTerm(Join join, String leftOperands, String rightOperands) {
        AttributeSpecification[] left = parseOperands(leftOperands);
        AttributeSpecification[] right = parseOperands(rightOperands);
        for (int i = 0; i < left.length; i++) {
            JoinTerm term = createElement(JoinTerm.class);
            term.setLeftOperand(left[i]);
            term.setRightOperand(right[i]);
            join.getJoinPredicate().getJoinTerm().add(term);
        }
    }

    public void addJoinTerm(Join join, int leftParameter, int leftAttribute, int rightParameter, int rightAttribute) {
        JoinTerm term = createElement(JoinTerm.class);
        AttributeSpecification leftElement = createElement(AttributeSpecification.class);
        leftElement.setInputChannel(0);
        leftElement.setParameterNumber(leftParameter);
        leftElement.setAttributeId(leftAttribute);
        term.setLeftOperand(leftElement);

        AttributeSpecification rightElement = createElement(AttributeSpecification.class);
        rightElement.setInputChannel(1);
        rightElement.setParameterNumber(rightParameter);
        rightElement.setAttributeId(rightAttribute);
        term.setRightOperand(rightElement);

        join.getJoinPredicate().getJoinTerm().add(term);
    }
}
