package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import com.sap.glx.ide.model.configuration.AttributePredicate;
import com.sap.glx.ide.model.configuration.AttributeSpecification;
import com.sap.glx.ide.model.configuration.AttributeTerm;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.ParameterFilter;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;

public class ParameterFilterFactory extends NodeFactory {

    public ParameterFilterFactory(ITriggernetFacade facade, Subnet subnet) {
        super(facade, subnet);
    }

    @Override
    protected String getNodePrefix() {
        return "PARAMETER_FILTER"; //$NON-NLS-1$
    }

    @Override
    protected int getInputCount() {
        return 1;
    }

    @Override
    protected int getOutputCount() {
        return 2;
    }

    public ParameterFilter generateFilter(ModelElement artifact, String name, String left, String right, String comparators) {
        ParameterFilter filter = createElement(ParameterFilter.class);
        prepareNode(filter, artifact, name);
        AttributePredicate predicate = createElement(AttributePredicate.class);
        filter.setAttributePredicate(predicate);
        addFilterTerm(filter, left, right, comparators);
        return filter;
    }

    public void addFilterTerm(ParameterFilter filter, String left, String right, String comparators) {
        AttributeSpecification[] left_operands = parseOperands(left);
        AttributeSpecification[] right_operands = parseOperands(right);
        String[] operators = comparators.split("&"); //$NON-NLS-1$
        for (int i = 0; i < left_operands.length; i++) {
            AttributeTerm term = createElement(AttributeTerm.class);
            term.setComparator(operators[i].trim());
            term.setLeftOperand(left_operands[i]);
            term.setRightOperand(right_operands[i]);
            filter.getAttributePredicate().getAttributeTerm().add(term);
        }
    }
}
