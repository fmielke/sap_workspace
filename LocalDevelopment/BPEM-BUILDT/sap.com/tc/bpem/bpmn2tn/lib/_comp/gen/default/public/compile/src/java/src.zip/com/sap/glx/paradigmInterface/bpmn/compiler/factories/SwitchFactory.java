package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import java.util.Arrays;

import com.sap.glx.ide.model.configuration.SwitchCase;
import com.sap.glx.ide.model.configuration.SwitchPredicate;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.Output;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.ide.model.triggernet.Switch;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;

public class SwitchFactory extends NodeFactory {

    public SwitchFactory(ITriggernetFacade facade, Subnet subnet) {
        super(facade, subnet);
    }

    @Override
    protected String getNodePrefix() {
        return "SWITCH"; //$NON-NLS-1$
    }

    @Override
    protected int getInputCount() {
        return 1;
    }

    @Override
    protected int getOutputCount() {
        return 0;
    }

    public Switch generateSwitch(ModelElement artifact, String name, String operands) {
        Switch witch = createElement(Switch.class);
        prepareNode(witch, artifact, name);
        SwitchPredicate predicate = createElement(SwitchPredicate.class);
        predicate.getAttributeSpecification().addAll(Arrays.asList(parseOperands(operands)));
        witch.setSwitchPredicate(predicate);
        return witch;
    }

    public void addCase(Switch witch, String constants) throws BPMNCompilerException {
        SwitchCase casa = createElement(SwitchCase.class);
        casa.getElement().addAll(Arrays.asList(parseConstants(constants)));
        witch.getSwitchPredicate().getRow().add(casa);
        Output output = createElement(Output.class);
        witch.getOutputChannels().add(output);
    }
}
