package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.mapping.Mapping;
import com.sap.glx.ide.model.galaxy.mapping.MappingPart;
import com.sap.glx.ide.model.galaxy.processsupplements.NotificationActivity;
import com.sap.glx.ide.model.galaxy.processsupplements.ReportingActivity;
import com.sap.glx.ide.model.galaxy.processsupplements.ReportingDefinition;
import com.sap.glx.ide.model.galaxy.rule.Condition;
import com.sap.glx.ide.model.galaxy.rule.Expression;
import com.sap.glx.ide.model.galaxy.rule.ExpressionFunction;
import com.sap.glx.ide.model.galaxy.rule.Function;
import com.sap.glx.ide.model.galaxy.rule.FunctionInterface;
import com.sap.glx.ide.model.galaxy.rule.FunctionInvocation;
import com.sap.glx.ide.model.galaxy.rule.MappingFunction;
import com.sap.glx.ide.model.galaxy.rule.StaticList;
import com.sap.glx.ide.model.galaxy.rule.Step;
import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.ide.model.galaxy.workflow.Activity;
import com.sap.glx.ide.model.galaxy.workflow.AutomatedActivity;
import com.sap.glx.ide.model.galaxy.workflow.BoundaryEvent;
import com.sap.glx.ide.model.galaxy.workflow.CatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.Collaboration;
import com.sap.glx.ide.model.galaxy.workflow.ConditionalSequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.ErrorEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.Event;
import com.sap.glx.ide.model.galaxy.workflow.EventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.ExclusiveDataSplitGateway;
import com.sap.glx.ide.model.galaxy.workflow.MappableObject;
import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.ScopeObject;
import com.sap.glx.ide.model.galaxy.workflow.ScopeReference;
import com.sap.glx.ide.model.galaxy.workflow.SequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.StartEvent;
import com.sap.glx.ide.model.galaxy.workflow.ThrowEvent;
import com.sap.glx.ide.model.galaxy.workflow.View;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.tc.esmp.mm.wsdl2.Interface;
import com.sap.tc.esmp.mm.wsdl2.Operation;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import com.sap.tc.moin.repository.mmi.reflect.RefObject;

public class DependencyHelper {

    private Map<RefObject, Set<XsdElementDeclaration>> anchor2scope = new HashMap<RefObject, Set<XsdElementDeclaration>>();
    private Set<ErrorEventDefinition> faults = new HashSet<ErrorEventDefinition>();
    private Set<MessageEventDefinition> modelledEndpoints = new HashSet<MessageEventDefinition>();
    private Set<Pair<MessageEventDefinition, Pool>> generatedEndpoints = new HashSet<Pair<MessageEventDefinition, Pool>>();
    private Set<ReportingDefinition> reportingDefs = new HashSet<ReportingDefinition>();

    // used to save the result of the GenerateScopeClassesStage
    private Map<Iterable<XsdElementDeclaration>, GalaxyClass> scope2class = new HashMap<Iterable<XsdElementDeclaration>, GalaxyClass>();

    /**
     * Registers an XSD element as type dependency. On demand, it will create a new type scope (=list of elements) which is the actually
     * versioned artifact. A given anchor (e.g., DataContainer, WSDL Interface, Function, ...) serves as convenient lookup vehicle. It is
     * made sure, that no element resides in more than one scope or appears more than once within a single scope.
     * 
     * @param anchor is the "bracket" that defines a scope. All type dependencies with the same anchor will end up in the same scope.
     * Moreover, an element exclusively resides in one scope. If one and the same element is added multiple times with different anchors,
     * that scope can be looked up using both anchors. However, there is one scope only.
     * @param element is the XSD element that is references from the flow model.
     * @return true in case this call added a new element otherwise false is returned.
     */
    private boolean addTypeDependency(RefObject anchor, XsdElementDeclaration element) {
        if (anchor != null && element != null) {
            // check, if this anchor was already registered
            Set<XsdElementDeclaration> scope = anchor2scope.get(anchor);
            if (scope == null) {
                // create a new scope
                scope = new LinkedHashSet<XsdElementDeclaration>();

                // register the scope for this anchor
                anchor2scope.put(anchor, scope);
            }
            return scope.add(element);
        }
        return false;
    }

    /**
     * Registers all request/response/fault elements of the service interface the operation belongs to.
     * 
     * @param operation
     */
    private void addTypeDependency(Operation operation) {
        if (operation != null) {
            Interface iface = operation.getServiceInterface();
            if (!anchor2scope.containsKey(iface)) {
                anchor2scope.put(iface, OperationHelper.getDependentScope(iface));
            }
        }
    }

    private void addTypeDependencies(Scope scope) {
        for (ScopeObject object : scope.getScopeObjects()) {
            // data objects, views and roles
            if (object instanceof DataContainer) {
                DataContainer container = (DataContainer) object;
                addTypeDependency(container, container.getXsdElementDeclaration());
                if (container instanceof View) {
                    addMappingTypeDependencies(((View) object).getMapping());
                }
            }

            // conditions of outgoing connector of the exclusive split gateway
            if (object instanceof ExclusiveDataSplitGateway) {
                ExclusiveDataSplitGateway gateway = (ExclusiveDataSplitGateway) object;
                for (SequenceConnector connector : gateway.getOutgoingConnectors()) {
                    ConditionalSequenceConnector conditional = (ConditionalSequenceConnector) connector;
                    if (!conditional.isDefault())
                        addExpressionTypeDependencies(conditional.getCondition());
                }
            }

            // mappable objects
            if (object instanceof MappableObject) {
                addMappingTypeDependencies(((MappableObject) object).getInputMapping());
                addMappingTypeDependencies(((MappableObject) object).getOutputMapping());

                if (object instanceof Activity) {
                    Activity activity = (Activity) object;
                    
                    // TODO: Clarify usage of this event definitions	
                    if (activity.getEventDefinitions() != null) {
                        for (EventDefinition definition: activity.getEventDefinitions()) {
                            if (definition instanceof ErrorEventDefinition)
                                addTypeDependency((ErrorEventDefinition) definition);
                        }
                    }
                    if (activity.getBoundaryEvents() != null) {
                        for (BoundaryEvent event : activity.getBoundaryEvents()) {
                            if (event.getTrigger() instanceof ErrorEventDefinition) {
                                addTypeDependency((ErrorEventDefinition) event.getTrigger());
                            }
                            // CSN 0120061532 0002448042 2011
                            // Include and mapping dependencies for boundary events
                            addMappingTypeDependencies(((MappableObject) event).getOutputMapping());
                        }

                    }

                    // add the types of the WSDL operation/signature
                    if (activity instanceof AutomatedActivity || activity instanceof ScopeReference
                            || activity instanceof NotificationActivity) {
                        addTypeDependency(activity.getOperation());
                    }

                    // add the input type of the reporting activity
                    if (activity instanceof ReportingActivity) {
                        ReportingDefinition definition = ((ReportingActivity) activity).getReportingDefinition();
                        if (definition != null) {
                            addTypeDependency(definition, definition.getParameter()); // $JL-SUSPICIOUSFUNCTIONS$
                        }
                    }

                    // recursively collect type dependencies
                    if (activity instanceof EmbeddedScope) {
                        this.addTypeDependencies((EmbeddedScope) activity);
                    }
                }
                
                if (object instanceof Event) {
                    Event event = (Event) object;

                    // correlation expression of catch events (timer and messages)
                    if (event instanceof CatchEvent && event.getEventDefinition() != null) {
                        addExpressionTypeDependencies(((CatchEvent) event).getExpression());
                    } 

                    // raise evention handling (the catching semantics can only be attached to boundaries)
                    if (event instanceof ThrowEvent && event.getEventDefinition() instanceof ErrorEventDefinition) {
                        addTypeDependency((ErrorEventDefinition) event.getEventDefinition());
                    }
                    
                    // message event definition with operation
                    if (event.getEventDefinition() instanceof MessageEventDefinition) {
                        Operation operation = ((MessageEventDefinition) event.getEventDefinition()).getOperation();
                        addTypeDependency(operation);
                    }
                }
            }
        }
    }
    
    /**
     * Convenience method to register the evention payload type under the evention anchor.
     * 
     * @param evention
     */
    private void addTypeDependency(ErrorEventDefinition evention) {
        if (evention.getWsdlFault() != null) {
            addTypeDependency(evention, evention.getWsdlFault().getElement());
        } else {
            addTypeDependency(evention, evention.getParameter()); // $JL-SUSPICIOUSFUNCTIONS$
        }
    }

    private void addExpressionTypeDependencies(Expression expression) {
        if (expression != null)
            for (Step step : expression.getSteps()) {
                if (step instanceof FunctionInvocation) {
                    addFunctionInvocationDependancy((FunctionInvocation) step);
                } else if (step instanceof Condition){
                	addConditionDependency((Condition) step);
                } else if (step instanceof StaticList){
                	addStaticListDependancy((StaticList) step);
                }
                
            }
    }

	private void addStaticListDependancy(StaticList list) {
		addTypeDependency(list, (XsdElementDeclaration) list.getXsdFeature());
		
		for(Expression expression: list.getElements()){
			addExpressionTypeDependencies(expression);
		}
	}

	private void addConditionDependency(Condition condition) {
		addTypeDependency(condition, (XsdElementDeclaration) condition.getXsdFeature());
		
		addExpressionTypeDependencies(condition.getConditionExpression());
		addExpressionTypeDependencies(condition.getConditionPositiveExpression());
		addExpressionTypeDependencies(condition.getConditionNegativeExpression());
	}

	
	private void addFunctionInvocationDependancy(FunctionInvocation invocation) {
		addTypeDependency(invocation.getFunctionInterface());

		// recursively traverse the parameter mappings
		addMappingTypeDependencies(invocation.getParameterMapping());
	}

    private void addMappingTypeDependencies(Mapping mapping) {
        if (mapping != null)
            for (MappingPart part : mapping.getActiveMappingParts())
                addPartTypeDependencies(part);

    }

    private void addPartTypeDependencies(MappingPart part) {
        // recursively traverse child parts
        for (MappingPart sub : part.getActiveChildren()) {
            addPartTypeDependencies(sub);
        }
        addExpressionTypeDependencies(part.getExpression());
    }

    /**
     * Convenience to register input and output elements of a mapping function as a joint type scope.
     * 
     * @param function
     */
    private void addTypeDependency(FunctionInterface functionInterface) {
        // in case the formal parameter and the result type where already added, do not go down recursively
        boolean isNew = addTypeDependency(functionInterface, (XsdElementDeclaration) functionInterface.getFormalParameter());
        isNew = isNew | addTypeDependency(functionInterface, (XsdElementDeclaration) functionInterface.getResultType());

        if (isNew) {
            for (Function function : functionInterface.getFunctions()) {
                if (function instanceof MappingFunction) {
                    addMappingTypeDependencies(((MappingFunction) function).getMapping());
                }
                if (function instanceof ExpressionFunction) {
                    addExpressionTypeDependencies(((ExpressionFunction) function).getExpression());
                }
            }
        }
    }


    
    /**
     * Traverses this scope and identifies all start and intermediate controls to become WS provisioning endpoints.
     * 
     * @param scope
     *            is the root scope (i.e., the pool or the task).
     */
    private void addEndpointDependencies(Scope scope) {
        for (ScopeObject object : scope.getScopeObjects()) {
            if (object instanceof CatchEvent) {
                CatchEvent event = (CatchEvent) object;
                if (event.getTrigger() instanceof MessageEventDefinition) {
                    MessageEventDefinition trigger = (MessageEventDefinition) event.getTrigger();
                    if (trigger.getOperation() != null) {
                        Scope rootScope = WorkflowHelper.getRootScope(event);
                        if (OperationHelper.isModelledEndpoint(trigger)) {
                            modelledEndpoints.add(trigger);
                        } else if (rootScope instanceof Pool) {
                            generatedEndpoints.add(new Pair<MessageEventDefinition, Pool>(trigger, (Pool) rootScope));
                        }
                    }
                }
            }
            if (object instanceof EmbeddedScope) {
                addEndpointDependencies((EmbeddedScope) object);
            }
        }
    }

    /**
     * Traverses the scope and identifies all raise and catch artifacts.
     * 
     * @param scope
     *            is the root scope (i.e., the pool or the task).
     */
    private void addFaultDependencies(Scope scope) {
        for (ScopeObject object : scope.getScopeObjects()) {
            // the operation for provisioning can also contain errors (especially for task with UI faults)
            if (object instanceof StartEvent && ((StartEvent) object).getTrigger() instanceof MessageEventDefinition) {
                MessageEventDefinition trigger = (MessageEventDefinition) ((StartEvent) object).getTrigger();
                for (ErrorEventDefinition error : trigger.getErrorEventDefinitions()) {
                    if (error.getWsdlFault() != null) {
                        faults.add(error);
                    }
                }
            }
            
            // throwing errors on end events
            if (object instanceof EndEvent && ((EndEvent) object).getResult() instanceof ErrorEventDefinition) {
                ErrorEventDefinition error = (ErrorEventDefinition) ((EndEvent) object).getResult();
                if (error.getWsdlFault() != null || error.getParameter() != null) {
                    faults.add(error);
                }
            }

            if (object instanceof Activity) {
                Activity activity = (Activity) object;

                // required for handlers on scope references and embedded subflows (error event definition can reside in a different process model)
                if (activity.getBoundaryEvents() != null) {
                    for (BoundaryEvent event : activity.getBoundaryEvents()) {
                        if (event.getEventDefinition() instanceof ErrorEventDefinition)
                            faults.add((ErrorEventDefinition) event.getEventDefinition());
                    }
                }
                // required for automated activities and the call configuration (should contain all faults for the operation)
                if (activity.getEventDefinitions() != null) {
                    for (EventDefinition defintion: activity.getEventDefinitions()) {
                        if (defintion instanceof ErrorEventDefinition)
                            faults.add((ErrorEventDefinition) defintion);
                    }
                }
                if (activity instanceof EmbeddedScope) {
                    this.addFaultDependencies((EmbeddedScope) activity);
                }
            }
        }
    }

    private void addAnalyticsDependencies(Scope scope) {
        for (ScopeObject object : scope.getScopeObjects()) {
            if (object instanceof ReportingActivity) {
            	ReportingActivity activity = (ReportingActivity) object;
            	if (activity.getReportingDefinition() != null) {
            		reportingDefs.add(activity.getReportingDefinition());	
            	}
            } else if (object instanceof EmbeddedScope) {
				addAnalyticsDependencies((EmbeddedScope) object);
			}
        }
    }
    
    private void getScopeDependencies(Scope root, ArrayList<Object> dependencies) {
        addTypeDependencies(root);
        addEndpointDependencies(root);
        addFaultDependencies(root);
        addAnalyticsDependencies(root);
        
        dependencies.addAll(anchor2scope.values());
        dependencies.addAll(generatedEndpoints);
        dependencies.addAll(modelledEndpoints);
        dependencies.addAll(faults);
        dependencies.addAll(reportingDefs);
    }
    
    public Object[] getAllDependencies(Collaboration flow) {
        ArrayList<Object> dependencies = new ArrayList<Object>();
        
        // the collaboration itself for process visualization and texts
        dependencies.add(flow);
        getScopeDependencies(WorkflowHelper.getActivePool(flow), dependencies);
        
        return dependencies.toArray();
    }

    public Object[] getAllDependencies(Task task) {
        ArrayList<Object> dependencies = new ArrayList<Object>();
        
        // the task itself for text dependencies
        dependencies.add(task);
        getScopeDependencies(task, dependencies);
        
        return dependencies.toArray();
    }
    
    /**
     * Populates look-up table from type scope to "Scope_*" GalaxyClass.
     * 
     * @param scope
     *            is the type scope.
     * @param scope_class
     *            is the "Scope_*" GalaxyClass.
     */
    public void addScopeClassOld(Iterable<XsdElementDeclaration> scope, GalaxyClass clsScope) {
        scope2class.put(scope, clsScope);
    }
    
    /**
     * Looks up "Scope_*" GalaxyClass from lookup table.
     * 
     * @param scope
     *            is the type scope.
     * @return the "Scope_*" GalaxyClass this scope is associated with.
     */
    public GalaxyClass getScopeClassOld(Iterable<XsdElementDeclaration> scope) {
        return scope2class.get(scope);
    }
    
    public Iterable<XsdElementDeclaration> getScopeOld(DataContainer container) {
        return anchor2scope.get(container);
    }

    public Iterable<XsdElementDeclaration> getScopeOld(Function function) {
        return anchor2scope.get(function);
    }

    public Iterable<XsdElementDeclaration> getScope(Operation operation) {
        return anchor2scope.get(operation.getServiceInterface());
    }

    public Iterable<XsdElementDeclaration> getScope(EventDefinition evention) {
        return anchor2scope.get(evention);
    }

    public Iterable<XsdElementDeclaration> getScopeOld(ReportingDefinition reporting) {
        return anchor2scope.get(reporting);
    }

    @SuppressWarnings("unchecked")
    public Collection<Iterable<XsdElementDeclaration>> getAllTypeDependenciesOld() {
        return (Collection<Iterable<XsdElementDeclaration>>) (Collection<? extends Iterable<XsdElementDeclaration>>) anchor2scope.values();
    }
}
