package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.net.MalformedURLException;
import java.util.LinkedHashSet;
import java.util.Set;

import com.sap.glx.ide.model.galaxy.workflow.Event;
import com.sap.glx.ide.model.galaxy.workflow.EventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.ScopeObject;
import com.sap.glx.ide.model.galaxy.workflow.ScopeReference;
import com.sap.glx.ide.model.galaxy.workflow.StartEvent;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.paradigmInterface.util.ProvisioningURLUtils;
import com.sap.tc.esmp.mm.wsdl2.FaultReference;
import com.sap.tc.esmp.mm.wsdl2.Interface;
import com.sap.tc.esmp.mm.wsdl2.MessageReference;
import com.sap.tc.esmp.mm.wsdl2.Operation;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import com.sap.tc.moin.repository.Partitionable;

public class OperationHelper {

    /**
     * Convenience method for {@link OperationHelper#getDependentScope(Interface)}. The method returns the dependent type scope for the
     * service interface of the operation.
     * 
     * @see OperationHelper#getDependentScope(Interface)
     * 
     * @param operation
     *            of which the type scope should be calculated
     * @return type scope as input for the type compiler
     */
    public static Set<XsdElementDeclaration> getDependentScope(Operation operation) {
        return getDependentScope(operation.getServiceInterface());
    }

    /**
     * Calculates the dependent scope of a service interface. That is, a set of XsdElementDeclaration is created which contains all element
     * used in the corresponding service interface. This includes all message and fault elements. The resulting set can be declared as a
     * dependency by a compiler in order to trigger the type compiler and therefore the generation of a type scope.
     * 
     * @param iface
     *            of which the type scope should be calculated
     * @return type scope as input for the type compiler
     */
    public static Set<XsdElementDeclaration> getDependentScope(Interface iface) {
        Set<XsdElementDeclaration> scope = new LinkedHashSet<XsdElementDeclaration>();
        for (Operation o : iface.getOperations()) {
            if (o != null) {
                for (MessageReference message : o.getMessages()) {
                    if (message.getElement() != null) {
                        scope.add(message.getElement());
                    }
                }
                for (FaultReference fault : o.getFaults()) {
                    if (fault.getFault().getElement() != null) {
                        scope.add(fault.getFault().getElement());
                    }
                }
            }
        }
        return scope;
    }

    private static MessageEventDefinition getMessageEventDefinition(Scope scope) {
        for (ScopeObject object : scope.getScopeObjects()) {
            if (object instanceof StartEvent) {
                StartEvent event = (StartEvent) object;
                if (event.getTrigger() instanceof MessageEventDefinition) {
                    return (MessageEventDefinition) event.getTrigger();
                }
            }
        }
        return null;
    }

    private static MessageEventDefinition getMessageEventDefinition(CompilerContext ctx, Event event) throws BPMNCompilerException {
        ctx.getValidator().validate(event.getEventDefinition() instanceof MessageEventDefinition,
                "BPM.rt_c_bpmn.000007", "Message event definition as trigger or result expected on event '%s'.", //$NON-NLS-1$ //$NON-NLS-2$
                event.getOriginalName());

        MessageEventDefinition endpoint = (MessageEventDefinition) event.getEventDefinition();
        Operation operation = endpoint.getOperation();
        ctx.getValidator().validate(operation != null, "BPM.rt_c_bpmn.000008", "Operation of message event '%s' must be set.", //$NON-NLS-1$ //$NON-NLS-2$
                event.getOriginalName());
        return endpoint;
    }

    public static Pair<String, Operation> getBPMNEndpoint(CompilerContext ctx, Event event) throws BPMNCompilerException {
        MessageEventDefinition endpoint = getMessageEventDefinition(ctx, event);
        Scope scope = WorkflowHelper.getRootScope(event);
        ctx.getValidator().validate(scope.getIdentifier() != null,
                "BPM.rt_c_bpmn.000009", "Service identifier of the scope '%s' must be set.", scope.getOriginalDescription()); //$NON-NLS-1$ //$NON-NLS-2$
        return new Pair<String, Operation>(scope.getIdentifier(), endpoint.getOperation());
    }

    /**
     * This method returns the configuration details for the request class of the unified connectivity adapter. In case the event refers to
     * a modelled message trigger the service identifier contains the vendor and name of the development component and the name of the
     * message trigger without any version ids. If the message event definition is contained in the process (7.11 content), the service
     * identifier is named after the process plus the version id of the service interface.
     * 
     * @param ctx
     *            compiler context
     * @param event
     *            must be contained inside a pool as tasks are not available over web services
     * @return the service identifier and operation assigned to the event
     * @throws BPMNCompilerException
     */
    public static Pair<String, Operation> getUCEndpoint(CompilerContext ctx, Event event) throws BPMNCompilerException {
        MessageEventDefinition endpoint = getMessageEventDefinition(ctx, event);
        if (isModelledEndpoint(endpoint)) {
            String serviceId = getModelledServiceIdentifier(endpoint);
            return new Pair<String, Operation>(serviceId, endpoint.getOperation());
        } else {
            Scope scope = WorkflowHelper.getRootScope(event);
            if (scope instanceof Pool) {
                ctx.getValidator().validate(scope.getIdentifier() != null,
                        "BPM.rt_c_bpmn.000009", "Service identifier of the scope '%s' must be set.", scope.getOriginalDescription()); //$NON-NLS-1$ //$NON-NLS-2$
                String version = ctx.getHost().getVersionId(new Pair<MessageEventDefinition, Scope>(endpoint, scope),
                        CompilerType.INTERFACECOMPILER);
                String serviceId = getGeneratedServiceIdentifier((Pool) scope, version);
                return new Pair<String, Operation>(serviceId, endpoint.getOperation());
            } else {
                throw new IllegalArgumentException();
            }
        }
    }

    public static Pair<String, Operation> getBPMNEndpoint(CompilerContext ctx, ScopeReference activity) throws BPMNCompilerException {
        // get message trigger of the inner start event
        Scope scope = activity.getReferencedScope();
        ctx.getValidator().validate(scope != null, "BPM.rt_c_bpmn.000010", "Referenced scope of activity '%s' must be set.",
                activity.getOriginalName());
        MessageEventDefinition trigger = getMessageEventDefinition(scope);
        ctx.getValidator().validate(trigger != null, "BPM.rt_c_bpmn.000011",
                "Referenced scope of activity '%s' must have a valid operation on the message start event.", activity.getOriginalName());
        ctx.getValidator().validate(trigger.getOperation() != null, "BPM.rt_c_bpmn.000012",
                "Referenced scope of activity '%s' must have a valid operation asssigned.", activity.getOriginalName());

        // get the service identifier
        String serviceId = scope.getIdentifier();
        ctx.getValidator().validate(serviceId != null, "BPM.rt_c_bpmn.000013",
                "Referenced scope of activity '%s' must have a valid identifier.", activity);

        // validate activity against referenced scope
        ctx.getValidator().validate(activity.getOperation() != null, "BPM.rt_c_bpmn.000014", "Operation of activity '%s' must be set.",
                activity.getOriginalName());
        ctx.getValidator().validate(activity.getOperation() == trigger.getOperation(), "BPM.rt_c_bpmn.000015",
                "Operation of activity '%s' must be the equal to the operation of the referenced scope '%s'.", activity.getOriginalName(),
                scope.getOriginalName());

        return new Pair<String, Operation>(serviceId, trigger.getOperation());
    }

    public static String getModelledServiceIdentifier(MessageEventDefinition endpoint) {
        return ((Partitionable) endpoint).get___Mri().getContainerName() + '/' + endpoint.getOriginalName();
    }

    public static String getGeneratedServiceIdentifier(Pool pool, String version) {
        return pool.getIdentifier() + '_' + version;
    }

    public static boolean isModelledEndpoint(EventDefinition endpoint) {
        final String EVENT_DEF_EXTENSION = ".eventdef";
        if (endpoint.get___Partition().getPri().getPartitionName().endsWith(EVENT_DEF_EXTENSION)) {
            return true;
        } else {
            return false;
        }
    }

    public static String getEndpointUrl(CompilerContext ctx, Event event) throws BPMNCompilerException {
        Pair<String, Operation> endpoint = getUCEndpoint(ctx, event);
        if (isModelledEndpoint(event.getEventDefinition())) {
            return ProvisioningURLUtils.getAbsoluteModelledURL(endpoint.first);
        } else {
            try {
                return ProvisioningURLUtils.getAbsoluteGeneratedURL(endpoint.first, endpoint.second.getServiceInterface());
            } catch (MalformedURLException e) {
                throw new BPMNCompilerException(e);
            }
        }
    }
}
