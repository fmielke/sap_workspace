package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.SortedSet;

import javax.xml.namespace.QName;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.classes.SimpleType;
import com.sap.glx.ide.model.classes.Type;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.View;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.BooleanLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Literal;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.NullLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.mapping.base.compiler.IMappingCompiler.Summary;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

public class ScriptHelper {

    private static final Pair<String, String> clsExit = new Pair<String, String>(CompilerConstants.ADAPTER_BPMN, CompilerConstants.GALAXY_EXIT);
    
    // Mapping related classes
    private static final Pair<String, String> clsData = new Pair<String, String>(CompilerConstants.ADAPTER_TRANSFORMER, CompilerConstants.GALAXY_DATA);
    private static final Pair<String, String> clsExtractor = new Pair<String, String>(CompilerConstants.ADAPTER_TRANSFORMER, CompilerConstants.GALAXY_COMPUTER);
    private static final Pair<String, String> clsMapper = new Pair<String, String>(CompilerConstants.ADAPTER_TRANSFORMER, CompilerConstants.GALAXY_TRANSFORMATOR);
    private static final Pair<String, String> clsScope = new Pair<String, String>(CompilerConstants.ADAPTER_TYPEREGISTRY, CompilerConstants.GALAXY_GENERIC_SCOPE);

    /**
     * Generates a script which invokes the "cancel" method in the CancellationHelper whose instance is to be created before and deleted,
     * after that.
     * 
     * @param scope_name is the name of the scope (instance, token, task, ...) which is to be "cancelled".
     * @return the script out of constructor, invocation, destructor.
     */
    public static String generateCancellationScript(Variable scope_name) {
        StringBuilder sb = new StringBuilder();

        // cancellation_helper = new ExceptionAdapter:CancellationHelper();
        sb.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_CANCELLATION_HELPER),
                new Pair<String, String>(CompilerConstants.ADAPTER_EXCEPTION, CompilerConstants.GALAXY_CANCELLATION_HELPER)));

        // cancellation_helper:cancel(<scope>);
        sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_CANCELLATION_HELPER),
                "cancel", scope_name));

        // delete cancellation_helper;
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_CANCELLATION_HELPER)));

        return sb.toString();
    }

    /**
     * Generates a script command string which generates a new class instance and assigns the instance to a local variable. With 2nd-stage
     * class versioning.
     * 
     * @param instance_name is the name of the local variable (optional).
     * @param cls is the GalaxyClass.
     * @param attributes is an array of attribute values.
     * @return the creation command (e.g., token=new BPMN:Token(parent,"initial"); ).
     */
    @SuppressWarnings("unchecked")
    public static String generateNewCommand(Variable instance_name, GalaxyClass cls, Literal... attributes) {
        StringBuilder sb = new StringBuilder();
        if (instance_name != null) {
            sb.append(instance_name);
            sb.append("=");
        }
        sb.append(CompilerConstants.SCRIPT_COMMAND_NEW);
        sb.append(" ");
        sb.append(cls.getAdapter());
        sb.append(":");
        sb.append(cls.getName());
        sb.append("_" + CompilerConstants.SCRIPT_VALUE_VERSION);
        // if (!(cls.getAdapter().equals(CompilerConstants.ADAPTER_TRANSFORMER) ||
        // cls.getName().startsWith(CompilerConstants.GALAXY_EVENT)))
        // sb.append(cls.getName() + "_" + CompilerConstants.SCRIPT_VALUE_VERSION);
        sb.append("(");
        for (int i = 0; i < cls.getAttribute().size(); i++) {
            sb.append(i < attributes.length ? attributes[i] : CompilerConstants.SCRIPT_VALUE_NULL);
            if (i < cls.getAttribute().size() - 1)
                sb.append(", ");
        }
        sb.append("); ");

        return sb.toString();
    }

    /**
     * New class instance of a generic class. No class versioning.
     * 
     * @param instance_name
     * @param cls
     * @param attributes
     * @return
     */
    @SuppressWarnings("unchecked")
    public static String generateNewCommand(Variable instance_name, Pair<String, String> cls, Literal... attributes) {
        StringBuilder sb = new StringBuilder();
        if (instance_name != null) {
            sb.append(instance_name);
            sb.append("=");
        }
        sb.append(CompilerConstants.SCRIPT_COMMAND_NEW);
        sb.append(" ");
        sb.append(cls.first);
        sb.append(":");
        sb.append(cls.second);
        sb.append("(");
        for (int i = 0; i < attributes.length; i++) {
            sb.append(attributes[i]);
            if (i < attributes.length - 1)
                sb.append(", ");
        }
        sb.append("); ");

        return sb.toString();

    }

    /**
     * Generates a script command string which updates a single attribute of a GalaxyObject instance.
     * 
     * @param instance_name is the name of the GalaxyObject instance.
     * @param attribute_name is the name of the attribute.
     * @param value is the new value of the attribute
     * @return update command (e.g., token:state="abc"; ).
     */
    @SuppressWarnings("unchecked")
    public static String generateUpdateCommand(Variable instance_name, String attribute_name, Literal value) {
        StringBuilder sb = new StringBuilder();
        sb.append(instance_name);
        sb.append(":");
        sb.append(attribute_name);
        sb.append("=");
        sb.append(value);
        sb.append("; ");
        return sb.toString();
    }

    /**
     * Generates a script command string for GalaxyObject instance deletion.
     * 
     * @param instance_name is the name of the GalaxyObject instance.
     * @return deletion command (e.g., delete token; ).
     */
    public static String generateDeleteCommand(Variable instance_name) {
        StringBuilder sb = new StringBuilder();
        sb.append(CompilerConstants.SCRIPT_COMMAND_DELETE);
        sb.append(" ");
        sb.append(instance_name);
        sb.append("; ");
        return sb.toString();
    }

    /**
     * Generates a script command string for assignment of a local variable.
     * 
     * @param local_variable is the name of the local variable.
     * @param instance_name is the name of another local variable.
     * @param attribute_name is an attribute name of instance_name (optional - only if instance_name refers to a GalaxyObject)
     * @return assignment command (e.g., owner=token:parent; ).
     */
    public static String generateAssignCommand(Variable local_variable, Variable instance_name, String attribute_name) {
        StringBuilder sb = new StringBuilder();
        sb.append(local_variable);
        sb.append("=");
        sb.append(instance_name);

        if (attribute_name != null) {
            sb.append(":");
            sb.append(attribute_name);
        }

        sb.append("; ");
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    public static String generateAssignCommand(Variable local_variable, Literal literal) {
        StringBuilder sb = new StringBuilder();
        sb.append(local_variable);
        sb.append("=");
        sb.append(literal);
        sb.append("; ");
        return sb.toString();
    }

    /**
     * Generates a script command string for method invocation.
     * 
     * @param result_variable takes the method return value.
     * @param instance_name is the (GalaxyObject) instance to invoke the method on.
     * @param method_name is the name of the method.
     * @param parameters is an array of parameters to be passed to the method.
     * @return invocation command (e.g., counter=input:inc(); ).
     */
    @SuppressWarnings("unchecked")
    public static String generateInvocationCommand(Variable result_variable, Variable instance_name, String method_name,
            Literal... parameters) {
        StringBuilder sb = new StringBuilder();
        if (result_variable != null) {
            sb.append(result_variable);
            sb.append("=");
        }

        sb.append(instance_name);
        sb.append(":");
        sb.append(method_name);
        sb.append("(");

        for (int i = 0; i < parameters.length; i++) {
            sb.append(parameters[i]);
            if (i < parameters.length - 1)
                sb.append(", ");
        }
        sb.append("); ");

        return sb.toString();
    }

    public static String generateBindCommand(Variable variable) {
        return CompilerConstants.SCRIPT_COMMAND_BIND + " " + variable + "; ";
    }
    
    
    /**
     * Generates a script parameter declaration in script command. Also takes care of proper versioning of the class name.
     * 
     * @param clazz is the GalaxyClass of the parameter.
     * @param name is the local variable name of this parameter.
     * @return <adapter>:<class> <parameter>
     */
    public static String generateClassDeclaration(GalaxyClass clazz, Variable name) {
        return generateClassDeclaration(clazz, name, true);
    }

    public static String generateClassDeclaration(String adapter_name, String class_name, Variable variable_name) {
        return generateClassDeclaration(adapter_name, class_name, variable_name, false);
    }

    private static String generateClassDeclaration(GalaxyClass clazz, Variable name, boolean with_class_versioning) {
        StringBuilder sb = new StringBuilder();
        if (clazz != null) {
            sb.append(clazz.getAdapter());
            sb.append(":");
            sb.append(clazz.getName());
            if (with_class_versioning)
                sb.append("_" + CompilerConstants.SCRIPT_VALUE_VERSION);
        } else
            sb.append("*");
        sb.append(" ");
        sb.append(name);
        return sb.toString();

    }

    public static String generateClassDeclaration(String adapter_name, String class_name, Variable variable_name,
            boolean with_class_versioning) {
        StringBuilder sb = new StringBuilder();
        sb.append(adapter_name);
        sb.append(":");
        sb.append(class_name);
        if (with_class_versioning)
            sb.append("_" + CompilerConstants.SCRIPT_VALUE_VERSION);

        sb.append(" ");
        sb.append(variable_name);
        return sb.toString();

    }

    public static String generateHeaderPrefix(Scope scope, String prefix, MessageFlowObject object) {
        String scriptName;
        if (object != null) {
        	scriptName = IdentifierHelper.createIdentifier(prefix, object.getOriginalName());
        } else {
        	scriptName = IdentifierHelper.createIdentifier(prefix);
        }
    	return IdentifierHelper.createNamespace(scope) + ':' + scriptName + '(';
    }


    public static String generateBodyPrefix(Pair<String, String> exit_class, int lifecycle, MessageFlowObject object,
            Node target, Collection<Variable> parameters) {
        StringBuilder sb = new StringBuilder("{ ");
        sb.append(generateDebugCode(object, lifecycle, new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        return sb.toString();
    }

    public static String generateBodyPrefix(Pair<String, String> exit_class, int lifecycle_bitmask, MessageFlowObject flow_object,
            Node target, Variable... parameters) {
        return generateBodyPrefix(exit_class, lifecycle_bitmask, flow_object, target, Arrays.asList(parameters));
    }

    public static String generateBodyPrefix(MessageFlowObject object) {
        return generateBodyPrefix(clsExit, CompilerConstants.BITMASK_ON_ACTIVATION, object, null);
    }

    public static String generateDebugCode(MessageFlowObject object) {
        return generateDebugCode(object, CompilerConstants.BITMASK_ON_ACTIVATION, 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN));
    }

    public static String generateDebugCode(MessageFlowObject object, int lifecycle, Variable instance, Variable token) {
        StringBuilder sb = new StringBuilder();
        sb.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_EXIT), clsExit));

        if ((lifecycle & CompilerConstants.BITMASK_ON_ACTIVATION) == CompilerConstants.BITMASK_ON_ACTIVATION)
            sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_EXIT), "onActivation",
                    new StringLiteral(object.refMofId()), instance, token));
        if ((lifecycle & CompilerConstants.BITMASK_BEFORE_COMPLETION) == CompilerConstants.BITMASK_BEFORE_COMPLETION)
            sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_EXIT),
                    "beforeCompletion", new StringLiteral(object.refMofId()), instance, token));
        if ((lifecycle & CompilerConstants.BITMASK_AFTER_COMPLETION) == CompilerConstants.BITMASK_AFTER_COMPLETION)
            sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_EXIT), "afterCompletion",
                    new StringLiteral(object.refMofId()), instance, token));
        if ((lifecycle & CompilerConstants.BITMASK_ON_FAILURE) == CompilerConstants.BITMASK_ON_FAILURE)
            sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_EXIT), "onFailure",
                    new StringLiteral(object.refMofId()), instance, token));

        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_EXIT)));

        return sb.toString();
    }

    /**
     * Generates a "scoping" code snippet which publishes the current scope (aka subflow instance). Used for business logging and exception
     * handling.
     * 
     * @param controller_class
     * @param scope
     * @return
     */
    public static String generateScopeCode(Pair<String, String> controller_class, Variable scope) {
        StringBuilder sb = new StringBuilder();
        sb.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTROLLER), controller_class));
        sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTROLLER), "setContext",
                scope));
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTROLLER)));
        return sb.toString();
    }

   
    /**
     * Generates new-style extraction script code making use of the generic "Computer" class.
     * 
     * @param ctx is the compiler context.
     * @param expression_id is the expression id (before proper mapping versioning: <Expression MOFID>_<flow version>, after that: the
     * expression version#)
     * @param context_in is a collection of global input parameters (DataContainer entities). Notice that the corresponding variable names
     * are used and these must be bound to an instance of the container (DataContainer GalaxyObject).
     * @param local_in is a collection local input parameters given as tuples of an XSD element (which is the type of the local SDO
     * variable), the local variable name, and the type scope version. Notice that the local variable is supposed to be instantiated before!
     * No instantiation code is generated as part of this script.
     * @param target_variable is the script variable the result of the expression shall be assigned to.
     * @return the script code to do the extraction.
     */
    public static String generateExpressionCode(CompilerContext ctx, String expression_id, Collection<DataContainer> context_in,
            Set<Triple<XsdElementDeclaration, Variable, StringLiteral>> local_in, Variable target_variable, Type target_type) {

        StringBuilder sb = new StringBuilder();

        // extractor=new Computer();
        sb.append(generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_EXTRACTOR), clsExtractor));

        // context_in = new Data();
        sb.append(generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), clsData));

        // sets the local input context
        if (local_in != null) {
            for (Triple<XsdElementDeclaration, Variable, StringLiteral> element_name_scopeid : local_in) {
                // context_in:setData(<ns>,<name>,<variable name>,scope);
                QName sdo_name = SDOHelper.generateSDOName(element_name_scopeid.first);
                sb.append(generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), "setData",
                        new StringLiteral(sdo_name.getNamespaceURI()), new StringLiteral(sdo_name.getLocalPart()),
                        element_name_scopeid.second, element_name_scopeid.third));
            }
        }

        // sets the global input context
        if (context_in != null)
            for (DataContainer context_variable : context_in) {
                // fetch the script variable name for this container
                String context_name = ctx.getState().getContextVariableName(context_variable);

                // fetch the type scope id from the IBuilderHost
                String scope_id = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScopeOld(context_variable),
                        CompilerType.TYPECOMPILER);

                // compute the renamed SDO name of the payload (this is what the mapping assumes)
                QName sdo_name = SDOHelper.generateSDOName(context_variable.getXsdElementDeclaration());

                if (WorkflowHelper.isTaskStatusDataObject(ctx, context_variable)) {
                    // context_in:setData(<element ns>,<element name>,<variable>,<scope_id>);
                    sb.append(ScriptHelper.generateInvocationCommand(null,
                            new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), "setData", new StringLiteral(sdo_name
                                    .getNamespaceURI()), new StringLiteral(sdo_name.getLocalPart()), new Variable(context_name),
                            new StringLiteral(scope_id)));
                } else {
                    // data=<variable>:getData();
                    sb.append(generateInvocationCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_DATA), new Variable(context_name),
                            "getData"));

                    // context_in:setData(<element ns>,<element name>,data,<scope_id>);
                    sb.append(ScriptHelper.generateInvocationCommand(null,
                            new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), "setData", new StringLiteral(sdo_name
                                    .getNamespaceURI()), new StringLiteral(sdo_name.getLocalPart()), new Variable(
                                    CompilerConstants.SCRIPT_VARIABLE_DATA), new StringLiteral(scope_id)));
                }
            }

        // target=computer:extract("expression id", <context_in>);
        sb.append(generateInvocationCommand(target_variable, new Variable(CompilerConstants.SCRIPT_VARIABLE_EXTRACTOR), "extractAs",
                new StringLiteral(expression_id), new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), new StringLiteral(
                        ((SimpleType) target_type).getType().toString().toUpperCase(Locale.ENGLISH))));

        // delete yves_in;
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN)));

        // delete computer;
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_EXTRACTOR)));

        return sb.toString();
    }

    /**
     * @param ctx
     *            is the compiler context.
     * @param expressionId
     *            is the expression id (before proper mapping versioning: <Expression MOFID>_<flow version>, after
     *            that: the expression version#)
     * @param contextIn
     *            is a collection of global input parameters (DataContainer entities). Notice that the corresponding
     *            variable names are used and these must be bound to an instance of the container (DataContainer
     *            GalaxyObject).
     * @param localIn
     *            is a collection local input parameters given as tuples of an XSD element (which is the type of the
     *            local SDO variable), the local variable name, and the type scope version. Notice that the local
     *            variable is supposed to be instantiated before! No instantiation code is generated as part of this
     *            script.
     * @param listItem
     *            is the data container that represents one entry of the list
     * @param targetVariable
     *            is the script variable the result of the expression shall be assigned to.
     * @return the script code to do the extraction.
     */
    public static String generateExtractAsListCode(CompilerContext ctx, String expressionId, Collection<DataContainer> contextIn,
            DataContainer listItem, Variable targetVariable) {
        
        StringBuilder sb = new StringBuilder();
        
        // extractor=new Computer();
        sb.append(generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_EXTRACTOR), clsExtractor));

        // contextIn = new Data();
        sb.append(generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), clsData));

        // sets the global input context
        if (contextIn != null){
            for (DataContainer contextVariable : contextIn) {
                // fetch the script variable name for this container
                String contextName = ctx.getState().getContextVariableName(contextVariable);

                // fetch the type scope id from the IBuilderHost
                String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScopeOld(contextVariable), CompilerType.TYPECOMPILER);

                // compute the renamed SDO name of the payload (this is what the mapping assumes)
                QName sdoName = SDOHelper.generateSDOName(contextVariable.getXsdElementDeclaration());
                
                if (WorkflowHelper.isTaskStatusDataObject(ctx, contextVariable)) {
                    // context_in:setData(<element ns>,<element name>,<variable>,<scope_id>);
                    sb.append(generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), "setData", new StringLiteral(
                            sdoName.getNamespaceURI()), new StringLiteral(sdoName.getLocalPart()), new Variable(contextName), new StringLiteral(scopeId)));
                } else {
                    // data=<variable>:getData();
                    sb.append(generateInvocationCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_DATA), new Variable(contextName), "getData"));

                    // context_in:setData(<element ns>,<element name>,data,<scope_id>);
                    sb.append(generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), "setData", new StringLiteral(
                            sdoName.getNamespaceURI()), new StringLiteral(sdoName.getLocalPart()), new Variable(CompilerConstants.SCRIPT_VARIABLE_DATA),
                            new StringLiteral(scopeId)));
                }
            }
        }    
        
        // list item type scope id from the IBuilderHost
        String listItemScopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScopeOld(listItem), CompilerType.TYPECOMPILER);
        // compute the renamed SDO name of the payload (this is what the mapping assumes)
        QName listItemSdoTypeName = SDOHelper.generateSDOName(listItem.getXsdElementDeclaration().getTypeDefinition());
        
        //Extractor: extractAsDataObjectList,(,STRING,REFERENCE,STRING,STRING,STRING,),VOID
        // target=extractAsDataObjectList("expression id", <contextIn>, listItemScopeId, listItemNamespace, listItemName);
        sb.append(generateInvocationCommand(targetVariable, new Variable(CompilerConstants.SCRIPT_VARIABLE_EXTRACTOR), "extractAsDataObjectList", 
                new StringLiteral(expressionId),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), 
                new StringLiteral(listItemScopeId),
                new StringLiteral(listItemSdoTypeName.getNamespaceURI()),
                new StringLiteral(listItemSdoTypeName.getLocalPart())));

        // delete yves_in;
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN)));

        // delete extractor;
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_EXTRACTOR)));

        return sb.toString();
    }
    
    
    @SuppressWarnings("unchecked")
    public static String generateMappingCode(CompilerContext ctx, String mapping_id, Collection<DataContainer> context_in,
            Collection<DataContainer> context_out, Triple<XsdElementDeclaration, Variable, StringLiteral> local_in,
            Triple<XsdElementDeclaration, Variable, StringLiteral> local_out) {
        StringBuilder sb = new StringBuilder();

        // mapper=new Transformer:DataMapper();
        sb.append(generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER), clsMapper));

        // generate basic mapping code
        sb.append(generateMappingCodeInternal(ctx, mapping_id, context_in, context_out,
                local_in != null ? new HashSet<Triple<XsdElementDeclaration, Variable, StringLiteral>>(Arrays.asList(local_in)) : null,
                local_out != null ? new HashSet<Triple<XsdElementDeclaration, Variable, StringLiteral>>(Arrays.asList(local_out)) : null,
                null, null));

        // viewUpdater=new ContainerAdapter:ViewUpdater();
        sb.append(generateNewCommand(new Variable("viewUpdater"), new Pair<String, String>(
                "com.sap.glx.adapter.internal.ContainerAdapter", "ViewUpdater")));
        
        // generate additional mapping code for optimized view update
        generateMappingCodeForDependingViews(context_out, sb, ctx);

        // delete viewUpdater;
        sb.append(generateDeleteCommand(new Variable("viewUpdater")));
        // delete mapper;
        sb.append(generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER)));

        return sb.toString();
    }
    
    public static void generateMappingCodeForDependingViews(Collection<DataContainer> contextOut, StringBuilder sb, CompilerContext ctx) {
        if (contextOut != null) {
            for (DataContainer dataContainer : contextOut) {
                SortedSet<View> dependingViews = ctx.getState().getDependingViews(dataContainer);
                if (dependingViews != null) {
                    for (View dependingView : dependingViews) {

                        // 1. add all source data containers of this view to the input list, otherwise view update will fail
                        // 2. reverseViewDependencies cannot be null, because at least one dependency exists
                        SortedSet<DataContainer> reverseViewDependencies = ctx.getState().getReverseViewDependencies(dependingView);

                        // generate code for getting data object modifiers
                        sb.append(generateSetModifiersCode(reverseViewDependencies, ctx));

                        ArrayList<DataContainer> inputList = new ArrayList<DataContainer>();
                        inputList.addAll(reverseViewDependencies);

                        ArrayList<DataContainer> outputList = new ArrayList<DataContainer>();
                        outputList.add(dependingView);

                        Pair<Summary, String> viewMapping = ctx.getState().getViewMapping(dependingView);

                        // generate mapping code for update of this view
                        // mapping will be skipped, if modifications of one of the source data containers is 0
                        String viewVariableName = ctx.getState().getContextVariableName(dependingView);
                        Variable viewVariable = new Variable(viewVariableName);
                        List<Variable> modVariablesOfSourceDataContainers = getModificationsVariablesForContainers(reverseViewDependencies,
                                ctx);
                        sb.append(generateMappingCodeInternal(ctx, viewMapping.second, inputList, outputList, null, null,
                                modVariablesOfSourceDataContainers, viewVariable));

                        // view:dirty=false; --> this is a regular view update which does not "invalidate" the view
                        sb.append(ScriptHelper.generateUpdateCommand(viewVariable, "dirty", BooleanLiteral.FALSE));

                        // traverse views depending on this view
                        generateMappingCodeForDependingViews(outputList, sb, ctx);
                    }
                }
            }
        }
    }
    
    public static String generateAddModifierCode(Collection<DataContainer> used_context, CompilerContext ctx, String viewVariableName) {
        StringBuilder sb = new StringBuilder();
        if (used_context != null) {
            for (DataContainer container : used_context) {
                // context_?_modifications=<context variable>:modifications;
                Variable contextVariable = new Variable(ctx.getState().getContextVariableName(container));
                Variable contextModVariable = createModificationsVariable(contextVariable.toString());
                sb.append(ScriptHelper
                        .generateAssignCommand(contextModVariable, contextVariable, CompilerConstants.ATTRIBUTE_MODIFICATIONS));

                // <view name>:addModifier(<mod count of this context object>
                sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(viewVariableName), "addModifier", contextModVariable));
            }
        }

        return sb.toString();
    }
    
    private static Variable createModificationsVariable(String contextVariableName){
        StringBuilder sb = new StringBuilder(contextVariableName);
        sb.append("_");
        sb.append(CompilerConstants.SCRIPT_VARIABLE_MODIFICATIONS);
        return new Variable(sb.toString());
    }
    
    private static List<Variable> getModificationsVariablesForContainers(Collection<DataContainer> used_context, CompilerContext ctx){
        List<Variable> result = new ArrayList<Variable>();
        for (DataContainer container : used_context) {
            result.add(createModificationsVariable(ctx.getState().getContextVariableName(container)));
        }
        return result;
    }
    
    private static String generateSetModifiersCode(Collection<DataContainer> used_context, CompilerContext ctx) {
        StringBuilder sb = new StringBuilder();
        if (used_context != null) {
            for (DataContainer container : used_context) {
                // context_?_modifications=<context variable>:modifications;
                Variable contextVariable = new Variable(ctx.getState().getContextVariableName(container));
                Variable contextModVariable = createModificationsVariable(contextVariable.toString());
                sb.append(ScriptHelper
                        .generateAssignCommand(contextModVariable, contextVariable, CompilerConstants.ATTRIBUTE_MODIFICATIONS));
            }
        }

        return sb.toString();
    }

    /**
     * Generates new-style mapping script code making use of the generic "Transformator" class.
     * 
     * @param ctx is the compiler context.
     * @param mapping_id is the mapping id (before proper mapping versioning: <Mapping MOFID>_<flow version>, after that: the mapping
     * version#)
     * @param context_in is a collection of global input parameters (DataContainer entities). Notice that the corresponding variable names
     * are used and these must be bound to an instance of the container (DataContainer GalaxyObject).
     * @param context_out is a collection of global output parameters (DataContainer entities). Notice that the corresponding variable names
     * are used and these must be bound to an instance of the container (DataContainer GalaxyObject).
     * @param local_in is a collection local input parameters given as tuples of an XSD element (which is the type of the local SDO
     * variable), the local variable name, and the type scope version. Notice that the local variable is supposed to be instantiated before!
     * No instantiation code is generated as part of this script.
     * @param local_out is a collection local output parameters given as tuples of an XSD element (which is the type of the local SDO
     * variable), the local variable name, and the type scope version. Notice that the local variable is supposed to be instantiated before!
     * No instantiation code is generated as part of this script.
     * @param modVariablesOfSourceDataContainers 
     * @param dependingViewVariable 
     * @return the script code to perform the mapping.
     */
    @SuppressWarnings("unchecked")
    private static String generateMappingCodeInternal(CompilerContext ctx, String mapping_id, Collection<DataContainer> context_in,
            Collection<DataContainer> context_out, Set<Triple<XsdElementDeclaration, Variable, StringLiteral>> local_in,
            Set<Triple<XsdElementDeclaration, Variable, StringLiteral>> local_out, List<Variable> modVariablesOfSourceDataContainers,
            Variable dependingViewVariable) {

        StringBuilder sb = new StringBuilder();

        // yves_in = new Data();
        sb.append(generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), clsData));

        // yves_out = new Data();
        sb.append(generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_OUT), clsData));

        // sets the local input context
        if (local_in != null) {
            for (Triple<XsdElementDeclaration, Variable, StringLiteral> element_name_scopeid : local_in) {
                // yves_in:setData(<ns>,<name>,<variable name>,scope);
                QName sdo_name = SDOHelper.generateSDOName(element_name_scopeid.first);
                sb.append(generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), "setData",
                        new StringLiteral(sdo_name.getNamespaceURI()), new StringLiteral(sdo_name.getLocalPart()),
                        element_name_scopeid.second, element_name_scopeid.third));
            }
        }

        // sets the global input context
        if (context_in != null)
            for (DataContainer context_variable : context_in) {
                // fetch the script variable name for this container
                String context_name = ctx.getState().getContextVariableName(context_variable);

                // fetch the type scope id from the IBuilderHost
                String scope_id = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScopeOld(context_variable),
                        CompilerType.TYPECOMPILER);

                // compute the renamed SDO name of the payload (this is what the mapping assumes)
                QName sdo_name = SDOHelper.generateSDOName(context_variable.getXsdElementDeclaration());

                if (WorkflowHelper.isTaskStatusDataObject(ctx, context_variable)) {
                    // yves_in:setData(<element ns>,<element name>,<variable>,<scope_id>);
                    sb.append(ScriptHelper.generateInvocationCommand(null,
                            new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), "setData", new StringLiteral(sdo_name
                                    .getNamespaceURI()), new StringLiteral(sdo_name.getLocalPart()), new Variable(context_name),
                            new StringLiteral(scope_id)));
                } else {
                    // data=<variable>:getData();
                    sb.append(generateInvocationCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_DATA), new Variable(context_name),
                            "getData"));

                    // yves_in:setData(<element ns>,<element name>,data,<scope_id>);
                    sb.append(ScriptHelper.generateInvocationCommand(null,
                            new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), "setData", new StringLiteral(sdo_name
                                    .getNamespaceURI()), new StringLiteral(sdo_name.getLocalPart()), new Variable(
                                    CompilerConstants.SCRIPT_VARIABLE_DATA), new StringLiteral(scope_id)));
                }
            }

        // sets the local output context
        if (local_out != null) {
            for (Triple<XsdElementDeclaration, Variable, StringLiteral> element_name_scopeid : local_out) {
                // yves_out:setOutput(<ns>,<name>,<local name>,scope);
                QName sdo_name = SDOHelper.generateSDOName(element_name_scopeid.first);
                sb.append(generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_OUT), "setData",
                        new StringLiteral(sdo_name.getNamespaceURI()), new StringLiteral(sdo_name.getLocalPart()),
                        element_name_scopeid.second, element_name_scopeid.third));
            }
        }

        // sets the global output context
        if (context_out != null)
            for (DataContainer context_variable : context_out) {
                String context_name = ctx.getState().getContextVariableName(context_variable);
                String scope_id = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScopeOld(context_variable),
                        CompilerType.TYPECOMPILER);
                QName sdo_name = SDOHelper.generateSDOName(context_variable.getXsdElementDeclaration());

                if (WorkflowHelper.isTaskStatusDataObject(ctx, context_variable)) {
                    sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(
                            CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_OUT), "setData",
                            new StringLiteral(sdo_name.getNamespaceURI()), new StringLiteral(sdo_name.getLocalPart()), new Variable(
                                    context_name), new StringLiteral(scope_id)));
                } else {
                    
                    // bind context; (lock for write)
                    sb.append(generateBindCommand(new Variable(context_name)));
                    
                    // data=context:getData();
                    sb.append(generateInvocationCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_DATA), new Variable(context_name),
                            "getData"));

                    // scope=new GenericScope(NULL,scope_id);
                    sb.append(generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_SCOPE), clsScope, NullLiteral.NULL,
                            new StringLiteral(scope_id)));

                    // copy = scope:copy(data);
                    sb.append(generateInvocationCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_COPY), new Variable(
                            CompilerConstants.SCRIPT_VARIABLE_SCOPE), "copy", new Variable(CompilerConstants.SCRIPT_VARIABLE_DATA)));

                    // delete scope;
                    sb.append(generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_SCOPE)));

                    sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(
                            CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_OUT), "setData",
                            new StringLiteral(sdo_name.getNamespaceURI()), new StringLiteral(sdo_name.getLocalPart()), new Variable(
                                    CompilerConstants.SCRIPT_VARIABLE_COPY), new StringLiteral(scope_id)));
                }

            }

        if (modVariablesOfSourceDataContainers != null) {
            Variable variableViewUpdater = new Variable("viewUpdater");

            for (Variable modVariable : modVariablesOfSourceDataContainers) {
                // viewUpdater:addModifier(INTEGER);
                sb.append(generateInvocationCommand(null, variableViewUpdater, "addModifier", modVariable));
            }

            Literal mapper = new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER);
            Literal mappingId = new StringLiteral(mapping_id);
            Literal input = new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN);
            Literal output = new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_OUT);
            // viewUpdater:updateView(view, mapper, "mapping id", <context in>, <context out>);
            sb.append(generateInvocationCommand(null, variableViewUpdater, "updateView", dependingViewVariable, mapper, mappingId, input, output));
        } else {
            // mapper:map("mapping id", <context_in>,<context out>);
            sb.append(generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER), "map", new StringLiteral(
                    mapping_id), new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN), new Variable(
                    CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_OUT)));
        }

        // fetches the local output context
        if (local_out != null) {
            for (Triple<XsdElementDeclaration, Variable, StringLiteral> element_name_scopeid : local_out) {
                // local = mapper:getOutput(<ns>,<name>,scope);
                QName sdo_name = SDOHelper.generateSDOName(element_name_scopeid.first);
                sb.append(generateInvocationCommand(element_name_scopeid.second, new Variable(
                        CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_OUT), "getData", new StringLiteral(sdo_name.getNamespaceURI()),
                        new StringLiteral(sdo_name.getLocalPart()), element_name_scopeid.third));
            }
        }

        // fetches the global output context
        if (context_out != null)
            for (DataContainer context_variable : context_out) {
                if (WorkflowHelper.isTaskStatusDataObject(ctx, context_variable)) {
                    // nothing to do, mapping has already modified the task
                    // object in place
                } else {
                    // data = mapper:getOutput(<element ns>, <element name>,
                    // scope);
                    String context_name = ctx.getState().getContextVariableName(context_variable);
                    String scope_id = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScopeOld(context_variable),
                            CompilerType.TYPECOMPILER);
                    QName sdo_name = SDOHelper.generateSDOName(context_variable.getXsdElementDeclaration());
                    sb.append(ScriptHelper.generateInvocationCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_DATA), new Variable(
                            CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_OUT), "getData",
                            new StringLiteral(sdo_name.getNamespaceURI()), new StringLiteral(sdo_name.getLocalPart()), new StringLiteral(
                                    scope_id)));

                    // context:setData(data);
                    sb.append(generateInvocationCommand(null, new Variable(context_name), "setData", new Variable(
                            CompilerConstants.SCRIPT_VARIABLE_DATA)));
                }
            }

        // delete yves_in;
        sb.append(generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_IN)));

        // delete yves_out;
        sb.append(generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_MAPPER_CONTEXT_OUT)));

        return sb.toString();
    }
}
