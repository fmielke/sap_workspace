package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;
import java.util.LinkedList;

import com.sap.glx.constants.SharedCompilerConstants;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.configuration.ConfigurationString;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.triggernet.assembler.AssemblerException;
import com.sap.glx.paradigmInterface.triggernet.assembler.GalaxyAssembler;

public class VersioningHelper {

    private Collection<VersioningCallback> callbacks = new LinkedList<VersioningCallback>();

    public void registerVersioningCallback(VersioningCallback callback) {
        callbacks.add(callback);
    }

    public void registerClassVersioningCallback(GalaxyClass clazz) {
        callbacks.add(new ClassVersioningCallback(clazz));
    }

    public void registerAppendVersioningCallback(ConfigurationString string) {
        callbacks.add(new AppendVersioningCallback(string));
    }

    public void versionTriggerNetwork(String version_id) {
        for (VersioningCallback callback : callbacks)
            callback.incorporateVersionIdentifier(version_id);
    }

    /**
     * Computes an (almost) unique version identifier (MD5 hash) from an intermediate (i.e., incomplete) trigger network).
     * 
     * @param ctx is the compiler context
     * @param subnet is the root object in the MOIN representation of the trigger network
     * @return the MD5 hash (in hex encoding) of the intermediate trigger network CSV
     * @throws BPMNCompilerException in case the assemble find inconsistencies in the model
     */
    public static String computeTriggernetVersion(CompilerContext ctx, Subnet subnet) throws BPMNCompilerException {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(out, SharedCompilerConstants.UTF_8));
            (new GalaxyAssembler(ctx.getHost())).generateCSV(subnet, writer);
            return computeVersion(out.toByteArray());
        } catch (AssemblerException e) {
            throw new BPMNCompilerException("Assembler error for intermediate build result (faulty target model).", e);
        } catch (UnsupportedEncodingException e) {
            throw new UnsupportedOperationException("Failed to compute version id (UTF-8 not supported).", e);
        }
    }

    /**
     * Compute an MD5 hash over the UTF-8 representation of the string
     * @param input string
     * @return the MD5 hash (in hex encoding) of the input string
     */
    public static String computeVersion(String input) {
        try {
            return computeVersion(input.getBytes(SharedCompilerConstants.UTF_8));
        } catch (UnsupportedEncodingException e) {
            throw new UnsupportedOperationException("Failed to compute version id (UTF-8 not supported).", e);
        }
    }

    private static String computeVersion(byte[] input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] hash = digest.digest(input);
            StringBuilder version = new StringBuilder();
            for (byte b : hash) {
                // converts the signed byte [-128, 127] into a corresponding unsigned int [0, 255]
                String hex = Integer.toHexString(b & 0x00ff);
                if (hex.length() < 2) {
                    version.append('0');
                }
                version.append(hex);
            }
            return version.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new UnsupportedOperationException("Failed to compute version id (MD5 not available).", e);
        }
    }
}
