package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals;

import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;

public class FloatLiteral extends AbstractLiteral<Float> {

    protected FloatLiteral(float value) {
        super(value);
    }
    
    @Override
    public String toString() {
        return value == null ? CompilerConstants.SCRIPT_VALUE_NULL : Float.toString(value)+"f"; //$NON-NLS-1$
    }

}
