package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals;


public interface Literal<T> {
    public T getValue();
}
