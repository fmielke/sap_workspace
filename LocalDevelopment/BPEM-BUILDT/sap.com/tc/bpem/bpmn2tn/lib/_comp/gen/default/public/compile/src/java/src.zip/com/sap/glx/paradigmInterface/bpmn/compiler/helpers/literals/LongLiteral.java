package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals;

import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;

public class LongLiteral extends AbstractLiteral<Long> {

    public LongLiteral(long value) {
        super(value);
    }
    
    @Override
    public String toString() {
        return value == null ? CompilerConstants.SCRIPT_VALUE_NULL : Long.toString(value)+"l"; //$NON-NLS-1$
    }

}
