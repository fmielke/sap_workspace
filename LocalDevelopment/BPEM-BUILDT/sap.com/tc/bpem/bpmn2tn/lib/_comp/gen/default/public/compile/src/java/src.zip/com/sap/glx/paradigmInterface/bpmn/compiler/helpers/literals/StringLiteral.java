package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals;

import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;

public class StringLiteral extends AbstractLiteral<String> {
    /**
     * Escapes a string for rendering as a String literal for rendering in a script and encloses it in quotes. The
     * 
     * escaping is done for the quote character as well as for some non-printable whitespace characters.
     * 
     * @param string
     *            the string to escape
     * @param quoteString
     *            <code>true</code> if the string should be enclosed in quotes (")
     * @return the escaped string
     */
    public static String escapeStringLiteral(String string, boolean quoteString) {
        StringBuilder result = new StringBuilder(string.length() + 10);
        if (quoteString)
            result.append('"');
        for (int i = 0; i < string.length(); i++) {
            char ch = string.charAt(i);

            switch (ch) {
            case '\n':
                result.append("\\n"); //$NON-NLS-1$
                break;
            case '\r':
                result.append("\\r"); //$NON-NLS-1$
                break;
            case '\t':
                result.append("\\t"); //$NON-NLS-1$
                break;
            case '"':
                result.append("\\\""); //$NON-NLS-1$
                break;
            case '\\':
                result.append("\\\\"); //$NON-NLS-1$
                break;
            default:
                result.append(ch);
            }
        }
        if (quoteString)
            result.append('"');
        return result.toString();
    }

    public static String unescapeStringLiteral(String string) {
        // This looks crude, but is actually the fastest way to do this, since methods like indexOf also just loop over
        // the char[] and check every character
        // We always go over the StringBuilder to guarantee that we get a new String instance with a healthy char[]
        StringBuilder result = new StringBuilder(string.length());
        for (int i = 0; i < string.length(); i++) {
            char ch = string.charAt(i);
            if (ch == '\\') {
                i++;
                result.append(unescapeStringLiteral(string.charAt(i)));
            } else {
                result.append(ch);
            }
        }
        return result.toString();
    }

    public static char unescapeStringLiteral(char escapedChar) {
        switch (escapedChar) {
        case 'n':
            return '\n';
        case 'r':
            return '\r';
        case 't':
            return '\t';
        case '"':
            return '"';
        case '\\':
            return '\\';
        default:
            // TODO throw exception?
            break;
        }
        return Character.UNASSIGNED;
    }

    public StringLiteral(String value) {
        super(escapeQuotes(value));
    }

    @Override
    public String toString() {
        return value == null ? CompilerConstants.SCRIPT_VALUE_NULL : value;
    }

    /**
     * Escape backslashes and quotes.
     * 
     * @param s
     * @return
     */
    private static String escapeQuotes(String s) {
        return s == null ? null : escapeStringLiteral(s, true);
    }
}
