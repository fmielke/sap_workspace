package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope;

import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedList;

import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.triggernet.Node;

/**
 * represents the last context node in a context join cascade
 * holds ordered information about connected DataContainers
 */
public class ContextCascadeNode {

    private final Node m_cascadeNode;
    private LinkedList<DataContainer> m_orderedDataContainer = new LinkedList<DataContainer>();

    public ContextCascadeNode(Node cascadeNode) {
        m_cascadeNode = cascadeNode;
    }

    public void appendDataContainer(DataContainer dataObject) {
        if (dataObject != null) {
            m_orderedDataContainer.add(dataObject);
        }
    }

    public void appendDataContainers(LinkedList<DataContainer> orderedDataContainers) {
        for (DataContainer dataContainer : orderedDataContainers) {
            m_orderedDataContainer.add(dataContainer);
        }
    }

    public Enumeration<DataContainer> getOrderedDataContainer() {
        return Collections.enumeration(m_orderedDataContainer);
    }

    public Node getCascadeNode() {
        return m_cascadeNode;
    }
}
