package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.DataObject;
import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.Event;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.View;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.Source;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerState;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ContextHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.OperationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.DonFrame;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.FrameNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.tc.esmp.mm.wsdl2.Operation;
import com.sap.tc.esmp.mm.xsd1.XsdFeature;

/**
 * A base class for all compiler rules mainly offering convenience methods.
 * 
 * @author Thilo-Alexander Ginkel
 * @author Philipp Sommer
 * 
 */
public abstract class BaseCompilerRule<T extends ModelElement> implements CompilerRule<T> {
    enum Direction {
        IN, OUT, INOUT;
    }

    /**
     * A general <code>preprocess</code> implementation doing nothing for rules that do not need to prepare anything.
     */
    public void preprocess(CompilerContext ctx) throws BPMNCompilerException {}

    /**
     * A general <code>postprocess</code> implementation doing nothing for rules that do not need to perform any
     * post-processing.
     */
    public void postprocess(CompilerContext ctx) throws BPMNCompilerException {}

    /**
     * Creates the union of multiple sets. If the provided sets preserve the order of their elements the union operator
     * will also adhere to that order, which will be reflected in the result set.
     * 
     * @param sets
     *            the sets to unify
     * @return the set union
     */
    protected <U extends ModelElement> Set<U> union(Collection<U>... sets) {
        LinkedHashSet<U> result = new LinkedHashSet<U>();

        for (Collection<U> set : sets) {
            result.addAll(set);
        }

        return result;
    }

    private Set<DataContainer> getAllDataContainers(CompilerContext ctx) {
        Set<DataObject> dataobjects = ctx.getArtifacts(DataObject.class);
        Set<View> views = ctx.getArtifacts(View.class);

        Set<DataContainer> objects = new HashSet<DataContainer>();
        if (dataobjects != null)
            objects.addAll(dataobjects);
        if (views != null)
            objects.addAll(views);

        return objects;
    }

    protected LinkedHashSet<DataContainer> identifySourceDataObjects(CompilerContext ctx, IMappingCompiler.Summary summary) {
    	return identifyDataObjects(ctx, summary.getSourceFeatureSet());
    }
    
    protected LinkedHashSet<DataContainer> identifyTargetDataObjects(CompilerContext ctx, IMappingCompiler.Summary summary) {
    	return identifyDataObjects(ctx, summary.getTargetFeatureSet());
    }
    
    protected Pair<Set<DataContainer>, Set<DataContainer>> identifyInOutDataObjects(CompilerContext ctx, IMappingCompiler.Summary summary, Direction direction) {
        return new Pair<Set<DataContainer>, Set<DataContainer>>(identifyDataObjects(ctx, summary.getSourceFeatureSet()),
                !Direction.IN.equals(direction) ? identifyDataObjects(ctx, summary.getTargetFeatureSet()) : new LinkedHashSet<DataContainer>());
    }
    
    /**
     * Finds out the data objects that are affected by a mapping.
     * 
     * @param ctx the compiler context.
     * @param elements the xsd elements identified as source or target feature set
     * @return an ordered set of data objects
     */
    private LinkedHashSet<DataContainer> identifyDataObjects(CompilerContext ctx, Set<XsdFeature> elements) {
        LinkedHashSet<DataContainer> result = new LinkedHashSet<DataContainer>();

        for (MessageFlowObject object : getAllDataContainers(ctx)) {
            DataContainer data = (DataContainer) object;
            if (elements.contains(data.getXsdElementDeclaration()))
                result.add(data);
        }
        return result;
    }

    /**
     * Adds a swizzle in front of the context cascade. Ignores task data objects.
     */
    protected Node buildContextProjectionNetwork(CompilerContext ctx, ModelElement elem, String name, Collection<DataContainer> usedContext) {
        Node result = null;

        if (usedContext.size() > 0) {
            /*
             * Create projection from global context: 1. Determine parameter order 2. Create swizzle node 3. Connect the
             * swizzle node to the global context join network
             */
            Set<Integer> contextOrder = new LinkedHashSet<Integer>(usedContext.size());
            for (DataContainer obj : usedContext) {
                // if (!WorkflowHelper.isTaskStatusDataObject(ctx, obj))
                contextOrder.add(ctx.getState().getContextElementIndex(obj));
            }
            result = ctx.getSwizzleFactory().generateSwizzle(elem, "project_context" + (name != null ? "_" + name : ""), contextOrder.toArray(new Integer[0]));
            NodeFactory.connectNodes(ctx.getState().getGlobalContextJoinNetwork(), 0, result, 0);
        }

        return result;
    }

    /**
     * Constructs a plain correlation network which joins the given data objects by the owning instance. Ignores task
     * data objects.
     */
    protected Node buildContextJoinNetwork(CompilerContext ctx, ModelElement artifact, Collection<DataContainer> objects) throws BPMNCompilerException {
        Node last = null;

        if (objects != null)
            for (DataContainer object : objects) {
                if (last == null)
                    last = getFilteredDataObjectSource(ctx, object);
                else {
                    Join join = ctx.getJoinFactory().generateJoin(artifact, object.getOriginalName(), "0/0/0", "1/0/0");
                    NodeFactory.connectNodes(last, 0, join, 0);
                    NodeFactory.connectNodes(getFilteredDataObjectSource(ctx, object), 0, join, 1);
                    last = join;
                }

            }
        return last;
    }

    /**
     * Retrieves a source for a data object, which checks whether the data object's owner still exists.
     */
    private Node getFilteredDataObjectSource(CompilerContext ctx, DataContainer object) throws BPMNCompilerException {
        Source dataSource = ctx.getSourceFactory().getSource4Class(ctx.getContextHelper().getClassByDataObject(object));
        ConstantFilter ownerAlive = ctx.getConstantFilterFactory().generateFilter(object, "owner_alive", "0/0/0", "NULL", "!=");
        NodeFactory.connectNodes(dataSource, 0, ownerAlive, 0);
        return ownerAlive;
    }

    /**
     * Generates a script header for scripts that just take the token instance, process instance and context as
     * parameters.
     * 
     * @param ctx
     *            the compiler context
     * @param prefix
     *            the prefix to use when generating the script
     * @param object
     *            the flow object this script applies to
     * @param context
     *            the context used by the script
     * @return a string representing the generated script header
     */
    protected String generateSimpleScriptHeader(CompilerContext ctx, String prefix, MessageFlowObject object, Set<DataContainer> context) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), prefix, object));
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTokenSource().getGalaxyClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getInstanceSource().getGalaxyClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        for (DataContainer var : context) {
            sb.append(", ");
            sb.append(ScriptHelper.generateClassDeclaration(ctx.getContextHelper().getClassByDataObject(var), new Variable(ctx.getState().getContextVariableName(var))));
        }

        sb.append(")");
        return sb.toString();
    }

    /**
     * Generates a script header for scripts that just take the token instance and process instance as parameters.
     * 
     * @param ctx
     *            the compiler context
     * @param prefix
     *            the prefix to use when generating the script
     * @param object
     *            the flow object this script applies to
     * @return a string representing the generated script header
     */
    protected String generateSimpleScriptHeader(CompilerContext ctx, String prefix, MessageFlowObject object) {
        return generateSimpleScriptHeader(ctx, prefix, object, Collections.<DataContainer> emptySet());
    }

    /**
     * Generates a cascade of joins (and swizzles) such that identical updates that come in from the given nodes are
     * removed.
     * 
     * @param ctx
     *            the compiler context
     * @param artifact
     *            the BPMN artifact this cascade is generated for
     * @param update_size
     *            is the number of objects in the updates
     * @param nodes
     *            are the nodes from which the updates can come from
     * @return a single node whose output channel one must connect to in order to have the desired semantics
     */
    protected Node buildSingletonCascade(CompilerContext ctx, MessageFlowObject artifact, int update_size, Node... nodes) {
        if (nodes.length == 0)
            return null;

        Node last = nodes[0];
        Integer[] projection = new Integer[update_size];
        String[] left = new String[update_size], right = new String[update_size];
        for (int i = 0; i < update_size; i++) {
            projection[i] = i;
            left[i] = "0/" + i + "/-1";
            right[i] = "1/" + i + "/-1";
        }

        for (int i = 1; i < nodes.length; i++) {
            // join in a way that all elements from the left match all elements from the right
            Join join = ctx.getJoinFactory().generateJoin(artifact, "singleton_join_" + Integer.toString(i - 1), left, right);
            NodeFactory.connectNodes(last, 0, join, 0);
            NodeFactory.connectNodes(nodes[i], 0, join, 1);

            last = ctx.getSwizzleFactory().generateSwizzle(artifact, "singleton_projection_" + Integer.toString(i - 1), projection);
            NodeFactory.connectNodes(join, 0, last, 0);
            NodeFactory.connectNodes(join, 1, last, 0);
            NodeFactory.connectNodes(join, 2, last, 0);
        }
        return last;
    }
    
    protected int getTransitionPriority(EndEvent endEvent) {
    	if (endEvent.isTerminate()) {
    		return CompilerConstants.PRIORITY_CANCEL;
    	} else {
    		return CompilerConstants.PRIORITY_NORMAL;
    	}
    }
    
    /**
     * helper that resolves the scope and calls "protected ProjectionNode buildContextProjectionNode(CompilerContext ctx, FrameNode projectionScope, ModelElement artifact, String name, Collection<DataContainer> usedContext) throws BPMNCompilerException"
     */
    protected ProjectionNode buildContextProjectionNode(CompilerContext ctx, Scope projectionScope, ModelElement artifact, String name, Collection<DataContainer> usedContext) throws BPMNCompilerException{
        if(projectionScope==null){
            throw new BPMNCompilerException("invalid projection scope");
        }
        DonFrame derDon = ctx.getState().getDonFrame();
        FrameNode projectionFrameNode = derDon.getFrameNode4Scope(projectionScope);
        return this.buildContextProjectionNode(ctx, projectionFrameNode, artifact, name, usedContext);
    }
    
    /**
     * resolves the appropriate cascade node for a context projection,
     * creates a new swizzle node configured with the requested data objects and the scope as first object if it is an embedded scope
     * and connects it to the cascade node.
     * Returns a the swizzle as ProjectionNode which holds also the indexes.
     * @param ctx
     * @param artifactScope
     * @param name
     * @param usedContext
     * @return
     * @throws BPMNCompilerException
     */
    protected ProjectionNode buildContextProjectionNode(CompilerContext ctx, FrameNode projectionScope, ModelElement artifact, String name, Collection<DataContainer> usedContext) throws BPMNCompilerException{
    	if(ctx==null || projectionScope==null || artifact==null){
    		throw ctx.getValidator().error("BPM.rt_c_bpmn.000017", "Required parameter is null while trying to create a context projection node.");
    	}
    	if(usedContext==null || usedContext.isEmpty()){
    		return null;
       	}
    	CompilerState state = ctx.getState();
    	DonFrame derDon = state.getDonFrame();
    	//FrameNode currentFrame = derDon.getFrameNode4Scope(artifactScope);
    	ProjectionNode generalProjectionNode = projectionScope.getProjectionNode();
    	if(generalProjectionNode == null){
    		throw ctx.getValidator().error("BPM.rt_c_bpmn.000018", "Inconsistent state while trying to connect to context cascade for artifact '%s' in scope '%s'.", 
    		        artifact.getOriginalName(), projectionScope.getScope()!=null?projectionScope.getScope().getOriginalName():"generated scope");
    	}
    	Node generalNode = generalProjectionNode.getProjectionNode();
    	//project scope and given data objects
    	ProjectionNode configuredProjectionNode = new ProjectionNode();
    	int runningIndex = -1;
    	List<Integer> usedIndexes = new ArrayList<Integer>();
    	if(!derDon.isRootScope(projectionScope)){	
    		int indexOfScope = generalProjectionNode.getIndexOfObject(projectionScope.getGalaxyClass());
        	if(indexOfScope<0){
    			throw ctx.getValidator().error("BPM.rt_c_bpmn.000019", "Could not resolve index on projection join for scope '%s' of artifact '%s'.",
    			        projectionScope.getScope()!=null?projectionScope.getScope().getOriginalName():"generated scope", artifact.getOriginalName());
    		}
        	usedIndexes.add(indexOfScope);
        	runningIndex++;
        	configuredProjectionNode.addObjectIndex(projectionScope.getGalaxyClass(), runningIndex);
    	}
    	ContextHelper ctxHelper = ctx.getContextHelper();
    	for(DataContainer usedDataContainer : usedContext){
    	    GalaxyClass contextClass = ctxHelper.getClassByDataObject(usedDataContainer);
    		int indexOfUsedDataContainer = generalProjectionNode.getIndexOfObject(contextClass);
    		if(indexOfUsedDataContainer<0){
    			throw ctx.getValidator().error("BPM.rt_c_bpmn.000020", "Could not resolve index on projection join for data object '%s' for artifact '%s' in scope '%s'.", 
    			        usedDataContainer.getOriginalName(), artifact.getOriginalName(), projectionScope.getScope()!=null?projectionScope.getScope().getOriginalName():"generated scope");
    		}
    		usedIndexes.add(indexOfUsedDataContainer);
    		runningIndex++;
    		configuredProjectionNode.addObjectIndex(contextClass, runningIndex);
    	}
    	Swizzle modificationSwizzle = ctx.getSwizzleFactory().generateSwizzle(artifact, "context_projection" +(name != null ? "_" + name : ""), usedIndexes.toArray(new Integer[usedIndexes.size()]));
    	NodeFactory.connectNodes(generalNode, 0, modificationSwizzle, 0);
    	configuredProjectionNode.setProjectionNode(modificationSwizzle);
    	configuredProjectionNode.setLastIndex(runningIndex);
    	return configuredProjectionNode;
    }
    
    protected Triple<String, String, Operation> getEndpoint(CompilerContext ctx, Event event) throws BPMNCompilerException {
        Pair<String, Operation> bpmnEndpoint = OperationHelper.getBPMNEndpoint(ctx, event);
        ctx.getValidator().validateOperation(event, bpmnEndpoint.second);
        String ucEndpoint = null;
        if (!ctx.isTaskFlow()) {
            ucEndpoint = OperationHelper.getUCEndpoint(ctx, event).first;
        }
        return new Triple<String, String, Operation>(bpmnEndpoint.first, ucEndpoint, bpmnEndpoint.second);
    }
}
