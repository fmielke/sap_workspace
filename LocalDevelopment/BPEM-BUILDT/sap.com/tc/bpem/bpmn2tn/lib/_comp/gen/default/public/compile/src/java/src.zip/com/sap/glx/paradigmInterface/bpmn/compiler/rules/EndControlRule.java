package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import javax.xml.namespace.QName;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.Source;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SDOHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventLogHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventTypeIds;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.AdvancedScript;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Literal;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.LongLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Script;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptName;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.StringLiteral;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.tc.esmp.mm.wsdl2.Operation;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

/**
 * Compiles end events with a message event definition as result. Note that only events with a real message event definitions can be
 * compiled. If the message event definition links to an asynchronous operation it behaves like a blank end event {@link BlankEndEventRule}.
 * In the inner task flow there are even event message event definitions with no operation. These are also directed to the rule for blank
 * end events.
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * @author Philipp Sommer
 * 
 */
public class EndControlRule extends BaseCompilerRule<EndEvent> implements CompilerRule<EndEvent> {

    public Class<EndEvent> getSupportedArtifact() {
        return EndEvent.class;
    }

    public void compile(EndEvent endEvent, CompilerContext ctx) throws BPMNCompilerException {
        ctx.getValidator().validateConnectors(endEvent, 1, 0);

        Node tokenSwitch = ctx.getState().getTokenSwitch();
        int tokenOutput = ctx.getState().getBeforeTokenSwitchExit(endEvent);

        // Mapping stuff
        Node tokenInstanceContextNode;
        int tokenInstanceContextChannel;
        Pair<IMappingCompiler.Summary, String> mapping = ctx.getMappingHelper().compile(endEvent.getInputMapping());
        Pair<Set<DataContainer>, Set<DataContainer>> context = identifyInOutDataObjects(ctx, mapping.first, Direction.IN);
        @SuppressWarnings("unchecked")
        Set<DataContainer> usedContext = union(context.first, context.second);

        // add depending views and their dependencies to script header (for optimized view update)
        SortedSet<DataContainer> allViewDependencies = ctx.getState().getAllViewDependencies(usedContext);
        usedContext.addAll(allViewDependencies);

        // mapping projection
        if (usedContext.isEmpty()) {
            tokenInstanceContextNode = tokenSwitch;
            tokenInstanceContextChannel = tokenOutput;
        } else {
            ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, endEvent.getScope(), endEvent, null, usedContext);
            if (ctx.getRootScope().equals(endEvent.getScope())) {
                tokenInstanceContextNode = ctx.getJoinFactory().generateJoin(endEvent, "join_context", "0/1/-1", "1/0/0");
                NodeFactory.connectNodes(tokenSwitch, tokenOutput, tokenInstanceContextNode, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, tokenInstanceContextNode, 1);
                tokenInstanceContextChannel = 0;
            } else {
                // is in embedded scope, projection contains frame object as
                // first element
                // token.frame=frame
                Join contextJoin = ctx.getJoinFactory().generateJoin(endEvent, "context_join", "0/0/2", "1/0/-1");
                NodeFactory.connectNodes(tokenSwitch, tokenOutput, contextJoin, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);

                // for the target node the frame has to be removed now
                List<Integer> usedIndexes = new ArrayList<Integer>();
                // token, instance
                usedIndexes.add(0);
                usedIndexes.add(1);
                // ignore frame
                int runningIndex = 3;
                // data objects
                for (int i = 1; i <= projectionSwizzle.getLastIndex(); i++) {
                    usedIndexes.add(runningIndex++);
                }
                tokenInstanceContextNode = ctx.getSwizzleFactory().generateSwizzle(endEvent, "context_no_frame_projection",
                        usedIndexes.toArray(new Integer[usedIndexes.size()]));
                NodeFactory.connectNodes(contextJoin, 0, tokenInstanceContextNode, 0);
                tokenInstanceContextChannel = 0;
            }
        }

        if (!ctx.isTaskFlow()) {

            // create bridge class and use to join token, instance, context
            GalaxyClass clsBridge = ctx.getReplicator().generateBridgeClass(ctx.getState().getInstanceSource().getGalaxyClass());
            ctx.getState().setBridgeClass(clsBridge);
            Source source = ctx.getSourceFactory().getSource4Class(clsBridge);
            Node bridgeJoin = ctx.getJoinFactory().generateJoin(endEvent, null, "0/0/0", "1/1/-1");
            NodeFactory.connectNodes(source, 0, bridgeJoin, 0);
            NodeFactory.connectNodes(tokenInstanceContextNode, tokenInstanceContextChannel, bridgeJoin, 1);

            // create a pulsar with the token as owner for the timeout
            GalaxyClass clsPulsar = ctx.getReplicator().generatePulsarClass(endEvent, ctx.getState().getInstanceClass(), true);
            Source srcPulsar = ctx.getSourceFactory().getSource4Class(clsPulsar);

            // Target nodes
            Target targetBPMNResponse = generateBPMNResponseTransition(ctx, endEvent, context.first, context.second, usedContext,
                    mapping.second);
            Target targetUCResponse = generateUCResponseTransition(ctx, endEvent, context.first, context.second, usedContext,
                    mapping.second);
            Target targetBeaming = generateBeamingTransition(ctx, endEvent, clsPulsar);
            Target targetCreateCleanup = generateCreateCleanupTransition(ctx, endEvent, clsPulsar);
            Target targetDoCleanup = generateDoCleanupTransition(ctx, endEvent, clsPulsar);

            // when the instance refers to another instance as parent (-> same
            // group -> same cluster node)
            Node parentFilter = ctx.getConstantFilterFactory().generateFilter(endEvent, "parent_exists", "0/2/0", "NULL", "!=");
            Node bridgeOriginFilter = ctx.getClusterNodeFilterFactory().generateClusterFilter(endEvent, "bridge_origin", "0/0/3");
            Node bridgeIsUCFilter = ctx.getConstantFilterFactory().generateFilter(endEvent, "bridge_is_uc", "0/0/1",
                    "STRING:" + CompilerConstants.ADAPTER_UC, "==");
            NodeFactory.connectNodes(bridgeJoin, 0, parentFilter, 0);
            NodeFactory.connectNodes(parentFilter, 0, targetBPMNResponse, 0);
            NodeFactory.connectNodes(parentFilter, 1, bridgeOriginFilter, 0);
            NodeFactory.connectNodes(bridgeOriginFilter, 0, bridgeIsUCFilter, 0);
            NodeFactory.connectNodes(bridgeIsUCFilter, 0, targetUCResponse, 0);
            NodeFactory.connectNodes(bridgeIsUCFilter, 1, targetBPMNResponse, 0);

            // if the group does not run on the correct cluster node beaming is
            // necessary
            Node swizzleContext = ctx.getSwizzleFactory().generateSwizzle(endEvent, "remove_context", 0, 1, 2);
            Node timeoutJoin = ctx.getJoinFactory().generateJoin(endEvent, "timeout", "0/2/-1", "1/0/4");
            Node timeoutReachedFilter = ctx.getConstantFilterFactory().generateFilter(endEvent, "timout_reached", "0/3/0", "LONG:1", "==");
            Node bridgeSentOffFilter = ctx.getClusterNodeFilterFactory().generateClusterFilter(endEvent, "bridge_sent_off_location",
                    "0/0/4");
            NodeFactory.connectNodes(bridgeOriginFilter, 1, swizzleContext, 0);
            NodeFactory.connectNodes(swizzleContext, 0, timeoutJoin, 0);
            NodeFactory.connectNodes(srcPulsar, 0, timeoutJoin, 1);
            NodeFactory.connectNodes(timeoutJoin, 1, targetCreateCleanup, 0);
            NodeFactory.connectNodes(timeoutJoin, 0, timeoutReachedFilter, 0);
            NodeFactory.connectNodes(timeoutReachedFilter, 0, targetDoCleanup, 0);
            NodeFactory.connectNodes(timeoutReachedFilter, 1, bridgeSentOffFilter, 0);
            NodeFactory.connectNodes(bridgeSentOffFilter, 1, targetBeaming, 0);

        } else {
            Target targetBPMNResponse = generateBPMNResponseTransition(ctx, endEvent, context.first, context.second, usedContext,
                    mapping.second);
            NodeFactory.connectNodes(tokenInstanceContextNode, tokenInstanceContextChannel, targetBPMNResponse, 0);
        }
    }

    private Target generateBPMNResponseTransition(CompilerContext ctx, EndEvent endEvent, Set<DataContainer> contextIn,
            Set<DataContainer> contextOut, Set<DataContainer> usedContext, String mappingId) throws BPMNCompilerException {
        return generateMessageResponseTransition(ctx, endEvent, false, contextIn, contextOut, usedContext, mappingId);
    }

    private Target generateUCResponseTransition(CompilerContext ctx, EndEvent endEvent, Set<DataContainer> contextIn,
            Set<DataContainer> contextOut, Set<DataContainer> usedContext, String mappingId) throws BPMNCompilerException {
        return generateMessageResponseTransition(ctx, endEvent, true, contextIn, contextOut, usedContext, mappingId);
    }

    /**
     * Generates the transition script for an end control. Notice, that the end control differs from termination in that an end control
     * merely stops the control flow of this "branch" whereas termination stops *all* flows of this process instance (i.e., terminates the
     * instance).
     * 
     * @throws BPMNCompilerException
     * 
     */
    private Target generateMessageResponseTransition(CompilerContext ctx, EndEvent endEvent, boolean isUC, Set<DataContainer> contextIn,
            Set<DataContainer> contextOut, Set<DataContainer> usedContext, String mappingId) throws BPMNCompilerException {

        AdvancedScript script;
        if (isUC) {
            script = new AdvancedScript(ctx, ScriptName.END_EVENT_MESSAGE_UC, endEvent);
        } else {
            script = new AdvancedScript(ctx, ScriptName.END_EVENT_MESSAGE_BPMN, endEvent);
        }

        ScriptVariable varBridge = null;
        if (!ctx.isTaskFlow()) {
            varBridge = script.addParameter(ScriptVariable.BRIDGE, ctx.getState().getBridgeClass());
        }
        ScriptVariable varToken = script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        ScriptVariable varInstance = script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        List<ScriptVariable> varContext = new ArrayList<ScriptVariable>(usedContext.size());
        for (DataContainer container : usedContext) {
            varContext.add(script.addParameter(ctx.getState().getContextVariable(container), ctx.getContextHelper().getClassByDataObject(
                    container)));
        }

        Triple<String, String, Operation> endpoint = getEndpoint(ctx, endEvent);

        script.generateDebugCode(varInstance, varToken);
        script.generateScopeCode(varToken);

        // type scope instantiation
        String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScope(endpoint.third), CompilerType.TYPECOMPILER);
        GalaxyClass clsScope = ctx.getDependencyHelper().getScopeClassOld(ctx.getDependencyHelper().getScope(endpoint.third));
        ScriptVariable varCallscope = script.generateNewCommand(ScriptVariable.CALLSCOPE, clsScope, varInstance);

        // create the response
        XsdElementDeclaration response = WSDLHelper.getResponseElement(endpoint.third);
        QName responseType = SDOHelper.generateSDOName(WSDLHelper.getElementType(response));
        ScriptVariable varPayload = script.generateInvocationCommand(ScriptVariable.PAYLOAD, varCallscope, "instantiate",
                new StringLiteral(responseType.getNamespaceURI()), new StringLiteral(responseType.getLocalPart()));
        script.generateMappingCode(mappingId, contextIn, contextOut, null, new Triple<ScriptVariable, XsdElementDeclaration, String>(
                varPayload, response, scopeId));

        ScriptVariable varKicker = null;
        ScriptVariable varParent = null;
        if (ctx.isTaskFlow() && ctx.useITF_Decoupling()) {
            // For ITF_Decoupling we put an AsyncAction to the queue.
            // The mapping will be executed on the current cluster node already, but
            // the response object creation happens remote on the node which processes the action.

            // kicker=instance:kicker;
            varKicker = script.generateAssignCommand(ScriptVariable.KICKER, varInstance, "kicker");
            // parent=instance:parent;
            varParent = script.generateAssignCommand(ScriptVariable.PARENT, varInstance, "parent");

            // asyncHandler = new AsyncActionAdapter:AsyncActionHandler();
            ScriptVariable varAsyncHandler = new ScriptVariable("asyncActionHandler");
            script.generateNewCommand(varAsyncHandler, new Pair<String, String>("com.sap.glx.adapter.internal.AsyncActionAdapter",
                    "AsyncActionHandler"));

            StringLiteral serviceId = new StringLiteral(endpoint.first);
            StringLiteral operation = new StringLiteral(endpoint.third.getName());

            // add all parameters via AsyncActionHandler
            script.generateInvocationCommand(varAsyncHandler, "addActionParameter", new StringLiteral("serviceId"), serviceId);
            script.generateInvocationCommand(varAsyncHandler, "addActionParameter", new StringLiteral("operation"), operation);
            script.generateInvocationCommand(varAsyncHandler, "addActionParameter", new StringLiteral("kicker"), varKicker);
            script.generateInvocationCommand(varAsyncHandler, "addActionSDOParameter", new StringLiteral("payload"), varPayload,
                    new StringLiteral(scopeId));

            // put the action to the queue
            // asyncHandler:executeAction(anchor=parent,parameters=[serviceId,operation,kicker,payload])
            StringLiteral actionName = new StringLiteral("com.sap.glx.adapter.BPMNAdapter.MessageResponseTransitionAsyncActionExecutor");
            script.generateInvocationCommand(varAsyncHandler, "executeAction", varParent, actionName);

            // delete asyncHandler;
            script.generateDeleteCommand(varAsyncHandler);

        } else {
            if (isUC) {
                varKicker = varBridge;
            } else {
                varKicker = script.generateAssignCommand(ScriptVariable.KICKER, varInstance, "kicker");
            }

            // parent=instance:parent;
            varParent = script.generateAssignCommand(ScriptVariable.PARENT, varInstance, CompilerConstants.ATTRIBUTE_PARENT);

            // response=new UC/BPMNAdapter:Response(<service>,<operation>,parent,kicker);
            Pair<String, String> clsResponse;
            StringLiteral serviceId;
            if (isUC) {
                clsResponse = new Pair<String, String>(CompilerConstants.ADAPTER_UC, CompilerConstants.GALAXY_RESPONSE);
                serviceId = new StringLiteral(endpoint.second);
            } else {
                clsResponse = new Pair<String, String>(CompilerConstants.ADAPTER_BPMN, CompilerConstants.GALAXY_RESPONSE);
                serviceId = new StringLiteral(endpoint.first);
            }
            StringLiteral operation = new StringLiteral(endpoint.third.getName());
            ScriptVariable varResponse = script.generateNewCommand(ScriptVariable.RESPONSE, clsResponse, serviceId, operation, varParent,
                    varKicker);

            script.generateInvocationCommand(null, varResponse, "setData", varPayload);
        }

        // event logging for end event
        if (!(endEvent.getScope() instanceof EmbeddedScope) && !ctx.isTaskFlow()) {
            EventLogHelper.addEvent(script, ctx.getState().getEventLoggerClass(), EventTypeIds.END_TRIGGERED, ((Pool) ctx.getRootScope())
                    .refMofId(), varInstance, endEvent.refMofId(), varKicker);
        }

        script.generateDeleteCommand(varCallscope);
        script.generateDeleteCommand(varToken);

        // optionally add "delete instance;"
        if (endEvent.isTerminate()) {
            script.generateDeleteCommand(varInstance);
        }

        return script.getTarget(getTransitionPriority(endEvent));
    }

    private Target generateBeamingTransition(CompilerContext ctx, EndEvent endEvent, GalaxyClass clsPulsar) throws BPMNCompilerException {
        Script script = new Script(ctx, ScriptName.BEAM_ME_UP, endEvent);
        ScriptVariable varBridge = script.addParameter(ScriptVariable.BRIDGE, ctx.getState().getBridgeClass());
        script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        script.addParameter(ScriptVariable.PULSAR, clsPulsar);

        script.generateInvocationCommand(varBridge, "beamMeUp");

        return script.getTarget(getTransitionPriority(endEvent));
    }

    private Target generateCreateCleanupTransition(CompilerContext ctx, EndEvent endEvent, GalaxyClass clsPulsar)
            throws BPMNCompilerException {
        Script script = new Script(ctx, ScriptName.BEAM_CREATE_TIMEOUT, endEvent);
        ScriptVariable varBridge = script.addParameter(ScriptVariable.BRIDGE, ctx.getState().getBridgeClass());
        script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        ScriptVariable varInstance = script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());

        ScriptVariable varDuration = script.generateInvocationCommand(ScriptVariable.DURATION, varBridge, "getTimeout");
        script.generateNewCommand(null, clsPulsar, new LongLiteral(0l), new LongLiteral(1l), varDuration, Literal.NULL, varInstance);

        return script.getTarget(getTransitionPriority(endEvent));
    }

    private Target generateDoCleanupTransition(CompilerContext ctx, EndEvent endEvent, GalaxyClass clsPulsar) throws BPMNCompilerException {
        Script script = new Script(ctx, ScriptName.BEAM_TIMEOUT, endEvent);
        ScriptVariable varBridge = script.addParameter(ScriptVariable.BRIDGE, ctx.getState().getBridgeClass());
        ScriptVariable varToken = script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        ScriptVariable varInstance = script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        script.addParameter(ScriptVariable.PULSAR, clsPulsar);

        script.generateInvocationCommand(varInstance, "suspendWithChildren");
        script.generateInvocationCommand(varBridge, "logTimeout");
        script.generateDeleteCommand(varToken);

        return script.getTarget(getTransitionPriority(endEvent));
    }
}
