package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import javax.xml.namespace.QName;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.processsupplements.NotificationActivity;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SDOHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.paradigmInterface.util.IMoinUtils;
import com.sap.glx.paradigmInterface.util.ToolUtils;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

/**
 * A compiler rule for notification activities.
 * 
 * @author Philipp Sommer
 * 
 * @version $Id:
 *          //bpem/bpem.tools/dev/src/_com.sap.glx.bpmn2tn/java/com/sap/glx/paradigmInterface/bpmn/compiler/rules/NotificationActivity.java#1 $
 */
public class NotificationActivityRule extends BaseCompilerRule<NotificationActivity> implements
        CompilerRule<NotificationActivity> {

	private static Pair<String, String> clsNotifier = new Pair<String, String>(CompilerConstants.ADAPTER_NOTIFICATION, CompilerConstants.GALAXY_NOTIFIER);
	
    public Class<NotificationActivity> getSupportedArtifact() {
        return NotificationActivity.class;
    }

    public void compile(NotificationActivity activity, CompilerContext ctx) throws BPMNCompilerException {
    	// validation of the activity
    	ctx.getValidator().validateConnectors(activity, 1, 1);

        // retrieve galaxy class for this scope
    	GalaxyClass clsScope = ctx.getDependencyHelper().getScopeClassOld(ctx.getDependencyHelper().getScope(activity.getOperation()));
        
        // compile the input mapping
        Pair<IMappingCompiler.Summary, String> inputMapping = ctx.getMappingHelper().compile(activity.getInputMapping());
        Set<DataContainer> usedContext = identifySourceDataObjects(ctx, inputMapping.first);
        
        // handling for depending views
        SortedSet<DataContainer> allViewDependencies = ctx.getState().getAllViewDependencies(usedContext);
        usedContext.addAll(allViewDependencies);

        // create transition
        Target target = ctx.getTargetFactory().generateTarget(activity, activity.getOriginalName());
        ctx.getTargetFactory().setScript(
                target,
                generateScriptHeader(ctx, activity, usedContext),
                generateScriptBody(ctx, activity, target, inputMapping.second, usedContext, clsScope));
        
        int tokenChannel = ctx.getState().getBeforeTokenSwitchExit(activity);
        if(usedContext.isEmpty()){
        	NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), tokenChannel, target, 0);
        }else{
        	ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, activity.getScope(), activity, null, usedContext);
        	if(ctx.getRootScope().equals(activity.getScope())){
            	//is root scope, projection only contains data objects
        		Join contextJoin = ctx.getJoinFactory().generateJoin(activity, "context_join", "0/1/-1", "1/0/0");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), tokenChannel, contextJoin, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);
                NodeFactory.connectNodes(contextJoin, 0, target, 0);
            }else{
            	//is in embedded scope, projection contains frame object as first element
            	//token.frame=frame
           		Join contextJoin = ctx.getJoinFactory().generateJoin(activity, "context_join", "0/0/2", "1/0/-1");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), tokenChannel, contextJoin, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);
                
        		//for the target node the frame has to be removed now
        		List<Integer> usedIndexes = new ArrayList<Integer>();
        		//token and instance
        		usedIndexes.add(0);
        		usedIndexes.add(1);
        		//ignore frame
        		int runningIndex = 3;
        		//data objects
        		for(int i = 1; i<=projectionSwizzle.getLastIndex(); i++){
        			usedIndexes.add(runningIndex++);
        		}
        		Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(activity, "context_no_frame_projection", usedIndexes.toArray(new Integer[usedIndexes.size()]));
        		NodeFactory.connectNodes(contextJoin, 0, noFrameSwizzle, 0);
        		NodeFactory.connectNodes(noFrameSwizzle, 0, target, 0);
            }
        }
    }
    
    private String generateScriptHeader(CompilerContext ctx, NotificationActivity activity, Set<DataContainer> used_context) {
        return generateSimpleScriptHeader(ctx, CompilerConstants.TARGET_NOTIFICATION_ACTIVITY, activity, used_context);
    }

    private String generateScriptBody(CompilerContext ctx, NotificationActivity activity, Target target, String mappingId, Set<DataContainer> usedContext, 
    		GalaxyClass clsScope) throws BPMNCompilerException {

        List<Variable> parameters = new ArrayList<Variable>(2 + usedContext.size());
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT));
        for (DataContainer obj : usedContext) {
            parameters.add(new Variable(ctx.getState().getContextVariableName(obj)));
        }

        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(), CompilerConstants.BITMASK_ON_ACTIVATION, activity,
                target, parameters));
        sb.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        XsdElementDeclaration requestElement = WSDLHelper.getRequestElement(activity.getOperation());
        String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScope(activity.getOperation()), CompilerType.TYPECOMPILER);
        QName requestType = SDOHelper.generateSDOName(WSDLHelper.getElementType(requestElement));
        
        // create scope instance
        sb.append(ScriptHelper.generateNewCommand(
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_CALLSCOPE), 
        		clsScope, 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        // create notifier instance
        sb.append(ScriptHelper.generateNewCommand(
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_NOTIFIER),
        		clsNotifier));
        
        // request=scope:instantiate(<ns>,<name>);
        sb.append(ScriptHelper.generateInvocationCommand(
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_REQUEST), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_CALLSCOPE), 
        		"instantiate",
                new StringLiteral(requestType.getNamespaceURI()), 
                new StringLiteral(requestType.getLocalPart())));

        Triple<XsdElementDeclaration, Variable, StringLiteral> request = new Triple<XsdElementDeclaration, Variable, StringLiteral>(
        		requestElement,
                new Variable(CompilerConstants.SCRIPT_VARIABLE_REQUEST), 
                new StringLiteral(scopeId));

        // generic input mapping script
        sb.append(ScriptHelper.generateMappingCode(ctx, mappingId, usedContext, null, null, request));

        // retrieve text ids for the subject and message text
        ctx.getValidator().validate(activity.getSubject() != null, "BPM.rt_c_bpmn.000047", "Subject text of notification activity '%s' must be set.", activity.getOriginalName());
        ctx.getValidator().validate(activity.getMessageBody() != null, "BPM.rt_c_bpmn.000048", "Message body text of notification activity '%s' must be set.", activity.getOriginalName());
        IMoinUtils mu = ToolUtils.getInstance();
        String subjectId = mu.getTextId(activity.getSubject());
        String messsageId = mu.getTextId(activity.getMessageBody());
        
        // send notifications
        sb.append(ScriptHelper.generateInvocationCommand(
        		null,
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_NOTIFIER),
        		"sendNotification",
        		new StringLiteral(subjectId),
        		new StringLiteral(messsageId),
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_REQUEST)));
        
        // delete the notifier
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_NOTIFIER)));
        
        // delete scope
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_CALLSCOPE)));
        
        // token:state=<next>;
        int nextState = ctx.getState().getAfterTokenLabel(activity);
        sb.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), "state", new IntegerLiteral(nextState)));

        sb.append("}");
        return sb.toString();
    }
}
