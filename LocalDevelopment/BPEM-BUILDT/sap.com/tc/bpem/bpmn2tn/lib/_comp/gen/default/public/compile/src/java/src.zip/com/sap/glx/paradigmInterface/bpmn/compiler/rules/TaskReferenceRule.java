package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import javax.xml.namespace.QName;

import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.HumanActivity;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.OperationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SDOHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.tc.esmp.mm.wsdl2.Operation;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

/**
 * A compiler rule for human activities. Should be the same as {@link SubflowRule}.
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * @author Philipp Sommer
 */

public class TaskReferenceRule extends BaseCompilerRule<HumanActivity> implements CompilerRule<HumanActivity> {

    @SuppressWarnings("unchecked")
    public Class getSupportedArtifact() {
        return HumanActivity.class;
    }

    public void compile(HumanActivity activity, CompilerContext ctx) throws BPMNCompilerException {
        ctx.getValidator().validateConnectors(activity, 1, 1);

        Pair<String, Operation> endpoint = OperationHelper.getBPMNEndpoint(ctx, activity);
        ctx.getValidator().validate(activity.getReferencedScope() instanceof Task, "BPM.rt_c_bpmn.000054", //$NON-NLS-1$
                "Referenced task needs to be set for human activity '%s'.", activity.getOriginalName()); //$NON-NLS-1$

        // generate (a)synchronous targets for subflow start and end
        Target target_start_taskflow = ctx.getTargetFactory().generateTarget(activity, "start_taskflow"); // async
        Target target_end_taskflow = ctx.getTargetFactory().generateTarget(activity, "end_taskflow"); // async with matchlock

        // generate classes and configuration for outer input and output mapping
        Pair<IMappingCompiler.Summary, String> input_mapping = ctx.getMappingHelper().compile(activity.getInputMapping()), output_mapping = ctx
                .getMappingHelper().compile(activity.getOutputMapping());

        Pair<Set<DataContainer>, Set<DataContainer>> input_context = identifyInOutDataObjects(ctx, input_mapping.first, Direction.IN), output_context = identifyInOutDataObjects(
                ctx, output_mapping.first, Direction.INOUT);

        // build a context network for the outer input/output mapping
        @SuppressWarnings("unchecked")
        Set<DataContainer> used_input_context = union(input_context.first, input_context.second);
        @SuppressWarnings("unchecked")
        Set<DataContainer> used_output_context = union(output_context.first, output_context.second);

        // start subflow: join needed context to the "before" state of the token
        int channel = ctx.getState().getBeforeTokenSwitchExit(activity);
        if (used_input_context.isEmpty()) {
            NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), channel, target_start_taskflow, 0);
        } else {
            ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, activity.getScope(), activity, null, used_input_context);
            if (ctx.getRootScope().equals(activity.getScope())) {
                // is root scope, projection only contains data objects
                // instance=context.owner
                Join before_context_join = ctx.getJoinFactory().generateJoin(activity, "start_context_join", "0/1/-1", "1/0/0");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), channel, before_context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, before_context_join, 1);
                NodeFactory.connectNodes(before_context_join, 0, target_start_taskflow, 0);
            } else {
                // is in embedded scope, projection contains frame object as first element
                // token.frame=frame
                Join before_context_join = ctx.getJoinFactory().generateJoin(activity, "start_context_join", "0/0/2", "1/0/-1");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), channel, before_context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, before_context_join, 1);

                // for the target node the frame has to be removed now
                List<Integer> usedIndexes = new ArrayList<Integer>();
                // token and instance
                usedIndexes.add(0);
                usedIndexes.add(1);
                // ignore frame
                int runningIndex = 3;
                // data objects
                for (int i = 1; i <= projectionSwizzle.getLastIndex(); i++) {
                    usedIndexes.add(runningIndex++);
                }
                Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(activity, "context_no_frame_projection",
                        usedIndexes.toArray(new Integer[usedIndexes.size()]));
                NodeFactory.connectNodes(before_context_join, 0, noFrameSwizzle, 0);
                NodeFactory.connectNodes(noFrameSwizzle, 0, target_start_taskflow, 0);
            }
        }

        // start subflow: set scripts for start subflow target
        ctx.getTargetFactory().setScript(target_start_taskflow, generateStartScriptHeader(ctx, activity, used_input_context),
                generateStartScriptBody(ctx, activity, input_context.first, input_context.second, input_mapping.second));

        // end subflow: filter response for the right service+operation
        ConstantFilter response_filter = ctx.getConstantFilterFactory().generateFilter(activity, "filter_response", "0/0/0&0/0/1",
                "STRING:" + endpoint.first + "&STRING:" + endpoint.second.getName(), "==&==");
        NodeFactory.connectNodes(ctx.getState().getResponseSource(), 0, response_filter, 0);

        // end subflow: check if response was sent by the right kicker (=this
        // token) Token=Response.kicker
        Join end_kicker_join = ctx.getJoinFactory().generateJoin(activity, "end_kicker_join", "0/0/-1", "1/0/3");
        NodeFactory.connectNodes(ctx.getState().getTokenSwitchWithoutSuspend(), ctx.getState().getTokenSwitchExit(activity), end_kicker_join, 0);
        NodeFactory.connectNodes(response_filter, 0, end_kicker_join, 1);

        // triggernet fragment for match lock node
        // owner=token
        // ignore=instance
        // lock=response
        GenericOperator lock = ctx.getLockFactory().generateLock(activity, "lock_for_lock", 0, 1);
        NodeFactory.connectNodes(end_kicker_join, 0, lock, 0);

        //lock is already there, now only execute if instance is not suspended
        ConstantFilter suspendedFilter = ctx.getConstantFilterFactory().generateFilter(ctx.getRootScope(), "suspended", "0/1/3",
                "BOOLEAN:false", "==");
        NodeFactory.connectNodes(lock, 0, suspendedFilter, 0);
        
        // handling for depending views
        SortedSet<DataContainer> allViewDependencies = ctx.getState().getAllViewDependencies(used_output_context);
        used_output_context.addAll(allViewDependencies);
        
        // end subflow: join needed context to the "intermediate" state of the token
        if (used_output_context.isEmpty()) {
            NodeFactory.connectNodes(suspendedFilter, 0, target_end_taskflow, 0);
        } else {
            ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, activity.getScope(), activity, null, used_output_context);
            if (ctx.getRootScope().equals(activity.getScope())) {
                // is root scope, projection only contains data objects
                // instance=context.owner
                Join after_context_join = ctx.getJoinFactory().generateJoin(activity, "end_context_join", "0/1/-1", "1/0/0");
                NodeFactory.connectNodes(suspendedFilter, 0, after_context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, after_context_join, 1);
                NodeFactory.connectNodes(after_context_join, 0, target_end_taskflow, 0);
            } else {
                // is in embedded scope, projection contains frame object as first element
                // token.frame=frame
                Join after_context_join = ctx.getJoinFactory().generateJoin(activity, "end_context_join", "0/0/2", "1/0/-1");
                NodeFactory.connectNodes(suspendedFilter, 0, after_context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, after_context_join, 1);

                // for the target node the frame has to be removed now
                List<Integer> usedIndexes = new ArrayList<Integer>();
                // token, parent, response, ghost
                usedIndexes.add(0);
                usedIndexes.add(1);
                usedIndexes.add(2);
                usedIndexes.add(3);
                // ignore frame
                int runningIndex = 5;
                // data objects
                for (int i = 1; i <= projectionSwizzle.getLastIndex(); i++) {
                    usedIndexes.add(runningIndex++);
                }
                Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(activity, "context_no_frame_projection",
                        usedIndexes.toArray(new Integer[usedIndexes.size()]));
                NodeFactory.connectNodes(after_context_join, 0, noFrameSwizzle, 0);
                NodeFactory.connectNodes(noFrameSwizzle, 0, target_end_taskflow, 0);
            }
        }

        // end subflow: set scripts
        ctx.getTargetFactory().setScript(target_end_taskflow, generateEndScriptHeader(ctx, activity, used_output_context),
                generateEndScriptBody(ctx, activity, output_context.first, output_context.second, output_mapping.second));
    }

    private String generateStartScriptHeader(CompilerContext ctx, HumanActivity activity, Set<DataContainer> used_input_context) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), CompilerConstants.TARGET_START_TASKFLOW,
                activity));
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTokenSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getInstanceSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        for (DataContainer obj : used_input_context) {
            sb.append(", ");
            sb.append(ScriptHelper.generateClassDeclaration(ctx.getContextHelper().getClassByDataObject(obj), new Variable(ctx.getState()
                    .getContextVariableName(obj))));
        }

        sb.append(")");
        return sb.toString();
    }

    private String generateStartScriptBody(CompilerContext ctx, HumanActivity activity, Set<DataContainer> input_context_in,
            Set<DataContainer> input_context_out, String mapping_id) throws BPMNCompilerException {

        Pair<String, Operation> endpoint = OperationHelper.getBPMNEndpoint(ctx, activity);
        String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScope(endpoint.second), CompilerType.TYPECOMPILER);

        XsdElementDeclaration request = WSDLHelper.getRequestElement(endpoint.second);
        QName requestType = SDOHelper.generateSDOName(WSDLHelper.getElementType(request));

        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(activity));

        sb.append(ScriptHelper
                .generateScopeCode(ctx.getState().getControllerClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        // token:state=<intermediate>;
        sb.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), "state", new IntegerLiteral(ctx
                .getState().getTokenLabel(activity))));

        // request = new BPMNAdapter:Request(service,operation,parent,token);
        sb.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_REQUEST), new Pair<String, String>(
                CompilerConstants.ADAPTER_BPMN, CompilerConstants.GALAXY_REQUEST), new StringLiteral(endpoint.first), new StringLiteral(
                endpoint.second.getName()), new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        // scope_business = new TypeRegistry:GenericScope(parent,operation);
        sb.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_SCOPE + "_business"),
                new Pair<String, String>(CompilerConstants.ADAPTER_TYPEREGISTRY, CompilerConstants.GALAXY_GENERIC_SCOPE), new Variable(
                        CompilerConstants.SCRIPT_VARIABLE_PARENT), new StringLiteral(scopeId)));

        // document = scope_business:instantiate(<type ns>,<type name>);
        sb.append(ScriptHelper.generateInvocationCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_DOCUMENT), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_SCOPE + "_business"), "instantiate", new StringLiteral(requestType.getNamespaceURI()),
                new StringLiteral(requestType.getLocalPart())));

        // delete scope_business;
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_SCOPE + "_business")));

        // mapping onto request document
        sb.append(ScriptHelper.generateMappingCode(ctx, mapping_id, input_context_in, input_context_out, null,
                new Triple<XsdElementDeclaration, Variable, StringLiteral>(request,
                        new Variable(CompilerConstants.SCRIPT_VARIABLE_DOCUMENT), new StringLiteral(scopeId))));

        // request:setData(document);
        sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_REQUEST), "setData",
                new Variable(CompilerConstants.SCRIPT_VARIABLE_DOCUMENT)));

        // reset principal on the waiting token
        if (ctx.isPrincipalPropagationActive()) {
            sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                    CompilerConstants.METHOD_TOKEN_RESET_PRINCIPAL));
        }

        sb.append("}");
        return sb.toString();
    }

    private String generateEndScriptHeader(CompilerContext ctx, HumanActivity activity, Set<DataContainer> used_output_context) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), CompilerConstants.TARGET_END_SUBFLOW,
                activity));
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTokenSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_KICKER)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getInstanceSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(CompilerConstants.ADAPTER_BPMN, CompilerConstants.GALAXY_RESPONSE, new Variable(
                CompilerConstants.SCRIPT_VARIABLE_RESPONSE)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_GHOST)));

        for (DataContainer obj : used_output_context) {
            sb.append(", ");
            sb.append(ScriptHelper.generateClassDeclaration(ctx.getContextHelper().getClassByDataObject(obj), new Variable(ctx.getState()
                    .getContextVariableName(obj))));
        }

        sb.append(")");
        return sb.toString();
    }

    private String generateEndScriptBody(CompilerContext ctx, HumanActivity activity, Set<DataContainer> output_context_in,
            Set<DataContainer> output_context_out, String mapping_id) throws BPMNCompilerException {

        Pair<String, Operation> endpoint = OperationHelper.getBPMNEndpoint(ctx, activity);
        String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScope(endpoint.second), CompilerType.TYPECOMPILER);

        XsdElementDeclaration response = WSDLHelper.getResponseElement(endpoint.second);

        StringBuilder sb = new StringBuilder("{ ");

        sb.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER)));

        // frame=token:frame
        sb.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_KICKER), CompilerConstants.ATTRIBUTE_FRAME));

        // token=new token(instance, state, frame)
        sb.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), ctx.getState().getTokenClass(),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), new IntegerLiteral(ctx.getState().getAfterTokenLabel(activity)),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));

        if (ctx.isPrincipalPropagationActive()) {
            sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                    CompilerConstants.METHOD_TOKEN_COPY_PRINCIPAL_FROM_TOKEN, new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER)));
        }

        // document = response:getData();
        sb.append(ScriptHelper.generateInvocationCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_DOCUMENT), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_RESPONSE), "getData"));

        // mapping from response
        sb.append(ScriptHelper.generateMappingCode(ctx, mapping_id, output_context_in, output_context_out,
                new Triple<XsdElementDeclaration, Variable, StringLiteral>(response, new Variable(
                        CompilerConstants.SCRIPT_VARIABLE_DOCUMENT), new StringLiteral(scopeId)), null));

        // delete ghost;
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_GHOST)));

        // delete kicker
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER)));

        sb.append("}");
        return sb.toString();
    }

}
