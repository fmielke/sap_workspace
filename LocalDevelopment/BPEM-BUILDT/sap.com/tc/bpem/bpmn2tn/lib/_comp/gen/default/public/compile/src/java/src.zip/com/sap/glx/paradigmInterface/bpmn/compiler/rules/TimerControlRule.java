package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.rule.Expression;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.IntermediateCatchEvent;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Source;
import com.sap.glx.ide.model.triggernet.Switch;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.AdvancedScript;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Literal;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.LongLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptName;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;
import com.sap.mapping.base.compiler.IMappingCompiler;

/**
 * A compiler rule for timer control artifacts.
 * 
 * The rule generates a trigger network fragment, comprising three (partially exclusive) asynchronous transition:
 * <ol>
 * <li>{@link ScriptName#INTERMEDIATE_TIMER_COMPUTE_DURATION} initially computes the timer duration (the delay before the timer "fires")</li>
 * <li>{@link ScriptName#INTERMEDIATE_TIMER_NO_DELAY} skips the timer event if the delay was evaluated to a value of <= 0</li>
 * <li>{@link ScriptName#INTERMEDIATE_TIMER_SCHEDULE_JOB} creates a "Pulsar" object (for the "Chronometer" adapter) otherwise</li>
 * <li>{@link ScriptName#INTERMEDIATE_TIMER_ON_TICK} completes the timer event when the "Pulsar" has fired.
 * </ol>
 * The corresponding WANF conditions are as follows (where "E" means "exists", "~" means "not", "&&" means "and"):
 * <ul>
 * <li>{@link ScriptName#INTERMEDIATE_TIMER_COMPUTE_DURATION} (container objects omitted from condition):
 * 
 * <pre>
 * E Token token ( 
 *    E Instance instance (
 *       &tilde;instance.suspended &amp;&amp; token.owner==instance &amp;&amp; token.state==before &amp;&amp; &tilde;E Pulsar pulsar (
 *          pulsar.token==token &amp;&amp; &tilde;E Duration duration (
 *             duration.token==token 
 *          )
 *       )
 *    )
 * )
 * </pre>
 * 
 * </li>
 * 
 * <li>{@link ScriptName#INTERMEDIATE_TIMER_NO_DELAY}:
 * 
 * <pre>
 * E Token token (
 *    E Instance instance (
 *       &tilde;instance.suspended &amp;&amp; token.owner==instance &amp;&amp; token.state==before &amp;&amp; &tilde;E Pulsar pulsar (
 *          pulsar.token==token &amp;&amp; E Duration duration (
 *             duration.token==token &amp;&amp; &tilde;duration.value&gt;0 
 *          )
 *       )
 *    )
 * )
 * </pre>
 * 
 * </li>
 * 
 * <li>
 * {@link ScriptName#INTERMEDIATE_TIMER_SCHEDULE_JOB}:
 * 
 * <pre>
 * E Token token (
 *    E Instance instance (
 *       &tilde;instance.suspended &amp;&amp; token.owner==instance &amp;&amp; token.state==before &amp;&amp; &tilde;E Pulsar pulsar (
 *          pulsar.token==token &amp;&amp; E Duration duration (
 *             duration.token==token &amp;&amp; duration.value&gt;0 
 *          )
 *       )
 *    )
 * )
 * </pre>
 * 
 * </li>
 * 
 * <li>
 * {@link ScriptName#INTERMEDIATE_TIMER_ON_TICK}:
 * 
 * <pre>
 * E Token token (
 *    E Instance instance (
 *       token.owner==instance &amp;&amp; token.state==before &amp;&amp; E Pulsar pulsar (
 *          pulsar.token==0 &amp;&amp; instance.suspended==FALSE
 *       )
 *    )
 * )
 * </pre>
 * 
 * </li>
 * </ul>
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * @author Philipp Sommer
 * 
 */
public class TimerControlRule extends BaseCompilerRule<IntermediateCatchEvent> implements CompilerRule<IntermediateCatchEvent> {

    public Class<IntermediateCatchEvent> getSupportedArtifact() {
        throw new IllegalStateException("Should be never called. Creation through dispather rule."); //$NON-NLS-1$
    }

    public void compile(IntermediateCatchEvent timer, CompilerContext ctx) throws BPMNCompilerException {

        ctx.getValidator().validateConnectors(timer, 1, 1);

        Expression duration = timer.getExpression();
        ctx.getValidator().validate(duration != null, "BPM.rt_c_bpmn.000056", //$NON-NLS-1$
                "No duration specified for intermediate timer event '%s'.", timer.getOriginalName()); //$NON-NLS-1$

        GalaxyClass clsPulsar = ctx.getReplicator().generatePulsarClass(timer, ctx.getState().getTokenClass(), false);
        Source srcPulsar = ctx.getSourceFactory().generateSource(clsPulsar);

        GalaxyClass clsDuration = ctx.getReplicator().generateDurationClass(timer, ctx.getState().getInstanceClass(),
                ctx.getState().getTokenClass());
        Source srcDuration = ctx.getSourceFactory().generateSource(clsDuration);

        Pair<IMappingCompiler.Summary, String> extraction = ctx.getMappingHelper().compile(duration);
        LinkedHashSet<DataContainer> usedContext = identifySourceDataObjects(ctx, extraction.first);
        Target computeDurationTarget = generateComputeDurationTransition(ctx, timer, clsDuration, usedContext, extraction.second);

        // token.state=<before>
        int beforeLabel = ctx.getState().getBeforeTokenLabel(timer);
        // use no-suspend switch as pulsar would be deleted otherwise if process is suspended
        Switch tokenSwitchWithoutSuspend = ctx.getState().getTokenSwitchWithoutSuspend();

        // token = pulsar.token
        Join pulsarJoin = ctx.getJoinFactory().generateJoin(timer, "token_pulsar_join", "0/0/-1", "1/0/4");
        NodeFactory.connectNodes(tokenSwitchWithoutSuspend, beforeLabel, pulsarJoin, 0);
        NodeFactory.connectNodes(srcPulsar, 0, pulsarJoin, 1);

        // instance.suspended==FALSE
        ConstantFilter suspendedFilter = ctx.getConstantFilterFactory().generateFilter(timer, "suspended", "0/1/3", "BOOLEAN:false", "==");
        NodeFactory.connectNodes(pulsarJoin, 1, suspendedFilter, 0);

        // token = duration.token
        Join durationJoin = ctx.getJoinFactory().generateJoin(timer, "token_duration_join", "0/0/-1", "1/0/1");
        NodeFactory.connectNodes(suspendedFilter, 0, durationJoin, 0);
        NodeFactory.connectNodes(srcDuration, 0, durationJoin, 1);

        // duration.value>0
        ConstantFilter durationFilter = ctx.getConstantFilterFactory().generateFilter(clsDuration, "duration_filter", "0/2/2", "LONG:0",
                ">");
        NodeFactory.connectNodes(durationJoin, 0, durationFilter, 0);

        Target scheduleJobTarget = generateScheduleJobTransition(ctx, timer, clsPulsar, clsDuration);
        NodeFactory.connectNodes(durationFilter, 0, scheduleJobTarget, 0);

        Target noDelayTarget = generateNoDelayTarget(ctx, timer, clsDuration);
        NodeFactory.connectNodes(durationFilter, 1, noDelayTarget, 0);

        if (usedContext.isEmpty()) {
            NodeFactory.connectNodes(durationJoin, 1, computeDurationTarget, 0);
        } else {
            ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, timer.getScope(), timer, null, usedContext);
            if (ctx.getRootScope().equals(timer.getScope())) {
                // is root scope, projection only contains data objects
                Join context_join = ctx.getJoinFactory().generateJoin(timer, "join_context", "0/1/-1", "1/0/0");
                NodeFactory.connectNodes(durationJoin, 1, context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, context_join, 1);
                NodeFactory.connectNodes(context_join, 0, computeDurationTarget, 0);
            } else {
                // is in embedded scope, projection contains frame object as
                // first element
                // token.frame=frame
                Join context_join = ctx.getJoinFactory().generateJoin(timer, "join_context", "0/0/2", "1/0/-1");
                NodeFactory.connectNodes(durationJoin, 1, context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, context_join, 1);

                // for the target node the frame has to be removed now
                List<Integer> usedIndexes = new ArrayList<Integer>();
                // token and instance
                usedIndexes.add(0);
                usedIndexes.add(1);
                // ignore frame
                int runningIndex = 3;
                // data objects
                for (int i = 1; i <= projectionSwizzle.getLastIndex(); i++) {
                    usedIndexes.add(runningIndex++);
                }
                Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(timer, "context_no_frame_projection",
                        usedIndexes.toArray(new Integer[usedIndexes.size()]));
                NodeFactory.connectNodes(context_join, 0, noFrameSwizzle, 0);
                NodeFactory.connectNodes(noFrameSwizzle, 0, computeDurationTarget, 0);
            }
        }

        ConstantFilter suspendedTickFilter = ctx.getConstantFilterFactory().generateFilter(timer, "suspended_tick", "0/1/3&0/2/0",
                "BOOLEAN:false&LONG:1", "==&==");
        NodeFactory.connectNodes(pulsarJoin, 0, suspendedTickFilter, 0);
        Target onTickTarget = generateOnTickTransition(ctx, timer, clsPulsar);
        NodeFactory.connectNodes(suspendedTickFilter, 0, onTickTarget, 0);

        NodeFactory.connectNodes(pulsarJoin, 2, ctx.getReplicator().getDrain(), 0);
    }

    /**
     * Generates a target node (async) for initially computing the timer duration and storing the resulting value in a "Duration"
     * {@link GalaxyClass}.
     * 
     * <pre>
     * &lt;i&gt;scoping instrumentation code&lt;/i&gt;
     * duration = &lt;i&gt;expression evaluation code&lt;/i&gt;
     * &lt;b&gt;new&lt;/b&gt; BPMNAdapter:Duration(duration, token);
     * </pre>
     * 
     * @param ctx
     *            is the {@link CompilerContext} instance.
     * @param timer
     *            is the {@link IntermediateCatchEvent} representing the timer control.
     * @param clsDuration
     *            is the {@link GalaxyClass} (BPMNAdapter) for temporarily storing calculated delays of this timer control.
     * @param context
     *            is the (ordered) set of context objects needed to calculate the duration expression.
     * @param expressionId
     *            is the version identifier of the mapping expression.
     * @return a target node.
     * @throws BPMNCompilerException
     */
    private Target generateComputeDurationTransition(CompilerContext ctx, IntermediateCatchEvent timer, GalaxyClass clsDuration,
            LinkedHashSet<DataContainer> context, String expressionId) throws BPMNCompilerException {
        AdvancedScript script = new AdvancedScript(ctx, ScriptName.INTERMEDIATE_TIMER_COMPUTE_DURATION, timer);
        ScriptVariable varToken = script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        ScriptVariable varInstance = script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        List<ScriptVariable> varContext = new ArrayList<ScriptVariable>(context.size());
        for (DataContainer container : context) {
            varContext.add(script.addParameter(ctx.getState().getContextVariable(container), ctx.getContextHelper().getClassByDataObject(
                    container)));
        }
        script.generateScopeCode(varToken);

        // duration = ...
        ScriptVariable varDuration = script.generateExpressionCode(expressionId, context, null, ScriptVariable.DURATION, ctx.getSimpleTypes().LONG);

        // new Duration(instance, token, duration);
        script.generateNewCommand(null, clsDuration, varInstance, varToken, varDuration);
        return script.getTarget();
    }

    /**
     * Generates a target node to create a "Pulsar" instance which triggers the JEE scheduler at runtime (thru the "Chronometer" adapter).
     * 
     * <pre>
     * value = duration:value;
     * &lt;b&gt;new&lt;/b&gt; Chronometer:Pulsar(0l, 1l, value, null, token);
     * &lt;b&gt;delete&lt;/b&gt; duration;
     * </pre>
     * 
     * @param ctx
     *            is the {@link CompilerContext} instance.
     * @param timer
     *            is the {@link IntermediateCatchEvent} instance, representing the timer control.
     * @param clsPulsar
     *            is the "Pulsar" {@link GalaxyClass} (Chronometer) for this timer control.
     * @param clsDuration
     *            is the "Duration" {@link GalaxyClass} (BPMNAdapter) for this timer control.
     * @return a target node.
     */
    private Target generateScheduleJobTransition(CompilerContext ctx, IntermediateCatchEvent timer, GalaxyClass clsPulsar,
            GalaxyClass clsDuration) throws BPMNCompilerException {
        AdvancedScript script = new AdvancedScript(ctx, ScriptName.INTERMEDIATE_TIMER_SCHEDULE_JOB, timer);
        ScriptVariable varToken = script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        ScriptVariable varDuration = script.addParameter(ScriptVariable.DURATION, clsDuration);

        // value = duration:value;
        script.generateAssignCommand(ScriptVariable.VALUE, varDuration, CompilerConstants.ATTRIBUTE_VALUE);

        // new Pulsar(0l, 1l, duration, null, token);
        script.generateNewCommand(null, clsPulsar, new LongLiteral(0l), new LongLiteral(1l), ScriptVariable.VALUE, Literal.NULL, varToken);

        // delete duration
        script.generateDeleteCommand(varDuration);

        return script.getTarget();
    }

    /**
     * Generates a target node (async) whose script fires whenever the timer had a zero-length delay (i.e., no "Pulsar" instance was ever
     * created).
     * 
     * <pre>
     * token:state = <i>behind timer control</i>;
     * <b>delete</b> duration;
     * </pre>
     * 
     * @param ctx
     *            is the {@link CompilerContext} instance.
     * @param timer
     *            is the timer control.
     * @param clsDuration
     *            is the "Duration" (BPMNAdapter) {@link GalaxyClass}
     * @return a target node.
     * @throws BPMNCompilerException
     */
    private Target generateNoDelayTarget(CompilerContext ctx, IntermediateCatchEvent timer, GalaxyClass clsDuration)
            throws BPMNCompilerException {
        AdvancedScript script = new AdvancedScript(ctx, ScriptName.INTERMEDIATE_TIMER_NO_DELAY, timer);
        ScriptVariable varToken = script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        ScriptVariable varInstance = script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        ScriptVariable varDuration = script.addParameter(ScriptVariable.DURATION, clsDuration);

        script.generateDebugCode(varInstance, varToken);

        // token:state=<next>;
        script.generateUpdateCommand(varToken, CompilerConstants.ATTRIBUTE_STATE, new IntegerLiteral(ctx.getState().getAfterTokenLabel(
                timer)));

        // delete duration;
        script.generateDeleteCommand(varDuration);

        return script.getTarget();
    }

    /**
     * Generates a target node (async) whose script fires after the JEE scheduler has changed the Pulsar's "tick" attribute.
     * 
     * <pre>
     * token:state = <i>behind timer control</i>;
     * <b>delete</b> pulsar;
     * </pre>
     * 
     * @param ctx
     *            is the {@link CompilerContext} instance.
     * @param timer
     *            is the timer control.
     * @param clsPulsar
     *            is the "Pulsar" (Chronometer) {@link GalaxyClass}
     * @return a target node.
     * @throws BPMNCompilerException
     */
    private Target generateOnTickTransition(CompilerContext ctx, IntermediateCatchEvent timer, GalaxyClass clsPulsar)
            throws BPMNCompilerException {
        AdvancedScript script = new AdvancedScript(ctx, ScriptName.INTERMEDIATE_TIMER_ON_TICK, timer);
        ScriptVariable varToken = script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        ScriptVariable varInstance = script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        ScriptVariable varPulsar = script.addParameter(ScriptVariable.PULSAR, clsPulsar);
        script.generateDebugCode(varInstance, varToken);

        // token:state=<next>;
        script.generateUpdateCommand(varToken, CompilerConstants.ATTRIBUTE_STATE, new IntegerLiteral(ctx.getState().getAfterTokenLabel(
                timer)));

        // delete pulsar;
        script.generateDeleteCommand(varPulsar);
        return script.getTarget();
    }

}
