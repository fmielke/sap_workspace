package com.sap.glx.paradigmInterface.bpmn.compiler.scripts;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import javax.xml.namespace.QName;

import com.sap.glx.ide.model.classes.SimpleType;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SDOHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WorkflowHelper;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

/**
 * The AdavancedScript class provides additional methods for scripts for
 * <ul>
 * <li>debugging instrumentation</li>
 * <li>exception scoping</li>
 * <li>mapping execution</li>
 * </ul>
 * 
 * @author Philipp Sommer
 */
public class AdvancedScript extends Script {

    private static final Pair<String, String> clsExit = new Pair<String, String>(CompilerConstants.ADAPTER_BPMN,
            CompilerConstants.GALAXY_EXIT);
    private static final Pair<String, String> clsController = new Pair<String, String>(CompilerConstants.ADAPTER_EXCEPTION,
            CompilerConstants.GALAXY_CONTROLLER);    
    private static final Pair<String, String> clsData = new Pair<String, String>(CompilerConstants.ADAPTER_TRANSFORMER,
            CompilerConstants.GALAXY_DATA);
    private static final Pair<String, String> clsExtractor = new Pair<String, String>(CompilerConstants.ADAPTER_TRANSFORMER,
            CompilerConstants.GALAXY_COMPUTER);
    private static final Pair<String, String> clsMapper = new Pair<String, String>(CompilerConstants.ADAPTER_TRANSFORMER,
            CompilerConstants.GALAXY_TRANSFORMATOR);
    private static final Pair<String, String> clsScope = new Pair<String, String>(CompilerConstants.ADAPTER_TYPEREGISTRY,
            CompilerConstants.GALAXY_GENERIC_SCOPE);

    public AdvancedScript(CompilerContext ctx, ScriptName prefix, MessageFlowObject element) throws ScriptException {
        super(ctx, prefix, element);
    }

    /**
     * Generates business debugger instrumentation BPMN flow elements. This script snippet must be placed inside those transitions which
     * perform the logics of a certain BPMN artifact.
     * 
     * @param varInstance variable representing the BPMN instance
     * @param varToken variable representing the BPMN token
     */
    public void generateDebugCode(ScriptVariable varInstance, ScriptVariable varToken) {
        ScriptVariable varExit = generateNewCommand(ScriptVariable.EXIT, clsExit);
        int lifecycle = CompilerConstants.BITMASK_ON_ACTIVATION;
        if ((lifecycle & CompilerConstants.BITMASK_ON_ACTIVATION) == CompilerConstants.BITMASK_ON_ACTIVATION)
            generateInvocationCommand(varExit, "onActivation", new StringLiteral(modelElement.refMofId()), varInstance, varToken);
        if ((lifecycle & CompilerConstants.BITMASK_BEFORE_COMPLETION) == CompilerConstants.BITMASK_BEFORE_COMPLETION)
            generateInvocationCommand(varExit, "beforeCompletion", new StringLiteral(modelElement.refMofId()), varInstance, varToken);
        if ((lifecycle & CompilerConstants.BITMASK_AFTER_COMPLETION) == CompilerConstants.BITMASK_AFTER_COMPLETION)
            generateInvocationCommand(varExit, "afterCompletion", new StringLiteral(modelElement.refMofId()), varInstance, varToken);
        if ((lifecycle & CompilerConstants.BITMASK_ON_FAILURE) == CompilerConstants.BITMASK_ON_FAILURE)
            generateInvocationCommand(varExit, "onFailure", new StringLiteral(modelElement.refMofId()), varInstance, varToken);
        generateDeleteCommand(varExit);
    }

    /**
     * Generates a "scoping" code snippet which publishes the current scope (aka subflow instance). Used for business logging and exception
     * handling.
     * 
     * @param varScope variable representing the current scope (in most cases a token)
     */
    public void generateScopeCode(ScriptVariable varScope) {
        ScriptVariable varController = generateNewCommand(ScriptVariable.CONTROLLER, clsController);
        generateInvocationCommand(null, varController, "setContext", varScope);
        generateDeleteCommand(varController);
    }
    
    @SuppressWarnings("unchecked")
    public void generateMappingCode(String mappingId, Collection<DataContainer> contextInputs, Collection<DataContainer> contextOutputs,
            Triple<ScriptVariable, XsdElementDeclaration, String> localInputs, Triple<ScriptVariable, XsdElementDeclaration, String> localOutputs) {
        
        // create mapper
        ScriptVariable varMapper = generateNewCommand(ScriptVariable.MAPPER, clsMapper);
        
        // create general mapping
        generateMappingCodeInternal(mappingId, contextInputs, contextOutputs,
                localInputs != null ? new HashSet<Triple<ScriptVariable, XsdElementDeclaration, String>>(Arrays.asList(localInputs)) : null,
                localOutputs != null ? new HashSet<Triple<ScriptVariable, XsdElementDeclaration, String>>(Arrays.asList(localOutputs)) : null);
        
        // viewUpdater=new ContainerAdapter:ViewUpdater();
        generateNewCommand(ScriptVariable.VIEW_UPDATER, new Pair<String, String>(
                "com.sap.glx.adapter.internal.ContainerAdapter", "ViewUpdater"));
        
        // generate additional mapping code for optimized view update
        ScriptHelper.generateMappingCodeForDependingViews(contextOutputs, this.body, ctx);
        
        generateDeleteCommand(ScriptVariable.VIEW_UPDATER);
        generateDeleteCommand(varMapper);
    }

    /**
     * Generates new-style mapping script code making use of the generic "Transformator" class.
     * 
     * @param ctx is the compiler context.
     * @param mappingId is the mapping id (before proper mapping versioning: <Mapping MOFID>_<flow version>, after that: the mapping
     * version#)
     * @param contextInputs is a collection of global input parameters (DataContainer entities). Notice that the corresponding variable
     * names are used and these must be bound to an instance of the container (DataContainer GalaxyObject).
     * @param contextOutputs is a collection of global output parameters (DataContainer entities). Notice that the corresponding variable
     * names are used and these must be bound to an instance of the container (DataContainer GalaxyObject).
     * @param localInputs is a collection local input parameters given as tuples of an XSD element (which is the type of the local SDO
     * variable), the local variable name, and the type scope version. Notice that the local variable is supposed to be instantiated before!
     * No instantiation code is generated as part of this script.
     * @param localOutputs is a collection local output parameters given as tuples of an XSD element (which is the type of the local SDO
     * variable), the local variable name, and the type scope version. Notice that the local variable is supposed to be instantiated before!
     * No instantiation code is generated as part of this script.
     */
    private void generateMappingCodeInternal(String mappingId, Collection<DataContainer> contextInputs, Collection<DataContainer> contextOutputs,
            Set<Triple<ScriptVariable, XsdElementDeclaration, String>> localInputs,
            Set<Triple<ScriptVariable, XsdElementDeclaration, String>> localOutputs) {

        // create input and output data
        ScriptVariable varYvesIn = createInputData(localInputs, contextInputs);
        ScriptVariable varYvesOut = createOutputData(localOutputs, contextOutputs);

        // mapper:map("mapping id", <context_in>,<context out>);
        generateInvocationCommand(ScriptVariable.MAPPER, "map", new StringLiteral(mappingId), varYvesIn, varYvesOut);

        // fetches the local output context
        if (localOutputs != null) {
            for (Triple<ScriptVariable, XsdElementDeclaration, String> localOutput : localOutputs) {
                QName name = SDOHelper.generateSDOName(localOutput.second);
                generateInvocationCommand(localOutput.first, varYvesOut, "getData", new StringLiteral(name.getNamespaceURI()),
                        new StringLiteral(name.getLocalPart()), new StringLiteral(localOutput.third));
            }
        }

        // fetches the global output context
        if (contextOutputs != null) {
            for (DataContainer contextOutput : contextOutputs) {
                if (WorkflowHelper.isTaskStatusDataObject(ctx, contextOutput)) {
                    // nothing to do, mapping has already modified the task object in place
                } else {
                    // data = mapper:getOutput(<element ns>, <element name>, scope);
                    ScriptVariable varContextOutput = ctx.getState().getContextVariable(contextOutput);
                    String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScopeOld(contextOutput),
                            CompilerType.TYPECOMPILER);
                    QName name = SDOHelper.generateSDOName(contextOutput.getXsdElementDeclaration());

                    ScriptVariable varData = generateInvocationCommand(ScriptVariable.DATA, varYvesOut, "getData", new StringLiteral(name
                            .getNamespaceURI()), new StringLiteral(name.getLocalPart()), new StringLiteral(scopeId));

                    // context:setData(data);
                    generateInvocationCommand(varContextOutput, "setData", varData);
                }
            }
        }

        // cleanup of created objects
        generateDeleteCommand(varYvesIn);
        generateDeleteCommand(varYvesOut);
    }

    /**
     * Generates new-style extraction script code making use of the generic "Computer" class.
     * 
     * @param expressionId is the expression id (before proper mapping versioning: <Expression MOFID>_<flow version>, after that: the
     * expression version#)
     * @param contextInputs is a collection of global input parameters (DataContainer entities). Notice that the corresponding variable
     * names are used and these must be bound to an instance of the container (DataContainer GalaxyObject).
     * @param localInputs is a collection local input parameters given as tuples of an XSD element (which is the type of the local SDO
     * variable), the local variable name, and the type scope version. Notice that the local variable is supposed to be instantiated before!
     * No instantiation code is generated as part of this script.
     * @param varTarget is the script variable the result of the expression shall be assigned to.
     * @return the script code to do the extraction.
     */
    public ScriptVariable generateExpressionCode(String expressionId, Collection<DataContainer> contextInputs,
            Set<Triple<ScriptVariable, XsdElementDeclaration, String>> localInputs, ScriptVariable varTarget, SimpleType type) {

        // create extractor and input data
        ScriptVariable varExtractor = generateNewCommand(ScriptVariable.EXTRACTOR, clsExtractor);
        ScriptVariable varYvesIn = createInputData(localInputs, contextInputs);

        // target=computer:extract(<expression id>, yves_in, <target type>);
        generateInvocationCommand(varTarget, varExtractor, "extractAs", new StringLiteral(expressionId), varYvesIn, new StringLiteral(type
                .getType().toString().toUpperCase(Locale.ENGLISH)));

        // cleanup of created objects
        generateDeleteCommand(varYvesIn);
        generateDeleteCommand(varExtractor);

        return varTarget;
    }

    private ScriptVariable createInputData(Set<Triple<ScriptVariable, XsdElementDeclaration, String>> localInputs,
            Collection<DataContainer> contextInputs) {
        // create input data object
        ScriptVariable varYvesIn = generateNewCommand(ScriptVariable.YVES_IN, clsData);

        // sets the local input context
        if (localInputs != null) {
            for (Triple<ScriptVariable, XsdElementDeclaration, String> localInput : localInputs) {
                // yves_in:setData(<ns>,<name>,<variable name>,scope);
                QName name = SDOHelper.generateSDOName(localInput.second);
                generateInvocationCommand(varYvesIn, "setData", new StringLiteral(name.getNamespaceURI()), new StringLiteral(name
                        .getLocalPart()), localInput.first, new StringLiteral(localInput.third));
            }
        }

        // sets the global input context
        if (contextInputs != null) {
            for (DataContainer contextInput : contextInputs) {
                // fetch the variable
                ScriptVariable varContextInput = ctx.getState().getContextVariable(contextInput);

                // fetch the type scope id from the IBuilderHost
                String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScopeOld(contextInput), CompilerType.TYPECOMPILER);

                // compute the renamed SDO name of the payload (this is what the mapping assumes)
                QName name = SDOHelper.generateSDOName(contextInput.getXsdElementDeclaration());

                if (WorkflowHelper.isTaskStatusDataObject(ctx, contextInput)) {
                    // yves_in:setData(<element ns>,<element name>,<variable>,<scope_id>);
                    generateInvocationCommand(varYvesIn, "setData", new StringLiteral(name.getNamespaceURI()), new StringLiteral(name
                            .getLocalPart()), varContextInput, new StringLiteral(scopeId));
                } else {
                    // data=<variable>:getData();
                    ScriptVariable varData = generateInvocationCommand(ScriptVariable.DATA, varContextInput, "getData");

                    // yves_in:setData(<element ns>,<element name>,data,<scope_id>);
                    generateInvocationCommand(varYvesIn, "setData", new StringLiteral(name.getNamespaceURI()), new StringLiteral(name
                            .getLocalPart()), varData, new StringLiteral(scopeId));
                }
            }
        }

        return varYvesIn;
    }

    private ScriptVariable createOutputData(Set<Triple<ScriptVariable, XsdElementDeclaration, String>> localOutputs,
            Collection<DataContainer> contextOutputs) {
        // create output data object
        ScriptVariable varYvesOut = generateNewCommand(ScriptVariable.YVES_OUT, clsData);

        // sets the local output context
        if (localOutputs != null) {
            for (Triple<ScriptVariable, XsdElementDeclaration, String> localOutput : localOutputs) {
                // yves_out:setOutput(<ns>,<name>,<local name>,scope);
                QName name = SDOHelper.generateSDOName(localOutput.second);
                generateInvocationCommand(varYvesOut, "setData", new StringLiteral(name.getNamespaceURI()), new StringLiteral(name
                        .getLocalPart()), localOutput.first, new StringLiteral(localOutput.third));
            }
        }

        // sets the global output context
        if (contextOutputs != null) {
            for (DataContainer contextOutput : contextOutputs) {
                ScriptVariable varContextOutput = ctx.getState().getContextVariable(contextOutput);
                String scopeId = ctx.getHost()
                        .getVersionId(ctx.getDependencyHelper().getScopeOld(contextOutput), CompilerType.TYPECOMPILER);
                QName name = SDOHelper.generateSDOName(contextOutput.getXsdElementDeclaration());

                if (WorkflowHelper.isTaskStatusDataObject(ctx, contextOutput)) {
                    generateInvocationCommand(varYvesOut, "setData", new StringLiteral(name.getNamespaceURI()), new StringLiteral(name
                            .getLocalPart()), varContextOutput, new StringLiteral(scopeId));
                } else {
                    // bind context; (lock for write)
                    if (isParameter(varContextOutput))
                        generateBindCommand(varContextOutput);

                    // data=context:getData();
                    ScriptVariable varData = generateInvocationCommand(ScriptVariable.DATA, varContextOutput, "getData");

                    // scope=new GenericScope(NULL,scope_id);
                    ScriptVariable varScope = generateNewCommand(ScriptVariable.SCOPE, clsScope, Literal.NULL, new StringLiteral(scopeId));

                    // copy = scope:copy(data);
                    ScriptVariable varCopy = generateInvocationCommand(ScriptVariable.COPY, varScope, "copy", varData);

                    // delete scope;
                    generateDeleteCommand(varScope);

                    generateInvocationCommand(varYvesOut, "setData", new StringLiteral(name.getNamespaceURI()), new StringLiteral(name
                            .getLocalPart()), varCopy, new StringLiteral(scopeId));
                }
            }
        }
        return varYvesOut;
    }
}
