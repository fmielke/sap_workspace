package com.sap.glx.paradigmInterface.bpmn.compiler.scripts;

/**
 * IntegerLiteral in trigger network scripts
 * 
 * @author Philipp Sommer
 */
public class IntegerLiteral extends Literal<Integer> implements Parameter {

    public static IntegerLiteral ZERO = new IntegerLiteral(0);

    public IntegerLiteral(int value) {
        super(value);
    }
}
