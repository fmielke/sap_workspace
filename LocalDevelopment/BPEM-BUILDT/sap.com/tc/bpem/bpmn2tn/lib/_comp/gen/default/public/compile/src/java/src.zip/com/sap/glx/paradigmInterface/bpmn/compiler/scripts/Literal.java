package com.sap.glx.paradigmInterface.bpmn.compiler.scripts;

import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;


public class Literal<T> implements Parameter {
    
    public static Literal<Object> NULL = new Literal<Object>(null);
    
    protected T value;
    
    protected Literal(T value) {
        this.value = value;
    }

    public String toString() {
        return value != null ? value.toString() : CompilerConstants.SCRIPT_VALUE_NULL;
    }
}
