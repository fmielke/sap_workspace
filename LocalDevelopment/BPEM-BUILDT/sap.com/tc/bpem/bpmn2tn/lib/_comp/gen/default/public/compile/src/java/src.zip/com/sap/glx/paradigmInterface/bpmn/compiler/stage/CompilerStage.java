package com.sap.glx.paradigmInterface.bpmn.compiler.stage;

import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

/**
 * An interface representing one of the many compiler stages, which are executed in a fixed order during the BPMN2TN
 * compilation process.
 * 
 * @author Thilo-Alexander Ginkel
 * 
 * @version $Id: //bpem/bpem.bp/NW731EXT_10_REL/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2tn/lib/_comp/src/com/sap/glx/paradigmInterface/bpmn/compiler/stage/CompilerStage.java#1 $
 */
public interface CompilerStage {

    /**
     * Executes the compiler stage, i.e. applies the stage's changes to the compiler state.
     * @param ctx the compiler context
     * @throws BPMNCompilerException if a compilation error occurred
     */
    void execute(CompilerContext ctx) throws BPMNCompilerException;
}
