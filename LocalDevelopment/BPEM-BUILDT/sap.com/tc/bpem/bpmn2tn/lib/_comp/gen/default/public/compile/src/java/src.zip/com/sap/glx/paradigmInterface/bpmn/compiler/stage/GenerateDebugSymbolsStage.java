package com.sap.glx.paradigmInterface.bpmn.compiler.stage;

import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

/**
 * Generates debug symbols at the end of the compilation process.
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * 
 * @version $Id: //bpem/bpem.bp/NW731EXT_10_REL/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2tn/lib/_comp/src/com/sap/glx/paradigmInterface/bpmn/compiler/stage/GenerateDebugSymbolsStage.java#1 $
 */
public class GenerateDebugSymbolsStage implements CompilerStage {

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.stage.CompilerStage#execute(com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext)
     */
    public void execute(CompilerContext ctx) throws BPMNCompilerException {
        /*
        for (MessageFlowObject flow_object : getFlowObjects(ctx.getRootScope())) {
            // retrieve target nodes for this BPMN artifact
            ctx.getConfigFactory().generateDebugSymbolConfiguration(ctx.getState().getInstanceSource().getGalaxyClass(), flow_object,
                    ctx.getTargetFactory().getDebugSymbols(flow_object));
            // retrieve execution nodes for this BPMN artifact
            ctx.getConfigFactory().generateDebugSymbolConfiguration(ctx.getState().getInstanceSource().getGalaxyClass(), flow_object,
                    ctx.getExecutionFactory().getDebugSymbols(flow_object));
        }
        */
    }
}
