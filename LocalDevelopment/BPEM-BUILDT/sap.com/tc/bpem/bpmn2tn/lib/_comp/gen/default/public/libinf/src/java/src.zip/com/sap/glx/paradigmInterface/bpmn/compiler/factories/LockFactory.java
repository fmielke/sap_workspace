package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;

public class LockFactory extends NodeFactory {

    private static final String JAVA_CLASS = "com.sap.glx.core.kernel.trigger.node.WheelLockNode"; //$NON-NLS-1$

    public LockFactory(ITriggernetFacade facade, Subnet subnet) {
        super(facade, subnet);
    }

    @Override
    protected String getNodePrefix() {
        return "WHEEL_LOCK"; //$NON-NLS-1$
    }

    @Override
    protected int getInputCount() {
        return 1;
    }

    @Override
    protected int getOutputCount() {
        return 1;
    }

    private GenericOperator generateLock(int owner, int... ignore) {
        GenericOperator generic = createElement(GenericOperator.class);
        generic.getParameters().add(Integer.toString(owner));
        if (ignore.length > 0) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < ignore.length; i++) {
                if (i != 0) {
                    // ignore parameters separated by pipe symbol
                    sb.append("|");
                }
                sb.append(ignore[i]);
            }
            generic.getParameters().add(sb.toString());
        }
        generic.setImplementationClass(JAVA_CLASS);
        return generic;
    }

    public GenericOperator generateLock(ModelElement artifact, String name, int owner, int... ignore) {
        GenericOperator lock = generateLock(owner, ignore);
        prepareNode(lock, artifact, name);
        return lock;
    }

    public GenericOperator generateLock(GalaxyClass cls, String name, int owner, int... ignore) {
        GenericOperator lock = generateLock(owner, ignore);
        prepareNode(lock, cls, name);
        return lock;
    }
}
