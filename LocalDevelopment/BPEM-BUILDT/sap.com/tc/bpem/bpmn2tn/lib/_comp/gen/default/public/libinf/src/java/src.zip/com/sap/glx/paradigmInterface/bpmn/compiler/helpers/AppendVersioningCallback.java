package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import com.sap.glx.ide.model.configuration.ConfigurationString;

public class AppendVersioningCallback extends AbstractVersioningCallback<ConfigurationString> {
    String delim = "_";

    public AppendVersioningCallback(ConfigurationString anchor) {
        super(null, anchor);
    }

    public AppendVersioningCallback(ConfigurationString anchor, String delim) {
        super(null, anchor);
        this.delim = delim;
    }
    
    public AppendVersioningCallback(ConfigurationString anchor, char delim) {
        this(anchor, Character.toString(delim));
    }

    public void incorporateVersionIdentifier(String version_id) {
        if (!anchor.getValue().endsWith(version_id))
            anchor.setValue(anchor.getValue() + delim + version_id);
    }

}
