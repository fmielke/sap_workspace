package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.classes.Type;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.ide.model.galaxy.workflow.AutomatedActivity;
import com.sap.glx.ide.model.galaxy.workflow.BoundaryEvent;
import com.sap.glx.ide.model.galaxy.workflow.CatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.ConditionalSequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.DataObject;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.Event;
import com.sap.glx.ide.model.galaxy.workflow.IntermediateCatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Source;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.FrameNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Script;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptName;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

public class ClassHelper {
    private final CompilerContext context;

    private final Target black_hole, singularity;
    private final GenericOperator drain;
    private final Map<Integer, Join> cleanupJoinsInstance;

    public ClassHelper(final CompilerContext ctx) throws BPMNCompilerException {
        this.context = ctx;

        black_hole = generateBlackHole(ctx);
        singularity = generateSingularity(ctx);
        drain = generateDrain(ctx);

        // create a map for join nodes which are connected to the black hole
        cleanupJoinsInstance = new HashMap<Integer, Join>();
    }

    private Target generateBlackHole(final CompilerContext ctx) throws BPMNCompilerException {
        final Script script = new Script(ctx, ScriptName.BLACK_HOLE, null);
        final ScriptVariable varObject = script.addParameter(ScriptVariable.OBJECT);
        script.generateDeleteCommand(varObject);
        return script.getTarget();
    }

    private Target generateSingularity(final CompilerContext ctx) throws BPMNCompilerException {
        final Script script = new Script(ctx, ScriptName.SINGULARITY, null);
        final ScriptVariable varObject = script.addParameter(ScriptVariable.OBJECT);
        script.generateDeleteCommand(varObject);
        return script.getTarget();
    }

    private GenericOperator generateDrain(final CompilerContext ctx) throws BPMNCompilerException {
        final Script script = new Script(ctx, ScriptName.DISRUPTOR, null);
        final ScriptVariable varObject = script.addParameter(ScriptVariable.OBJECT);
        script.generateDeleteCommand(varObject);
        return script.getExecution();
    }

    public GalaxyClass generateListenerClass(final Scope scope) throws BPMNCompilerException {
        final GalaxyClass listener_class = context.getClassFactory().generateClass(scope, CompilerConstants.GALAXY_LISTENER,
                CompilerConstants.ADAPTER_BPMN);
        context.getClassFactory().addAttribute(listener_class, "source", context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addAttribute(listener_class, "target", context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addAttribute(listener_class, "modifications", context.getSimpleTypes().INTEGER);
        context.getSourceFactory().generateSource(listener_class);

        return listener_class;

    }

    /**
     * Create a new CorrelationTrigger class for the Sunbeam for Correlation feature.
     * 
     * @param artifact
     * @return A new CorrelationTrigger galaxy class
     * @throws BPMNCompilerException
     */
    public GalaxyClass generateCorrelationTriggerClass(final MessageFlowObject artifact) throws BPMNCompilerException {
        final GalaxyClass correlationTriggerClass = context.getClassFactory().generateClass(artifact,
                CompilerConstants.GALAXY_CORRELATION_TRIGGER, CompilerConstants.ADAPTER_CORRELATION);

        context.getClassFactory().addAttribute(correlationTriggerClass, CompilerConstants.ATTRIBUTE_OWNER,
                context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addAttribute(correlationTriggerClass, "sdoRef", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, CompilerConstants.ATTRIBUTE_PP_USERNAME,
                context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, CompilerConstants.ATTRIBUTE_PP_HASH,
                context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, "messageId", context.getSimpleTypes().STRING);

        // SDO<payload> correlationTrigger.getData();
        context.getClassFactory().addMethod(correlationTriggerClass, "getData", context.getSimpleTypes().SDO);
        // void correlationTrigger.logConsumption(instance,<mofId of Intermediate Message Event>);
        context.getClassFactory().addMethod(correlationTriggerClass, CompilerConstants.METHOD_CORRELATIONTRIGGER_LOG_CONSUMPTION,
                context.getSimpleTypes().VOID, context.getSimpleTypes().REFERENCE, context.getSimpleTypes().STRING);

        context.getSourceFactory().generateSource(correlationTriggerClass);
        return correlationTriggerClass;
    }

    /**
     * Create a new ConditionalStartCorrelationTrigger class for matched messages in a conditional start scenario.
     * Part of the Sunbeam for Correlation feature.
     */
    public GalaxyClass generateConditionalStartCorrelationTriggerClass(final MessageFlowObject artifact) throws BPMNCompilerException {
        final GalaxyClass correlationTriggerClass = context.getClassFactory().generateClass(artifact,
                CompilerConstants.GALAXY_CONDITIONAL_START_CORRELATION_TRIGGER, CompilerConstants.ADAPTER_CORRELATION);

        context.getClassFactory().addAttribute(correlationTriggerClass, CompilerConstants.ATTRIBUTE_OWNER,
                context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addAttribute(correlationTriggerClass, "service", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, "operation", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, "sdoRef", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, "sdoRootElementNamespace", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, "sdoRootElementName", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, "sdoScopeId", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, "messageId", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, CompilerConstants.ATTRIBUTE_PP_USERNAME,
                context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, CompilerConstants.ATTRIBUTE_PP_HASH,
                context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, "consumed", context.getSimpleTypes().BOOLEAN);
        context.getClassFactory().addAttribute(correlationTriggerClass, "instanceId", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(correlationTriggerClass, "subscriptionId", context.getSimpleTypes().STRING);

        // SDO<payload> correlationTrigger.getData();
        context.getClassFactory().addMethod(correlationTriggerClass, "getData", context.getSimpleTypes().SDO);
        // void correlationTrigger.logConsumption(instance,<mofId of Intermediate Message Event>);
        context.getClassFactory().addMethod(correlationTriggerClass, CompilerConstants.METHOD_CORRELATIONTRIGGER_LOG_CONSUMPTION,
                context.getSimpleTypes().VOID, context.getSimpleTypes().REFERENCE, context.getSimpleTypes().STRING);
        
        context.getSourceFactory().generateSource(correlationTriggerClass);
        return correlationTriggerClass;
    }

    /**
     * Create a new ResendRequest class for the handling of leftover messages in a conditional start scenario.
     * Part of the Sunbeam for Correlation feature.
     */
    public GalaxyClass generateResendRequestClass(final MessageFlowObject artifact) throws BPMNCompilerException {
        final GalaxyClass resendRequestClass = context.getClassFactory().generateClass("", CompilerConstants.GALAXY_RESEND_REQUEST,
                CompilerConstants.ADAPTER_CORRELATION);

        context.getClassFactory().addAttribute(resendRequestClass, "service", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(resendRequestClass, "operation", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(resendRequestClass, "sdoRef", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(resendRequestClass, "sdoRootElementNamespace", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(resendRequestClass, "sdoRootElementName", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(resendRequestClass, "sdoScopeId", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(resendRequestClass, "instanceId", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(resendRequestClass, "subscriptionId", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(resendRequestClass, "messageId", context.getSimpleTypes().STRING);
        context.getClassFactory()
                .addAttribute(resendRequestClass, CompilerConstants.ATTRIBUTE_PP_USERNAME, context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(resendRequestClass, CompilerConstants.ATTRIBUTE_PP_HASH, context.getSimpleTypes().STRING);
        
        context.getClassFactory().addMethod(resendRequestClass, "getData", context.getSimpleTypes().SDO);
        
        context.getSourceFactory().generateSource(resendRequestClass);
        return resendRequestClass;
    }

    public GalaxyClass generateSubscriptionClass(final MessageFlowObject artifact) throws BPMNCompilerException {
        GalaxyClass subscriptionClass;
        if ((context.useSunbeamNonConditionalStart() || context.useSunbeamConditionalStart())&& !context.isTaskFlow()) {
            subscriptionClass = context.getClassFactory().generateClass(artifact, CompilerConstants.GALAXY_SUBSCRIPTION,
                    CompilerConstants.ADAPTER_CORRELATION);
        } else {
            subscriptionClass = context.getClassFactory().generateClass(artifact, CompilerConstants.GALAXY_SUBSCRIPTION,
                    CompilerConstants.ADAPTER_BPMN);
        }
        addSubscriptionAttributes(subscriptionClass);
        final Source srcSubscription = context.getSourceFactory().generateSource(subscriptionClass);

        deleteIfInstanceIsGone(srcSubscription, 0);
        return subscriptionClass;
    }

    public GalaxyClass generateGroupLocalityHandlerClass(final Scope scope) throws BPMNCompilerException {
        final GalaxyClass groupLocalityHandlerClass = context.getClassFactory().generateClass(scope,
                CompilerConstants.GALAXY_GROUPLOCALITYHANDLER, CompilerConstants.ADAPTER_ASYNCACTION);

        context.getClassFactory().addAttribute(groupLocalityHandlerClass, CompilerConstants.ATTRIBUTE_PARENT,
                context.getSimpleTypes().REFERENCE);
        final Source groupLocalityHandlerSource = context.getSourceFactory().generateSource(groupLocalityHandlerClass);

        deleteIfInstanceIsGone(groupLocalityHandlerSource, 0);
        return groupLocalityHandlerClass;
    }

    public GalaxyClass generateReferenceProxyClass(final Scope scope) throws BPMNCompilerException {
        final GalaxyClass referenceProxyClass = context.getClassFactory().generateClass(scope, "ReferenceProxy",
                CompilerConstants.ADAPTER_ASYNCACTION);

        context.getClassFactory().addAttribute(referenceProxyClass, CompilerConstants.ATTRIBUTE_PARENT, context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addAttribute(referenceProxyClass, "reference", context.getSimpleTypes().STRING);
        final Source referenceProxySource = context.getSourceFactory().generateSource(referenceProxyClass);

        deleteIfInstanceIsGone(referenceProxySource, 0);
        return referenceProxyClass;
    }

    private void addSubscriptionAttributes(final GalaxyClass clsSubscription) {
        context.getClassFactory().addAttribute(clsSubscription, CompilerConstants.ATTRIBUTE_OWNER, context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addMethod(clsSubscription, "addModifier", context.getSimpleTypes().VOID,
                context.getSimpleTypes().INTEGER, context.getSimpleTypes().REFERENCE);
    }

    public GalaxyClass generateCorrelationKeyClass(final MessageFlowObject artifact) throws BPMNCompilerException {
        final GalaxyClass correlationKeyClass = context.getClassFactory().generateClass(artifact, CompilerConstants.GALAXY_CORRELATION_KEY,
                CompilerConstants.ADAPTER_CORRELATION);
        addStandardEventAttributesToClass(correlationKeyClass);
        context.getSourceFactory().generateSource(correlationKeyClass);

        return correlationKeyClass;
    }

    public GalaxyClass generateConditionalStarterClass(final MessageFlowObject artifact) throws BPMNCompilerException {
        final GalaxyClass conditionalStarterClass = context.getClassFactory().generateClass(artifact,
                CompilerConstants.GALAXY_CONDITIONAL_STARTER, CompilerConstants.ADAPTER_CORRELATION);
        context.getClassFactory().addAttribute(conditionalStarterClass, CompilerConstants.ATTRIBUTE_ORIGIN,
                context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addAttribute(conditionalStarterClass, CompilerConstants.ATTRIBUTE_START_OPERATION,
                context.getSimpleTypes().STRING);
        context.getSourceFactory().generateSource(conditionalStarterClass);
        return conditionalStarterClass;
    }

    public GalaxyClass generateEventClass(final MessageFlowObject artifact) throws BPMNCompilerException {
        final GalaxyClass clsEvent = context.getClassFactory().generateClass(artifact, CompilerConstants.GALAXY_EVENT,
                CompilerConstants.ADAPTER_BPMN);
        addStandardEventAttributesToClass(clsEvent);

        context.getSourceFactory().generateSource(clsEvent);
        context.getState().addEvent((CatchEvent) artifact, clsEvent);
        return clsEvent;
    }

    private void addStandardEventAttributesToClass(final GalaxyClass clsEvent) {
        context.getClassFactory().addAttribute(clsEvent, CompilerConstants.ATTRIBUTE_ORIGIN, context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addAttribute(clsEvent, CompilerConstants.ATTRIBUTE_PP_USERNAME, context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(clsEvent, CompilerConstants.ATTRIBUTE_PP_HASH, context.getSimpleTypes().STRING);
    }

    public GalaxyClass generateCallClass(final AutomatedActivity activity) throws BPMNCompilerException {
        // CLASS,callsws,com.sap.glx.adapter.UnifiedConnectivityAdapter,scope,REFERENCE,getInputData,(,STRING,STRING,),SDO,setInputData,(,STRING,STRING,SDO,),VOID,getOutputData,(,STRING,STRING,),SDO,setOutputData,(,STRING,STRING,SDO,),VOID,invoke,(,),BOOLEAN,getFault,(,STRING,STRING,),SDO

        final GalaxyClass call_class = context.getClassFactory().generateClass(activity, CompilerConstants.GALAXY_CALL,
                CompilerConstants.ADAPTER_UC);

        context.getClassFactory().addAttribute(call_class, "scope", context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addMethod(call_class, "getInputData", context.getSimpleTypes().SDO, context.getSimpleTypes().STRING,
                context.getSimpleTypes().STRING);
        context.getClassFactory().addMethod(call_class, "setInputData", context.getSimpleTypes().VOID, context.getSimpleTypes().STRING,
                context.getSimpleTypes().STRING, context.getSimpleTypes().SDO);
        context.getClassFactory().addMethod(call_class, "getOutputData", context.getSimpleTypes().SDO, context.getSimpleTypes().STRING,
                context.getSimpleTypes().STRING);
        context.getClassFactory().addMethod(call_class, "invoke", context.getSimpleTypes().BOOLEAN);
        context.getClassFactory().addMethod(call_class, "getFault", context.getSimpleTypes().SDO, context.getSimpleTypes().STRING,
                context.getSimpleTypes().STRING);
        context.getClassFactory().addMethod(call_class, "setOutputData", context.getSimpleTypes().VOID, context.getSimpleTypes().STRING,
                context.getSimpleTypes().STRING, context.getSimpleTypes().SDO);
        context.getClassFactory().addMethod(call_class, "setPrincipal", context.getSimpleTypes().VOID, context.getSimpleTypes().STRING,
                context.getSimpleTypes().STRING, context.getSimpleTypes().REFERENCE);

        connectToBlackHole(call_class);
        return call_class;
    }

    public GalaxyClass generateScopeClass(final ModelElement artifact, final Iterable<XsdElementDeclaration> type_scope)
            throws BPMNCompilerException {
        final GalaxyClass scope_class = context.getClassFactory().generateClass(artifact, CompilerConstants.GALAXY_SCOPE,
                CompilerConstants.ADAPTER_TYPEREGISTRY);
        context.getClassFactory().addAttribute(scope_class, "owner", context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addMethod(scope_class, "instantiate", context.getSimpleTypes().SDO, context.getSimpleTypes().STRING,
                context.getSimpleTypes().STRING);
        context.getClassFactory().addMethod(scope_class, "parseXML", context.getSimpleTypes().SDO, context.getSimpleTypes().STRING);
        context.getClassFactory().addMethod(scope_class, "renderXML", context.getSimpleTypes().STRING, context.getSimpleTypes().SDO,
                context.getSimpleTypes().STRING, context.getSimpleTypes().STRING);
        context.getClassFactory().addMethod(scope_class, "copy", context.getSimpleTypes().SDO, context.getSimpleTypes().SDO);
        context.getClassFactory().addMethod(scope_class, "getIdentifier", context.getSimpleTypes().STRING);

        final Source source = context.getSourceFactory().generateSource(scope_class);
        deleteIfInstanceIsGone(source, 0);
        return scope_class;
    }

    /**
     * Instance(parent: REFERENCE, creation_time: LONG, kicker: REFERENCE, suspended: BOOLEAN);
     */
    public GalaxyClass generateInstanceClass() throws BPMNCompilerException {
        final GalaxyClass instance_class = context.getClassFactory().generateRoot(context.getTopLevelEntity(),
                CompilerConstants.GALAXY_INSTANCE, CompilerConstants.ADAPTER_BPMN);
        context.getClassFactory().addAttribute(instance_class, "parent", context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addAttribute(instance_class, "creation_time", context.getSimpleTypes().LONG);
        context.getClassFactory().addAttribute(instance_class, "kicker", context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addAttribute(instance_class, "suspended", context.getSimpleTypes().BOOLEAN);
        context.getClassFactory().addAttribute(instance_class, "messageId", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(instance_class, "initiatingUsername", context.getSimpleTypes().STRING);
        
        context.getClassFactory().addMethod(instance_class, "setContainerObject", context.getSimpleTypes().VOID,
                context.getSimpleTypes().STRING, context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addMethod(instance_class, "updateContainerObject", context.getSimpleTypes().VOID,
                context.getSimpleTypes().STRING, context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addMethod(instance_class, "aboutToBeCancelled", context.getSimpleTypes().VOID);
        context.getClassFactory().addMethod(instance_class, "suspendWithChildren", context.getSimpleTypes().VOID);
        context.getClassFactory().addMethod(instance_class, "propagatePrincipalToParent", context.getSimpleTypes().VOID);

        context.getSourceFactory().generateSource(instance_class);
        return instance_class;
    }

    public GalaxyClass generateTaskClass(final Task task, final GalaxyClass instance_class) throws BPMNCompilerException {
        final GalaxyClass task_class = context.getClassFactory().generateClass(task, CompilerConstants.GALAXY_TASK,
                CompilerConstants.ADAPTER_TASK);

        context.getClassFactory().addAttribute(task_class, CompilerConstants.ATTRIBUTE_OWNER, instance_class);
        context.getClassFactory().addAttribute(task_class, "$" + CompilerConstants.ATTRIBUTE_LIFECYCLE, context.getSimpleTypes().INTEGER);
        context.getClassFactory().addAttribute(task_class, "$" + CompilerConstants.ATTRIBUTE_ERROR, context.getSimpleTypes().BOOLEAN);
        context.getClassFactory().addAttribute(task_class, "$" + CompilerConstants.ATTRIBUTE_ASSIGNED, context.getSimpleTypes().BOOLEAN);
        context.getClassFactory().addAttribute(task_class, "$" + CompilerConstants.ATTRIBUTE_ESCALATION, context.getSimpleTypes().BOOLEAN);
        context.getClassFactory().addAttribute(task_class, CompilerConstants.ATTRIBUTE_SUSPENDED, context.getSimpleTypes().BOOLEAN);

        context.getClassFactory().addMethod(task_class, "setContainerObject", context.getSimpleTypes().VOID,
                context.getSimpleTypes().STRING, context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addMethod(task_class, "updateContainerObject", context.getSimpleTypes().VOID,
                context.getSimpleTypes().STRING, context.getSimpleTypes().REFERENCE);

        context.getSourceFactory().generateSource(task_class);
        return task_class;
    }

    /**
     * Token(owner: Instance, state: STRING, frame: REFERENCE, ppUsername: STRING, ppHash: STRING)
     */
    public GalaxyClass generateTokenClass(final GalaxyClass instance_class) throws BPMNCompilerException {
        final GalaxyClass token_class = context.getClassFactory().generateClass(context.getTopLevelEntity(),
                CompilerConstants.GALAXY_TOKEN, CompilerConstants.ADAPTER_BPMN);
        context.getClassFactory().addAttribute(token_class, CompilerConstants.ATTRIBUTE_OWNER, instance_class);
        context.getClassFactory().addAttribute(token_class, CompilerConstants.ATTRIBUTE_STATE, context.getSimpleTypes().INTEGER);
        context.getClassFactory().addAttribute(token_class, CompilerConstants.ATTRIBUTE_FRAME, context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addAttribute(token_class, CompilerConstants.ATTRIBUTE_PP_USERNAME, context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(token_class, CompilerConstants.ATTRIBUTE_PP_HASH, context.getSimpleTypes().STRING);

        context.getClassFactory().addMethod(token_class, CompilerConstants.METHOD_TOKEN_COPY_PRINCIPAL_FROM_TOKEN,
                context.getSimpleTypes().VOID, context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addMethod(token_class, CompilerConstants.METHOD_TOKEN_COPY_PRINCIPAL_FROM_EVENT,
                context.getSimpleTypes().VOID, context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addMethod(token_class, CompilerConstants.METHOD_TOKEN_RESET_PRINCIPAL, context.getSimpleTypes().VOID);

        context.getSourceFactory().generateSource(token_class);
        return token_class;
    }

    /**
     * Add the Token.copyPrincipalFromCorrelationTrigger() method to the given token class. This has to be deferred because at Token class
     * creation time, we do not know, whether the process uses conditional start or not.
     * 
     * @param tokenClass
     * @throws BPMNCompilerException
     */
    public void enrichTokenClassWithSunbeamMethod(final GalaxyClass tokenClass) throws BPMNCompilerException {
        context.getClassFactory().addMethod(tokenClass, CompilerConstants.METHOD_TOKEN_COPY_PRINCIPAL_FROM_CORRELATIONTRIGGER,
                context.getSimpleTypes().VOID, context.getSimpleTypes().REFERENCE, context.getSimpleTypes().REFERENCE);
    }

    /**
     * CLASS,Bridge,com.sap.glx.adapter.internal.Synchronizer, owner,REFERENCE, request_adapter,STRING, request_id,STRING,
     * request_location,STRING, sent_off_location,STRING, beamMeUp,(,),VOID, setRequest,(,REFERENCE,),VOID
     */
    public GalaxyClass generateBridgeClass(final GalaxyClass clsInstance) throws BPMNCompilerException {
        final GalaxyClass clsBridge = context.getClassFactory().generateClass(context.getTopLevelEntity(), CompilerConstants.GALAXY_BRIDGE,
                CompilerConstants.ADAPTER_SYNCHRONIZER);

        context.getClassFactory().addAttribute(clsBridge, "owner", clsInstance);
        context.getClassFactory().addAttribute(clsBridge, "request_adapter", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(clsBridge, "request_id", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(clsBridge, "request_location", context.getSimpleTypes().STRING);
        context.getClassFactory().addAttribute(clsBridge, "sent_off_location", context.getSimpleTypes().STRING);

        context.getClassFactory().addMethod(clsBridge, "beamMeUp", context.getSimpleTypes().VOID);
        context.getClassFactory().addMethod(clsBridge, "setRequest", context.getSimpleTypes().VOID, context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addMethod(clsBridge, "getTimeout", context.getSimpleTypes().LONG);
        context.getClassFactory().addMethod(clsBridge, "logTimeout", context.getSimpleTypes().VOID);

        final Source source = context.getSourceFactory().generateSource(clsBridge);
        deleteIfInstanceIsGone(source, 0);
        return clsBridge;
    }

    public GalaxyClass generateFlightRecorder(final GalaxyClass clsInstance) throws BPMNCompilerException {
        final GalaxyClass clsFlightRecorder = context.getClassFactory().generateImmutable(context.getTopLevelEntity(),
                CompilerConstants.GALAXY_FLIGHT_RECORDER, CompilerConstants.ADAPTER_LOGGING);
        context.getClassFactory().addAttribute(clsFlightRecorder, CompilerConstants.ATTRIBUTE_OWNER, clsInstance);

        final Source source = context.getSourceFactory().generateSource(clsFlightRecorder);
        deleteIfInstanceIsGone(source, 0);
        return clsFlightRecorder;
    }

    /**
     * CLASS,Pulsar,Chronometer,ticks,LONG,max,LONG,period,LONG,last,LONG,owner,Instance
     */
    public GalaxyClass generatePulsarClass(final Event timer, final GalaxyClass clsOwner, final boolean doInstanceCleanup)
            throws BPMNCompilerException {
        final GalaxyClass clsPulsar = context.getClassFactory().generateClass(timer, CompilerConstants.GALAXY_PULSAR,
                CompilerConstants.ADAPTER_CHRONOMETER);
        final Source srcPulsar = context.getSourceFactory().generateSource(clsPulsar);

        context.getClassFactory().addAttribute(clsPulsar, "ticks", context.getSimpleTypes().LONG);
        context.getClassFactory().addAttribute(clsPulsar, "max", context.getSimpleTypes().LONG);
        context.getClassFactory().addAttribute(clsPulsar, "period", context.getSimpleTypes().LONG);
        context.getClassFactory().addAttribute(clsPulsar, "last", context.getSimpleTypes().LONG);
        context.getClassFactory().addAttribute(clsPulsar, "owner", clsOwner);
        if (doInstanceCleanup) {
            deleteIfInstanceIsGone(srcPulsar, 4);
        }
        return clsPulsar;
    }

    public GalaxyClass generateContainerClass(final DataContainer data, final Type ownerType, final GalaxyClass scope_class)
            throws BPMNCompilerException {
        final GalaxyClass container_class = context.getClassFactory().generateClass(data,
                (data instanceof DataObject ? CompilerConstants.GALAXY_CONTEXT : CompilerConstants.GALAXY_VIEW),
                CompilerConstants.ADAPTER_CONTAINER);
        context.getClassFactory().addAttribute(container_class, CompilerConstants.ATTRIBUTE_OWNER, ownerType);
        context.getClassFactory().addAttribute(container_class, CompilerConstants.ATTRIBUTE_SCOPE, scope_class);
        context.getClassFactory()
                .addAttribute(container_class, CompilerConstants.ATTRIBUTE_MODIFICATIONS, context.getSimpleTypes().INTEGER);
        context.getClassFactory().addAttribute(container_class, "dirty", context.getSimpleTypes().BOOLEAN);
        context.getClassFactory().addAttribute(container_class, CompilerConstants.ATTRIBUTE_PERSISTENT, context.getSimpleTypes().BOOLEAN);
        context.getClassFactory()
                .addAttribute(container_class, CompilerConstants.ATTRIBUTE_PERSISTER_NAME, context.getSimpleTypes().STRING);
        context.getClassFactory().addMethod(container_class, "getData", context.getSimpleTypes().SDO);
        context.getClassFactory().addMethod(container_class, "setData", context.getSimpleTypes().VOID, context.getSimpleTypes().SDO);
        context.getClassFactory()
                .addMethod(container_class, "addModifier", context.getSimpleTypes().VOID, context.getSimpleTypes().INTEGER);

        context.getSourceFactory().generateSource(container_class);
        // deleteIfOwnerIsGone(container_class, instance_class, 0);

        return container_class;
    }

    public GalaxyClass generateConnectorClass(final ConditionalSequenceConnector connector, final GalaxyClass clsInstance,
            final GalaxyClass clsToken, final GalaxyClass frameClass) throws BPMNCompilerException {
        final GalaxyClass connector_class = context.getClassFactory().generateClass(connector, CompilerConstants.GALAXY_CONNECTOR,
                CompilerConstants.ADAPTER_BPMN);
        context.getClassFactory().addAttribute(connector_class, CompilerConstants.ATTRIBUTE_OWNER, clsInstance);
        context.getClassFactory().addAttribute(connector_class, CompilerConstants.ATTRIBUTE_TOKEN, clsToken);
        context.getClassFactory().addAttribute(connector_class, CompilerConstants.ATTRIBUTE_VALID, context.getSimpleTypes().BOOLEAN);
        context.getClassFactory().addAttribute(connector_class, CompilerConstants.ATTRIBUTE_FRAME, frameClass);

        context.getSourceFactory().generateSource(connector_class);
        return connector_class;
    }

    public GalaxyClass generateDurationClass(final IntermediateCatchEvent timerEvent, final GalaxyClass clsInstance,
            final GalaxyClass clsToken) throws BPMNCompilerException {
        final GalaxyClass duration_class = context.getClassFactory().generateClass(timerEvent, CompilerConstants.GALAXY_DURATION,
                CompilerConstants.ADAPTER_BPMN);
        context.getClassFactory().addAttribute(duration_class, CompilerConstants.ATTRIBUTE_OWNER, clsInstance);
        context.getClassFactory().addAttribute(duration_class, CompilerConstants.ATTRIBUTE_TOKEN, clsToken);
        context.getClassFactory().addAttribute(duration_class, CompilerConstants.ATTRIBUTE_VALUE, context.getSimpleTypes().LONG);

        final Source source = context.getSourceFactory().generateSource(duration_class);

        deleteIfInstanceIsGone(source, 0);
        return duration_class;

    }

    public GalaxyClass generateExceptionHelperClass(final CompilerContext ctx, final GalaxyClass instanceClass, final BoundaryEvent handler)
            throws BPMNCompilerException {
        final GalaxyClass exceptionHelper = context.getClassFactory().generateClass(handler, CompilerConstants.GALAXY_EXCEPTION_HELPER,
                CompilerConstants.ADAPTER_EXCEPTION);

        context.getClassFactory().addAttribute(exceptionHelper, CompilerConstants.ATTRIBUTE_OWNER, instanceClass);
        context.getClassFactory().addAttribute(exceptionHelper, CompilerConstants.ATTRIBUTE_EXCEPTION, ctx.getSimpleTypes().REFERENCE);
        context.getClassFactory().addAttribute(exceptionHelper, CompilerConstants.ATTRIBUTE_VALID, ctx.getSimpleTypes().BOOLEAN);

        context.getSourceFactory().generateSource(exceptionHelper);

        return exceptionHelper;
    }

    public GalaxyClass generateFrameClass(final FrameNode currentFrameNode, final GalaxyClass parentClass, final CompilerContext ctx)
            throws BPMNCompilerException {
        GalaxyClass frameClass;
        final Scope frameScope = currentFrameNode.getScope();
        if (frameScope != null) {
            frameClass = context.getClassFactory()
                    .generateClass(frameScope, CompilerConstants.GALAXY_FRAME, CompilerConstants.ADAPTER_BPMN);
        } else {
            // this is an admiral frame without own scope model element
            final List<FrameNode> children = currentFrameNode.getChildren();
            if (children == null || children.size() != 1) {
                throw new BPMNCompilerException("Inconsistent generation of scope hierarchy.");
            }
            final Scope childScope = children.get(0).getScope();
            if (childScope == null) {
                // only one hierarchy level with null scope allowed
                throw new BPMNCompilerException("Inconsistent generation of scope hierarchy, could not validate child.");
            }
            frameClass = context.getClassFactory().generateClass(childScope, CompilerConstants.GALAXY_FRAME_ADMIRAL,
                    CompilerConstants.ADAPTER_BPMN);
        }
        context.getClassFactory().addAttribute(frameClass, CompilerConstants.ATTRIBUTE_PARENT, parentClass);
        context.getClassFactory().addAttribute(frameClass, CompilerConstants.ATTRIBUTE_CANCELLED, ctx.getSimpleTypes().BOOLEAN);
        context.getClassFactory().addAttribute(frameClass, CompilerConstants.ATTRIBUTE_COMPLETED, ctx.getSimpleTypes().BOOLEAN);
        context.getSourceFactory().generateSource(frameClass);
        return frameClass;
    }

    public GalaxyClass generateLoopStarterClass(final EmbeddedScope embeddedScope) throws BPMNCompilerException {
        final GalaxyClass loopStarterClass = context.getClassFactory().generateClass(embeddedScope, CompilerConstants.GALAXY_LOOP_STARTER,
                CompilerConstants.ADAPTER_BPMN);
        context.getClassFactory().addAttribute(loopStarterClass, CompilerConstants.ATTRIBUTE_OWNER, context.getSimpleTypes().REFERENCE);
        context.getSourceFactory().generateSource(loopStarterClass);
        return loopStarterClass;
    }
    
    /**
     * CLASS,EventLogger,com.sap.glx.adapter.internal.EventLogAdapter,createEntry,(,INTEGER,STRING,REFERENCE,STRING,REFERENCE,),VOID
     * <p>
     * Parameter description:
     * <ul>
     * <li>EventTypeId {@link EventTypeIds}</li>
     * <li>Process definition id (i.e. the MOF id of the active Pool)</li>
     * <li>Reference to the process instance (i.e. {@code parent} or {@code instance})</li>
     * <li>MOF id of the artifact triggering the event (i.e. holding the waiting token)</li>
     * <li>A process calling a reference subflow will choose the waiting {@code token} as a reference to the called process.
     * The referenced subflow in turn will choose the {@code kicker} as a reference to its calling process.</li>
     * </ul>
     * </p>
     * 
     * createEntryWithContext,(,INTEGER,STRING,REFERENCE,STRING,REFERENCE,STRING,REFERENCE),VOID <br>
     * 
     * Parameter description:
     * <ul>
     * <li>EventTypeId {@link EventTypeIds}</li>
     * <li>Process definition id (i.e. the MOF id of the active Pool)</li>
     * <li>Reference to the process instance (i.e. {@code parent} or {@code instance})</li>
     * <li>MOF id of the artifact triggering the event (i.e. holding the waiting token)</li>
     * <li>A process calling a reference subflow will choose the waiting {@code token} as a reference to the called process. The referenced
     * subflow in turn will choose the {@code kicker} as a reference to its calling process.</li>
     * <li>MOF id of the Reporting Data Source</li>
     * <li>Reference to the SDO persisting the context</li>
     * </ul>
     * </p>
     * @return
     * @throws BPMNCompilerException
     */
    public GalaxyClass generateEventLoggerClass() throws BPMNCompilerException {
        final GalaxyClass eventLoggerClass = context.getClassFactory().generateClass(context.getTopLevelEntity(),
                CompilerConstants.GALAXY_EVENT_LOGGER, CompilerConstants.APAPTER_EVENTLOG);
        context.getClassFactory().addMethod(eventLoggerClass, CompilerConstants.METHOD_CREATE_EVENT_LOG_ENTRY,
                context.getSimpleTypes().VOID, context.getSimpleTypes().INTEGER, context.getSimpleTypes().STRING,
                context.getSimpleTypes().REFERENCE, context.getSimpleTypes().STRING, context.getSimpleTypes().REFERENCE);
        context.getClassFactory().addMethod(eventLoggerClass, CompilerConstants.METHOD_CREATE_RDS_LOG_ENTRY, context.getSimpleTypes().VOID,
                context.getSimpleTypes().INTEGER, context.getSimpleTypes().STRING, context.getSimpleTypes().REFERENCE,
                context.getSimpleTypes().STRING, context.getSimpleTypes().REFERENCE, context.getSimpleTypes().STRING,
                context.getSimpleTypes().REFERENCE);
        return eventLoggerClass;
    }
    

    private void deleteIfInstanceIsGone(final Source source, final int ownerAttribute) {
        final Join cleanupJoin = getCleanupJoin(cleanupJoinsInstance, context.getState().getInstanceSource(), ownerAttribute);
        NodeFactory.connectNodes(source, 0, cleanupJoin, 1);
    }

    private Join getCleanupJoin(final Map<Integer, Join> cleanupJoins, final Source ownerSource, final int ownerAttribute) {
        Join cleanupJoin = cleanupJoins.get(ownerAttribute);
        // create a join node, if non exists
        if (cleanupJoin == null) {
            cleanupJoin = context.getJoinFactory().generateJoin(context.getRootScope(), "owner_is_gone", "0/0/-1", "1/0/" + ownerAttribute);
            NodeFactory.connectNodes(cleanupJoin, 2, black_hole, 0);
            NodeFactory.connectNodes(ownerSource, 0, cleanupJoin, 0);
            cleanupJoins.put(ownerAttribute, cleanupJoin);
        }
        return cleanupJoin;
    }

    private void connectToBlackHole(final GalaxyClass cls) {
        final Source source = context.getSourceFactory().generateSource(cls);
        NodeFactory.connectNodes(source, 0, black_hole, 0);
    }

    public GenericOperator getDrain() {
        return drain;
    }

    public Target getBlackHole() {
        return black_hole;
    }

    public Target getSingularity() {
        return singularity;
    }
}
