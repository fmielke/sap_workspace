package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import com.sap.glx.ide.model.classes.GalaxyClass;

public class ClassVersioningCallback extends AbstractVersioningCallback<GalaxyClass> {

    public ClassVersioningCallback(GalaxyClass anchor) {
        super(null, anchor); // the compiler context isn't needed in this case
    }

    public void incorporateVersionIdentifier(String version_id) {
        if (!anchor.getName().endsWith(version_id))
            anchor.setName(anchor.getName() + "_" + version_id);
    }

}
