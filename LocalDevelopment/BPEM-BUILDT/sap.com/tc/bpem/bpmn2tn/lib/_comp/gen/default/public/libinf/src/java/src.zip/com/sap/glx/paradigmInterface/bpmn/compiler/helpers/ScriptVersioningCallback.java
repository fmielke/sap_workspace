package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import com.sap.glx.ide.model.actions.ScriptedAction;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;


public class ScriptVersioningCallback extends
		AbstractVersioningCallback<ScriptedAction> {

	public ScriptVersioningCallback(ScriptedAction anchor) {
		super(null, anchor);
	}

	public void incorporateVersionIdentifier(String version_id) {
		String text = anchor.getScriptText();
		anchor.setScriptText(text.replace(CompilerConstants.SCRIPT_VALUE_VERSION, version_id));
	}
}
