package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import com.sap.glx.ide.model.galaxy.workflow.MappableObject;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.ScopeObject;
import com.sap.glx.ide.model.galaxy.workflow.SequenceConnector;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.Warnable;
import com.sap.tc.esmp.mm.wsdl2.Operation;

public class ValidationHelper {
    Warnable warnable;
    Scope rootScope;

    public ValidationHelper(Scope scope, Warnable warnable) {
        this.warnable = warnable;
        this.rootScope = scope;
    }

    public void info(String text, Object... params) {
        this.warnable.addWarning(Warnable.Severity.INFORMATION, rootScope, text, params);
    }

    public void warning(String messageId, String text, Object... params) {
        this.warnable.addWarning(Warnable.Severity.WARNING, rootScope, text, params);
    }

    public void warning(String text, Object... params) {
        this.warnable.addWarning(Warnable.Severity.WARNING, rootScope, text, params);
    }

    public BPMNCompilerException error(String messageId, String text, Throwable e, Object... params) {
        this.warnable.addWarning(Warnable.Severity.ERROR, this.rootScope, "[" + messageId + "] " + text, params);

        StringBuilder sb = new StringBuilder();
        sb.append("I'm sorry ");
        sb.append(System.getProperty("user.name")); 
        sb.append(", I'm afraid I can't do that: ");
        sb.append(String.format(text, params));
        if (e != null)
            return new BPMNCompilerException(messageId, sb.toString(), e);
        else
            return new BPMNCompilerException(messageId, sb.toString());
    }
    
    public BPMNCompilerException error(String messageId, String text, Object... params) {
        return error(messageId, text, null, params);
    }

    public void validateConnector(SequenceConnector connector) throws BPMNCompilerException {
        if (connector.getSource() == null || connector.getTarget() == null)
            throw error("BPM.rt_c_bpmn.000075", "Orphan control flow connector '%s'.", connector.getOriginalName());
    }

    public void validateConnectors(MappableObject object, int inbound, int outbound) throws BPMNCompilerException {
        if (object.getIncomingConnectors() == null || object.getIncomingConnectors().size() != inbound)
            throw error("BPM.rt_c_bpmn.000076", "Model element '%s' of type '%s' must be equipped with exactly %d inbound control flow connector(s).", object.getOriginalName(), object.getClass().getSimpleName(),
                    inbound);
        if (object.getOutgoingConnectors() == null || object.getOutgoingConnectors().size() != outbound)
            throw error("BPM.rt_c_bpmn.000077", "Model element '%s' of type '%s' must be equipped with exactly %d outbound control flow connector(s).", object.getOriginalName(), object.getClass().getSimpleName(),
                    outbound);
    }

    public void validateConnectors(ScopeObject object, int inboundMin, int inboundMax, int outboundMin, int outboundMax) throws BPMNCompilerException {
        if (object.getIncomingConnectors() == null || object.getIncomingConnectors().size() < inboundMin
                || object.getIncomingConnectors().size() > inboundMax)
            throw error("BPM.rt_c_bpmn.000078", "Model element '%s' of type '%s' must be equipped with %d..%d inbound control flow connector(s).", object.getOriginalName(), object.getClass().getSimpleName(),
                    inboundMin, inboundMax);
        if (object.getOutgoingConnectors() == null || object.getOutgoingConnectors().size() < outboundMin
                || object.getOutgoingConnectors().size() > outboundMax)
            throw error("BPM.rt_c_bpmn.000079", "Model element '%s' of type '%s' must be equipped with %d..%d outbound control flow connector(s).", object.getOriginalName(), object.getClass().getSimpleName(),
                    outboundMin, outboundMax);
    }
    
    public void validateOperation(ScopeObject object, Operation operation) {
        try {
            WSDLHelper.validateOperation(operation);
        } catch (IllegalArgumentException e) {
            error("BPM.rt_c_bpmn.000080", "Model element '%s' is assigned to an invalid operation '%s'.", e, object.getOriginalName(), operation.getName());
        }
    }

    public void validate(boolean condition, String messageId, String text, Object... args) throws BPMNCompilerException {
        if (!condition) throw error(messageId, text, args);
    }
}
