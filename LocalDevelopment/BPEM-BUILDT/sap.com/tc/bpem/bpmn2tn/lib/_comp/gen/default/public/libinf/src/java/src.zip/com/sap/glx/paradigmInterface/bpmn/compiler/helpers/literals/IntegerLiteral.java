package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals;

public class IntegerLiteral extends AbstractLiteral<Integer> {
    public IntegerLiteral(int value) {
        super(value);
    }
}
