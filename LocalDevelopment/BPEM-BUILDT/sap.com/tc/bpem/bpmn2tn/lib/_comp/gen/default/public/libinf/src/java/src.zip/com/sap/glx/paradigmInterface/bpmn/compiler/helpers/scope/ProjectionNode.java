package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope;

import java.util.HashMap;
import java.util.Map;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.triggernet.Node;

public class ProjectionNode {

    private Node m_projectionNode;
    private Map<GalaxyClass, Integer> m_object2Index = new HashMap<GalaxyClass, Integer>();
    private int m_lastIndex = -1;

    public ProjectionNode() {
        m_projectionNode = null;
    }

    public ProjectionNode(Node projectionNode) {
        m_projectionNode = projectionNode;
    }

    public void setProjectionNode(Node projectionNode) {
        m_projectionNode = projectionNode;
    }

    public Node getProjectionNode() {
        return m_projectionNode;
    }

    /**
     * returns the index of the desired object in the node
     * @param object
     * @return index
     */
    public int getIndexOfObject(GalaxyClass object) {
        Integer index = m_object2Index.get(object);
        return (index != null ? index.intValue() : -1);
    }

    public Map<GalaxyClass, Integer> getAllIndexedObjects() {
        return m_object2Index;
    }

    public void addObjectIndex(GalaxyClass object, int index) {
        m_object2Index.put(object, index);
    }

    public void setLastIndex(int lastIndex) {
        m_lastIndex = lastIndex;
    }

    public int getLastIndex() {
        return m_lastIndex;
    }

}
