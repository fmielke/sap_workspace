package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.LinkedHashSet;

import com.sap.glx.ide.model.classes.Attribute;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.classes.SimpleType;
import com.sap.glx.ide.model.galaxy.rule.Expression;
import com.sap.glx.ide.model.galaxy.workflow.CatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.IntermediateCatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.Source;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.NormalizationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.OperationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.AdvancedScript;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptName;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.tc.esmp.mm.wsdl2.Operation;

/**
 * Base class for catch events with a message event definition. It provides convenience methods to handle correlation expressions and the
 * creation of attributes on the related galaxy classes.
 * 
 * @author Philipp Sommer (D050121)
 * 
 */

public abstract class CatchEventMessageRule<T extends CatchEvent> extends BaseCompilerRule<T> implements CompilerRule<T> {

    private static final String $CONDITIONAL_START = "$CONDITIONAL_START";

    protected static final String ATTRIBUTE_CORRELATION = "cor";
    protected static final String ATTRIBUTE_MODIFICATION = "mod";
    protected static final String ATTRIBUTE_VALID = "valid";
    protected static final String ATTRIBUTE_FINGERPRINT = "fingerprint";

    protected boolean isShared(CompilerContext ctx, IntermediateCatchEvent intermediateEvent) {
        return intermediateEvent.getTrigger() == ctx.getState().getStartEvent().getTrigger();
    }

    protected void configureEndpoint(CompilerContext ctx, CatchEvent event, GalaxyClass clsEvent) throws BPMNCompilerException {
        Triple<String, String, Operation> endpoint = getEndpoint(ctx, event);
        MessageEventDefinition trigger = (MessageEventDefinition) event.getTrigger();
        Operation operation = endpoint.third;

        // configuration of the event class of the BPMN adapter
        ctx.getConfigFactory().generateEventConfiguration(clsEvent, event, endpoint.first, operation);

        combinedEndpointConfiguration(ctx, event, clsEvent, endpoint.first, endpoint.second, getOperationName(ctx, operation), trigger);
    }

    protected String getOperationName(CompilerContext ctx, Operation operation) {
        String operationName = operation.getName();
        if (ctx.useSunbeamConditionalStart()) {
            operationName += $CONDITIONAL_START;
        }
        return operationName;
    }

    protected void configureSunbeamEndpoint(CompilerContext ctx, CatchEvent event, GalaxyClass correlationKeyClass)
            throws BPMNCompilerException {
        Triple<String, String, Operation> endpoint = getEndpoint(ctx, event);
        MessageEventDefinition trigger = (MessageEventDefinition) event.getTrigger();
        combinedEndpointConfiguration(ctx, event, correlationKeyClass, endpoint.first, endpoint.second, endpoint.third.getName(), trigger);
    }

    private void combinedEndpointConfiguration(CompilerContext ctx, CatchEvent event, GalaxyClass clsEvent, String bpmnService,
            String ucService, String operation, MessageEventDefinition trigger) throws BPMNCompilerException {
        // intermediate, non-shared events are not configured for the request/response class of the BPMN adapter and the generator rules
        if (event instanceof IntermediateCatchEvent) {
            IntermediateCatchEvent intermediateEvent = (IntermediateCatchEvent) event;
            if (!isShared(ctx, intermediateEvent)) {
                bpmnService = null;
            }
        }

        // configuration of the generator for ppUsername and ppHash attributes of the event class
        ctx.getMappingHelper().generate(bpmnService, ucService, operation, clsEvent, clsEvent.getAttribute().get(1));
        ctx.getMappingHelper().generate(bpmnService, ucService, operation, clsEvent, clsEvent.getAttribute().get(2));

        // the message configuration for modelled endpoints in generated by the interface compiler
        if (OperationHelper.isModelledEndpoint(trigger)) {
            ucService = null;
        }

        // configuration of the request/response classes
        ctx.getConfigFactory().generateMessageConfiguration(trigger, bpmnService, ucService);
    }

    protected Join generateRequestEventJoin(CompilerContext ctx, Source srcRequest, Node srcEvent, String serviceId, String operation)
            throws BPMNCompilerException {

        // request.operation=...&request.service=...
        ConstantFilter operationServiceFilter = ctx.getConstantFilterFactory().generateFilter(ctx.getState().getStartEvent(),
                "service_operation", "0/0/0&0/0/1", "STRING:" + serviceId + "&STRING:" + operation, "==&==");

        NodeFactory.connectNodes(srcRequest, 0, operationServiceFilter, 0);

        // request=event.origin
        Join requestEventJoin = ctx.getJoinFactory().generateJoin(ctx.getState().getStartEvent(), "request_event", "0/0/-1", "1/0/0");

        NodeFactory.connectNodes(operationServiceFilter, 0, requestEventJoin, 0);
        NodeFactory.connectNodes(srcEvent, 0, requestEventJoin, 1);

        return requestEventJoin;
    }


    /**
     * Adds a correlation attribute to a subscription class. The attribute is updated whenever a context object in the given expression
     * changes (due to mapping). This is done synchronously. In case the attribute is always true, no triggernet for updates is generated,
     * but the attribute name gets "true" as a suffix. This way the on creation of the subscription the value can be set to true.
     * 
     * @throws BPMNCompilerException
     */
    protected Attribute addSubscriptionAttribute(CatchEvent event, GalaxyClass clsSubscription,
            Triple<String, Expression, Expression> equality, CompilerContext ctx) throws BPMNCompilerException {

        // create new attribute on the subscription class
        int modificationIndex = clsSubscription.getAttribute().size() + 1;
        int attributeNumber = (clsSubscription.getAttribute().size() - 1) / 2;
        Attribute attCorrelation = ctx.getClassFactory().addAttribute(clsSubscription, ATTRIBUTE_CORRELATION + attributeNumber,
                getSimpleType(equality.first, ctx));
        ctx.getClassFactory().addAttribute(clsSubscription, ATTRIBUTE_MODIFICATION + attributeNumber, ctx.getSimpleTypes().INTEGER);

        if (equality.third != null) {
            Pair<IMappingCompiler.Summary, String> extraction = ctx.getMappingHelper().compile(equality.third);

            // re-evaluate subscription whenever context changes
            LinkedHashSet<DataContainer> usedContext = identifySourceDataObjects(ctx, extraction.first);
            if (usedContext.isEmpty()) {
                // code ist broken (RegisteredTrademark)
                ctx.getValidator().error("BPM.rt_c_bpmn.000022", "Expression '%s' does not make use of context.",
                        equality.third.getStringExpression());
            }

            // for the moment only root data objects are allowed to be used. Therefore use the root projection node.
            ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, ctx.getRootScope(), event, "subscription_attribute_",
                    usedContext);

            // Subscription.owner=Context.owner
            Join subscriptionContextJoin = ctx.getJoinFactory().generateJoin(event, "subscription_attribute_" + attributeNumber, "0/0/0",
                    "1/0/0");

            NodeFactory.connectNodes(ctx.getSourceFactory().getSource4Class(clsSubscription), 0, subscriptionContextJoin, 0);
            NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, subscriptionContextJoin, 1);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < usedContext.size(); i++) {
                sb.append("0/" + Integer.toString(i + 1) + "/2");
                if (i < usedContext.size() - 1)
                    sb.append("&");
            }
            GenericOperator modificationsComparator = ctx.getModificationsComparatorFactory().generateModificationsComparator(event,
                    "subscription_attribute_" + attributeNumber, "0/0/" + modificationIndex, sb.toString());
            NodeFactory.connectNodes(subscriptionContextJoin, 0, modificationsComparator, 0);

            GenericOperator subscriptionUpdateExecution = generateSubscriptionUpdateExecution(ctx, event, clsSubscription, attCorrelation,
                    extraction.second, usedContext);
            NodeFactory.connectNodes(modificationsComparator, 1, subscriptionUpdateExecution, 0);

            ctx.getState().addCorrelationAttribute(attCorrelation, extraction.second, usedContext);
        } else {
            ctx.getState().addCorrelationAttribute(attCorrelation, null, null);
        }
        return attCorrelation;
    }

    /**
     * Adds a correlation attribute to an message class. The attribute is set in the (key) generation transition (from the standard
     * library). The needed key generation configuration is created.
     */
    protected Attribute addEventAttribute(String bpmnService, String ucService, Operation operation, GalaxyClass clsEvent,
            Triple<String, Expression, Expression> equality, CompilerContext ctx) throws BPMNCompilerException {
        // create an attribute on the event class
        int currentIndex = clsEvent.getAttribute().size();
        if (currentIndex > 3 && clsEvent.getAttribute().get(3).getName().equals(ATTRIBUTE_VALID)) {
            currentIndex = currentIndex - 4;
        } else {
            currentIndex = currentIndex - 3;
        }
        Attribute attribute = ctx.getClassFactory().addAttribute(clsEvent, ATTRIBUTE_CORRELATION + currentIndex,
                getSimpleType(equality.first, ctx));

        // create the expression or set to true
        Expression expression = equality.second;
        if (expression == null) {
            expression = NormalizationHelper.createTrueExpression(ctx);
        }

        // configure the generator
        ctx.getMappingHelper().generate(bpmnService, ucService, operation.getName(), clsEvent, attribute, expression);

        return attribute;
    }

    /**
     * Constructs the script body for subscription update. This script is supposed to fire synchronously whenever the data objects this
     * subscription attribute depends on have changed (i.e., an "alter" update of the "modifications" attribute happens in one of them). The
     * transition will re-evaluate the respective expression and update the correlation attribute. The expression itself is taken from a
     * base predicate of the (normalized) correlation condition.
     */
    private GenericOperator generateSubscriptionUpdateExecution(CompilerContext ctx, CatchEvent event, GalaxyClass clsSubscription,
            Attribute attCorrelation, String expressionId, LinkedHashSet<DataContainer> context) {
        AdvancedScript script = new AdvancedScript(ctx, ScriptName.SUBSCRIPTION_UPDATE, event);
        ScriptVariable varSubscription = script.addParameter(ScriptVariable.SUBSCRIPTION, clsSubscription);
        for (DataContainer container : context) {
            script.addParameter(ctx.getState().getContextVariable(container), ctx.getContextHelper().getClassByDataObject(container));
        }

        ScriptVariable varScope = script.generateAssignCommand(ScriptVariable.SCOPE, varSubscription, CompilerConstants.ATTRIBUTE_OWNER);
        script.generateScopeCode(varScope);
        generateSubscriptionUpdateScript(ctx, script, clsSubscription, varSubscription, attCorrelation, expressionId, context);
        return script.getExecution();
    }

    /**
     * Generates the script implementing the actual extraction and assignment to the subscription attribute. This is used for initial
     * creation of the subscription and changes in the underlying data containers.
     */
    protected void generateSubscriptionUpdateScript(CompilerContext ctx, AdvancedScript script, GalaxyClass clsSubscription,
            ScriptVariable varSubscription, Attribute attCorrelation, String expressionId, LinkedHashSet<DataContainer> context) {
        ScriptVariable varValue = script.generateExpressionCode(expressionId, context, null, ScriptVariable.VALUE,
                (SimpleType) attCorrelation.getAttributeType());
        script.generateUpdateCommand(varSubscription, attCorrelation.getName(), varValue);
        IntegerLiteral modAttributeIndex = new IntegerLiteral(clsSubscription.getAttribute().indexOf(attCorrelation) + 1);
        for (DataContainer container : context) {
            ScriptVariable varContext = ctx.getState().getContextVariable(container);
            script.generateInvocationCommand(varSubscription, "addModifier", modAttributeIndex, varContext);
        }
    }

    private SimpleType getSimpleType(String namespace, CompilerContext ctx) {
        if (NormalizationHelper.NS_BUILTIN_TEXT.equals(namespace)) {
            return ctx.getSimpleTypes().STRING;
        }
        if (NormalizationHelper.NS_BUILTIN_FINITE_INTEGER.equals(namespace)) {
            return ctx.getSimpleTypes().LONG;
        }
        if (NormalizationHelper.NS_BUILTIN_BOOLEAN.equals(namespace)) {
            return ctx.getSimpleTypes().BOOLEAN;
        }
        return null;
    }
}
