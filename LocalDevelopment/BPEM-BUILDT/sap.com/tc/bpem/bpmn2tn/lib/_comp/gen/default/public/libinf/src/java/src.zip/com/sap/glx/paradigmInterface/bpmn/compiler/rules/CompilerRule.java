package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

/**
 * An interface defining a compiler rule.
 * 
 * @author Thilo-Alexander Ginkel
 * 
 * @version $Id: //bpem/bpem.bp/NW731EXT_10_REL/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2tn/lib/_comp/src/com/sap/glx/paradigmInterface/bpmn/compiler/rules/CompilerRule.java#1 $
 */
public interface CompilerRule<T extends ModelElement> {

    /**
     * Determines the class identifying the artifact this compiler rule can compile.
     * 
     * @return the artifact's class
     */
    Class<T> getSupportedArtifact();

    /**
     * Pre-processes the compilation of the rule's artifacts, e.g., by allocating global structures and/or creating
     * global sub-networks.
     * 
     * @param ctx
     *            the compiler context (whose state may be incomplete at the time <code>preprocess</code> is invoked)
     * @throws BPMNCompilerException
     */
    void preprocess(CompilerContext ctx) throws BPMNCompilerException;

    /**
     * Compiles a given model artifact into a TriggerNetwork sub-net.
     * 
     * @param artifact
     *            the artifact to compile
     * @param ctx
     *            the compiler context used to compile the artifact
     * @throws BPMNCompilerException
     */
    void compile(T artifact, CompilerContext ctx) throws BPMNCompilerException;

    /**
     * Post-processes the compilation of the rule's artifacts, e.g., by allocating global structures and/or creating
     * global sub-networks.
     * 
     * @param ctx
     *            the compiler context
     * @throws BPMNCompilerException
     */
    void postprocess(CompilerContext ctx) throws BPMNCompilerException;
}
