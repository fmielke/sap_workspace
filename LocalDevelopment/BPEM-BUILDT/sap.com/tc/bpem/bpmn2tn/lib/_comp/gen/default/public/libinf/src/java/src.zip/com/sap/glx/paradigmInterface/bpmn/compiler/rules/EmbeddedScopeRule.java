package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.rule.Expression;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.DataObject;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.EventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.LoopCharacteristics;
import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.ide.model.galaxy.workflow.MultiInstanceLoopCharacteristics;
import com.sap.glx.ide.model.galaxy.workflow.ScopeObject;
import com.sap.glx.ide.model.galaxy.workflow.SequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.StartEvent;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Source;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerState;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ContextHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.BooleanLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.NullLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.DonFrame;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.FrameNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.mapping.base.compiler.IMappingCompiler;

public class EmbeddedScopeRule extends BaseCompilerRule<EmbeddedScope> implements CompilerRule<EmbeddedScope> {

    private Join childFrameNonExistenceJoin = null;
    private Join tokenNonExistenceJoin;
    private ConstantFilter frameCancelFilter;

    public Class<EmbeddedScope> getSupportedArtifact() {
        return EmbeddedScope.class;
    }

    @Override
    public void preprocess(CompilerContext ctx) throws BPMNCompilerException {
        // create frame deletion generic node network
        // non existence of token: token.frame = frame
        tokenNonExistenceJoin = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "token_exists_for_frame", "0/0/2", "1/0/-1");

        // only token that have a frame: token.frame != null
        ConstantFilter filterTokenHasFrame = ctx.getConstantFilterFactory().generateFilter(ctx.getRootScope(), "token_has_frame", "0/0/2",
                "NULL", "!=");
        // connect token source
        NodeFactory.connectNodes(ctx.getState().getTokenSource(), 0, filterTokenHasFrame, 0);
        // connect filter
        NodeFactory.connectNodes(filterTokenHasFrame, 0, tokenNonExistenceJoin, 0);

        // delete if no token or no token and no childframe
        NodeFactory.connectNodes(tokenNonExistenceJoin, 2, ctx.getReplicator().getBlackHole(), 0);

        // cancellation of frames, delete if cancel
        // filter for frame.cancel=true
        frameCancelFilter = ctx.getConstantFilterFactory().generateFilter(ctx.getRootScope(), "frame_is_cancel", "0/0/1", "BOOLEAN:true",
                "==");
        // token.frame=frame
        Join cancelFrameTokenJoin = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "cancel_frame", "0/0/2", "1/0/-1");
        // connect token filter and cancel filter
        NodeFactory.connectNodes(filterTokenHasFrame, 0, cancelFrameTokenJoin, 0);
        NodeFactory.connectNodes(frameCancelFilter, 0, cancelFrameTokenJoin, 1);
        // deletion targets
        Target targetDeleteTokenOfCancelledFrame = ctx.getTargetFactory().generateTarget(ctx.getRootScope(),
                "DELETE_TOKEN_OF_CANCELLED_FRAME");
        ctx.getTargetFactory().setScript(targetDeleteTokenOfCancelledFrame, generateCancelFrameDeleteTokenScriptHeader(ctx),
                generateCancelFrameDeleteTokenScriptBody(), CompilerConstants.PRIORITY_CANCEL);
        // cancelled frame and existing tokens
        NodeFactory.connectNodes(cancelFrameTokenJoin, 0, targetDeleteTokenOfCancelledFrame, 0);

        Target targetDeleteCancelledFrame = ctx.getTargetFactory().generateTarget(ctx.getRootScope(), "DELETE_CANCELLED FRAME");
        ctx.getTargetFactory().setScript(targetDeleteCancelledFrame, generateCancelFrameDeleteFrameScriptHeader(ctx),
                generateCancelFrameDeleteFrameScriptBody(), CompilerConstants.PRIORITY_CANCEL);
        // cancelled frame without tokens
        NodeFactory.connectNodes(cancelFrameTokenJoin, 2, targetDeleteCancelledFrame, 0);
    }

    public void compile(EmbeddedScope embeddedScope, CompilerContext ctx) throws BPMNCompilerException {
        LoopCharacteristics loopCharacteristics = embeddedScope.getLoopCharacteristics();

        // validate that the embedded subflow has at least 1 incoming connector and exactly 1 outgoing connector
        ctx.getValidator().validateConnectors(embeddedScope, 1, Integer.MAX_VALUE, 1, 1);
        CompilerState state = ctx.getState();

        // collect and validate start / end events
        StartEvent startEvent = null;
        List<EndEvent> blankEndEvents = new ArrayList<EndEvent>();
        Collection<ScopeObject> scopeObjectCollection = embeddedScope.getScopeObjects();
        for (MessageFlowObject flowObject : scopeObjectCollection) {
            if (flowObject instanceof StartEvent) {
                ctx.getValidator().validate(startEvent == null, "BPM.rt_c_bpmn.000025",
                        "More than one start event in the embedded subflow '%s'.", embeddedScope.getOriginalName());
                startEvent = (StartEvent) flowObject;
            } else if (flowObject instanceof EndEvent) {
                EndEvent endEvent = (EndEvent) flowObject;
                EventDefinition eventDef = endEvent.getEventDefinition();
                ctx.getValidator().validate(!(eventDef instanceof MessageEventDefinition), "BPM.rt_c_bpmn.000026",
                        "Message end events is not allowed in embedded subflow '%s'.", embeddedScope.getOriginalName());
                if (eventDef == null) {
                    // blank end event
                    blankEndEvents.add(endEvent);
                }
            }
        }
        ctx.getValidator().validate(startEvent != null, "BPM.rt_c_bpmn.000027", "Embedded subflow '%s' does not contain a start event.",
                embeddedScope.getOriginalName());

        SequenceConnector startConnector = startEvent.getOutgoingConnectors().get(0);
        int startEventChannel = state.getTokenSwitchExit(startConnector);

        Collection<SequenceConnector> inputConnectors = embeddedScope.getIncomingConnectors();
        SequenceConnector outgoingConnector = embeddedScope.getOutgoingConnectors().get(0);
        int outgoingChannel = state.getTokenSwitchExit(outgoingConnector);
        // the temporary state when reaching a blank end
        int endChannel = state.getTokenSwitchExitLabelFrameEnd(embeddedScope);

        DonFrame derDon = state.getDonFrame();
        FrameNode frameNode = derDon.getFrameNode4Scope(embeddedScope);
        GalaxyClass frameClass = frameNode.getGalaxyClass();
        Source frameSourceNode = ctx.getSourceFactory().getSource4Class(frameClass);
        boolean hasChildren = frameNode.hasChildren();

        /**
         * THIS IS A LOOP SCOPE
         */
        if (loopCharacteristics != null) {
            ctx.getValidator().validate(loopCharacteristics instanceof MultiInstanceLoopCharacteristics, "BPM.rt_c_bpmn.000028",
                    "Unsupported loop characteristics found.");
            MultiInstanceLoopCharacteristics miLoopCharacteristics = (MultiInstanceLoopCharacteristics) loopCharacteristics;
            DataContainer numberOfCompletedItemsDO = miLoopCharacteristics.getNumberOfCompletedIterationsDo();
            DataContainer listItemDO = miLoopCharacteristics.getCurrentCollectionItemDo();

            GalaxyClass numberOfCompletedItemsDOGalaxyClass = ctx.getContextHelper().getClassByDataObject(numberOfCompletedItemsDO);
            GalaxyClass listItemDOGalaxyClass = ctx.getContextHelper().getClassByDataObject(listItemDO);

            Expression loopExpression = miLoopCharacteristics.getExpression();

            GalaxyClass loopStarterClass = ctx.getReplicator().generateLoopStarterClass(embeddedScope);
            Source loopStarterSource = ctx.getSourceFactory().getSource4Class(loopStarterClass);

            // cleanup the currentItemDataObject in case there is no matching loop starter and no frame
            // frame = dataObject:owner
            Join m_frame_current_context_cleanup_join = ctx.getJoinFactory().generateJoin(ctx.getRootScope(),
                    "frame_current_context_cleanup", "0/0/-1", "1/0/0");
            // exists CurrentItemDO, not exists frame
            NodeFactory.connectNodes(m_frame_current_context_cleanup_join, 2, ctx.getReplicator().getDrain(), 0);
            NodeFactory.connectNodes(frameSourceNode, 0, m_frame_current_context_cleanup_join, 0);

            /**
             * <START LOOP>
             */
            FrameNode loopFrameNode = frameNode.getParent();
            // either the nesting frame or the root scope
            FrameNode loopParentFrame = loopFrameNode.getParent();
            ctx.getValidator().validate(loopParentFrame.getScope() != null, "BPM.rt_c_bpmn.000029",
                    "Inconsistent scope hierarchy. The loop scope '%s' has no valid parent scope.", embeddedScope.getOriginalName());
            // the parent is the root scope
            boolean isParentRootScope = derDon.isParentRootScope(loopFrameNode);
            int loopWaitingChannel = state.getTokenSwitchExitLabelLoopCycleWaiting(embeddedScope);

            // identify used context of loop expression
            Pair<IMappingCompiler.Summary, String> loopExpressionExtraction = ctx.getMappingHelper().compile(loopExpression);
            Set<DataContainer> usedContext = identifySourceDataObjects(ctx, loopExpressionExtraction.first);

            Target loopCreationTarget = ctx.getTargetFactory().generateTarget(embeddedScope, "LOOP_START");
            ctx.getTargetFactory().setScript(
                    loopCreationTarget,
                    generateLoopStartHeader(ctx, isParentRootScope, embeddedScope, usedContext),
                    generateLoopStartBody(ctx, loopFrameNode, loopStarterClass, numberOfCompletedItemsDO, embeddedScope,
                            loopCreationTarget, loopExpressionExtraction.second, usedContext, listItemDO, isParentRootScope));

            // if in an embedded scope the parent frame has to be joined and used as connector to the mapping node or the target.
            // if on root level, the token switch can be used directly with all states of the incoming connectors.

            // if no data objects used, directly connect to the target, otherwise use data container projection
            if (usedContext.isEmpty()) {
                if (isParentRootScope) {
                    for (SequenceConnector inputConnector : inputConnectors) {
                        int incomingChannel = state.getTokenSwitchExit(inputConnector);
                        NodeFactory.connectNodes(state.getTokenSwitch(), incomingChannel, loopCreationTarget, 0);
                    }
                } else {
                    // new join token:frame=frame
                    Join loopStartParentScopeJoin = ctx.getJoinFactory().generateJoin(embeddedScope, "join_loop_parent_frame", "0/0/2",
                            "1/0/-1");
                    for (SequenceConnector inputConnector : inputConnectors) {
                        int incomingChannel = state.getTokenSwitchExit(inputConnector);
                        NodeFactory.connectNodes(state.getTokenSwitch(), incomingChannel, loopStartParentScopeJoin, 0);
                    }
                    Source loopParentSource = ctx.getSourceFactory().getSource4Class(loopParentFrame.getGalaxyClass());
                    NodeFactory.connectNodes(loopParentSource, 0, loopStartParentScopeJoin, 1);
                    NodeFactory.connectNodes(loopStartParentScopeJoin, 0, loopCreationTarget, 0);
                }
            } else {
                ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, loopParentFrame, embeddedScope, "loop_start_swizzle",
                        usedContext);
                if (isParentRootScope) {
                    // parent is the instance
                    // instance=context:owner
                    Join contextJoin = ctx.getJoinFactory().generateJoin(embeddedScope, "context_join", "0/1/-1", "1/0/0");
                    for (SequenceConnector inputConnector : inputConnectors) {
                        int incomingChannel = state.getTokenSwitchExit(inputConnector);
                        NodeFactory.connectNodes(state.getTokenSwitch(), incomingChannel, contextJoin, 0);
                    }
                    NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);
                    NodeFactory.connectNodes(contextJoin, 0, loopCreationTarget, 0);
                } else {
                    // join parent frame
                    // token:frame=frame
                    Join loopStartParentScopeJoin = ctx.getJoinFactory().generateJoin(embeddedScope, "join_loop_parent_frame", "0/0/2",
                            "1/0/-1");
                    for (SequenceConnector inputConnector : inputConnectors) {
                        int incomingChannel = state.getTokenSwitchExit(inputConnector);
                        NodeFactory.connectNodes(state.getTokenSwitch(), incomingChannel, loopStartParentScopeJoin, 0);
                    }
                    Source loopParentSource = ctx.getSourceFactory().getSource4Class(loopParentFrame.getGalaxyClass());
                    NodeFactory.connectNodes(loopParentSource, 0, loopStartParentScopeJoin, 1);

                    // projection join
                    // frame=frame
                    Join contextJoin = ctx.getJoinFactory().generateJoin(embeddedScope, "context_join", "0/2/-1", "1/0/-1");
                    NodeFactory.connectNodes(loopStartParentScopeJoin, 0, contextJoin, 0);
                    NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);

                    // for the target node the frame of the context cascade has to be removed now
                    List<Integer> usedIndexes = new ArrayList<Integer>();
                    // Token/Instance/Frame
                    usedIndexes.add(0);
                    usedIndexes.add(1);
                    usedIndexes.add(2);
                    // ignore frame
                    int runningIndex = 4;
                    // data objects
                    for (int i = 1; i <= projectionSwizzle.getLastIndex(); i++) {
                        usedIndexes.add(runningIndex++);
                    }
                    Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(embeddedScope, "context_no_frame_projection",
                            usedIndexes.toArray(new Integer[usedIndexes.size()]));
                    NodeFactory.connectNodes(contextJoin, 0, noFrameSwizzle, 0);
                    NodeFactory.connectNodes(noFrameSwizzle, 0, loopCreationTarget, 0);
                }
            }
            /**
             * </START LOOP>
             */

            /**
             * <START LOOP CYCLES>
             */
            Source listItemDOSource = ctx.getSourceFactory().getSource4Class(listItemDOGalaxyClass);
            // make synchronous as we have row lock issues with async
            GenericOperator loopCycleCreationTarget = ctx.getExecutionFactory().generateExecution(embeddedScope, "LOOP_CYCLE_START");
            ctx.getExecutionFactory().setScript(loopCycleCreationTarget,
                    generateLoopCycleStartHeader(ctx, embeddedScope, loopStarterClass, listItemDOGalaxyClass),
                    generateLoopCycleStartBody(ctx, frameNode, listItemDO, numberOfCompletedItemsDO, startEventChannel));

            // LoopStarter=DO_listItem.owner
            Join loopStarterJoin = ctx.getJoinFactory().generateJoin(embeddedScope, "join_loopstarter_listitem", "0/0/-1", "1/0/0");
            NodeFactory.connectNodes(loopStarterSource, 0, loopStarterJoin, 0);
            NodeFactory.connectNodes(listItemDOSource, 0, loopStarterJoin, 1);
            // sync delete LoopStarter if no more list items present
            NodeFactory.connectNodes(loopStarterJoin, 1, ctx.getReplicator().getDrain(), 0);

            // delete the current list item if no loopStarter AND no frame
            NodeFactory.connectNodes(loopStarterJoin, 2, m_frame_current_context_cleanup_join, 1);

            // token.frame=LS.owner token in waiting state, for principal propagation
            Join loopStarterTokenJoin = ctx.getJoinFactory().generateJoin(embeddedScope, "join_loopstarter_token", "0/0/2", "1/0/0");
            NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), loopWaitingChannel, loopStarterTokenJoin, 0);
            NodeFactory.connectNodes(loopStarterJoin, 0, loopStarterTokenJoin, 1);
            NodeFactory.connectNodes(loopStarterTokenJoin, 0, loopCycleCreationTarget, 0);
            /**
             * </START LOOP CYCLES>
             */

            /**
             * <REACHING END STATE OF CYCLE>
             */
            // token.frame=frame
            Join frameTokenEndJoin = ctx.getJoinFactory().generateJoin(embeddedScope, "join_frame_token_end", "0/0/2", "1/0/-1");
            NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), endChannel, frameTokenEndJoin, 0);
            NodeFactory.connectNodes(frameSourceNode, 0, frameTokenEndJoin, 1);

            // filter for frame.completed!=true
            ConstantFilter frameCompletedIncrementFilter = ctx.getConstantFilterFactory().generateFilter(ctx.getRootScope(),
                    "end_frame_is_completed", "0/2/2", "BOOLEAN:true", "!=");
            NodeFactory.connectNodes(frameTokenEndJoin, 0, frameCompletedIncrementFilter, 0);

            // frame.parent=do.owner
            Source numberOfCompletedItemsDOSource = ctx.getSourceFactory().getSource4Class(numberOfCompletedItemsDOGalaxyClass);
            Join numberOfCompletedJoin = ctx.getJoinFactory().generateJoin(embeddedScope, "join_number_of_completed", "0/2/0", "1/0/0");
            NodeFactory.connectNodes(frameCompletedIncrementFilter, 0, numberOfCompletedJoin, 0);
            NodeFactory.connectNodes(numberOfCompletedItemsDOSource, 0, numberOfCompletedJoin, 1);

            Target completedCyclesIncrementTarget = ctx.getTargetFactory().generateTarget(embeddedScope, "LOOP_CYCLE_INCREMENT");
            ctx.getTargetFactory().setScript(completedCyclesIncrementTarget,
                    generateCompletedCyclesIncrementHeader(ctx, embeddedScope, frameClass, numberOfCompletedItemsDOGalaxyClass),
                    generateCompletedCyclesIncrementBody(ctx));
            Target completedCyclesDeleteTokenTarget = ctx.getTargetFactory().generateTarget(embeddedScope, "LOOP_CYCLE_DELETE_TOKEN");
            ctx.getTargetFactory().setScript(completedCyclesDeleteTokenTarget,
                    generateCompletedCyclesIgnoreHeader(ctx, embeddedScope, frameClass), generateCompletedCyclesIgnoreBody(ctx));
            // increment DO_#
            NodeFactory.connectNodes(numberOfCompletedJoin, 0, completedCyclesIncrementTarget, 0);
            // is not first end token, just delete
            NodeFactory.connectNodes(frameCompletedIncrementFilter, 1, completedCyclesDeleteTokenTarget, 0);
            /**
             * </REACHING END STATE OF CYCLE>
             */

            /**
             * <COMPLETING THE LOOP>
             */
            Target completedLoopTarget = ctx.getTargetFactory().generateTarget(embeddedScope, "LOOP_REGULAR_COMPLETION");
            ctx.getTargetFactory().setScript(completedLoopTarget,
                    generateCompletedLoopHeader(ctx, embeddedScope, loopFrameNode.getGalaxyClass()),
                    generateCompletedLoopBody(ctx, outgoingChannel, isParentRootScope));

            Source loopFrameSource = ctx.getSourceFactory().getSource4Class(loopFrameNode.getGalaxyClass());
            // filter for frame.completed!=true
            ConstantFilter frameCompletedFilter = ctx.getConstantFilterFactory().generateFilter(ctx.getRootScope(),
                    "frame_cycle_is_completed", "0/0/2", "BOOLEAN:true", "!=");
            NodeFactory.connectNodes(frameSourceNode, 0, frameCompletedFilter, 0);
            // LoopStarter.owner=TopFrame
            Join loopStarterTopFrameJoin = ctx.getJoinFactory().generateJoin(embeddedScope, "join_loop_starter_top", "0/0/0", "1/0/-1");
            NodeFactory.connectNodes(loopStarterSource, 0, loopStarterTopFrameJoin, 0);
            NodeFactory.connectNodes(loopFrameSource, 0, loopStarterTopFrameJoin, 1);
            // frameCycle.parent=TopFrame
            Join frameCycleTopFrameJoin = ctx.getJoinFactory().generateJoin(embeddedScope, "join_cycle_top", "0/0/0", "1/0/-1");
            // true filter (not completed cycles)
            NodeFactory.connectNodes(frameCompletedFilter, 0, frameCycleTopFrameJoin, 0);
            // right inhibitor (topframe without loopstarter)
            NodeFactory.connectNodes(loopStarterTopFrameJoin, 2, frameCycleTopFrameJoin, 1);
            // WaitingToken.frame=TopFrame
            Join waitingTokenJoin = ctx.getJoinFactory().generateJoin(embeddedScope, "join_waiting_token", "0/0/2", "1/0/-1");
            // waiting token state
            NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), loopWaitingChannel, waitingTokenJoin, 0);
            // right inhibitor (topframe without incomplete cycles)
            NodeFactory.connectNodes(frameCycleTopFrameJoin, 2, waitingTokenJoin, 1);
            NodeFactory.connectNodes(waitingTokenJoin, 0, completedLoopTarget, 0);
            /**
             * </COMPLETING THE LOOP
             */

            /**
             * <DELETION OF FRAME>
             */
            this.initializeChildFrameNonExistenceJoin(ctx);
            // connect to the child frame non existence join (deletes frame if no token and no child frame
            NodeFactory.connectNodes(loopFrameSource, 0, childFrameNonExistenceJoin, 0);
            NodeFactory.connectNodes(frameSourceNode, 0, childFrameNonExistenceJoin, 1);
            if (!isParentRootScope) {
                // this is a nested frame
                // connect the loop top frame to the child frame non existence join as child
                NodeFactory.connectNodes(loopFrameSource, 0, childFrameNonExistenceJoin, 1);
            }
            if (hasChildren) {
                // connect to the child frame non existence join as parent
                NodeFactory.connectNodes(frameSourceNode, 0, childFrameNonExistenceJoin, 0);
            } else {
                // directly connect to token non existence join
                NodeFactory.connectNodes(frameSourceNode, 0, tokenNonExistenceJoin, 1);
            }
            // cancel frame if parent is gone
            // connect to isCancel filter
            NodeFactory.connectNodes(loopFrameSource, 0, frameCancelFilter, 0);
            NodeFactory.connectNodes(frameSourceNode, 0, frameCancelFilter, 0);
            /**
             * </DELETION OF FRAME>
             */

        }

        /**
         * THIS IS AN EMBEDDED SUBFLOW
         */
        else {
            boolean isParentRootScope = derDon.isParentRootScope(frameNode);
            FrameNode parentFrame = frameNode.getParent();

            /**
             * <CREATION OF FRAME> Script Code
             */
            Target target = ctx.getTargetFactory().generateTarget(embeddedScope, "EMBEDDED_SCOPE");
            String creationScriptHeader = this.generateFrameCreationScriptHeader(ctx, embeddedScope, isParentRootScope);
            String creationScriptBody = this.generateFrameCreationScriptBody(ctx, embeddedScope, target, isParentRootScope, frameNode,
                    startEventChannel);

            ctx.getTargetFactory().setScript(target, creationScriptHeader, creationScriptBody);

            if (isParentRootScope) {
                for (SequenceConnector inputConnector : inputConnectors) {
                    int incomingChannel = state.getTokenSwitchExit(inputConnector);
                    NodeFactory.connectNodes(state.getTokenSwitch(), incomingChannel, target, 0);
                }
            } else {
                // token.frame = parent frame
                Join joinParentFrameJoin = ctx.getJoinFactory().generateJoin(embeddedScope, "join_parent_frame", "0/0/2", "1/0/-1");
                Source parentSource = ctx.getSourceFactory().getSource4Class(parentFrame.getGalaxyClass());
                for (SequenceConnector inputConnector : inputConnectors) {
                    int incomingChannel = state.getTokenSwitchExit(inputConnector);
                    NodeFactory.connectNodes(state.getTokenSwitch(), incomingChannel, joinParentFrameJoin, 0);
                }
                NodeFactory.connectNodes(parentSource, 0, joinParentFrameJoin, 1);
                NodeFactory.connectNodes(joinParentFrameJoin, 0, target, 0);
            }
            /**
             * </CREATION OF FRAME>
             */

            /**
             * <DELETION OF FRAME>
             */
            if (!isParentRootScope) {
                // connect to the child frame non existence join as child
                this.initializeChildFrameNonExistenceJoin(ctx);
                NodeFactory.connectNodes(frameSourceNode, 0, childFrameNonExistenceJoin, 1);
            }
            if (hasChildren) {
                // connect to the child frame non existence join as parent
                this.initializeChildFrameNonExistenceJoin(ctx);
                NodeFactory.connectNodes(frameSourceNode, 0, childFrameNonExistenceJoin, 0);
            } else {
                // directly connect to token non existence join
                NodeFactory.connectNodes(frameSourceNode, 0, tokenNonExistenceJoin, 1);
            }
            // cancel frame if parent is gone
            // connect to isCancel filter
            NodeFactory.connectNodes(frameSourceNode, 0, frameCancelFilter, 0);
            /**
             * </DELETION OF FRAME>
             */

            /**
             * Connect End State to Outgoing Connector - Continue
             */
            Target targetEmbeddedScopeEnd = ctx.getTargetFactory().generateTarget(embeddedScope, "EMBEDDED_SCOPE_END");
            ctx.getTargetFactory().setScript(targetEmbeddedScopeEnd, generateFrameEndForwardScriptHeader(ctx, embeddedScope),
                    generateFrameEndForwardScriptBody(ctx, isParentRootScope, outgoingChannel));
            // end events will connect to this end channel
            NodeFactory.connectNodes(state.getTokenSwitch(), endChannel, targetEmbeddedScopeEnd, 0);
        }
    }

    @Override
    public void postprocess(CompilerContext ctx) throws BPMNCompilerException {}

    private String generateFrameCreationScriptHeader(CompilerContext ctx, EmbeddedScope embeddedScope, boolean isFirstLevelScope) {
        CompilerState state = ctx.getState();
        StringBuilder header = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(),
                CompilerConstants.TARGET_CREATE_FRAME, embeddedScope));
        header.append(ScriptHelper.generateClassDeclaration(state.getTokenSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        header.append(", ");
        header.append(ScriptHelper.generateClassDeclaration(state.getInstanceSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        if (!isFirstLevelScope) {
            // generic parent attribute for frame parent
            header.append(", ");
            header.append(ScriptHelper.generateClassDeclaration(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT)));
        }
        header.append(")");
        return header.toString();
    }

    private String generateFrameCreationScriptBody(CompilerContext ctx, EmbeddedScope embeddedScope, Target target,
            boolean isFirstLevelScope, FrameNode frame, int startEventChannel) {
        // debugger code
        StringBuilder body = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_ON_ACTIVATION, embeddedScope, target, new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        // set exception scope
        body.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        // instantiate Frame into local Variable frame
        if (isFirstLevelScope) {
            body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), frame.getGalaxyClass(),
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), BooleanLiteral.FALSE, BooleanLiteral.FALSE));
        } else {
            body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), frame.getGalaxyClass(),
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT), BooleanLiteral.FALSE, BooleanLiteral.FALSE));
        }

        // DO creation
        // need corresponding DO information
        ContextHelper ctxHelper = ctx.getContextHelper();
        Set<DataContainer> scopeDataContainer = ctx.getState().getDataContainer4Frame(frame);

        for (DataContainer curDataContainer : scopeDataContainer) {
            GalaxyClass curDataContainerClass = ctxHelper.getClassByDataObject(curDataContainer);
            // scope = new TypeRegistry:ScopeX(parent);
            GalaxyClass scope_class = ctx.getContextHelper().getScopeClass(curDataContainerClass);
            body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_SCOPE), scope_class, new Variable(
                    CompilerConstants.SCRIPT_VARIABLE_PARENT)));

            // context_i = new ContainerAdapter:ContextX(parent,scope,0,false,false,null);
            body.append(ScriptHelper.generateNewCommand(new Variable(ctx.getState().getContextVariableName(curDataContainer)),
                    curDataContainerClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), new Variable(
                            CompilerConstants.SCRIPT_VARIABLE_SCOPE), new IntegerLiteral(curDataContainer instanceof DataObject ? 0 : -1),
                    BooleanLiteral.FALSE, BooleanLiteral.FALSE, NullLiteral.NULL));
        }

        // set token frame to newly instantiated frame
        body.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                CompilerConstants.ATTRIBUTE_FRAME, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));
        // set token state to after start event
        body.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                CompilerConstants.ATTRIBUTE_STATE, new IntegerLiteral(startEventChannel)));

        body.append("}");
        return body.toString();
    }

    private String generateFrameEndForwardScriptHeader(CompilerContext ctx, EmbeddedScope embeddedScope) {
        return generateSimpleScriptHeader(ctx, "FORWARD_FRAME_STATE", embeddedScope);
    }

    private String generateFrameEndForwardScriptBody(CompilerContext ctx, boolean isFirstLevelScope, int outgoingChannel) {
        StringBuilder bodyForwardState = new StringBuilder("{");
        // set exception scope
        bodyForwardState.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        if (isFirstLevelScope) {
            // set token:frame to null
            bodyForwardState.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                    CompilerConstants.ATTRIBUTE_FRAME, NullLiteral.NULL));
        } else {
            // read current token:frame attribute into local frameParent variable
            bodyForwardState.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), new Variable(
                    CompilerConstants.SCRIPT_VARIABLE_TOKEN), CompilerConstants.ATTRIBUTE_FRAME));
            bodyForwardState.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT),
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), CompilerConstants.ATTRIBUTE_PARENT));
            // update token:frame attribute with frameParent value
            bodyForwardState.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                    CompilerConstants.ATTRIBUTE_FRAME, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT)));
        }
        // update token:state
        bodyForwardState.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                CompilerConstants.ATTRIBUTE_STATE, new IntegerLiteral(outgoingChannel)));

        bodyForwardState.append("}");
        return bodyForwardState.toString();
    }

    private String generateLoopStartHeader(CompilerContext ctx, boolean isFirstLevelScope, EmbeddedScope embeddedScope,
            Set<DataContainer> usedContext) {
        CompilerState state = ctx.getState();
        StringBuilder header = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(),
                CompilerConstants.TARGET_CREATE_LOOP, embeddedScope));
        header.append(ScriptHelper.generateClassDeclaration(state.getTokenSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        header.append(", ");
        header.append(ScriptHelper.generateClassDeclaration(state.getInstanceSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        if (!isFirstLevelScope) {
            // generic parent attribute for frame parent
            header.append(", ");
            header.append(ScriptHelper.generateClassDeclaration(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT)));
        }
        for (DataContainer var : usedContext) {
            header.append(", ");
            header.append(ScriptHelper.generateClassDeclaration(ctx.getContextHelper().getClassByDataObject(var), new Variable(ctx
                    .getState().getContextVariableName(var))));
        }

        header.append(")");
        return header.toString();
    }

    private String generateLoopStartBody(CompilerContext ctx, FrameNode loopFrameNode, GalaxyClass loopStarterClass,
            DataContainer numberOfCompletedItems, EmbeddedScope embeddedScope, Target target, String expressionId,
            Set<DataContainer> usedContext, DataContainer listItemDO, boolean isFirstLevelScope) throws BPMNCompilerException {
        /**
         *new FrameTop(parent) new LoopStarter extractAsList LS.split new DO_# token.state=waiting
         */
        // debugger code
        StringBuilder body = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_ON_ACTIVATION, embeddedScope, target, new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        // set exception scope
        body.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        // instantiate FrameTop into local Variable frame
        if (isFirstLevelScope) {
            body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), loopFrameNode
                    .getGalaxyClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), BooleanLiteral.FALSE, BooleanLiteral.FALSE));
        } else {
            body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), loopFrameNode
                    .getGalaxyClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT), BooleanLiteral.FALSE,
                    BooleanLiteral.FALSE));
        }

        // LoopStarter=new LoopStarter(owner:TopFrame)
        body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_LOOP_STARTER), loopStarterClass,
                new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));

        // extractAsList into local list variable
        body.append(ScriptHelper.generateExtractAsListCode(ctx, expressionId, usedContext, listItemDO, new Variable(
                CompilerConstants.SCRIPT_VARIABLE_LIST)));

        ContextHelper ctxHelper = ctx.getContextHelper();
        // listItemDO creation to clone
        GalaxyClass listItemDOClass = ctxHelper.getClassByDataObject(listItemDO);
        // scope = new TypeRegistry:ScopeX(parent);
        GalaxyClass listItemDOScopeClass = ctx.getContextHelper().getScopeClass(listItemDOClass);
        body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_SCOPE), listItemDOScopeClass,
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        // listItem = new ContainerAdapter:ContextX(parent,scope,0,false,false,null);
        body.append(ScriptHelper
                .generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_LOOP_LIST_ITEM), listItemDOClass, new Variable(
                        CompilerConstants.SCRIPT_VARIABLE_LOOP_STARTER), new Variable(CompilerConstants.SCRIPT_VARIABLE_SCOPE),
                        new IntegerLiteral(listItemDO instanceof DataObject ? 0 : -1), BooleanLiteral.FALSE, BooleanLiteral.FALSE,
                        NullLiteral.NULL));

        // split list, use DO as template
        body.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_LOOP_LIST_ITEM),
                CompilerConstants.METHOD_LOOP_CONTEXT_SPLIT_LIST, new Variable(CompilerConstants.SCRIPT_VARIABLE_LIST)));

        // delete helper DO for cloning
        body.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_LOOP_LIST_ITEM)));

        // DO_# creation
        GalaxyClass numberOfCompletedItemsDataContainerClass = ctxHelper.getClassByDataObject(numberOfCompletedItems);
        // scope = new TypeRegistry:ScopeX(parent);
        GalaxyClass numberOfCompletedItemsScopeClass = ctx.getContextHelper().getScopeClass(numberOfCompletedItemsDataContainerClass);
        body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_SCOPE),
                numberOfCompletedItemsScopeClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        // context_# = new ContainerAdapter:ContextX(parent,scope,0,false,false,null);
        body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_LOOP_COMPLETED_ITEMS),
                numberOfCompletedItemsDataContainerClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), new Variable(
                        CompilerConstants.SCRIPT_VARIABLE_SCOPE),
                new IntegerLiteral(numberOfCompletedItems instanceof DataObject ? 0 : -1), BooleanLiteral.FALSE, BooleanLiteral.FALSE,
                NullLiteral.NULL));

        // context_#.initialize
        body.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_LOOP_COMPLETED_ITEMS),
                CompilerConstants.METHOD_LOOP_CONTEXT_INITIALIZE_COUNTER));

        // set token frame to newly instantiated frame
        body.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                CompilerConstants.ATTRIBUTE_FRAME, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));
        // set token state to loop waiting state
        int loopWaitingLabel = ctx.getState().getTokenSwitchExitLabelLoopCycleWaiting(embeddedScope);
        body.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                CompilerConstants.ATTRIBUTE_STATE, new IntegerLiteral(loopWaitingLabel)));

        body.append("}");
        return body.toString();

    }

    /**
     * Header and Body for starting a loop cycle
     */
    private String generateLoopCycleStartHeader(CompilerContext ctx, EmbeddedScope embeddedScope, GalaxyClass loopStarterClass,
            GalaxyClass listItemDOClass) {
        StringBuilder header = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(),
                CompilerConstants.TARGET_CREATE_LOOP_CYCLE, embeddedScope));
        CompilerState state = ctx.getState();
        header.append(ScriptHelper.generateClassDeclaration(state.getTokenSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_KICKER)));
        header.append(", ");
        header.append(ScriptHelper.generateClassDeclaration(state.getInstanceSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_INSTANCE)));
        header.append(", ");
        header
                .append(ScriptHelper.generateClassDeclaration(loopStarterClass,
                        new Variable(CompilerConstants.SCRIPT_VARIABLE_LOOP_STARTER)));
        header.append(", ");
        header.append(ScriptHelper
                .generateClassDeclaration(listItemDOClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_LOOP_LIST_ITEM)));
        header.append(")");
        return header.toString();
    }

    private String generateLoopCycleStartBody(CompilerContext ctx, FrameNode loopCycleFrame, DataContainer listItemDO,
            DataContainer numberOfCompletedCyclesDO, int startChannel) {
        /**
         * new Frame(LS.owner) createDO_frame<n> DO_listItem.owner=Frame new token(instance,startChannel, frame, principal)
         */

        StringBuilder body = new StringBuilder("{");
        // frameParent=loopStarter:owner
        body.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_LOOP_STARTER), CompilerConstants.ATTRIBUTE_OWNER));

        // instantiate Frame into local Variable frame
        body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), loopCycleFrame.getGalaxyClass(),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT), BooleanLiteral.FALSE, BooleanLiteral.FALSE));

        // //get the instance for the token and scope creation
        // final String SCOPEHELPER = "scope_helper";
        // //scopeHelper = new ScopeHelper;
        // body.append(ScriptHelper.generateNewCommand(
        // new Variable(SCOPEHELPER),
        // new Pair<String, String>(CompilerConstants.ADAPTER_BPMN, CompilerConstants.GALAXY_SCOPE_HELPER)));
        // //instance = scopeHelper.getInstanceOfScope(SCOPE);
        // body.append(ScriptHelper.generateInvocationCommand(
        // new Variable(CompilerConstants.SCRIPT_VARIABLE_INSTANCE),
        // new Variable(SCOPEHELPER),
        // CompilerConstants.METHOD_SCOPE_HELPER_GET_INSTANCE_OF_SCOPE,
        // new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT)));
        // //delete scopeHelper
        // body.append(ScriptHelper.generateDeleteCommand(new Variable(SCOPEHELPER)));

        // DO creation
        // need corresponding DO information
        ContextHelper ctxHelper = ctx.getContextHelper();
        Set<DataContainer> scopeDataContainer = ctx.getState().getDataContainer4Frame(loopCycleFrame);

        for (DataContainer curDataContainer : scopeDataContainer) {
            if (curDataContainer.equals(listItemDO) || curDataContainer.equals(numberOfCompletedCyclesDO)) {
                // special treating for generated loop data objects
                continue;
            }
            GalaxyClass curDataContainerClass = ctxHelper.getClassByDataObject(curDataContainer);
            // scope = new TypeRegistry:ScopeX(parent);
            GalaxyClass scope_class = ctx.getContextHelper().getScopeClass(curDataContainerClass);
            body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_SCOPE), scope_class, new Variable(
                    CompilerConstants.SCRIPT_VARIABLE_INSTANCE)));

            // context_i = new ContainerAdapter:ContextX(parent,scope,0,false,false,null);
            body.append(ScriptHelper.generateNewCommand(new Variable(ctx.getState().getContextVariableName(curDataContainer)),
                    curDataContainerClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), new Variable(
                            CompilerConstants.SCRIPT_VARIABLE_SCOPE), new IntegerLiteral(curDataContainer instanceof DataObject ? 0 : -1),
                    BooleanLiteral.FALSE, BooleanLiteral.FALSE, NullLiteral.NULL));
        }

        // listItem:owner=frame
        body.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_LOOP_LIST_ITEM),
                CompilerConstants.ATTRIBUTE_OWNER, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));

        // token=new token(instance, next, frame)
        body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), ctx.getState().getTokenClass(),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_INSTANCE), new IntegerLiteral(startChannel), new Variable(
                        CompilerConstants.SCRIPT_VARIABLE_FRAME)));

        if (ctx.isPrincipalPropagationActive()) {
            body.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                    CompilerConstants.METHOD_TOKEN_COPY_PRINCIPAL_FROM_TOKEN, new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER)));
        }

        // set exception scope
        body.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        body.append("}");
        return body.toString();

    }

    /**
     * Header and Body to increment completed cycles number on first completed token
     */
    private String generateCompletedCyclesIncrementHeader(CompilerContext ctx, EmbeddedScope embeddedScope, GalaxyClass cycleFrameClass,
            GalaxyClass numberOfCompletedItemsDOClass) {
        CompilerState state = ctx.getState();
        StringBuilder header = new StringBuilder(ScriptHelper.generateHeaderPrefix(embeddedScope, "increment_completed", null));
        header.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTokenSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        header.append(", ");
        header.append(ScriptHelper.generateClassDeclaration(state.getInstanceSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        header.append(", ");
        header.append(ScriptHelper.generateClassDeclaration(cycleFrameClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));
        header.append(", ");
        header.append(ScriptHelper.generateClassDeclaration(numberOfCompletedItemsDOClass, new Variable(
                CompilerConstants.SCRIPT_VARIABLE_LOOP_COMPLETED_ITEMS)));
        header.append(")");
        return header.toString();
    }

    private String generateCompletedCyclesIncrementBody(CompilerContext ctx) {
        StringBuilder body = new StringBuilder("{");

        // bind the instance, this helps the kernel with locking issues in the token/instance join during mass operations
        body.append(ScriptHelper.generateBindCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        // bind completedIterations galaxy object, in order to avoid deadlock situations when incrementing
        body.append(ScriptHelper.generateBindCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_LOOP_COMPLETED_ITEMS)));

        // increment counter on completed items data object
        body.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_LOOP_COMPLETED_ITEMS),
                CompilerConstants.METHOD_LOOP_CONTEXT_INCREMENT_COUNTER));

        // frame.completed=true
        body.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME),
                CompilerConstants.ATTRIBUTE_COMPLETED, BooleanLiteral.TRUE));

        // delete token
        body.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        body.append("}");
        return body.toString();
    }

    /**
     * Header and Body to delete subsequent tokens to the end state of a cycle (only first one increments)
     */
    private String generateCompletedCyclesIgnoreHeader(CompilerContext ctx, EmbeddedScope embeddedScope, GalaxyClass cycleFrameClass) {
        CompilerState state = ctx.getState();
        StringBuilder header = new StringBuilder(ScriptHelper.generateHeaderPrefix(embeddedScope, "handle_subsequent_completed", null));
        header.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTokenSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        header.append(", ");
        header.append(ScriptHelper.generateClassDeclaration(state.getInstanceSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        header.append(", ");
        header.append(ScriptHelper.generateClassDeclaration(cycleFrameClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));
        header.append(")");
        return header.toString();
    }

    private String generateCompletedCyclesIgnoreBody(CompilerContext ctx) {
        StringBuilder body = new StringBuilder("{");
        // bind the instance
        // this helps the kernel with locking issues in the token/instance join during mass operations
        body.append(ScriptHelper.generateBindCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        // delete token
        body.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        body.append("}");
        return body.toString();
    }

    /**
     * Header and Body to complete the loop instance and continue the flow
     */
    private String generateCompletedLoopHeader(CompilerContext ctx, EmbeddedScope embeddedScope, GalaxyClass topFrameClass) {
        CompilerState state = ctx.getState();
        StringBuilder header = new StringBuilder(ScriptHelper.generateHeaderPrefix(embeddedScope, "completed_loop", null));
        header.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTokenSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_KICKER)));
        header.append(", ");
        header.append(ScriptHelper.generateClassDeclaration(state.getInstanceSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_INSTANCE)));
        header.append(", ");
        header.append(ScriptHelper.generateClassDeclaration(topFrameClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));
        header.append(")");
        return header.toString();
    }

    private String generateCompletedLoopBody(CompilerContext ctx, int loopOutgoingChannel, boolean isParentRootScope) {
        StringBuilder body = new StringBuilder("{");

        if (!isParentRootScope) {
            // is a nested scope, need parent frame for new token
            body.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT), new Variable(
                    CompilerConstants.SCRIPT_VARIABLE_FRAME), CompilerConstants.ATTRIBUTE_PARENT));
        }

        // token=new token(instance, next, frame)
        body.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), ctx.getState().getTokenClass(),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_INSTANCE), new IntegerLiteral(loopOutgoingChannel),
                isParentRootScope ? NullLiteral.NULL : new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT)));

        // delete waiting token
        body.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER)));

        // TopFrame:cancelled=true
        body.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME),
                CompilerConstants.ATTRIBUTE_CANCELLED, BooleanLiteral.TRUE));

        body.append("}");
        return body.toString();
    }

    /**
     * Header and Body for cancelled frame deletions
     */
    private String generateCancelFrameDeleteTokenScriptHeader(CompilerContext ctx) {
        StringBuilder header = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), "CANCEL_DELETE_TOKEN", null));
        header.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTokenSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        header.append(", ");
        header.append(ScriptHelper.generateClassDeclaration(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));
        header.append(")");
        return header.toString();
    }

    private String generateCancelFrameDeleteTokenScriptBody() {
        StringBuilder body = new StringBuilder("{");
        // get instance
        body.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_INSTANCE), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN), CompilerConstants.ATTRIBUTE_OWNER));
        // bind the instance
        // this helps the kernel with locking issues in the token/instance join during mass operations
        body.append(ScriptHelper.generateBindCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_INSTANCE)));
        // delete token
        body.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        body.append("}");
        return body.toString();
    }

    private String generateCancelFrameDeleteFrameScriptHeader(CompilerContext ctx) {
        StringBuilder header = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), "CANCEL_DELETE_FRAME", null));
        header.append(ScriptHelper.generateClassDeclaration(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));
        header.append(")");
        return header.toString();
    }

    private String generateCancelFrameDeleteFrameScriptBody() {
        StringBuilder body = new StringBuilder("{");
        body.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));
        body.append("}");
        return body.toString();
    }

    /**
     * Header and Body to set cancel attribute of frame to true
     */
    private String generateCancelFrameScriptHeader(CompilerContext ctx) {
        StringBuilder header = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), "CANCEL_FRAME", null));
        header.append(ScriptHelper.generateClassDeclaration(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));
        header.append(")");
        return header.toString();
    }

    private String generateCancelFrameScriptBody() {
        StringBuilder body = new StringBuilder("{");
        body.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME),
                CompilerConstants.ATTRIBUTE_CANCELLED, BooleanLiteral.TRUE));
        body.append("}");
        return body.toString();
    }

    // initializes the join, node should only be created if used
    private void initializeChildFrameNonExistenceJoin(CompilerContext ctx) throws BPMNCompilerException {
        if (childFrameNonExistenceJoin == null) {
            // non existence of childFrames: frame = childFrame.parent
            childFrameNonExistenceJoin = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "child_exists_for_frame", "0/0/-1", "1/0/0");
            // left inhibitor to right input channel
            NodeFactory.connectNodes(childFrameNonExistenceJoin, 1, tokenNonExistenceJoin, 1);
            // cancellation
            // cancel frame if parent is gone
            Target targetCancelFrame = ctx.getTargetFactory().generateTarget(ctx.getRootScope(), "CANCEL_FRAME");
            ctx.getTargetFactory().setScript(targetCancelFrame, generateCancelFrameScriptHeader(ctx), generateCancelFrameScriptBody(),
                    CompilerConstants.PRIORITY_CANCEL);

            // add a filter for not already cancelled before the target to switch off transition execution if cancel was already triggered
            ConstantFilter frameIsNotCancelled = ctx.getConstantFilterFactory().generateFilter(ctx.getRootScope(),
                    "frame_is_not_cancelled", "0/0/1", "BOOLEAN:true", "!=");
            // exists child, non-exists parent
            NodeFactory.connectNodes(childFrameNonExistenceJoin, 2, frameIsNotCancelled, 0);
            NodeFactory.connectNodes(frameIsNotCancelled, 0, targetCancelFrame, 0);
        }
    }

}
