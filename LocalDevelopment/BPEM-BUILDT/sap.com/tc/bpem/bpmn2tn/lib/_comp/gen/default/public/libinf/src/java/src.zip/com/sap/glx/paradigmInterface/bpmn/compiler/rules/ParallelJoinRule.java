package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.ide.model.galaxy.workflow.ParallelJoinGateway;
import com.sap.glx.ide.model.galaxy.workflow.SequenceConnector;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;

/**
 * Compiles parallel join gateways.
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * 
 * @version $Id: //bpem/bpem.bp/NW731EXT_10_REL/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2tn/lib/_comp/src/com/sap/glx/paradigmInterface/bpmn/compiler/rules/ParallelJoinRule.java#1 $
 */
public class ParallelJoinRule extends BaseCompilerRule<ParallelJoinGateway> implements CompilerRule<ParallelJoinGateway> {

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#getSupportedArtifact()
     */
    public Class<ParallelJoinGateway> getSupportedArtifact() {
        return ParallelJoinGateway.class;
    }

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#compile(com.sap.glx.ide.model.galaxy.core.ModelElement,
     *      com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext)
     */
    public void compile(ParallelJoinGateway parallelJoinGateway, CompilerContext ctx) throws BPMNCompilerException {
        // two or more incoming connectors and exactly one outgoing connector
    	ctx.getValidator().validateConnectors(parallelJoinGateway, 2, Integer.MAX_VALUE, 1, 1);

        // create target node
        Target target = ctx.getTargetFactory().generateTarget(parallelJoinGateway);
        ctx.getTargetFactory().setScript(target, 
        		generateScriptHeader(ctx, parallelJoinGateway), 
        		generateScriptBody(ctx, parallelJoinGateway, target));

        // create a ordered set of the incoming connectors for a deterministic order
        SortedSet<SequenceConnector> connectors = new TreeSet<SequenceConnector>(new Comparator<MessageFlowObject>() {
            public int compare(MessageFlowObject o1, MessageFlowObject o2) {
                return o1 == o2 ? 0 : o1 == null ? -1 : o2 == null ? 1 : o1.refMofId().compareTo(o2.refMofId());
            }
        });
    	connectors.addAll(parallelJoinGateway.getIncomingConnectors());
        
        // build join cascade of branch tokens
        int i = 0;
        Join current = null; 
        Join last = null;
        for (SequenceConnector connector : connectors) {
            if (last == null) {
                if (current == null) {
                    current = ctx.getJoinFactory().generateJoin(parallelJoinGateway, "branch_" + i, "0/0/0", "1/0/0");
                    NodeFactory.connectNodes(
                    		ctx.getState().getTokenSwitch(), ctx.getState().getTokenSwitchExit(connector), current, 0);
                } else {
                    last = current;
                    NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), ctx.getState().getTokenSwitchExit(connector), current, 1);
                }
            } else {
                current = ctx.getJoinFactory().generateJoin(parallelJoinGateway, "branch_" + i, "0/0/0", "1/0/0");
                NodeFactory.connectNodes(last, 0, current, 0);
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), ctx.getState().getTokenSwitchExit(connector), current, 1);
                last = current;
            }
            i++;
        }
        NodeFactory.connectNodes(current, 0, target, 0);
    }

    private String generateScriptHeader(CompilerContext ctx, ParallelJoinGateway parallelJoinGateway) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), CompilerConstants.TARGET_AND_MERGE, parallelJoinGateway));
        // instances are needed for locking purposes.
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTokenSource().getGalaxyClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getInstanceSource().getGalaxyClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        sb.append(", ");
        for (int i = 1; i < parallelJoinGateway.getIncomingConnectors().size(); i++) {
            sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTokenSource().getGalaxyClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN + "_" + i)));
            sb.append(", ");
            sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getInstanceSource().getGalaxyClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT + "_" + i)));
            if (i < parallelJoinGateway.getIncomingConnectors().size() - 1) {
            	sb.append(", ");
            }
        }
        sb.append(")");
        return sb.toString();
    }

    private String generateScriptBody(CompilerContext ctx, ParallelJoinGateway parallelJoinGateway, Node target) throws BPMNCompilerException {
        List<Variable> parameters = new ArrayList<Variable>(parallelJoinGateway.getIncomingConnectors().size() * 2);
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT));
        for (int i = 1; i < parallelJoinGateway.getIncomingConnectors().size(); i++) {
            parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN + "_" + i));
            parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT + "_" + i));
        }
        
        // generates script code which relies on the the existence of variables with the name parent and token 
        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_ON_ACTIVATION, parallelJoinGateway, target, parameters));
        
        sb.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        
        // the first token is forwarded
        sb.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), 
        		"state", 
        		new IntegerLiteral(ctx.getState().getAfterTokenLabel(parallelJoinGateway))));

        // reset principal on the first token
        sb.append(ScriptHelper.generateInvocationCommand(
        		null, 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
        		CompilerConstants.METHOD_TOKEN_RESET_PRINCIPAL));
        
        // the rest is deleted
        for (int i = 1; i < parallelJoinGateway.getIncomingConnectors().size(); i++)
            sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN + "_" + i)));

        sb.append("}");
        return sb.toString();
    }
}
