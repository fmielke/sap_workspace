package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import javax.xml.namespace.QName;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.ErrorEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.EventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.IntermediateThrowEvent;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.galaxy.workflow.ThrowEvent;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SDOHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventLogHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventTypeIds;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

/**
 * A rule to raise eventions (currently just exceptions).
 * 
 * @author Thilo-Alexander Ginkel
 * @author Philipp Sommer
 * 
 */
public class RaiseEventionRule extends BaseCompilerRule<ThrowEvent> implements CompilerRule<ThrowEvent> {

    @SuppressWarnings("unchecked")
    public Class getSupportedArtifact() {
        return IntermediateThrowEvent.class;
    }

    public void compile(ThrowEvent raiseEvention, CompilerContext ctx) throws BPMNCompilerException {
        if (raiseEvention instanceof IntermediateThrowEvent)
            ctx.getValidator().validateConnectors(raiseEvention, 1, 1);
        else
            ctx.getValidator().validateConnectors(raiseEvention, 1, 0);

        GalaxyClass scope_class = ctx.getDependencyHelper().getScopeClassOld(ctx.getDependencyHelper().getScope(raiseEvention.getResult()));

        // generate classes and configuration for mapping
        Pair<IMappingCompiler.Summary, String> input_mapping = ctx.getMappingHelper().compile(raiseEvention.getInputMapping());
        Pair<Set<DataContainer>, Set<DataContainer>> mappingContext = identifyInOutDataObjects(ctx, input_mapping.first, Direction.IN);

        // build a context network for the mapping
        @SuppressWarnings("unchecked")
        Set<DataContainer> usedContext = union(mappingContext.first, mappingContext.second);

        // handling for depending views
        SortedSet<DataContainer> allViewDependencies = ctx.getState().getAllViewDependencies(usedContext);
        usedContext.addAll(allViewDependencies);

        Target raiseEventionTarget = ctx.getTargetFactory().generateTarget(raiseEvention, "raise_evention");
        ctx.getExecutionFactory().setScript(
                raiseEventionTarget,
                generateScriptHeader(ctx, raiseEvention, usedContext),
                generateScriptBody(ctx, raiseEvention, mappingContext.first, mappingContext.second, usedContext, raiseEventionTarget,
                        input_mapping.second, scope_class));

        int tokenChannel = ctx.getState().getBeforeTokenSwitchExit(raiseEvention);
        if (usedContext.isEmpty()) {
            NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), tokenChannel, raiseEventionTarget, 0);
        } else {
            ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, raiseEvention.getScope(), raiseEvention, null, usedContext);
            if (ctx.getRootScope().equals(raiseEvention.getScope())) {
                // is root scope, projection only contains data objects
                // instance=context.owner
                Join before_context_join = ctx.getJoinFactory().generateJoin(raiseEvention, "context_join", "0/1/-1", "1/0/0");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), tokenChannel, before_context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, before_context_join, 1);
                NodeFactory.connectNodes(before_context_join, 0, raiseEventionTarget, 0);
            } else {
                // is in embedded scope, projection contains frame object as first element
                // token.frame=frame
                Join before_context_join = ctx.getJoinFactory().generateJoin(raiseEvention, "context_join", "0/0/2", "1/0/-1");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), tokenChannel, before_context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, before_context_join, 1);

                // for the target node the frame has to be removed now
                List<Integer> usedIndexes = new ArrayList<Integer>();
                // token and instance
                usedIndexes.add(0);
                usedIndexes.add(1);
                // ignore frame
                int runningIndex = 3;
                // data objects
                for (int i = 1; i <= projectionSwizzle.getLastIndex(); i++) {
                    usedIndexes.add(runningIndex++);
                }
                Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(raiseEvention, "context_no_frame_projection",
                        usedIndexes.toArray(new Integer[usedIndexes.size()]));
                NodeFactory.connectNodes(before_context_join, 0, noFrameSwizzle, 0);
                NodeFactory.connectNodes(noFrameSwizzle, 0, raiseEventionTarget, 0);
            }
        }
    }

    private String generateScriptHeader(CompilerContext ctx, ThrowEvent raiseEvention, Set<DataContainer> usedContext) {
        return generateSimpleScriptHeader(ctx, CompilerConstants.TARGET_RAISE_EVENTION, raiseEvention, usedContext);
    }

    private String generateScriptBody(CompilerContext ctx, ThrowEvent raiseEvention, Set<DataContainer> contextIn,
            Set<DataContainer> contextOut, Set<DataContainer> usedContext, Target target, String mapping_id, GalaxyClass scope_class)
            throws BPMNCompilerException {

        EventDefinition evention = raiseEvention.getResult();
        ctx.getValidator().validate(evention instanceof ErrorEventDefinition, "BPM.rt_c_bpmn.000049",
                "Unsupported evention type referenced by Raise Evention artifact '%s'.", evention.getOriginalName());
        ErrorEventDefinition exception = (ErrorEventDefinition) evention;

        List<Variable> parameters = new ArrayList<Variable>(2 + contextIn.size());
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT));
        for (DataContainer obj : usedContext) {
            parameters.add(new Variable(ctx.getState().getContextVariableName(obj)));
        }

        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_ON_ACTIVATION, raiseEvention, target, parameters));

        // controller:setScope(token)
        sb.append(ScriptHelper
                .generateScopeCode(ctx.getState().getControllerClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        // parent=token:owner;
        sb.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN), CompilerConstants.ATTRIBUTE_OWNER));

        // scope=new Scope(parent);
        sb.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_SCOPE), scope_class, new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        // payload=scope:instantiate(ns,name)
        QName payload_type_name = SDOHelper.generateSDOName(WSDLHelper.getElementType(getErrorElement(exception)));
        sb.append(ScriptHelper.generateInvocationCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_PAYLOAD), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_SCOPE), "instantiate", new StringLiteral(payload_type_name.getNamespaceURI()),
                new StringLiteral(payload_type_name.getLocalPart())));

        // delete scope;
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_SCOPE)));

        // mapping to evention payload
        sb.append(ScriptHelper.generateMappingCode(ctx, mapping_id, contextIn, contextOut, null,
                new Triple<XsdElementDeclaration, Variable, StringLiteral>(getErrorElement(exception), new Variable(
                        CompilerConstants.SCRIPT_VARIABLE_PAYLOAD), new StringLiteral(ctx.getHost().getVersionId(
                        ctx.getDependencyHelper().getScope(exception), CompilerType.TYPECOMPILER)))));

        // exceptionController=new ExceptionController();
        sb.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_EX_CONTROLLER), new Pair<String, String>(
                CompilerConstants.ADAPTER_EXCEPTION, CompilerConstants.GALAXY_CONTROLLER)));

        // exceptionController:raiseException(<id>,<message>,data,<severity>);
        sb.append(ScriptHelper.generateInvocationCommand(null, //
                new Variable(CompilerConstants.SCRIPT_VARIABLE_EX_CONTROLLER), //
                CompilerConstants.METHOD_EX_CONTROLLER_RAISE_EXCEPTION, // 
                new StringLiteral(ctx.getHost().getVersionId((ErrorEventDefinition) raiseEvention.getEventDefinition(),
                        CompilerType.EXCEPTIONCOMPILER)), // 
                new StringLiteral(raiseEvention.getOriginalDocumentation()), // 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PAYLOAD), //
                new StringLiteral(exception.isCritical() ? CompilerConstants.EXCEPTION_SEVERITY_CRITICAL
                        : CompilerConstants.EXCEPTION_SEVERITY_NONCRITICAL)));

        // delete exceptionController();
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_EX_CONTROLLER)));

        // token:state=nextState
        sb.append(tokenHandling(ctx, raiseEvention));

        // event logging for error events
        if (!(raiseEvention.getScope() instanceof EmbeddedScope) && !ctx.isTaskFlow()) {
            sb.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER), new Variable(
                    CompilerConstants.SCRIPT_VARIABLE_PARENT), CompilerConstants.SCRIPT_VARIABLE_KICKER));
            EventLogHelper.addEvent(sb, ctx.getState().getEventLoggerClass(), EventTypeIds.END_TRIGGERED, ((Pool) ctx.getRootScope())
                    .refMofId(), new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), raiseEvention.refMofId(), new Variable(
                    CompilerConstants.SCRIPT_VARIABLE_KICKER));
        }

        sb.append("}");
        return sb.toString();
    }

    private XsdElementDeclaration getErrorElement(ErrorEventDefinition error) {
        if (error.getWsdlFault() != null) {
            return error.getWsdlFault().getElement();
        } else {
            return error.getParameter();
        }
    }

    protected String tokenHandling(CompilerContext ctx, ThrowEvent event) throws BPMNCompilerException {
        // token:state=nextState
        int nextState = ctx.getState().getAfterTokenLabel(event);
        return ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), "state", new IntegerLiteral(
                nextState));
    }

    protected String tokenHandlingWaitingState(CompilerContext ctx, ThrowEvent event) throws BPMNCompilerException {
        // set token state to the specific state of the end event
        return ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), "state", new IntegerLiteral(ctx
                .getState().getTokenLabel((EndEvent) event)));
    }
}
