package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.View;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerState;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ContextHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.BooleanLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.DonFrame;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.FrameNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.mapping.base.compiler.IMappingCompiler;

/**
 * A view is a data container whose value is defined by a mapping atop other data containers. Please note, that this
 * rule does not yet support views atop views.
 * 
 * @author d046672
 * 
 */
public class ViewRule extends DataObjectRule {

    @Override
    public void compile(DataContainer container, CompilerContext ctx) throws BPMNCompilerException {
        super.compile(container, ctx);
        /**
         * View specific handling in post process
         * Done because the data object join cascade is generated in the post process rule for data objects (for data objects AND views)
         */
    }

    /**
     * updateView(View view, Context1 c1, Context2 c2, ...)
     * 
     * @param ctx
     * @param view
     * @param view_class
     * @param used_context
     * @return
     */
    protected String generateViewUpdateScriptHeader(CompilerContext ctx, View view, GalaxyClass view_class, Set<DataContainer> used_context) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), CompilerConstants.TARGET_UPDATE_VIEW, view));

        sb.append(ScriptHelper.generateClassDeclaration(
        		view_class, 
        		new Variable(ctx.getState().getContextVariableName(view))));
        for (DataContainer var : used_context) {
            sb.append(", ");
            sb.append(ScriptHelper.generateClassDeclaration(
            		ctx.getContextHelper().getClassByDataObject(var), 
            		new Variable(ctx.getState().getContextVariableName(var))));
        }
        sb.append(") ");
        return sb.toString();
    }

    protected String generateViewPopulationScriptHeader(CompilerContext ctx, View view, GalaxyClass view_class) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), CompilerConstants.TARGET_POPULATE_VIEW, view));
        sb.append(ScriptHelper.generateClassDeclaration(
        		view_class, 
        		new Variable(ctx.getState().getContextVariableName(view))));
        sb.append(") ");
        return sb.toString();

    }

    public String generateScriptBody(CompilerContext ctx, View view, GalaxyClass view_class, String mapping_id, Collection<DataContainer> used_context,
            GenericOperator target) {
    	String viewVariableName = ctx.getState().getContextVariableName(view);
    	List<Variable> parameters = new ArrayList<Variable>(1 + used_context.size());
        parameters.add(new Variable(viewVariableName));
        for (DataContainer obj : used_context) {
            parameters.add(new Variable(ctx.getState().getContextVariableName(obj)));
        }
        
        // previously this was flagged as CompilerConstants.BITMASK_ON_ACTIVATION |
        // CompilerConstants.BITMASK_AFTER_COMPLETION, which caused deployment issues
        // TODO: does this need to be revised?
        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(), CompilerConstants.BITMASK_NO_CALLBACK, view,
                target, parameters));

        // owner=view:owner;
        sb.append(ScriptHelper.generateAssignCommand(
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_OWNER), 
        		new Variable(viewVariableName),
                CompilerConstants.ATTRIBUTE_OWNER));

        // controller:setScope(owner)
        sb.append(ScriptHelper.generateScopeCode(
        		ctx.getState().getControllerClass(), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_OWNER)));

        // attach mapping code to update the view -> implicit assumption: context serves for view update, only
        sb.append(ScriptHelper.generateMappingCode(ctx, mapping_id, used_context, Arrays.asList((DataContainer)view), null, null));

        sb.append(ScriptHelper.generateAddModifierCode(used_context, ctx, viewVariableName));
        
        // view:dirty=false; --> this is a regular view update which does not "invalidate" the view
        sb.append(ScriptHelper.generateUpdateCommand(new Variable(viewVariableName), "dirty", BooleanLiteral.FALSE));

        sb.append("}");
        return sb.toString();

    }

    @SuppressWarnings("unchecked")
    public Class getSupportedArtifact() {
        return View.class;
    }

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.BaseCompilerRule#postprocess(com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext)
     */
    @Override
    public void postprocess(CompilerContext ctx) throws BPMNCompilerException {
    	CompilerState state = ctx.getState();
    	DonFrame derDon = state.getDonFrame();
    	FrameNode rootFrame = derDon.getRootFrameNode();
    	//in case there are only view objects in the scopes, the context cascade would not be created
    	if(!state.isContextCascadeCreated()){
    		super.postprocess(ctx);
    	}
    	this.compileViewsOfScope(ctx, state, rootFrame);
    }

    
    private void compileViewsOfScope(CompilerContext ctx, CompilerState state, FrameNode currentFrame) throws BPMNCompilerException{
    	Scope currentScope = currentFrame.getScope();
    	Set<DataContainer> currentDataObjects = state.getDataContainer4Frame(currentFrame);
    	for(DataContainer dataContainer : currentDataObjects){
    		if(!(dataContainer instanceof View)){
    			continue;
    		}
    		/**
    		 * View handling is mostly done in post process because the projection join cascades are built in the postprocess of the DataObjectRule
    		 */
            View view = (View) dataContainer;
            ctx.getValidator().validate(view.getMapping() != null, "BPM.rt_c_bpmn.000057", //$NON-NLS-1$
                    "Mapping undefined for view '%s'.", view.getOriginalName()); //$NON-NLS-1$
            GalaxyClass viewClass = ctx.getContextHelper().getClassByDataObject(view);

            // create mapper class for the view update
            Pair<IMappingCompiler.Summary, String> materializationMapping = ctx.getMappingHelper().compile(view.getMapping());
            Set<DataContainer> usedContext = identifyInOutDataObjects(ctx, materializationMapping.first, Direction.INOUT).first;
            
            // handling for depending views
            SortedSet<DataContainer> allViewDependencies = ctx.getState().getAllViewDependencies(usedContext);
            // remove current view to avoid duplicate entry in script header
            allViewDependencies.remove(view);
            usedContext.addAll(allViewDependencies);

            // check if that view is really computed from context
            if (!usedContext.isEmpty()) {
            	
            	ProjectionNode projectionNode = currentFrame.getProjectionNode();
            	ctx.getValidator().validate(projectionNode != null, "BPM.rt_c_bpmn.000058", //$NON-NLS-1$
            	        "Inconsistent state of while compiling view '%s'.", view.getOriginalName()); //$NON-NLS-1$
            	
            	//project only used data objects and the view as first element
            	List<Integer> usedIndexes = new ArrayList<Integer>();
            	int indexOfView = projectionNode.getIndexOfObject(viewClass);
            	ctx.getValidator().validate(indexOfView >= 0, "BPM.rt_c_bpmn.000059", //$NON-NLS-1$
            	        "Could not resolve index on projection join for view '%s' in scope '%s'.", view.getOriginalName(), currentScope.getOriginalName()); //$NON-NLS-1$
        		
            	usedIndexes.add(indexOfView);
            	ContextHelper ctxHelper = ctx.getContextHelper();
            	for(DataContainer usedDataContainer : usedContext){
            		int indexOfUsedDataContainer = projectionNode.getIndexOfObject(ctxHelper.getClassByDataObject(usedDataContainer));
            		ctx.getValidator().validate(indexOfUsedDataContainer >= 0, "BPM.rt_c_bpmn.000060", //$NON-NLS-1$
            		        "Could not resolve index on projection join for data object '%s' in scope '%s'.", //$NON-NLS-1$
            		        usedDataContainer.getOriginalName(), currentScope.getOriginalName());
                    usedIndexes.add(indexOfUsedDataContainer);
            	}
            	Swizzle modificationSwizzle = ctx.getSwizzleFactory().generateSwizzle(view, "projection_modifications", usedIndexes.toArray(new Integer[usedIndexes.size()]));
            	NodeFactory.connectNodes(projectionNode.getProjectionNode(), 0, modificationSwizzle, 0);
            	
            	// make sure the view is not "dirty"
                ConstantFilter dirtyFilter = ctx.getConstantFilterFactory().generateFilter(view, "filter_dirty", "0/0/3", "BOOLEAN:true", "!=");
                NodeFactory.connectNodes(modificationSwizzle, 0, dirtyFilter, 0);
                            	
                // make sure all data objects have been modified (setData call) at least once: c1.mod>0 & ... & cn.mod>0
            	StringBuilder operands = new StringBuilder();
                StringBuilder constants = new StringBuilder();
                StringBuilder comparators = new StringBuilder();
                //index 0 is the view -> ignore
                for (int i=1; i<usedIndexes.size(); i++) {
                    if (i>1) {
                        operands.append("&");
                        constants.append("&");
                        comparators.append("&");
                    }
                    operands.append("0/"+Integer.toString(i)+"/2");
                    constants.append("INTEGER:0");
                    comparators.append(">");
                }
                ConstantFilter modificationFilter = ctx.getConstantFilterFactory().generateFilter(view, "filter_modifications", operands.toString(), constants.toString(), comparators.toString());
                NodeFactory.connectNodes(dirtyFilter, 0, modificationFilter, 0);
            	
                
                
                // create modification comparison operator for data objects
                StringBuilder sb = new StringBuilder();
                for (int i = 1; i < usedIndexes.size(); i++) {
                    sb.append("0/" + Integer.toString(i) + "/2");
                    if (i < usedIndexes.size() - 1)
                        sb.append("&");
                }
                //view.mod = c1.mod+...+cn.mod
                GenericOperator modificationsComparator = ctx.getModificationsComparatorFactory().generateModificationsComparator(view, "compare_view", "0/0/2", sb.toString());
                NodeFactory.connectNodes(modificationFilter, 0, modificationsComparator, 0);

                //generate target to update view if left sum does not equal right sum (false exit of modification comparator)
                GenericOperator targetUpdateView = ctx.getExecutionFactory().generateExecution(view, "update_view");
                ctx.getExecutionFactory().setScript(	targetUpdateView, 
                										generateViewUpdateScriptHeader(ctx, view, viewClass, usedContext), 
                										generateScriptBody(ctx, view, viewClass, materializationMapping.second, usedContext, targetUpdateView));
                NodeFactory.connectNodes(modificationsComparator, 1, targetUpdateView, 0);
                
            	
           
            } else { 
            	// view only based on constants (sic!)
                // do a one-time population of the view upon creation
                GenericOperator targetPopulateView = ctx.getExecutionFactory().generateExecution(view, "populate_view");
                ctx.getExecutionFactory().setScript(	targetPopulateView, 
                										generateViewPopulationScriptHeader(ctx, view, viewClass),
                										generateScriptBody(ctx, view, viewClass, materializationMapping.second, usedContext, targetPopulateView));
                NodeFactory.connectNodes(ctx.getSourceFactory().getSource4Class(viewClass), 0, targetPopulateView, 0);
            }
    	}
    }
    
    
    
    
    
    protected void addGlobalViewJoinNetwork(CompilerContext ctx) throws BPMNCompilerException {
        Set<DataContainer> globalContext = new LinkedHashSet<DataContainer>();

        Set<View> views = ctx.getArtifacts(View.class);
        if (views != null)
            globalContext.addAll(views);

        Node view_network = buildContextJoinNetwork(ctx, ctx.getRootScope(), globalContext);
        Node do_network = ctx.getState().getGlobalContextJoinNetwork();
        if (do_network != null) {
            if (view_network != null) {
                Join join_do_view = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "data_objects_views", "0/0/0", "1/0/0");
                NodeFactory.connectNodes(do_network, 0, join_do_view, 0);
                NodeFactory.connectNodes(view_network, 0, join_do_view, 1);
                ctx.getState().setGlobalContextJoinNetwork(join_do_view);
            } else
                ctx.getState().setGlobalContextJoinNetwork(do_network);
        } else
            ctx.getState().setGlobalContextJoinNetwork(view_network);

    }
    
    protected String generateInstanceListenerCreationScriptHeader(CompilerContext ctx) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), CompilerConstants.TARGET_CREATE_LISTENER, null));
        sb.append(ScriptHelper.generateClassDeclaration(
        		ctx.getState().getInstanceSource().getGalaxyClass(), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(
        		null, 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_VIEW)));
        sb.append(") ");
        return sb.toString();
    }
    
    protected String generateInstanceListenerCreationScriptBody(CompilerContext ctx, GenericOperator target) throws BPMNCompilerException {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(
        		ctx.getState().getExitClass(), 
        		CompilerConstants.BITMASK_NO_CALLBACK, 
        		null, 
        		target, 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_VIEW)));
        
        sb.append(ScriptHelper.generateScopeCode(
        		ctx.getState().getControllerClass(), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        
        // new BPMNAdapter:Listener(context,parent,0);
        sb.append(ScriptHelper.generateNewCommand(
        		null, 
        		ctx.getState().getListenerSource().getGalaxyClass(), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_VIEW), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), 
        		new IntegerLiteral(-1)));

        sb.append("}");
        return sb.toString();
    }

    protected String generateTaskListenerCreationScriptHeader(CompilerContext ctx) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), CompilerConstants.TARGET_CREATE_LISTENER, null));
        sb.append(ScriptHelper.generateClassDeclaration(
        		ctx.getState().getInstanceSource().getGalaxyClass(), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(
        		ctx.getState().getTaskSource().getGalaxyClass(), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_TASK)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(
        		null, 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_VIEW)));
        sb.append(") ");
        return sb.toString();
    }
    
    protected String generateTaskListenerCreationScriptBody(CompilerContext ctx, GenericOperator target) throws BPMNCompilerException {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(
        		ctx.getState().getExitClass(), 
        		CompilerConstants.BITMASK_NO_CALLBACK, 
        		null, 
        		target, 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_TASK), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_VIEW)));
        
        sb.append(ScriptHelper.generateScopeCode(
        		ctx.getState().getControllerClass(), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        
        // new BPMNAdapter:Listener(context,task,0);
        sb.append(ScriptHelper.generateNewCommand(
        		null, 
        		ctx.getState().getListenerSource().getGalaxyClass(),
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_VIEW), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_TASK),
        		new IntegerLiteral(-1)));

        sb.append("}");
        return sb.toString();
    }


}
