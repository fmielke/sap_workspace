package com.sap.glx.paradigmInterface.bpmn.compiler.scripts;



public class LongLiteral extends Literal<Long> implements Parameter{
    
    public LongLiteral(long value) {
        super(value);
    }
    
    public String toString() {
        return Long.toString(value) + 'l';
    }
}
