package com.sap.glx.paradigmInterface.bpmn.compiler.scripts;


public interface Parameter {
    
}
