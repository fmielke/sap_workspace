package com.sap.glx.paradigmInterface.bpmn.compiler.scripts;

/**
 * This enumeration list all possible name prefixes for scripts.
 * 
 * @author Philipp Sommer
 */
public enum ScriptName {

    START_EVENT_BPMN,
    START_EVENT_UC,
    START_EVENT_RESEND,

    SUBSCRIPTION_UPDATE,

    INTERMEDIATE_TIMER_COMPUTE_DURATION,
    INTERMEDIATE_TIMER_SCHEDULE_JOB,
    INTERMEDIATE_TIMER_ON_TICK,
    INTERMEDIATE_TIMER_NO_DELAY,

    END_EVENT_BLANK,
    END_EVENT_ERROR_TOKEN_REMOVAL,
    END_EVENT_MESSAGE_UC,
    END_EVENT_MESSAGE_BPMN,
    BEAM_ME_UP,
    BEAM_CREATE_TIMEOUT,
    BEAM_TIMEOUT,

    SUSPEND_TASK,
    RESUME_TASK,
    PROPAGATE_PRINCIPAL_OF_TASK,

    BLACK_HOLE,
    SINGULARITY,
    DISRUPTOR,

    AUTOMATED_ACTIVITY,
    
    CREATE_GROUP_LOCALITY_HANDLER,
    EXTRACT_EVENT_CLASS
}
