package com.sap.glx.paradigmInterface.bpmn.compiler.scripts;



public class StringLiteral extends Literal<String> implements Parameter {
    
    public StringLiteral(String value) {
        super(escapeString(value));
    }
   
    /**
     * Escapes a string for rendering as a String literal for rendering in a script and encloses it in quotes. The
     * 
     * escaping is done for the quote character as well as for some non-printable whitespace characters.
     * 
     * @param string
     *            the string to escape
     * @param quoteString
     *            <code>true</code> if the string should be enclosed in quotes (")
     * @return the escaped string
     */
    private static String escapeString(String string) {
        StringBuilder result = new StringBuilder(string.length() + 10);
        result.append('"');
        for (int i = 0; i < string.length(); i++) {
            char ch = string.charAt(i);

            switch (ch) {
            case '\n':
                result.append("\\n"); //$NON-NLS-1$
                break;
            case '\r':
                result.append("\\r"); //$NON-NLS-1$
                break;
            case '\t':
                result.append("\\t"); //$NON-NLS-1$
                break;
            case '"':
                result.append("\\\""); //$NON-NLS-1$
                break;
            case '\\':
                result.append("\\\\"); //$NON-NLS-1$
                break;
            default:
                result.append(ch);
            }
        }
        result.append('"');
        return result.toString();
    }
}
