package com.sap.glx.paradigmInterface.bpmn.compiler.stage;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

/**
 * Creates a "ScopeX" GalaxyClass for each type scope which was identified as type dependency.
 * @author d046672
 *
 */
public class CreateScopeClassesStage implements CompilerStage {

	public void execute(CompilerContext ctx) throws BPMNCompilerException {
	    for (Iterable<XsdElementDeclaration> scope: ctx.getDependencyHelper().getAllTypeDependenciesOld()) {
			GalaxyClass scope_class = ctx.getReplicator().generateScopeClass(ctx.getRootScope(), scope);
			ctx.getDependencyHelper().addScopeClassOld(scope,scope_class);
			ctx.getConfigFactory().generateScopeConfiguration(scope);
		}
	}

}
