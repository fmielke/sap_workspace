package com.sap.glx.paradigmInterface.triggernet.assembler;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.sap.glx.constants.RevisionConstants;
import com.sap.glx.ide.model.actions.Action;
import com.sap.glx.ide.model.actions.HardwiredAction;
import com.sap.glx.ide.model.actions.ScriptedAction;
import com.sap.glx.ide.model.classes.Attribute;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.classes.Method;
import com.sap.glx.ide.model.classes.Parameter;
import com.sap.glx.ide.model.classes.SimpleType;
import com.sap.glx.ide.model.classes.SimpleTypesEnum;
import com.sap.glx.ide.model.classes.Type;
import com.sap.glx.ide.model.configuration.AdapterConfiguration;
import com.sap.glx.ide.model.configuration.AttributePredicate;
import com.sap.glx.ide.model.configuration.AttributeSpecification;
import com.sap.glx.ide.model.configuration.AttributeTerm;
import com.sap.glx.ide.model.configuration.ConfigurationString;
import com.sap.glx.ide.model.configuration.ConstantPredicate;
import com.sap.glx.ide.model.configuration.ConstantTerm;
import com.sap.glx.ide.model.configuration.JoinPredicate;
import com.sap.glx.ide.model.configuration.JoinTerm;
import com.sap.glx.ide.model.configuration.SwitchCase;
import com.sap.glx.ide.model.configuration.SwitchPredicate;
import com.sap.glx.ide.model.configuration.TypedConstant;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.CrossProduct;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Input;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.LocalSource;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.Operator;
import com.sap.glx.ide.model.triggernet.Output;
import com.sap.glx.ide.model.triggernet.ParameterFilter;
import com.sap.glx.ide.model.triggernet.RemoteSource;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.ide.model.triggernet.Switch;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.Warnable.Severity;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;

public class GalaxyAssembler {

    // ATTENTION: it is important that the '#' comes first in the list ensure correct escaping
    // of the escape character.
    private static final char[] ESCAPES = { '#', ',', '\n', '\r' };
    private static final char ENDLINE = '\n';

    private static final String CSV_MODE_DECLARATION = "-- DECLARATION --"; //$NON-NLS-1$
    private static final String CSV_MODE_CONFIGURATION = "-- CONFIG --"; //$NON-NLS-1$
    private static final String CSV_MODE_NETWORK = "-- NETWORK --"; //$NON-NLS-1$

    private static final String JAVA_JOIN_CLASS = "com.sap.glx.core.kernel.trigger.node.LockingTreeJoinNode"; //$NON-NLS-1$
    private static final String JAVA_CONSTANT_FILTER_CLASS = "com.sap.glx.core.kernel.trigger.node.ConstantFilterNode"; //$NON-NLS-1$
    private static final String JAVA_PARAMETER_FILTER_CLASS = "com.sap.glx.core.kernel.trigger.node.ParameterFilterNode"; //$NON-NLS-1$
    private static final String JAVA_TARGET_CLASS = "com.sap.glx.core.kernel.trigger.node.DestinationNode"; //$NON-NLS-1$
    private static final String JAVA_SWIZZLE_CLASS = "com.sap.glx.core.kernel.trigger.node.SwizzleNode"; //$NON-NLS-1$
    private static final String JAVA_CROSS_PRODUCT_CLASS = "com.sap.glx.core.kernel.trigger.node.CrossProductNode"; //$NON-NLS-1$
    private static final String JAVA_SWITCH_CLASS = "com.sap.glx.core.kernel.trigger.node.SwitchFilterNode"; //$NON-NLS-1$
    private static final String JAVA_READYSET_CLASS = "com.sap.glx.core.kernel.execution.ready.SemisimpleReadySet"; //$NON-NLS-1$

    private static final String NETWORK = "NETWORK"; //$NON-NLS-1$
    private static final String NODE = "NODE"; //$NON-NLS-1$
    private static final String CLASS = "CLASS";//$NON-NLS-1$
    private static final String ROOT = "ROOT";//$NON-NLS-1$
    private static final String IMMUTABLE = "IMMUTABLE";//$NON-NLS-1$
    private static final String SOURCE = "SOURCE";//$NON-NLS-1$
    private static final String BOOLEAN = "BOOLEAN";//$NON-NLS-1$
    private static final String DOUBLE = "DOUBLE";//$NON-NLS-1$
    private static final String FLOAT = "FLOAT";//$NON-NLS-1$
    private static final String IDENTITY = "IDENTITY";//$NON-NLS-1$
    private static final String INTEGER = "INTEGER";//$NON-NLS-1$
    private static final String LONG = "LONG";//$NON-NLS-1$
    private static final String PARASITE = "PARASITE";//$NON-NLS-1$
    private static final String STREAM = "STREAM";//$NON-NLS-1$
    private static final String STRING = "STRING";//$NON-NLS-1$
    private static final String VOID = "VOID";//$NON-NLS-1$
    private static final String SDO = "SDO";//$NON-NLS-1$
    private static final String REFERENCE = "REFERENCE";//$NON-NLS-1$
    private static final String CONFIG = "CONFIG";//$NON-NLS-1$

    private static final String READYSET = "READYSET";//$NON-NLS-1$

    private static final String[] VALID_COMPARATORS = { "=", "==", "!=", "<>", "<", "<=", ">", ">=" }; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$

    private final IBuilderHost host;

    public GalaxyAssembler(IBuilderHost host) {
        this.host = host;
    }

    public void generateCSV(Subnet subnet, PrintWriter writer) throws AssemblerException {
        new AssemblerRun(subnet).generateCSV(writer);
    }

    class AssemblerRun {

        private final Subnet subnet;
        private PrintWriter out;

        public AssemblerRun(Subnet subnet) {
            this.subnet = subnet;
        }

        private void addLine(String line) {
            // this method does not use the println method because it uses the system
            // specific line separator. Therefore the operating system would influence
            // the process version.
            out.print(line);
            out.print(ENDLINE);
        }

        private String getTypeString(Type type) throws AssemblerException {
            if (type == null || type instanceof SimpleType) {
                return getSimpleString((SimpleType) type);
            } else {
                GalaxyClass cls = (GalaxyClass) type;
                checkClass(cls);
                return cls.getAdapter() + ':' + cls.getName();
            }
        }

        private String getSimpleString(SimpleType simple) {
            if (simple == null)
                return VOID;
            if (simple.getType().equals(SimpleTypesEnum.BOOLEAN))
                return BOOLEAN;
            if (simple.getType().equals(SimpleTypesEnum.DOUBLE))
                return DOUBLE;
            if (simple.getType().equals(SimpleTypesEnum.FLOAT))
                return FLOAT;
            if (simple.getType().equals(SimpleTypesEnum.IDENTITY))
                return IDENTITY;
            if (simple.getType().equals(SimpleTypesEnum.INTEGER))
                return INTEGER;
            if (simple.getType().equals(SimpleTypesEnum.LONG))
                return LONG;
            if (simple.getType().equals(SimpleTypesEnum.PARASITE))
                return PARASITE;
            if (simple.getType().equals(SimpleTypesEnum.STREAM))
                return STREAM;
            if (simple.getType().equals(SimpleTypesEnum.REFERENCE))
                return REFERENCE;
            if (simple.getType().equals(SimpleTypesEnum.SDO))
                return SDO;
            /* if (simple.getType().equals(SimpleTypesEnum.STRING)) */
            return STRING;
        }

        private String getClassString(GalaxyClass cls) throws AssemblerException {
            checkClass(cls);
            Collection<Attribute> attributes = cls.getAttribute();
            Collection<Method> methods = cls.getMethod();
            List<String> items = new LinkedList<String>();

            if (cls.isEvictable()) {
                items.add(ROOT);
            } else if (cls.isImmutable()) {
                items.add(IMMUTABLE);
            } else {
                items.add(CLASS);
            }

            items.add(cls.getName());
            items.add(cls.getAdapter());

            if (attributes != null)
                for (Attribute attribute : attributes) {
                    checkAttribute(attribute);
                    items.add(attribute.getName());
                    items.add(getTypeString(attribute.getAttributeType()));
                }

            if (methods != null)
                for (Method method : methods) {
                    checkMethod(method);
                    items.add(method.getName());
                    items.add("("); //$NON-NLS-1$
                    List<Parameter> parameters = method.getParameter();
                    if (parameters != null)
                        for (Parameter parameter : parameters) {
                            checkMethodType(parameter.getType());
                            items.add(getTypeString(parameter.getType()));
                        }
                    items.add(")"); //$NON-NLS-1$
                    items.add(getTypeString(method.getResultType()));
                }

            return getCommaString(items);
        }

        private String getTargetString(Target target) throws AssemblerException {
            List<String> items = new LinkedList<String>();
            items.add(NODE);
            items.add(target.getName());
            items.add(JAVA_TARGET_CLASS);

            Action action = target.getAction();
            checkAction(action);
            if (action instanceof HardwiredAction)
                items.add(((HardwiredAction) action).getClassName());
            else
                items.add("<% " + ((ScriptedAction) action).getScriptText() + " %>"); //$NON-NLS-1$//$NON-NLS-2$

            items.add("priority=" + Integer.toString(action.getPriority())); //$NON-NLS-1$

            return getCommaString(items);
        }

        private void customConfiguration(List<String> items, Operator operator) throws AssemblerException {
            if (operator.getCustomConfiguration() != null)
                items.add(operator.getCustomConfiguration());
            else
                throw new AssemblerException("Custom configuration is missing in operator: " + operator.getName()); //$NON-NLS-1$
        }

        private String getGenericString(GenericOperator generic) throws AssemblerException {
            checkGeneric(generic);

            List<String> items = new LinkedList<String>();
            items.add(NODE);
            items.add(generic.getName());
            items.add(generic.getImplementationClass());

            try {
                if (generic.getParameters() != null)
                    for (String parameter : generic.getParameters()) {
                        checkParameter(parameter);
                        items.add(parameter);
                    }
            } catch (AssemblerException e) {
                customConfiguration(items, generic);
            }

            return getCommaString(items);
        }

        private String getConstantFilterString(ConstantFilter filter) throws AssemblerException {
            checkOutgoingConnectors(filter);

            List<String> items = new LinkedList<String>();
            items.add(NODE);
            items.add(filter.getName());
            items.add(JAVA_CONSTANT_FILTER_CLASS);

            try {
                checkConstantPredicate(filter.getConstantPredicate());
                List<String> operands = new LinkedList<String>(), constants = new LinkedList<String>(), operators = new LinkedList<String>();
                for (ConstantTerm term : filter.getConstantPredicate().getConstantTerm()) {
                    checkConstantTerm(term);
                    operands.add(getSlashString(Integer.toString(term.getLeftOperand().getInputChannel()), Integer.toString(term
                            .getLeftOperand().getParameterNumber()), Integer.toString(term.getLeftOperand().getAttributeId())));
                    if (term.getRightOperand().getValue() != null)
                        constants.add(getSimpleString(term.getRightOperand().getSimpleType()) + ":" + term.getRightOperand().getValue()); //$NON-NLS-1$
                    else
                        constants.add("NULL"); //$NON-NLS-1$

                    operators.add(term.getComparator());
                }
                items.add(getAmpersandString(operands));
                items.add(getAmpersandString(constants));
                items.add(getAmpersandString(operators));
            } catch (AssemblerException e) {
                customConfiguration(items, filter);
            }

            return getCommaString(items);
        }

        private String getParameterFilterString(ParameterFilter filter) throws AssemblerException {
            checkOutgoingConnectors(filter);

            List<String> items = new LinkedList<String>();
            items.add(NODE);
            items.add(filter.getName());
            items.add(JAVA_PARAMETER_FILTER_CLASS);

            try {
                checkAttributePredicate(filter.getAttributePredicate());
                List<String> left_operands = new LinkedList<String>(), right_operands = new LinkedList<String>(), operators = new LinkedList<String>();
                for (AttributeTerm term : filter.getAttributePredicate().getAttributeTerm()) {
                    checkAttributeTerm(term);
                    left_operands.add(getSlashString(Integer.toString(term.getLeftOperand().getInputChannel()), Integer.toString(term
                            .getLeftOperand().getParameterNumber()), Integer.toString(term.getLeftOperand().getAttributeId())));
                    right_operands.add(getSlashString(Integer.toString(term.getRightOperand().getInputChannel()), Integer.toString(term
                            .getRightOperand().getParameterNumber()), Integer.toString(term.getRightOperand().getAttributeId())));
                    operators.add(term.getComparator());
                }
                items.add(getAmpersandString(left_operands));
                items.add(getAmpersandString(right_operands));
                items.add(getAmpersandString(operators));
            } catch (AssemblerException e) {
                customConfiguration(items, filter);
            }

            return getCommaString(items);
        }

        private String getJoinString(Join join) throws AssemblerException {
            checkOutgoingConnectors(join);

            List<String> items = new LinkedList<String>();
            items.add(NODE);
            items.add(join.getName());
            items.add(JAVA_JOIN_CLASS);

            try {
                checkJoinPredicate(join.getJoinPredicate());
                List<String> left_operands = new LinkedList<String>(), right_operands = new LinkedList<String>();
                for (JoinTerm term : join.getJoinPredicate().getJoinTerm()) {
                    checkJoinTerm(term);
                    left_operands.add(getSlashString(Integer.toString(term.getLeftOperand().getInputChannel()), Integer.toString(term
                            .getLeftOperand().getParameterNumber()), Integer.toString(term.getLeftOperand().getAttributeId())));
                    right_operands.add(getSlashString(Integer.toString(term.getRightOperand().getInputChannel()), Integer.toString(term
                            .getRightOperand().getParameterNumber()), Integer.toString(term.getRightOperand().getAttributeId())));
                }
                items.add(getAmpersandString(left_operands));
                items.add(getAmpersandString(right_operands));
            } catch (AssemblerException e) {
                customConfiguration(items, join);
            }

            return getCommaString(items);
        }

        private String getSwitchString(Switch witch) throws AssemblerException {
            checkOutgoingConnectors(witch);

            List<String> items = new LinkedList<String>();
            items.add(NODE);
            items.add(witch.getName());
            items.add(JAVA_SWITCH_CLASS);

            try {
                checkSwitchPredicate(witch.getSwitchPredicate());
                List<String> operands = new LinkedList<String>();
                for (AttributeSpecification attr : witch.getSwitchPredicate().getAttributeSpecification())
                    operands.add(getSlashString(Integer.toString(attr.getInputChannel()), Integer.toString(attr.getParameterNumber()),
                            Integer.toString(attr.getAttributeId())));
                items.add(getAmpersandString(operands));

                for (SwitchCase casa : witch.getSwitchPredicate().getRow()) {
                    checkSwitchCase(casa, operands.size());
                    List<String> constants = new LinkedList<String>();
                    for (TypedConstant constant : casa.getElement())
                        constants.add(getSimpleString(constant.getSimpleType()) + ":" + constant.getValue()); //$NON-NLS-1$
                    items.add(getAmpersandString(constants));
                }
            } catch (AssemblerException e) {
                customConfiguration(items, witch);
            }

            return getCommaString(items);
        }

        public String getSwizzleString(Swizzle swizzle) throws AssemblerException {
            checkOutgoingConnectors(swizzle);

            List<String> items = new LinkedList<String>();
            items.add(NODE);
            items.add(swizzle.getName());
            items.add(JAVA_SWIZZLE_CLASS);

            try {
                checkSwizzleParameters((List<Integer>) swizzle.getParameters());
                List<String> parameters = new LinkedList<String>();
                for (int param : (List<Integer>) swizzle.getParameters()) {
                    parameters.add(String.valueOf(param));
                }
                items.add(getSlashString(parameters));
            } catch (AssemblerException e) {
                customConfiguration(items, swizzle);
            }
            return getCommaString(items);
        }

        private String getCrossProductString(CrossProduct cross) throws AssemblerException {
            checkOutgoingConnectors(cross);

            List<String> items = new LinkedList<String>();
            items.add(NODE);
            items.add(cross.getName());
            items.add(JAVA_CROSS_PRODUCT_CLASS);

            return getCommaString(items);
        }

        private String getSourceString(LocalSource source) throws AssemblerException {
            checkOutgoingConnectors(source);
            GalaxyClass cls = source.getGalaxyClass();
            return getCommaString(SOURCE, source.getName(), cls.getName(), cls.getAdapter());
        }

        private String getSourceString(RemoteSource source) throws AssemblerException {
            checkOutgoingConnectors(source);
            return getCommaString(SOURCE, source.getName(), source.getClassName(), source.getAdapterName());
        }

        private String getReadySetString() {
            return getCommaString(READYSET, JAVA_READYSET_CLASS);
        }

        private void declarationMode() throws AssemblerException {
            addLine(CSV_MODE_DECLARATION);

            Set<GalaxyClass> seen_classes = new HashSet<GalaxyClass>();
            Collection<GalaxyClass> classes = subnet.getGalaxyClass();
            if (classes != null)
                for (GalaxyClass cls : classes) {
                    seen_classes.add(cls);
                    addLine(getClassString(cls));
                }

            Collection<Node> nodes = subnet.getNode();
            if (nodes != null)
                for (Node node : nodes) {
                    if (node instanceof LocalSource) {
                        GalaxyClass cls = ((LocalSource) node).getGalaxyClass();
                        if (!seen_classes.contains(cls)) {
                            seen_classes.add(cls);
                            addLine(getClassString(cls));
                        }
                        addLine(getSourceString((LocalSource) node));
                    } else if (node instanceof RemoteSource) {
                        addLine(getSourceString((RemoteSource) node));
                    } else if (node instanceof Target) {
                        addLine(getTargetString((Target) node));
                    } else if (node instanceof GenericOperator) {
                        addLine(getGenericString((GenericOperator) node));
                    } else if (node instanceof ConstantFilter) {
                        addLine(getConstantFilterString((ConstantFilter) node));
                    } else if (node instanceof ParameterFilter) {
                        addLine(getParameterFilterString((ParameterFilter) node));
                    } else if (node instanceof Join) {
                        addLine(getJoinString((Join) node));
                    } else if (node instanceof Switch) {
                        addLine(getSwitchString((Switch) node));
                    } else if (node instanceof Swizzle) {
                        addLine(getSwizzleString((Swizzle) node));
                    } else if (node instanceof CrossProduct) {
                        addLine(getCrossProductString((CrossProduct) node));
                    }
                }

            addLine(getReadySetString());

        }

        private void addAdapterLines(AdapterConfiguration config) throws AssemblerException {
            // walk thru the configuration lines directly bound to the adapter config
            for (ConfigurationString root : config.getRoot()) {
                List<String> line = new LinkedList<String>();
                line.add(CONFIG);
                line.add(config.getAdapterName());
                recursiveTraversal(line, root);
            }
        }

        private void recursiveTraversal(List<String> line, ConfigurationString root) {
            line.add(root.getValue());

            if (root.getChild() != null && root.getChild().size() > 0) {
                for (ConfigurationString child : root.getChild()) {
                    recursiveTraversal(new LinkedList<String>(line), child);
                }
            } else {
                addLine(getCommaString(line));
            }
        }

        private void configurationMode() throws AssemblerException {
            addLine(CSV_MODE_CONFIGURATION);

            Collection<AdapterConfiguration> configs = subnet.getAdapterConfiguration();
            if (configs != null)
                for (AdapterConfiguration config : configs) {
                    addAdapterLines(config);
                }
        }

        private void networkMode() throws AssemblerException {
            addLine(CSV_MODE_NETWORK);

            List<String> lines = new ArrayList<String>();
            Collection<Node> nodes = subnet.getNode();
            if (nodes != null)
                for (Node node : nodes) {
                    for (int i = 0; i < node.getOutputChannels().size(); i++) {
                        Output output = (node.getOutputChannels()).get(i);
                        for (Input input : output.getTargets()) {
                            lines.add(getCommaString(node.getName(), Integer.toString(i), input.getOwner().getName(), Integer
                                    .toString(input.getOwner().getInputChannels().indexOf(input))));
                        }
                    }
                }

            Object[] sorted = lines.toArray();
            Arrays.sort(sorted);
            for (Object line : sorted)
                addLine(line.toString());

        }

        public void generateCSV(PrintWriter out) throws AssemblerException {
            this.out = out;

            try {
                addLine(getCommaString(NETWORK, subnet.getId(), subnet.getName()));
                addLine(getCommaString("REVISIONID", Integer.toString(RevisionConstants.REVISION_MAJOR), //$NON-NLS-1$
                        Integer.toString(RevisionConstants.REVISION_MINOR), RevisionConstants.REVISION_COMMENT));

                declarationMode();

                configurationMode();

                networkMode();

                this.out.flush();
            } finally {
                this.out.close();
            }
        }

        private void checkClass(GalaxyClass cls) throws AssemblerException {
            if (cls == null)
                throw new AssemblerException("Class was NULL."); //$NON-NLS-1$
            if (cls.getName() == null || cls.getName().length() == 0)
                throw new AssemblerException("Class name in GalaxyClass specification was not set."); //$NON-NLS-1$
            if (cls.getAdapter() == null || cls.getAdapter().length() == 0)
                throw new AssemblerException("Adapter name in GalaxyClass specification was not set."); //$NON-NLS-1$
        }

        private void checkAttribute(Attribute attr) throws AssemblerException {
            if (attr == null)
                throw new AssemblerException("Attribute was NULL."); //$NON-NLS-1$
            if (attr.getName() == null || attr.getName().length() == 0)
                throw new AssemblerException("Attribute name was not set."); //$NON-NLS-1$
            checkAttributeType(attr.getAttributeType());
        }

        private void checkMethod(Method method) throws AssemblerException {
            if (method == null)
                throw new AssemblerException("Method was NULL."); //$NON-NLS-1$
            if (method.getName() == null || method.getName().length() == 0)
                throw new AssemblerException("Method name was not set."); //$NON-NLS-1$
            checkMethodType(method.getResultType());
        }

        private void checkSimple(SimpleType simple) throws AssemblerException {
            if (simple == null)
                throw new AssemblerException("Simple type was NULL."); //$NON-NLS-1$
            if (!(simple.getType().equals(SimpleTypesEnum.BOOLEAN) || simple.getType().equals(SimpleTypesEnum.DOUBLE)
                    || simple.getType().equals(SimpleTypesEnum.FLOAT) || simple.getType().equals(SimpleTypesEnum.IDENTITY)
                    || simple.getType().equals(SimpleTypesEnum.INTEGER) || simple.getType().equals(SimpleTypesEnum.LONG)
                    || simple.getType().equals(SimpleTypesEnum.PARASITE) || simple.getType().equals(SimpleTypesEnum.STREAM)
                    || simple.getType().equals(SimpleTypesEnum.STRING) || simple.getType().equals(SimpleTypesEnum.SDO) || simple.getType()
                    .equals(SimpleTypesEnum.REFERENCE)))
                throw new AssemblerException("Unknown simple type."); //$NON-NLS-1$
        }

        private void checkAttributeType(Type type) throws AssemblerException {
            if (type == null)
                throw new AssemblerException("Type was NULL."); //$NON-NLS-1$
            if (type instanceof GalaxyClass)
                checkClass((GalaxyClass) type);
            else
                checkSimple((SimpleType) type);
        }

        private void checkMethodType(Type type) throws AssemblerException {
            if (type != null) {
                if (type instanceof GalaxyClass)
                    checkClass((GalaxyClass) type);
                else
                    checkSimple((SimpleType) type);
            }
        }

        private void checkOutgoingConnectors(Node node) throws AssemblerException {
            boolean noConnectors = true;
            if (node.getOutputChannels() != null) {
                for (Output output : node.getOutputChannels()) {
                    if (output != null && output.getTargets() != null && !output.getTargets().isEmpty()) {
                        noConnectors = false;
                    }
                }
            }
            if (noConnectors) {
                host.getWarnable().addWarning(Severity.WARNING, node,
                        "Node '%s' of the generated triggernet has no outgoing connector.", node.getName()); //$NON-NLS-1$
            }
        }

        private void checkAction(Action action) throws AssemblerException {
            if (action == null)
                throw new AssemblerException("Action was NULL."); //$NON-NLS-1$
            if (action instanceof HardwiredAction) {
                if (((HardwiredAction) action).getClassName() == null || ((HardwiredAction) action).getClassName().length() == 0)
                    throw new AssemblerException("Missing or invalid class name of hardwired action."); //$NON-NLS-1$
            } else if (action instanceof ScriptedAction) {
                if (((ScriptedAction) action).getScriptText() == null || ((ScriptedAction) action).getScriptText().length() == 0)
                    throw new AssemblerException("Missing or invalid script text in scripted action."); //$NON-NLS-1$
            } else
                throw new AssemblerException("Action is neither scripted nor hard wired."); //$NON-NLS-1$
        }

        private void checkParameter(String param) throws AssemblerException {
            if (param == null || param.length() == 0)
                throw new AssemblerException("Node parameter was NULL or zero length."); //$NON-NLS-1$
        }

        private void checkGeneric(GenericOperator generic) throws AssemblerException {
            if (generic.getImplementationClass() == null || generic.getImplementationClass().length() == 0)
                throw new AssemblerException("Implementatin class of generic operator was not set."); //$NON-NLS-1$
        }

        private void checkConstantPredicate(ConstantPredicate pred) throws AssemblerException {
            if (pred == null)
                throw new AssemblerException("Constant filter predicate was NULL."); //$NON-NLS-1$
            if (pred.getConstantTerm() == null || pred.getConstantTerm().size() == 0)
                throw new AssemblerException("Missing terms in constant filter predicate."); //$NON-NLS-1$
        }

        private void checkConstantTerm(ConstantTerm term) throws AssemblerException {
            if (term == null)
                throw new AssemblerException("Term in constant filter predicate was NULL."); //$NON-NLS-1$
            if (term.getLeftOperand() == null || term.getLeftOperand().getInputChannel() != 0)
                throw new AssemblerException("Missing or wrong attribute specification in constant filter term."); //$NON-NLS-1$
            if (term.getRightOperand() == null)
                throw new AssemblerException("Missing constant specification in constant filter term."); //$NON-NLS-1$
            checkComparator(term.getComparator());
            checkSimple(term.getRightOperand().getSimpleType());
        }

        private void checkComparator(String comparator) throws AssemblerException {
            if (comparator == null)
                throw new AssemblerException("Comparator specification was NULL."); //$NON-NLS-1$
            for (String valid : VALID_COMPARATORS)
                if (valid.equals(comparator))
                    return;
            throw new AssemblerException("Invalid comparator specification."); //$NON-NLS-1$
        }

        private void checkAttributePredicate(AttributePredicate pred) throws AssemblerException {
            if (pred == null)
                throw new AssemblerException("Parameter filter predicate was NULL."); //$NON-NLS-1$
            if (pred.getAttributeTerm() == null || pred.getAttributeTerm().size() == 0)
                throw new AssemblerException("Missing terms in parameter filter predicate."); //$NON-NLS-1$
        }

        private void checkAttributeTerm(AttributeTerm term) throws AssemblerException {
            if (term == null)
                throw new AssemblerException("Term in attribute filter predicate was NULL."); //$NON-NLS-1$
            if (term.getLeftOperand() == null || term.getRightOperand() == null)
                throw new AssemblerException("Term in attribute filter predicate must relate to two attribute specifications."); //$NON-NLS-1$
            if (term.getLeftOperand().getInputChannel() != 0 || term.getRightOperand().getInputChannel() != 0)
                throw new AssemblerException("Input channels in attribute terms are invalid."); //$NON-NLS-1$
        }

        private void checkJoinPredicate(JoinPredicate pred) throws AssemblerException {
            if (pred == null)
                throw new AssemblerException("Join predicate was NULL."); //$NON-NLS-1$
            if (pred.getJoinTerm() == null || pred.getJoinTerm().size() == 0)
                throw new AssemblerException("Missing terms in join predicate."); //$NON-NLS-1$
        }

        private void checkJoinTerm(JoinTerm term) throws AssemblerException {
            if (term == null)
                throw new AssemblerException("Term in join predicate was NULL."); //$NON-NLS-1$
            if (term.getLeftOperand() == null || term.getRightOperand() == null)
                throw new AssemblerException("Term in join predicate must relate to two attribute specifications."); //$NON-NLS-1$
            if (term.getLeftOperand().getInputChannel() != 0 || term.getRightOperand().getInputChannel() != 1)
                throw new AssemblerException("Input channels in join term are invalid."); //$NON-NLS-1$
        }

        private void checkSwitchPredicate(SwitchPredicate pred) throws AssemblerException {
            if (pred == null)
                throw new AssemblerException("Switch predicate was NULL."); //$NON-NLS-1$
            if (pred.getAttributeSpecification() == null || pred.getAttributeSpecification().size() == 0)
                throw new AssemblerException("Switch attributes were not set."); //$NON-NLS-1$
            if (pred.getRow() == null || pred.getRow().size() == 0)
                throw new AssemblerException("No switch cases were defined."); //$NON-NLS-1$
        }

        private void checkSwitchCase(SwitchCase casa, int attribute_count) throws AssemblerException {
            if (casa == null)
                throw new AssemblerException("Switch case was NULL."); //$NON-NLS-1$
            if (casa.getElement() == null || casa.getElement().size() != attribute_count)
                throw new AssemblerException(
                        "Number of constants in switch case does not match the number of attributes in switch predicate."); //$NON-NLS-1$
            for (TypedConstant constant : casa.getElement()) {
                if (constant == null || constant.getValue() == null || constant.getValue().length() == 0)
                    throw new AssemblerException("Invalid constant specification in switch case."); //$NON-NLS-1$
                checkSimple(constant.getSimpleType());
            }
        }

        private void checkSwizzleParameters(List<Integer> parameters) throws AssemblerException {
            if (parameters == null || parameters.size() == 0)
                throw new AssemblerException("Swizzle parameters were not set."); //$NON-NLS-1$
        }
    }

    public static String escape(String s) {
        if (s != null) {
            for (char escape : ESCAPES) {
                String hex = Integer.toHexString(Character.codePointAt(new char[] { escape }, 0));
                while (hex.length() < 2) {
                    hex = "0" + hex; //$NON-NLS-1$
                }
                s = s.replace(new String(new char[] { escape }), "#" + hex + "#"); //$NON-NLS-1$//$NON-NLS-2$
            }
        }
        return s;
    }

    private static String getSeparatedString(char separator, String... items) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < items.length; i++) {
            sb.append(escape(items[i]));
            if (i < items.length - 1) {
                sb.append(separator);
            }
        }
        return sb.toString();
    }

    private static String getCommaString(String... items) {
        return getSeparatedString(',', items);
    }

    private static String getCommaString(List<String> items) {
        return getSeparatedString(',', items.toArray(new String[items.size()]));
    }

    private static String getAmpersandString(String... items) {
        return getSeparatedString('&', items);
    }

    private static String getAmpersandString(List<String> items) {
        return getAmpersandString(items.toArray(new String[items.size()]));
    }

    private static String getSlashString(String... items) {
        return getSeparatedString('/', items);
    }

    private static String getSlashString(List<String> items) {
        return getSlashString(items.toArray(new String[items.size()]));
    }

}
