package com.sap.glx.paradigmInterface.triggernet.nodes;

import java.util.List;

import com.sap.glx.ide.model.classes.Attribute;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;

public class DBCorrelationJoin {

	private GalaxyClass clsEvent;
	private GalaxyClass clsSubscription;
	private StringBuilder confEvent;
	private StringBuilder confSubscription;
	private String confNodeId;
	
	public DBCorrelationJoin(String nodeId, GalaxyClass clsEvent, GalaxyClass clsSubscription) {
		this.confNodeId = nodeId;
		this.clsEvent = clsEvent;
		this.clsSubscription = clsSubscription;
	}
	
	public GalaxyClass getSubscription() {
		return clsSubscription;
	}
	
	public GalaxyClass getEvent() {
		return clsEvent;
	}

	public void addConjuction(List<Pair<Attribute, Attribute>> conjuction) {
		if (confEvent == null) {
			confEvent = new StringBuilder();
			confSubscription = new StringBuilder();
		} else {
			confEvent.append("|");
			confSubscription.append("|");
		}

		int i = 0;
		for (Pair<Attribute, Attribute> equality : conjuction) {
			confEvent.append("0/1/");
			confEvent.append(clsEvent.getAttribute().indexOf(equality.first));
			confSubscription.append("1/0/");
			confSubscription.append(clsSubscription.getAttribute().indexOf(equality.second));
			if (i < (conjuction.size() -1 )) {
				confEvent.append("&");
				confSubscription.append("&");
			}
			i++;
		}
	}
	
	public String getEventConf() {
		return confEvent.toString();
	}

	public String getSubscriptionConf() {
		return confSubscription.toString();
	}
	
	public String getNodeIdConf() {
		return confNodeId;
	}
}