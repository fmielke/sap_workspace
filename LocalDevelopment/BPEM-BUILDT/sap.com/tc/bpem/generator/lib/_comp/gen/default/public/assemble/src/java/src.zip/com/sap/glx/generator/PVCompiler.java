package com.sap.glx.generator;

import java.io.IOException;
import java.io.OutputStream;

import com.sap.tc.moin.repository.mmi.reflect.RefObject;

import com.sap.glx.ide.model.galaxy.workflow.Collaboration;
import com.sap.glx.paradigmInterface.buildapi.BpemBuildException;
import com.sap.glx.paradigmInterface.buildapi.IArtifact;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost2;
import com.sap.glx.paradigmInterface.buildapi.ICompiler;
import com.sap.glx.paradigmInterface.buildapi.ICompiler2;
import com.sap.glx.paradigmInterface.buildapi.VisualizationArtifact;
import com.sap.mi.gfw.mm.pictograms.Diagram;

public class PVCompiler extends DiagramToXMLConverter implements ICompiler, ICompiler2<Collaboration, VisualizationArtifact>{
	
	String PROCVIS_FILE_EXTENSION = ".procvis"; //$NON-NLS-1$
	private static final String ENCODING="UTF-8";//$NON-NLS-1$
	/**
	 * The XML Converter can compile the Workflow objects.
	 */
	public boolean canCompile(Object artifact) {
		if (artifact instanceof Collaboration) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * The XML Converter hasn't got a dependency.
	 */
	public Object[] getDependencies(IBuilderHost host, Object artifact) {
		return new Object[0];
	}

	/**
	 * Compile the workflow into XML file.
	 */
	public boolean compile(IBuilderHost host, Object artifact) throws Exception {
		//crean the base variables
		clean();
		Collaboration aWorkflow = (Collaboration) artifact;
		String artifactName = aWorkflow.getName().getOriginalText();
		OutputStream stream = host.createVersionedTargetFile(artifactName
				+ PROCVIS_FILE_EXTENSION, artifact); 
		Object _obj = XMLUtil.getDiagram( (RefObject)artifact );
		iterateOverElements((Diagram)_obj, aWorkflow );
    	String _str = getCompiledContent();
    	stream.write(_str.getBytes(ENCODING));
    	stream.close();
    	//write to file as inputstream
    	
		return true;
	}
	
	/**
	 * Compile the workflow into XML file.
	 */
	public boolean compile(IBuilderHost2 host, VisualizationArtifact artifact) throws BpemBuildException {
		//crean the base variables
		clean();
		Collaboration aWorkflow = (Collaboration) artifact.getObject();
		String artifactName = aWorkflow.getName().getOriginalText();
		OutputStream stream = host.createVersionedTargetFile(artifactName
				+ PROCVIS_FILE_EXTENSION, artifact);
		Object _obj = XMLUtil.getDiagram( (RefObject)artifact.getObject() );
		iterateOverElements((Diagram)_obj, aWorkflow );
    	String _str = getCompiledContent();
    	
    	try{
    		stream.write(_str.getBytes(ENCODING));
    		stream.close();
    	}
    	catch(IOException e){
    		throw new BpemBuildException(e); 
    	}
    	//write to file as inputstream
    	
		return true;
	}

	/**
	 * The XML Converter hasn't got a dependency.
	 */
	public IArtifact<?>[] getDependencies(IBuilderHost2 host, VisualizationArtifact artifact) {
		return new IArtifact<?>[0];
	}
}
