package com.sap.glx.generator.api;

public interface ILocation {

    int getY();

    void setY(int y);

    int getX();

    void setX(int x);
}
