package com.sap.glx.generator;

import java.awt.Rectangle;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.sap.glx.generator.DiagramToXMLConverter.NodeType;
import com.sap.glx.generator.api.ILocation;
import com.sap.glx.ide.model.galaxy.processsupplements.NotificationActivity;
import com.sap.glx.ide.model.galaxy.processsupplements.ReportingActivity;
import com.sap.glx.ide.model.galaxy.task.StandaloneTask;
import com.sap.glx.ide.model.galaxy.workflow.Annotation;
import com.sap.glx.ide.model.galaxy.workflow.AutomatedActivity;
import com.sap.glx.ide.model.galaxy.workflow.BoundaryEvent;
import com.sap.glx.ide.model.galaxy.workflow.CatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.ConditionalSequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.DataObject;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.ErrorEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.EventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.ExclusiveDataSplitGateway;
import com.sap.glx.ide.model.galaxy.workflow.ExclusiveEventSplitGateway;
import com.sap.glx.ide.model.galaxy.workflow.HumanActivity;
import com.sap.glx.ide.model.galaxy.workflow.Lane;
import com.sap.glx.ide.model.galaxy.workflow.MappingActivity;
import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowConnector;
import com.sap.glx.ide.model.galaxy.workflow.ParallelJoinGateway;
import com.sap.glx.ide.model.galaxy.workflow.ParallelSplitGateway;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.galaxy.workflow.PoolReference;
import com.sap.glx.ide.model.galaxy.workflow.ScopeObject;
import com.sap.glx.ide.model.galaxy.workflow.SequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.StartEvent;
import com.sap.glx.ide.model.galaxy.workflow.ThrowEvent;
import com.sap.glx.ide.model.galaxy.workflow.TimerEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.UncontrolledJoinGateway;
import com.sap.glx.paradigmInterface.util.EventDefinitionUtil;
import com.sap.glx.paradigmInterface.util.ToolUtils;
import com.sap.glx.paradigmInterface.util.EventDefinitionUtil.EventDefinitionType;
import com.sap.mi.gfw.mm.pictograms.Diagram;
import com.sap.mi.gfw.mm.pictograms.GraphicsAlgorithm;
import com.sap.mi.gfw.mm.pictograms.PictogramElement;
import com.sap.mi.gfw.mm.pictograms.Property;
import com.sap.mi.gfw.mm.pictograms.PropertyContainer;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.moin.repository.Partitionable;
import com.sap.tc.moin.repository.mmi.reflect.RefObject;

/**
 * Class which contain all helper methods to query the RefObject's graphical
 * data.
 * 
 * @author I043996
 */
public class PVUtil {
    /**
     * Method to log information to LogView
     * @param String
     */
	protected static void log(String aMessage) {
        Log.info(aMessage);
    }

    /**
     * Method to create a file and fill it with content into the active project If the file exists in the project, then
     * it will be deleted, and a new file will be created.
     * 
     * @param String
     *            the file content
     */
//    @SuppressWarnings("deprecation")
    protected static void writeXMLToFile(Diagram aDiagram, String aXMLString) {
    }
	/**
	 * Gets the x coordinate of a RefObject
	 * 
	 * @param RefObject the RefObject
	 * @return int the x coordinate
	 */
    protected static int getXCoordinate( final RefObject aRefObject ){
    	if(XMLUtil.getFirstPictogramElementForBusinessObject( aRefObject )== null) return 0;
    	GraphicsAlgorithm ga = XMLUtil.getFirstPictogramElementForBusinessObject( aRefObject ).getGraphicsAlgorithm();
    	int x = 0;
    	if( ga.isFilled() == null || ga.isFilled() ){
    		x = x + ga.getX();
    	}else{
    		x = x + ga.getX();
    		x = x + ga.getGraphicsAlgorithmChildren().get(0).getX();
    	}
    	return x;
    }

    /**
	 * Gets the y coordinate of a RefObject
	 * 
	 * @param RefObject the RefObject
	 * @return int the y coordinate
	 */
    protected static int getYCoordinate( final RefObject aRefObject ){
    	if(XMLUtil.getFirstPictogramElementForBusinessObject( aRefObject )== null) return 0;
    	int y = 0;
    	GraphicsAlgorithm ga = XMLUtil.getFirstPictogramElementForBusinessObject( aRefObject ).getGraphicsAlgorithm();
    	if( ga.isFilled() == null || ga.isFilled() ){
    		y = y + ga.getY();	
    	}else{
    		y = y+ ga.getY();
    		y = y + ga.getGraphicsAlgorithmChildren().get(0).getY();
    	}
    	return y;
    }

    /**
	 * Gets the width of a RefObject
	 * 
	 * @param RefObject the RefObject
	 * @return int the width 
	 */
    protected static int getRefObjectWidth( final RefObject aRefObject ){
    	if(XMLUtil.getFirstPictogramElementForBusinessObject( aRefObject )==null)return 0;
    	GraphicsAlgorithm ga = XMLUtil.getFirstPictogramElementForBusinessObject( aRefObject ).getGraphicsAlgorithm();
    	if( ga.isFilled() ==null || ga.isFilled()){
    		return ga.getWidth();
    	}else{
    		return ga.getGraphicsAlgorithmChildren().get( 0 ).getWidth();	
    	}
    }

    /**
	 * Gets the height of a RefObject
	 * 
	 * @param RefObject the RefObject
	 * @return int the height 
	 */
    protected static int getRefObjectHeight( final RefObject aRefObject ){
    	if(XMLUtil.getFirstPictogramElementForBusinessObject( aRefObject )==null)return 0;
    	GraphicsAlgorithm ga = XMLUtil.getFirstPictogramElementForBusinessObject( aRefObject ).getGraphicsAlgorithm();
    	if( ga.isFilled() == null || ga.isFilled()){
    		return ga.getHeight();
    	}else{
    		return ga.getGraphicsAlgorithmChildren().get(0).getHeight();
    	}
    }
    
    /**
	 * Returns the pictogram element of a RefObject
	 * 
	 * @param RefObject the RefObject
	 * @return PictogramElement 
	 */
    protected static PictogramElement getPictogramElement( final RefObject aRefObject ){
    	 return  XMLUtil.getFirstPictogramElementForBusinessObject( aRefObject );
    }
    
    /**
	 * Gets the BusinessObject of a PictogramElement
	 * 
	 * @param RefObject the RefObject
	 * @return RefObject 
	 */
    protected static RefObject getBusinessObject( final PictogramElement aPictogramElement ){
    	return XMLUtil.getBusinessObjectForLinkedPictogramElement( aPictogramElement );
    }
    
    /**
	 * Gets the orientation of the Diagram
	 * 
	 * @param Diagram the diagram
	 * @return String the orientation 
	 */
    protected static String getDiagramOrientation( final Diagram aDiagram ){
    	return XMLUtil.getPropertyValue( aDiagram, FlowConstants.CONTAINER_ORIENTATION );
    }
    /**
	 * Gets the location of a Shape
	 * 
	 * @param Shape
	 * @return ILocation 
	 */
    protected static ILocation getLocationRelativetoDiagram( final com.sap.mi.gfw.mm.pictograms.Shape aShape ){
		return XMLUtil.getLocationRelativeToDiagram(aShape); 
    }
    
    /**
     * Gets the insets of a RefObject
     * 
     * @param RefObject
     * @param int :0-left, 1:top
     * @return int the inset
     */
    protected static int getInsets(final RefObject aRefObject, int which ){
    	switch( which){
    		case 0:{return 0;}
    		case 1:{return 0;}
    		default: return 0;
    	}
    }
    /**
     * Checks whether a pool has a due date (a.k.a. completion deadline).
     * 
     * @param aPool The pool to use
     * 
     * @return 
     * 		Whether the pool has a due date
     */
	     static protected boolean getActivityCompletition(final Pool aPool) {
        if (aPool == null)
            return false;
        // retrieve human activities in pool
        Collection<HumanActivity> has = ToolUtils.getInstance().queryByTypeAndJoinCondition(((Partitionable) aPool).get___Connection(), HumanActivity.class,
                HumanActivity.CLASS_DESCRIPTOR.getQualifiedName(), false, aPool, "scope", aPool); //$NON-NLS-1$

        // iterate over tasks to see whether they have the completion deadline set
        for (HumanActivity ha : has) {
            { // TODO: add support for embedded tasks in the future!
                if (ha.getReferencedScope() != null && ha.getReferencedScope() instanceof StandaloneTask
                        && XMLUtil.isCompletionDeadlineSet((StandaloneTask) ha.getReferencedScope()))
                    return true;
            }
        }
        return false;
    }
    
    /**
     * In case the Pool is not Default Pool, then a header is
     * draw, which contains the name of the pool. In this case
     * all X coordinates must be shifted with the width of the pool's
     * header 
     * 
     * @param int Orientation. Values can be the followings:
     * <ul>
     * 	<li> DiagramToXMLConverter.HORIZONTAL_ORIENTATION
     * 	<li> DiagramToXMLConverter.VERTICAL_ORIENTATION
     * </ul>
     * @param x
     * @return
     */
    static protected int modifyXCoordinateWithPoolHeader( final boolean isBoundaryVisible, final int aOrientation, int x ){
    	if( !isBoundaryVisible) return x;
//       	if( aOrientation == DiagramToXMLConverter.HORIZONTAL_ORIENTATION ){
//    		x = x  + DiagramToXMLConverter.POOL_HEADER;
//       	}
       	return x;
    }
    
    /**
     * In case the Pool is not Default Pool, then a header is
     * draw, which contains the name of the pool. In this case
     * all Y coordinates must be shifted with the width of the pool's
     * header 
     * 
     * @param int Orientation. Values can be the followings:
     * <ul>
     * 	<li> DiagramToXMLConverter.HORIZONTAL_ORIENTATION
     * 	<li> DiagramToXMLConverter.VERTICAL_ORIENTATION
     * </ul>
     * @param x
     * @return
     */
    static protected int modifyYCoordinateWithPoolHeader( final boolean isBoundaryVisible, final int aOrientation, int y ){
    	if( !isBoundaryVisible ) return y;
//       	if( aOrientation == DiagramToXMLConverter.HORIZONTAL_ORIENTATION ){
//    		y = y  + DiagramToXMLConverter.POOL_HEADER;
//       	}
       	return y;
    }
    
    /**
     * Counts the X coordinate for the connector. This method is used for
     * counting the start and end "x" coordinate
     * 
     *   @param RefObject 
     */
    static protected int getXForConnector( final RefObject aRefObject ){
    	int x = 0;
    	//get the x of the object
    	int x_coord  = PVUtil.getXCoordinate( aRefObject );
//    	//get the width
    	int width =PVUtil.getRefObjectWidth( aRefObject );
    	x = x_coord +  width/2;
    	return x;
    }
    
    /**
     * Counts the Y coordinate for the connector. This method is used for
     * counting the start and end "y" coordinate
     * 
     *   @param RefObject 
     */
    static protected int getYForConnector( final RefObject aRefObject ){
    	int y = 0;
    	//get the y of the object
    	int y_coord  = PVUtil.getYCoordinate( aRefObject );
    	//get the height
    	int height =PVUtil.getRefObjectHeight( aRefObject );
    	y = y_coord + height/2;    	
    	return y;
    }

	/**
	 * Calculates and returns the "x" coordinate for a BoundaryEvent
	 * 
	 * @param RefObject
	 *            represents the Activity of the BoundaryEvent
	 * @param RefObject
	 *            represents the BoundaryEvent
	 * @param int the "y" coordinate for the lane where the LaneObject is
	 * 
	 * @return int the "x" coordinate
	 */
    static protected int calculateXForBoundaryEvent( final RefObject aRefObject, final RefObject aBoundaryEvent, int aLineX ){
    	int x = 0;
    	//get the x coordinate for the Activity
    	int activityX = PVUtil.getXCoordinate(aRefObject);
    	//add the line X , on which it is
    	activityX  = activityX + aLineX;
    	//get the X coordinate for BoundaryEvent
    	int boundX = PVUtil.getXCoordinate( aBoundaryEvent );
    	x = activityX + boundX;
    	return x;
    }

    /**
     * Calculates and returns the "y" coordinate for a BoundaryEvent
     *  
     * @param RefObject represents the Activity of the BoundaryEvent
     * @param RefObject represents the BoundaryEvent
     * @param int the "y" coordinate for the lane where the LaneObject is
     * 
     * @return int the "y" coordinate
     */
    static protected int calculateYForBoundaryEvent( final RefObject aRefObject,final RefObject aBoundaryEvent, int aLineY ){
    	int y = 0;
    	//get the x coordinate for the Activity
    	int activityY = PVUtil.getYCoordinate(aRefObject);
    	//add the line X , on which it is
    	activityY  = activityY + aLineY;
    	//get the X coordinate for BoundaryEvent
    	int boundY = PVUtil.getYCoordinate( aBoundaryEvent );
    	y = activityY + boundY;
    	return y;
    }
    
    /**
	 * Returns the LaneObject's type
	 * 
	 * @param LaneObject
	 *            the object, which type must be queried
	 * @return String the lane object type
	 */
	public static String getLaneObjectType(ScopeObject aLaneObject) {
		if (aLaneObject instanceof EmbeddedScope) {
			return "EmbeddedSubWorkflow"; //$NON-NLS-1$
		}
		else if (aLaneObject instanceof HumanActivity) {
			return NodeType.HUMANACTIVITY.type();
		} else if (aLaneObject instanceof AutomatedActivity) {
			return NodeType.AUTOMATEDACTIVITY.type();
		} else if (aLaneObject instanceof PoolReference) {// SubCollaboration
			return NodeType.SUBWORKFLOW.type();
		} else if (aLaneObject instanceof StartEvent) {
			if(((StartEvent)aLaneObject).getEventDefinition()==null)
			{
				return NodeType.ABSTRACT_STARTEVENT.type();
			}
			return NodeType.STARTEVENT.type();
		} else if (aLaneObject instanceof EndEvent) {
			EventDefinition ed = ((EndEvent) aLaneObject).getEventDefinition();
			if (((EndEvent) aLaneObject).isTerminate() == true) {
				return NodeType.TERMINATION_END_EVENT.type(); 
			} else if (ed instanceof ErrorEventDefinition) {
			    ErrorEventDefinition eed = (ErrorEventDefinition)ed;
			    EventDefinitionType eventDefinitionType = EventDefinitionUtil.getInstance().getEventDefinitionType(eed);
				if (eventDefinitionType==EventDefinitionType.ESCALATION_EVENT_DEFINITION) {
					return NodeType.ESCALATION_END_EVENT.type();
				} else {
					return NodeType.ERROR_END_EVENT.type();
				}
			} else {
				return (ed == null) ? NodeType.ABSTRACT_ENDEVENT.type()
						: NodeType.ENDEVENT.type();
			}
		} else if (aLaneObject instanceof com.sap.glx.ide.model.galaxy.workflow.ExclusiveDataSplitGateway) {
			return NodeType.EXCLUSIVECHOICE.type();
		}
		// UncontrolledMerge
		else if (aLaneObject instanceof UncontrolledJoinGateway) {
			// check whether it is artificial
			if (isGatewayArtificial((UncontrolledJoinGateway) aLaneObject)) {
				return "ArtificialUncontrolledJoin"; //$NON-NLS-1$
			}
			return NodeType.UNCONTROLLEDMERGE.type();
		} else if (aLaneObject instanceof ParallelSplitGateway) {
			return NodeType.PARALELSPLIT.type();
		} else if (aLaneObject instanceof ParallelJoinGateway) {
			return NodeType.SYNCHRONIZATION.type();
		} else if (aLaneObject instanceof ExclusiveDataSplitGateway) {
			return NodeType.DEFEREDCHOICE.type();
		} else if (aLaneObject instanceof ExclusiveEventSplitGateway) {
			return NodeType.DEFEREDCHOICE.type();
		} else if (aLaneObject instanceof DataObject) {
			return NodeType.DATAOBJECT.type();
		} else if (aLaneObject instanceof Annotation) {
			return NodeType.ANNOTATION.type();
		} else if (aLaneObject instanceof Lane) {
			return NodeType.LANE.type();
		} else if (aLaneObject instanceof Pool) {
			return NodeType.POOL.type();
		} else if (aLaneObject instanceof MessageFlowConnector) {
			return "ConditionalSequenceConnector";	//$NON-NLS-1$
		} else if (aLaneObject instanceof ConditionalSequenceConnector) {
			return "ConditionalSequenceConnector";		//$NON-NLS-1$
		} else if (aLaneObject instanceof SequenceConnector) {
			return "SequenceConnector";	//$NON-NLS-1$
		} else if (aLaneObject instanceof BoundaryEvent) {		    
            EventDefinition ed = ((BoundaryEvent)aLaneObject).getEventDefinition();
            EventDefinitionType eventDefinitionType = EventDefinitionUtil.getInstance().getEventDefinitionType(ed);
            if (eventDefinitionType==EventDefinitionType.ESCALATION_EVENT_DEFINITION) {
                return NodeType.BOUNDARY_ESCALATION_EVENT.type();
            }else{
                return NodeType.BOUNDARY_ERROR_EVENT.type();
            }		
		} else if (aLaneObject instanceof PoolReference) {
			return "SubWorkflow";	//$NON-NLS-1$
		} else if (aLaneObject instanceof MappingActivity) {
			return "MappingActivity";	//$NON-NLS-1$
		} else if (aLaneObject instanceof NotificationActivity) {
			return NodeType.NOTIFICATION_ACTIVITY.type();
		} else if (aLaneObject instanceof ReportingActivity) {
			return NodeType.REPORTING_ACTIVITY.type();
		} else if (aLaneObject instanceof ThrowEvent) {
			ThrowEvent event = (ThrowEvent) aLaneObject;
			EventDefinition ed = event.getEventDefinition();
			if (ed instanceof MessageEventDefinition) {
				return NodeType.INTERMEDIATE_MESSAGE_EVENT.type();
			} else if (ed instanceof TimerEventDefinition) {
				return NodeType.TIMER_INTERMEDIATE_EVENT.type();
			} else {
				return NodeType.INTERMEDIATE_ERROR_EVENT.type();
			}
		} else if (aLaneObject instanceof CatchEvent) {
			CatchEvent event = (CatchEvent) aLaneObject;
			EventDefinition ed = event.getEventDefinition();
			if (ed instanceof MessageEventDefinition) {
				return NodeType.INTERMEDIATE_MESSAGE_EVENT.type();
			} else if (ed instanceof TimerEventDefinition) {
				return NodeType.TIMER_INTERMEDIATE_EVENT.type();
			} else {
				return NodeType.INTERMEDIATE_ERROR_EVENT.type();
			}

		}
		/*
		 * In case of any error, return with the HUMANACTIVITY type This must
		 * never happen. Only for testing purposes
		 */
		else {
			return NodeType.HUMANACTIVITY.type();
		}
	}
	
    /**
	 * Check whether the gateway is artificial or not
	 * 
	 * @param gateway
	 *            UncontrolledJoinGateway
	 * @return boolean
	 */
	public static boolean isGatewayArtificial(UncontrolledJoinGateway gateway) {
		boolean result = true;
		PictogramElement pictogramElement = XMLUtil
				.getFirstPictogramElementForBusinessObject(gateway); // Add
		// only
		// visible
		RefObject[] roArray = XMLUtil
				.getAllBusinessObjectsForPictogramElement(pictogramElement);
		if (pictogramElement != null && roArray.length == 1) {
			result = false;
		}
		return result;
	}

    /**
	 * Get the connector type
	 * 
	 * @param aObject
	 *            ScopeObject
	 * @return String
	 */
	public static String getConnectorType(Object aObject) {
		if (aObject instanceof SequenceConnector) {
			return "SequenceConnector"; //$NON-NLS-1$
		} else if (aObject instanceof SequenceConnector) {
			return "ConditionalSequenceConnector";	//$NON-NLS-1$
		} else if (aObject instanceof MessageFlowConnector) {
			return "MessageFlow";	//$NON-NLS-1$
		} else if (aObject instanceof SequenceConnector) {
			return "Association";	//$NON-NLS-1$
		} else if (aObject instanceof SequenceConnector) {
			return "DirectedAssociation";	//$NON-NLS-1$
		} else {
			return "SequenceConnector";	//$NON-NLS-1$
		}
	}
	
	/**
	 * Returns the property value of a given property container for a specific key.
	 * 
	 * @param propertyContainer
	 *            The property container (e.g. PictogramElement or GraphicsAlgorithm)
	 * @param key
	 *            The property key
	 * @return The value of the property for the key
	 */
	public static String getPropertyValue(PropertyContainer propertyContainer, String key) {
		Property property = getProperty(propertyContainer, key);
		if (property != null) {
			return property.getValue();
		}
		return null;
	}
	
	/**
	 * Returns the property of a given property container for a specific key.
	 * 
	 * @param propertyContainer
	 *            The property container (e.g. PictogramElement or GraphicsAlgorithm)
	 * @param key
	 *            The property key
	 * @return The property for the key
	 */
	public static Property getProperty(PropertyContainer propertyContainer, String key) {
		if (propertyContainer == null || key == null) {
			return null;
		}
		Collection<Property> collection = propertyContainer.getProperties();
		for (Iterator<Property> iter = collection.iterator(); iter.hasNext();) {
			Property property = iter.next();
			if (key.equals(property.getKey())) {
				return property;
			}
		}
		return null;
	}
	
	public static GraphicsAlgorithm getSelectionGraphicsAlgorithm(RefObject refObject) {
		PictogramElement pe = PVUtil.getPictogramElement(refObject);
		return PVUtil.getSelectionGraphicsAlgorithm(pe);
	}
	/**
	 * Gets selection graphics algorithm by given PictogramElement
	 * 
	 * @param pictogramElement
	 *            the PictogramElement, which graphics algorithm we search for
	 */
	public static GraphicsAlgorithm getSelectionGraphicsAlgorithm(PictogramElement pictogramElement) {
		GraphicsAlgorithm ga = null;
		ga = pictogramElement.getGraphicsAlgorithm();
		if (ga.isLineVisible() != null && !ga.isLineVisible() && !ga.isFilled()) {
			// it is a ghost graphics algorithm, then we should take the first
			// child(it should be the selection GA)
			List<GraphicsAlgorithm> children = ga.getGraphicsAlgorithmChildren();
			if (children != null && children.size() >= 1) {
				ga = children.get(0);
			}
		}
		return ga;
	}
	
	/**
	 * Returns the closest point on a rectagle's edge to specified point
	 * @param rX
	 * @param rY
	 * @param rWidth
	 * @param rHeight
	 * @param x
	 * @param y
	 * @return
	 */
    public static Point2D getClosestPointOnRectangle(int rX,int rY, int rWidth,int rHeight , Point2D p){

  	   Rectangle rectangle=new Rectangle(rX,rY,rWidth,rHeight);
  	   Point2D closestPoint=p;

  	   if(rectangle.contains(p))
  	   {
  		   return closestPoint;
  	   }
  		   
  	   /**
  	    * rectangle points:
  	    * 
  	    *         p1(rx,ry) *---------------------- * p2(rx+rWidth,ry)
  	    *                   |                       |
  	    *                   |                       |
  	    *                   |                       |
  	    *                   |                       |
  	    * p4(rx,ry+rHeight) *-----------------------* p3(rx+rWidth,ry+rHeight)          
  	    * 
  	    * Point p(x,y) *
  	    * 
  	    * 
  	    */
  	   Point2D p1= new Point2D.Double(rectangle.x                  , rectangle.y);
  	   Point2D p2= new Point2D.Double(rectangle.x + rectangle.width, rectangle.y);
  	   Point2D p3= new Point2D.Double(rectangle.x + rectangle.width, rectangle.y+rectangle.height);
  	   Point2D p4= new Point2D.Double(rectangle.x                  ,rectangle.y+rectangle.height);

  	   int j = 0;
  		double[] l = new double[4];
  		Point2D[][] edges= new Point2D[4][2];
  		edges[0]=new Point2D[]{p1,p2};
  		edges[1]=new Point2D[]{p2,p3};
  		edges[2]=new Point2D[]{p3,p4};
  		edges[3]=new Point2D[]{p4,p1};

  		//compute distances from each edge to the point
  		l[0] = Line2D.ptSegDist(p1.getX(),p1.getY(),p2.getX(),p2.getY(),p.getX(),p.getY());
  		l[1] = Line2D.ptSegDist(p2.getX(),p2.getY(),p3.getX(),p3.getY(),p.getX(),p.getY());
  		l[2] = Line2D.ptSegDist(p3.getX(),p3.getY(),p4.getX(),p4.getY(),p.getX(),p.getY());
  		l[3] = Line2D.ptSegDist(p4.getX(),p4.getY(),p1.getX(),p1.getY(),p.getX(),p.getY());
  		//find the nearest edge.
  		for (int i = 0; i < l.length; i++) {
  			if (Math.abs(l[i]) < Math.abs(l[j])) {
  				j = i;
  			}
  		}
  		Point2D[] nearestEdge=edges[j];
  		//find closest point on nearest edge.
  	   Point2D lineP1 = nearestEdge[0];
  	   Point2D lineP2 = nearestEdge[1];
  	   double xDelta = lineP2.getX() - lineP1.getX();
  	   double yDelta = lineP2.getY() - lineP1.getY();
  	   	if ((xDelta == 0) && (yDelta == 0)) {
  	   	    //p1 and p2 are the same point
  	   		return p;
  	   	}
  	   	double u = ((p.getX() - lineP1.getX()) * xDelta + (p.getY() - lineP1.getY()) * yDelta) / (xDelta * xDelta + yDelta * yDelta);
  	   	if (u < 0) {
  	   	    closestPoint = lineP1;
  	   	} else if (u > 1) {
  	   	    closestPoint = lineP2;
  	   	} else {
  	   	    closestPoint = new Point2D.Double(lineP1.getX() + u * xDelta, lineP1.getY() + u * yDelta);
  	   	}
  	   	
  	   	if(!rectangle.contains(closestPoint))
  	   	{
  	   		closestPoint= u>0.5? lineP2:lineP1;
  	   	}
  	   	return closestPoint;
     }

}

