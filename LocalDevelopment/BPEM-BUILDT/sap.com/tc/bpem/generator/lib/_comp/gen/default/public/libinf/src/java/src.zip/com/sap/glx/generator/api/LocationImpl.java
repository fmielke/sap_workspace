package com.sap.glx.generator.api;

import com.sap.glx.generator.api.ILocation;

public class LocationImpl implements ILocation {

    private int x;

    private int y;

    public LocationImpl(int x, int y) {
        setX(x);
        setY(y);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

}
