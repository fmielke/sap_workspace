package com.sap.glx.paradigmInterface.bpmn.compiler.endpoint;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

import javax.xml.namespace.QName;

import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.OperationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SDOHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.VersioningHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.buildapi.BpemBuildException;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.ICompiler;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.paradigmInterface.triggernet.assembler.GalaxyAssembler;
import com.sap.glx.constants.RevisionConstants;
import com.sap.tc.esmp.mm.wsdl2.Operation;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import com.sap.tc.esmp.tools.wsdlexport.ServiceDescription;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1Document;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1Exporter;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1ExporterProvider;

/**
 * Since the interface versioning issue fix in 7.20 SP1 the interface compiler is solely used for the process web service provisioning with
 * the Unified Connectivity Adapter. Depending on the version of the Process Composer an artifact to be compiled has one of the two
 * following types. Also future versions of this compiler must support both modes.
 * 
 * (1) The interface artifact is a Pair<MessageEventDefinition, Pool> whose members are the message trigger and the pool where this
 * interface is referenced from. The message trigger must always be contained in the same partition as the pool. This message trigger is
 * invisible in the tree of model elements in the process composer. It is therefore also called generated endpoint. Those endpoints always
 * have the version of the interface attached to the URL of the endpoint they expose at runtime. The only result of such a generated
 * endpoint is a hash calculation which is reported to the build plugin. The hash contains the name of the development component, the pool's
 * service identifier and the complete WSDL it references.
 * 
 * (2) The interface artifact is MessageEventDefinition. This artifact must be explicitly modelled and is therefore called modelled
 * endpoint. This endpoint is compiled independent from any scope and is contained in a separate partition. For such artifatcs this compiler
 * generates a trigger network solely containing configuration entries for the Unified Connectivity adapter.
 * 
 * For both cases this compiler is also responsible to report the required information to the WSProvisioningPostProcessor which generates
 * the corresponding deployment archives for the web service runtime.
 * 
 * @author Philipp Sommer
 */
public class InterfaceCompiler implements ICompiler {

    private static final char LINEEND = '\n';
    private static final String DEFAULT_TRIGGER_DC = "sap.com/tc~bpem~content~predefs~default";

    private static final Pair<String, String> clsRequest = new Pair<String, String>(CompilerConstants.ADAPTER_UC,
            CompilerConstants.GALAXY_REQUEST);
    private static final Pair<String, String> clsResponse = new Pair<String, String>(CompilerConstants.ADAPTER_UC,
            CompilerConstants.GALAXY_RESPONSE);

    /**
     * The digested artifacts can be either a Pair<MessageEventDefinition, Pool> whose members are the message trigger and the pool where
     * this interface is referenced from or a standalone message event definition.
     * 
     * @param artifact
     *            to be checked
     * @return whether this artifact can be compiled by this compiler
     */
    @SuppressWarnings("unchecked")
    public boolean canCompile(Object artifact) {
        if (artifact instanceof Pair) {
            Pair pair = (Pair) artifact;
            if (pair.first instanceof MessageEventDefinition && pair.second instanceof Pool) {
                return true;
            }
        }
        if (artifact instanceof MessageEventDefinition) {
            if (OperationHelper.isModelledEndpoint((MessageEventDefinition) artifact)) {
                return true;
            }
        }
        return false;
    }

    /**
     * For modelled endpoints the types of the related service interface must be reported as dependency. Generated endpoints only create a
     * hash and do not need to report any dependencies.
     */
    public Object[] getDependencies(IBuilderHost host, Object artifact) {
        if (canCompile(artifact)) {
            if (artifact instanceof MessageEventDefinition) {
                Operation operation = ((MessageEventDefinition) artifact).getOperation();
                if (operation != null) {
                    return new Object[] { OperationHelper.getDependentScope(operation) };
                }
            }
        }
        return new Object[0];
    }

    /**
     * The compilation of an interface artifact dependent of the version. It either calculates a hash or generates a trigger network
     * containing only configuration. If the endpoint is contained
     * 
     * (1) A interface version hash is calculated based on the development component, the pool's service identifier and the complete WSDL it
     * references.
     * 
     * (2)
     * <ul>
     * <li>DC name (WS provisioning deployment does not support identical endpoints deployed from different DCs)</li>
     * <li>Service identifer</li>
     * <li>Operation name</li>
     * <li>WSDL files</li>
     * </ul>
     * 
     * No artifact is generated but the respective post processor data is set.
     */
    public boolean compile(IBuilderHost host, Object artifact) throws Exception {
        if (canCompile(artifact)) {
            if (artifact instanceof MessageEventDefinition) {
                // modelled endpoint (7.20 and subsequent versions)
                MessageEventDefinition endpoint = (MessageEventDefinition) artifact;
                Operation operation = validateOperation(endpoint);
                if (host.isFromLocalDC(endpoint)) {
                    if (!DEFAULT_TRIGGER_DC.equals(host.getApplicationName(endpoint))) {
                        String serviceId = OperationHelper.getModelledServiceIdentifier(endpoint);
                        String triggernetId = VersioningHelper.computeVersion(serviceId);
                        String content = generateEndpointConfiguration(host, endpoint, serviceId, triggernetId);
                        writeFile(host, endpoint, triggernetId + ".endpoint", content); //$NON-NLS-1$
                        host.addPostProcessorData(true, new Pair<String, Operation>(serviceId, operation));
                    }
                }
            } else {
                // generated endpoint (7.11)
                @SuppressWarnings("unchecked")
                Pair<MessageEventDefinition, Pool> endpoint = (Pair<MessageEventDefinition, Pool>) artifact;
                Pool pool = endpoint.second;
                Operation operation = validateOperation(endpoint.first);
                if (OperationHelper.isModelledEndpoint(endpoint.first)) {
                    String msg = String.format(
                            "Message trigger '%s' is explicitly modelled but associated with a pool.", endpoint.first.getOriginalName()); //$NON-NLS-1$
                    throw new BpemBuildException("BPM.rt_c_int.000001", msg); //$NON-NLS-1$
                }

                // just pump in all the data that needs to influence the version
                StringBuilder sb = new StringBuilder();
                sb.append(CompilerConstants.CONFIG_DC + "=" + host.getDCIdentifier(pool).toString() + LINEEND); // DC //$NON-NLS-1$
                sb.append(CompilerConstants.CONFIG_SERVICE + "=" + pool.getIdentifier() + LINEEND); // identifier of the scope //$NON-NLS-1$
                sb.append(CompilerConstants.CONFIG_INTERFACE
                        + "=" + operation.getServiceInterface().getNamespace() + ":" + operation.getServiceInterface().getName() + LINEEND); // portType //$NON-NLS-1$ //$NON-NLS-2$
                sb.append(CompilerConstants.CONFIG_OPERATION + "=" + operation.getName() + LINEEND); // operation //$NON-NLS-1$

                Wsdl1Exporter<String> exporter = Wsdl1ExporterProvider.getWsdl1Exporter(null);
                ServiceDescription<String> description = exporter.getServiceDescription(operation.getServiceInterface());
                for (Wsdl1Document<String> document : description.getWsdl1Documents()) {
                    sb.append(CompilerConstants.CONFIG_SCHEMA_LOCATION + "=" + document.getLocation() + LINEEND); //$NON-NLS-1$
                    sb.append(CompilerConstants.CONFIG_TARGET_NAMESPACE + "=" + document.getNamespace() + LINEEND); //$NON-NLS-1$
                    sb.append(document.getContent());
                    sb.append(LINEEND);
                }

                // tell the build plugin this version
                String version = VersioningHelper.computeVersion(sb.toString());
                host.setVersionId(artifact, version);

                // now add the post processor data
                if (host.isFromLocalDC(pool) && !OperationHelper.isModelledEndpoint(endpoint.first)) {
                    String serviceId = OperationHelper.getGeneratedServiceIdentifier(pool, version);
                    host.addPostProcessorData(false, new Pair<String, Operation>(serviceId, operation));
                }
            }
            return true;
        }
        return false;
    }

    private Operation validateOperation(MessageEventDefinition endpoint) throws BpemBuildException {
        Operation operation = endpoint.getOperation();
        if (operation == null) {
            String msg = String.format("Message trigger '%s' does not refer to a valid WSDL operation.", endpoint.getOriginalName()); //$NON-NLS-1$
            throw new BpemBuildException("BPM.rt_c_int.000000", msg); //$NON-NLS-1$
        }
        WSDLHelper.validateOperation(operation);
        return operation;
    }

    private String generateEndpointConfiguration(IBuilderHost host, MessageEventDefinition endpoint, String service, String triggernetId)
            throws BpemBuildException {
        Operation operation = endpoint.getOperation();
        String scopeId = host.getVersionId(OperationHelper.getDependentScope(operation), CompilerType.TYPECOMPILER);

        StringBuilder sb = new StringBuilder();
        sb.append(String.format("# Message event definition %s (MOFId: %s)", endpoint.getOriginalName(), endpoint.refMofId())); //$NON-NLS-1$
        sb.append(LINEEND);
        sb.append("NETWORK,"); //$NON-NLS-1$
        sb.append(triggernetId);
        sb.append(',');
        sb.append(service);
        sb.append(LINEEND);
        sb.append("REVISIONID"); //$NON-NLS-1$
        sb.append(',');
        sb.append(RevisionConstants.REVISION_MAJOR);
        sb.append(',');
        sb.append(RevisionConstants.REVISION_MINOR);
        sb.append(',');
        sb.append("Galaxy interface compiler as of NetWeaver CE 7.30. Give yourself to the dark side."); //$NON-NLS-1$
        sb.append(LINEEND);
        sb.append("-- CONFIG --"); //$NON-NLS-1$
        sb.append(LINEEND);

        // generate configuration of request message
        XsdElementDeclaration requestElement = WSDLHelper.getRequestElement(operation);
        generateMessageConfiguration(sb, clsRequest, service, operation, scopeId, requestElement);

        // generate configuration of response message
        XsdElementDeclaration responseElement = WSDLHelper.getResponseElement(operation);
        if (responseElement != null) {
            generateMessageConfiguration(sb, clsResponse, service, operation, scopeId, responseElement);
        }
        return sb.toString();
    }

    private void generateMessageConfiguration(StringBuilder sb, Pair<String, String> cls, String service, Operation operation,
            String scopeId, XsdElementDeclaration element) {
        QName name = SDOHelper.generateSDOName(element);
        QName type = SDOHelper.generateSDOName(WSDLHelper.getElementType(element));

        generateConfiguration(sb, cls, CompilerConstants.CONFIG_ENDPOINTS, service, operation.getName(), CompilerConstants.CONFIG_SCOPE
                + '=' + scopeId);
        generateConfiguration(sb, cls, CompilerConstants.CONFIG_ENDPOINTS, service, operation.getName(), CompilerConstants.CONFIG_ELEMENT,
                CompilerConstants.CONFIG_NAME + '=' + name.getLocalPart());
        generateConfiguration(sb, cls, CompilerConstants.CONFIG_ENDPOINTS, service, operation.getName(), CompilerConstants.CONFIG_ELEMENT,
                CompilerConstants.CONFIG_NAMESPACE + '=' + name.getNamespaceURI());
        generateConfiguration(sb, cls, CompilerConstants.CONFIG_ENDPOINTS, service, operation.getName(), CompilerConstants.CONFIG_TYPE,
                CompilerConstants.CONFIG_NAME + '=' + type.getLocalPart());
        generateConfiguration(sb, cls, CompilerConstants.CONFIG_ENDPOINTS, service, operation.getName(), CompilerConstants.CONFIG_TYPE,
                CompilerConstants.CONFIG_NAMESPACE + '=' + type.getNamespaceURI());
    }

    private void generateConfiguration(StringBuilder sb, Pair<String, String> cls, String... items) {
        sb.append("CONFIG,"); //$NON-NLS-1$
        sb.append(GalaxyAssembler.escape(cls.first));
        sb.append(',');
        sb.append(GalaxyAssembler.escape(cls.second));
        sb.append(',');
        for (int i = 0; i < items.length; i++) {
            sb.append(GalaxyAssembler.escape(items[i]));
            if (i == items.length - 1) {
                sb.append(LINEEND);
            } else {
                sb.append(',');

            }
        }
    }

    private void writeFile(IBuilderHost host, Object artifact, String filename, String content) throws Exception {
        Writer writer = null;
        OutputStream stream = null;
        try {
            stream = host.createVersionedTargetFile(filename, artifact);
            writer = new OutputStreamWriter(stream, "UTF-8"); //$NON-NLS-1$
            writer.write(content);
        } finally {
            if (writer != null) {
                writer.close();
            }
            if (stream != null) {
                stream.close();
            }
        }
    }
}
