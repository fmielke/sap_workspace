package com.sap.glx.paradigmInterface.bpmn.compiler.reportingdefinition;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Arrays;
import java.util.LinkedList;

import com.sap.glx.constants.SharedCompilerConstants;
import com.sap.glx.ide.model.galaxy.processsupplements.ReportingDefinition;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.IdentifierHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SDOHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.VersioningHelper;
import com.sap.glx.paradigmInterface.buildapi.BpemBuildException;
import com.sap.glx.paradigmInterface.buildapi.IArtifact;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost2;
import com.sap.glx.paradigmInterface.buildapi.ICompiler;
import com.sap.glx.paradigmInterface.buildapi.ICompiler2;
import com.sap.glx.paradigmInterface.buildapi.ReportingDefinitionArtifact;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import commonj.sdo.Type;

public class ReportingDefinitionCompiler implements ICompiler, ICompiler2<ReportingDefinition, ReportingDefinitionArtifact> {
    public static final String DISABLEMENT_FLAG = "com.sap.glx.interfacecompiler.stopReportingFun"; //$NON-NLS-1$

    public static final String EXTENSION = "reportdef"; //$NON-NLS-1$
    public static final String LINEEND = "\n"; //$NON-NLS-1$

    private Iterable<XsdElementDeclaration> scope = null;

    private boolean enabled = (System.getProperty(DISABLEMENT_FLAG) == null);

    /**
     * The reporting definition compiler is handling reporting definitions.
     */
    public boolean canCompile(Object artifact) {
        return (artifact instanceof ReportingDefinition && enabled);
    }

    public boolean compile(IBuilderHost host, Object artifact) throws Exception {
        ReportingDefinition reportDef = (ReportingDefinition) artifact;
        XsdElementDeclaration dsTypeDef = reportDef.getParameter(); // $JL-SUSPICIOUSFUNCTIONS$
        Type dsType = SDOHelper.constructSDOType(dsTypeDef); // $JL-SUSPICIOUSFUNCTIONS$

        // lightweight 2-pass compile
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("# reporting definition %s (MOFId: %s)" + LINEEND, reportDef.getDataSourceName(), reportDef.refMofId())); //$NON-NLS-1$
        sb.append("VERSION_ID," + CompilerConstants.SCRIPT_VALUE_VERSION + LINEEND); //$NON-NLS-1$
        sb.append("DS_NAME," + reportDef.getDataSourceName() + LINEEND); //$NON-NLS-1$
        sb.append("TYPE_VERSION_ID," + host.getVersionId(scope, CompilerType.TYPECOMPILER) + LINEEND); //$NON-NLS-1$
        sb.append("TYPE_NAME," + dsType.getName() + LINEEND); //$NON-NLS-1$
        sb.append("TYPE_NAMESPACE," + dsType.getURI() + LINEEND); //$NON-NLS-1$
        String pass1 = sb.toString();

        // compute the version (MD5 hash) from the first pass
        String version = VersioningHelper.computeVersion(pass1);
        // tell it to the build plugin
        host.setVersionId(artifact, version);
        // and replace the version placeholders by the concrete version
        String pass2 = pass1.replace(CompilerConstants.SCRIPT_VALUE_VERSION, version);

        String filename = IdentifierHelper.createFilename(reportDef, EXTENSION);
        OutputStream stream = null;
        Writer writer = null;

        try {
            stream = host.createVersionedTargetFile(filename, artifact);
            writer = new OutputStreamWriter(stream, SharedCompilerConstants.UTF_8);
            writer.write(pass2);
        } finally {
            if (writer != null) {
                writer.flush();
                writer.close();
            }

            if (stream != null) {
                stream.flush();
                stream.close();
            }
        }

        return true;
    }

    public Object[] getDependencies(IBuilderHost host, Object artifact) {
        if (canCompile(artifact)) {
            ReportingDefinition report = (ReportingDefinition) artifact;
            XsdElementDeclaration dsTypeDef = report.getParameter(); // $JL-SUSPICIOUSFUNCTIONS$
            scope = new LinkedList<XsdElementDeclaration>(Arrays.asList(dsTypeDef)); // $JL-SUSPICIOUSFUNCTIONS$
            return new Object[] { scope };
        }
        return new Object[0];
    }

    public boolean compile(IBuilderHost2 host, ReportingDefinitionArtifact artifact) throws BpemBuildException {
        throw new UnsupportedOperationException();
    }

    public IArtifact<?>[] getDependencies(IBuilderHost2 host, ReportingDefinitionArtifact artifact) {
        throw new UnsupportedOperationException();
    }
}
