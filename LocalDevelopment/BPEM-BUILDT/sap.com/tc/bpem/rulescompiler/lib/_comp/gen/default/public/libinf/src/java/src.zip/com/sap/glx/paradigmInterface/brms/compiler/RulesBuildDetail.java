package com.sap.glx.paradigmInterface.brms.compiler;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Represents Build detail for rule artifacts in (a) Galaxy+Rules DC (b) Pure Rules DC.
 *  
 * @author I047255
 * @since 7.2
 */
class RulesBuildDetail {
	
	private String projectName = null;
	private String rulesBuildId = null;
	private String mofId = null;
	private boolean versionedInvocation = false;
	private Properties projectProps = null;
	
	
	RulesBuildDetail(){
		
	}
	
	void setProjectName(String projectName){
		this.projectName = projectName;
	}
	
	String getProjectName(){
		return this.projectName;
	}
	
	void setRulesBuildId(String rulesBuildId){
		this.rulesBuildId = rulesBuildId;
	}
	
	String getRulesetBuildId(){
		return this.rulesBuildId;
	}
	
	void setMofId(String mofId){
		this.mofId = mofId;
	}
	
	String getMofId(){
		return this.mofId;
	}
	
	void setVersionedInvocation(boolean versionedInvocation){
		this.versionedInvocation = versionedInvocation;
	}
	
	boolean isVersionedInvocation(){
		return this.versionedInvocation;
	}
	
	void setProjectProperties(Properties projectProps){
		this.projectProps = projectProps;
	}
	
	Properties getProjectProperties(){
		return this.projectProps;
	}
	
	byte[] getBytes() throws IOException{
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		StringBuffer buffer = new StringBuffer();
		buffer.append("ProjectName"+":"+projectName+"\r\n"); //$NON-NLS-1$
		buffer.append("RulesBuildID"+":"+rulesBuildId+"\r\n"); //$NON-NLS-1$
		buffer.append("TypeMofID"+":"+mofId+"\r\n"); //$NON-NLS-1$
		buffer.append("VersionedInvocation"+":"+versionedInvocation+"\r\n"); //$NON-NLS-1$
		out.write(RulesMergeUtility.getBytes(buffer.toString()));
		projectProps.storeToXML(out, "Project_Properties"); //$NON-NLS-1$
		return out.toByteArray();
	}
	
}

