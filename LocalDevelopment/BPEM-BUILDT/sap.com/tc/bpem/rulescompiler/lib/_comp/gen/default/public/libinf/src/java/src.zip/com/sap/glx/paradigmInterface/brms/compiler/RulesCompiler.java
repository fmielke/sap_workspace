package com.sap.glx.paradigmInterface.brms.compiler;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.sap.glx.paradigmInterface.brms.compiler.ValidationMessage.Type;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.ICompiler;
import com.sap.glx.paradigmInterface.buildapi.RulesArtifactWrapper;
import com.sap.glx.paradigmInterface.buildapi.RulesCompilationState;
import com.sap.glx.paradigmInterface.buildapi.RulesArtifactWrapper.RulesArtifactType;
import com.sap.tc.buildplugin.log.Log;

public class RulesCompiler implements ICompiler{
	
	public boolean canCompile(Object artifact) {
		if(artifact instanceof RulesArtifactWrapper){
			return true;
		}
		return false;
	}
	
	public boolean compile(IBuilderHost host, Object artifact) throws Exception {
		
		if (artifact instanceof RulesArtifactWrapper){
			
			RulesArtifactWrapper rulesArtifactWrapper = ((RulesArtifactWrapper)artifact);
			
			String path = rulesArtifactWrapper.getArtifactPath();
			RulesArtifactType type = rulesArtifactWrapper.getType();
			RulesCompilationState compilationState = rulesArtifactWrapper.getRulesCompilationState();
			String entityName = RulesCompilerUtility.getEntityName(path, false);
			
			byte[] content = null;
			String name = null;
			
			if(type == RulesArtifactType.RULESET){
				
				// Ruleset
				content = RulesCompilerUtility.getBytesOfFile(path);
				byte[] sharedResBytes = compilationState.getSharedResourceBytes();
				
				//RULES REUSE CHANGES STARTS
				//TODO: REVISIT REQUIRED
				byte[] newContent = RulesCompilerUtility.mergeRulesetWithReusedRulesetResources(path, compilationState);
				if(newContent != null){
					if(newContent.length > 0){
						content = newContent;
					}
				}
				//RULES REUSE CHANGES ENDS
				
				// Merge with Shared Resource if Shared Resource is present
				if(sharedResBytes != null){
					content = RulesMergeUtility.mergeRulesetWithSharedResource(content, sharedResBytes);
				}
				name = entityName+RulesConstant.RUNTIME_RULESET_EXT;
				
			}else if(type == RulesArtifactType.RULESET_ALIASSET){
				
				// Ruleset AliasSet
				content = RulesCompilerUtility.getBytesOfFile(path);
				name = entityName+RulesConstant.RUNTIME_ALIASSET_EXT;
				
			}else if(type == RulesArtifactType.PROJECT){
				
				// Project
				content = RulesCompilerUtility.getBytesOfFile(path);
				name = entityName+RulesConstant.RUNTIME_PROJECT_EXT;
				
			} else if(type == RulesArtifactType.PROJECT_ALIASSET){
				
				// Project AliasSet
				content = RulesCompilerUtility.getBytesOfFile(path);
				byte[] sharedResAliasSetBytes = compilationState.getSharedResourceAliasSetBytes();
				
				// Merge with Shared Resource AliasSet if Shared Resource AliasSet is present
				if(sharedResAliasSetBytes != null){
					content = RulesMergeUtility.mergeProjectAliasSetWithSharedResAliasSet(content, sharedResAliasSetBytes);
				}
				name = entityName+RulesConstant.RUNTIME_ALIASSET_EXT;
				
			} else if(type == RulesArtifactType.SHAREDRESOURCE){
				
				// Shared Resource. Do not persist.
				content = RulesCompilerUtility.getBytesOfFile(path);
				compilationState.setSharedResourceBytes(content);
				content = null;
				
			} else if(type == RulesArtifactType.SHAREDRESOURCE_ALIASSET){
				
				// Shared Resource AliasSet. Do not persist.
				content = RulesCompilerUtility.getBytesOfFile(path);
				compilationState.setSharedResourceAliasSetBytes(content);
				content = null;
			} else if(type == RulesArtifactType.CSDL){
				// wsdl
				content = RulesCompilerUtility.getBytesOfFile(path);
				// wsdl file name should not contain spaces(' ') as it will cause '400 BadRequest' http error in WS Navigator.
				// replace space with tilde(~) and the same needs to be done in the 'location' attribute value in composite. 
				String tildedEntityName = entityName.replace(' ', '~');
				name = RulesConstant.WSDL_OUT+File.separator+tildedEntityName+RulesConstant.WSDL_EXT;
			}else if(type == RulesArtifactType.VALIDATION_MSGS){
				ValidationResult validationResult = getValidationMessages(path);
				if(validationResult != null){
					Map<ValidationMessage.Type, List<ValidationMessage>> typeVsMessages = validationResult.getTypeVsValidationMessages();
					List<ValidationMessage> errorMessages = typeVsMessages.get(ValidationMessage.Type.ERROR);
					if(errorMessages!=null && errorMessages.size()>0){
						StringBuffer buffer = new StringBuffer();
						buffer.append("Following Errors are present in Rules:\n"); //$NON-NLS-1$
						for(ValidationMessage message : errorMessages){
							buffer.append(message.toString()+"\n"); //$NON-NLS-1$
						}
						throw new Exception(buffer.toString());
					}else{
						Map<Object, Object> genericMap = compilationState.getGenericMap();
						genericMap.put(RulesConstant.VALIDATION_RESULT_KEY, validationResult);
					}
				}
			}
			
			
			if(type != RulesArtifactType.VALIDATION_MSGS){
				// Log warnings
				Map<Object, Object> genericMap = compilationState.getGenericMap();
				ValidationResult validationResult = (ValidationResult)genericMap.get(RulesConstant.VALIDATION_RESULT_KEY);
				logWarnings(rulesArtifactWrapper, validationResult);
			}
			
			if(content != null && name != null){
				
				// Persist content
				OutputStream to = host.createVersionedTargetFile(name, artifact);
				to.write(content);			
				to.close();
				String md5Hash = host.getVersionId(artifact);
				compilationState.addEntityVsMD5Hash(name, md5Hash);
			}
			
			// Check if last rules artifact and persist rules build details if yes
			if(rulesArtifactWrapper.isLastRulesArtifact()){
				
				String projectName = compilationState.getProjectName();
				String rulesBuildId = compilationState.getRulesBuildID();
				String mofId = compilationState.getMofId();
				Properties projectProps = compilationState.getProjectProperties();
				boolean invokeColocatedVersion = false;
				if(projectProps.containsKey(RulesConstant.INVOKE_COLOCATED_VER_KEY)){
					String value = projectProps.getProperty(RulesConstant.INVOKE_COLOCATED_VER_KEY);
					if(value != null && value.trim().length()!=0){
						String trimmedValue = value.trim();
						if(trimmedValue.equals("true")){
							invokeColocatedVersion = true;
						}else if(trimmedValue.equals("false")){
							invokeColocatedVersion = false;
						}
					}
				}
				
				RulesBuildDetail buildDetail = new RulesBuildDetail();
				buildDetail.setProjectName(projectName);
				buildDetail.setRulesBuildId(rulesBuildId);
				buildDetail.setMofId(mofId);
				buildDetail.setVersionedInvocation(invokeColocatedVersion);
				buildDetail.setProjectProperties(projectProps);
				byte[] data = buildDetail.getBytes();
				
				String rulePropsName = projectName+RulesConstant.RUNTIME_RULE_PROPS;
				OutputStream out = host.createVersionedTargetFile(rulePropsName, "BRM Rules Build Detail");  //$NON-NLS-1$
				out.write(data);
				out.close();
				
				host.setRulesBuildId(rulesBuildId);
			}
			
			return true;
		}
		
		return false;
	}
	
	public Object[] getDependencies(IBuilderHost host, Object artifact) {
		
		if(artifact instanceof RulesArtifactWrapper){
			
			RulesArtifactWrapper rulesArtifact = (RulesArtifactWrapper) artifact;
			
			String path = rulesArtifact.getArtifactPath();
			RulesArtifactType type = rulesArtifact.getType();
			RulesCompilationState compilationState = rulesArtifact.getRulesCompilationState();
			
			Map<String,String> prefixVsNameSpace = compilationState.getPrefixVsNameSpaceMap();
			Map<String, Map<String,String>> entityNameVsElementNameVsPrefix = compilationState.getEntityNameVsElementNameVsPrefix();
			Properties projectProps = compilationState.getProjectProperties();
			
			if (type == RulesArtifactType.PROJECT_ALIASSET || type == RulesArtifactType.RULESET_ALIASSET ||	type == RulesArtifactType.SHAREDRESOURCE_ALIASSET) {
				// AliasSet
				collectXMLElementsUsed(path, entityNameVsElementNameVsPrefix);
			} else if (type == RulesArtifactType.RULESET) {
				// Ruleset
				// Backward compatibility : Retrieve prefix vs namespace information from ruleset if its not available in shared resource
				if(prefixVsNameSpace.size()==0){
					replaceRulesetFunctionParameters(path,entityNameVsElementNameVsPrefix, prefixVsNameSpace);
				}else{
					replaceRulesetFunctionParameters(path,entityNameVsElementNameVsPrefix, null);
				}
			} else if (type == RulesArtifactType.PROJECT) {
				// Project
				collectProperties(path, projectProps);
			} else if(type == RulesArtifactType.SHAREDRESOURCE){
				// Shared Resource
				collectPrefixVsNameSpace(path, prefixVsNameSpace);
			} 
			// Check if this is last rules artifact
			if (rulesArtifact.isLastRulesArtifact()) {
				return new Object[]{prefixVsNameSpace, entityNameVsElementNameVsPrefix};
			} else {
				return new Object[0];
			}
		}
		return new Object[0];
	}
	
	private void logWarnings(RulesArtifactWrapper rulesArtifact, ValidationResult validationResult){
		if(validationResult == null){
			// no validation results
			return;
		}
		String path = rulesArtifact.getArtifactPath();
		String resName = RulesCompilerUtility.getEntityName(path, true);
		
		Map<String, List<ValidationMessage>> resNameVsMessages = validationResult.getResNameVsValidationMessages();
		List<ValidationMessage> messages = resNameVsMessages.get(resName);
		
		if(messages != null && messages.size()>0){
			List<ValidationMessage> warningMessages = new ArrayList<ValidationMessage>();
			for(ValidationMessage message : messages){
				if(message.getType() == Type.WARNING){
					warningMessages.add(message);
				}
			}
			if(warningMessages.size()>0){
				for(ValidationMessage message : warningMessages){
					Log.warn(message.toString());
				}
			}
		}
	}
	
	/*** Start - XML Element collection ***/
	
	private void collectXMLElementsUsed(String aSetFile, Map<String, Map<String,String>> entityNameVsElementNameVsNameSpace){
		try{
			String entityName = RulesCompilerUtility.getEntityName(aSetFile, false);
			InputStream aSetIn = new FileInputStream(aSetFile);
			SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
			Map<String,String> elementNameVsPrefix = new HashMap<String, String>();
			parser.parse(aSetIn, new XMLElementCollector(elementNameVsPrefix));
			entityNameVsElementNameVsNameSpace.put(entityName, elementNameVsPrefix);
			aSetIn.close();
		}catch (IOException ioe) {
			throw new RuntimeException(ioe);
		}catch (SAXException se) {
			throw new RuntimeException(se);
		}catch (ParserConfigurationException pce) {
			throw new RuntimeException(pce);
		}
	}
	
	/*** End - XML Element collection ***/
	
	/*** Start - Prefix vs NameSpace collection ***/
	
	private void collectPrefixVsNameSpace(String path, Map<String, String> prefixVsNamespace){
		try{
			InputStream in = new FileInputStream(path);
			SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
			parser.parse(in, new NameSpaceMappingCollector(prefixVsNamespace));
			in.close();
		}catch (IOException ioe) {
			throw new RuntimeException(ioe);
		}catch (SAXException se) {
			throw new RuntimeException(se);
		}catch (ParserConfigurationException pce) {
			throw new RuntimeException(pce);
		}
	}
	
	/*** End - Prefix vs NameSpace collection ***/
	
	/*** Start - Properties collection ***/
	
	private void collectProperties(String path, Properties props){
		try{
			InputStream projIn = new FileInputStream(path);
			SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
			parser.parse(projIn, new PropertiesCollector(props));
			projIn.close();
		}catch (IOException ioe) {
			throw new RuntimeException(ioe);
		}catch (SAXException se) {
			throw new RuntimeException(se);
		}catch (ParserConfigurationException pce) {
			throw new RuntimeException(pce);
		}
	}
	
	/*** End - Properties collection ***/
	
	/*** Start - Replace Ruleset Function Parameters ***/
	
	private void replaceRulesetFunctionParameters(String path, Map<String, Map<String, String>> entityNameVsElementNameVsPrefix, Map<String, String> prefixVsNameSpace){
		try{
			String entityName = RulesCompilerUtility.getEntityName(path, false);
			InputStream aSetIn = new FileInputStream(path);
			SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
			Map<String,String> entityNameVsPrefix = entityNameVsElementNameVsPrefix.get(entityName);
			parser.parse(aSetIn, new RulesetFunctionParameterReplacer(entityNameVsPrefix, prefixVsNameSpace));
			aSetIn.close();
		}catch (IOException ioe) {
			throw new RuntimeException(ioe);
		}catch (SAXException se) {
			throw new RuntimeException(se);
		}catch (ParserConfigurationException pce) {
			throw new RuntimeException(pce);
		}
	}
	
	/*** End - Replace Ruleset Function Parameters ***/
	
	private ValidationResult getValidationMessages(String path) throws IOException, SAXException, ParserConfigurationException{
		byte[] content = RulesCompilerUtility.getBytesOfFile(path);
		// The file can exist with no content. So check if there is any content. 
		if(content.length > 0){
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			ByteArrayInputStream in = new ByteArrayInputStream(content);
			Document doc = docBuilder.parse(in);
			ValidationResult result = ValidationUtility.loadValidationResult(doc);
			return result;
		}
		return null;
	}
}

