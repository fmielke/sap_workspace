package com.sap.glx.paradigmInterface.brms.compiler;

/**
 * 
 * @author I047246
 *
 */
public class RulesConstant {
	// BRMS rule files extensions
	public static final String PROJECT_EXT = ".ruleprj"; //$NON-NLS-1$
	public static final String RULESET_EXT = ".ruleset"; //$NON-NLS-1$
	public static final String ALIASSET_EXT = ".aliasset"; //$NON-NLS-1$
	public static final String SHAREDRES_EXT = ".sharedres"; //$NON-NLS-1$
	
	// BRMS combination file extensions
	public static final String PROJECT_ALIASET_COMBO_EXT = ".prjas"; //$NON-NLS-1$
	public static final String RULESET_ALIASET_COMBO_EXT = ".rsas";	 //$NON-NLS-1$
	
	// BRMS Runtime file extensions
	public static final String RUNTIME_PROJECT_EXT = ".ruleprj"; //$NON-NLS-1$
	public static final String RUNTIME_RULESET_EXT = ".rulesetexe"; //$NON-NLS-1$
	public static final String RUNTIME_ALIASSET_EXT = ".aliasset"; //$NON-NLS-1$
	public static final String RUNTIME_SHAREDRES_EXT = ".sharedres"; //$NON-NLS-1$
	public static final String RUNTIME_RULE_PROPS= ".ruleprops"; //$NON-NLS-1$
	
	public static final String WSDL_OUT= "ws"; //$NON-NLS-1$
	public static final String WSDL_EXT= ".wsdl"; //$NON-NLS-1$
	
	public static final String INVOKE_COLOCATED_VER_KEY = "Invoke co-located version of rules"; //$NON-NLS-1$
	
	public static final String VALIDATION_RESULT_KEY = "Validation Result"; //$NON-NLS-1$
	
}
