package com.sap.glx.paradigmInterface.brms.compiler;

import java.io.UnsupportedEncodingException;

/**
 * Utility class useful for merging of (a) Ruleset with Shared Resource (b) Project AliasSet with Shared Resource AliasSet.
 * 
 * @author I047255
 * @since 7.2
 */

class RulesMergeUtility {

	private static final String UTF_8_ENCODING = "UTF-8";

	/**
	 * Ruleset+Shared Resource merge Pattern
	 */
	private static final XMLMergePattern RULESET_SHARED_RES_MERGE_PATTERN = new XMLMergePattern("ruleset"); //$NON-NLS-1$
	
	/**
	 * Project AliasSet+Shared Resource AliasSet merge Pattern
	 */
	private static final XMLMergePattern PROJECT_ALIASSET_SHARED_RES_ALIASSET_PATTERN = new XMLMergePattern("aliasSet"); //$NON-NLS-1$
	
	
	public static byte[] mergeRulesetWithSharedResource(byte[] rulesetBytes, byte[] sharedResBytes){
		String sharedResText = getString(sharedResBytes);
		String rulesetText = getString(rulesetBytes);
		String mergedRulesetText = XMLUtility.mergeXMLs(rulesetText, sharedResText, RULESET_SHARED_RES_MERGE_PATTERN);
		return getBytes(mergedRulesetText);
	}
	
	public static byte[] mergeProjectAliasSetWithSharedResAliasSet(byte[] projectAliasSetBytes, byte[] sharedResAliasSetBytes){
		String projectAliasSetText = getString(projectAliasSetBytes);		
		String sharedResAliasSetText = getString(sharedResAliasSetBytes);
		String mergedAliasSetText = XMLUtility.mergeXMLs(projectAliasSetText, sharedResAliasSetText, PROJECT_ALIASSET_SHARED_RES_ALIASSET_PATTERN);
		return getBytes(mergedAliasSetText);
	}
	
	public static byte[] getBytes(String message){
		byte[] messageContent = null;
		try {
			messageContent = message.getBytes(UTF_8_ENCODING);
		} catch (UnsupportedEncodingException e) {
			// $JL-EXC$ 
		}
		return messageContent;
	}
	
	public static String getString(byte[] content){
		String message = null;
		try {
			message = new String(content, UTF_8_ENCODING);
		} catch (UnsupportedEncodingException e) {
			// $JL-EXC$ 
		}
		return message;
	}
	

	static{
		/* Fill Ruleset+Shared Resource merge Pattern */
		
		XMLElementPattern variables = new XMLElementPattern("ruleset/variable", true, false); //$NON-NLS-1$
		RULESET_SHARED_RES_MERGE_PATTERN.addElementCombo(variables);
		
		XMLElementPattern actionRules = new XMLElementPattern("ruleset/actionrule", false, false); //$NON-NLS-1$
		RULESET_SHARED_RES_MERGE_PATTERN.addElementCombo(actionRules);
		
		XMLElementPattern task = new XMLElementPattern("ruleset/task", false, false); //$NON-NLS-1$
		RULESET_SHARED_RES_MERGE_PATTERN.addElementCombo(task);
		
		XMLElementPattern decisiongateway = new XMLElementPattern("ruleset/decision", false, false); //$NON-NLS-1$
		RULESET_SHARED_RES_MERGE_PATTERN.addElementCombo(decisiongateway);
		
		XMLElementPattern ruleflow = new XMLElementPattern("ruleset/ruleflow", false, false); //$NON-NLS-1$
		RULESET_SHARED_RES_MERGE_PATTERN.addElementCombo(ruleflow);
		
		XMLElementPattern decisiontable = new XMLElementPattern("ruleset/decisiontable", false, false); //$NON-NLS-1$
		RULESET_SHARED_RES_MERGE_PATTERN.addElementCombo(decisiontable);
		
		XMLElementPattern mutexrule = new XMLElementPattern("ruleset/mutexrule", false, false); //$NON-NLS-1$
		RULESET_SHARED_RES_MERGE_PATTERN.addElementCombo(mutexrule);
		
		XMLElementPattern effectivedateandtime = new XMLElementPattern("ruleset/effectivedateandtime", false, false); //$NON-NLS-1$
		RULESET_SHARED_RES_MERGE_PATTERN.addElementCombo(effectivedateandtime);
		
		XMLElementPattern rsPropertyset = new XMLElementPattern("ruleset/propertyset", true, true); //$NON-NLS-1$
		RULESET_SHARED_RES_MERGE_PATTERN.addElementCombo(rsPropertyset);
		
		XMLElementPattern effectivity = new XMLElementPattern("ruleset/effectivity", true, false); //$NON-NLS-1$ 
		RULESET_SHARED_RES_MERGE_PATTERN.addElementCombo(effectivity);
		
		XMLElementPattern namespacemappings = new XMLElementPattern("ruleset/namespacemappings", true, false); //$NON-NLS-1$
		RULESET_SHARED_RES_MERGE_PATTERN.addElementCombo(namespacemappings);
		
		XMLElementPattern rulesetfunctionsignature = new XMLElementPattern("ruleset/rulesetfunctionsignature", true, false); //$NON-NLS-1$
		RULESET_SHARED_RES_MERGE_PATTERN.addElementCombo(rulesetfunctionsignature); 
		
		/* Fill Project AliasSet+Shared Resource AliasSet merge Pattern */
		
		XMLElementPattern clazz = new XMLElementPattern("aliasSet/class", true, false); //$NON-NLS-1$
		PROJECT_ALIASSET_SHARED_RES_ALIASSET_PATTERN.addElementCombo(clazz);
		
		XMLElementPattern alias = new XMLElementPattern("aliasSet/alias", true, false); //$NON-NLS-1$
		PROJECT_ALIASSET_SHARED_RES_ALIASSET_PATTERN.addElementCombo(alias);
		
		XMLElementPattern datatype = new XMLElementPattern("aliasSet/datatype", true, false); //$NON-NLS-1$
		PROJECT_ALIASSET_SHARED_RES_ALIASSET_PATTERN.addElementCombo(datatype);
		
		XMLElementPattern comparatoralias = new XMLElementPattern("aliasSet/comparatoralias", true, false); //$NON-NLS-1$
		PROJECT_ALIASSET_SHARED_RES_ALIASSET_PATTERN.addElementCombo(comparatoralias);
		
		XMLElementPattern asPropertyset = new XMLElementPattern("aliasSet/propertyset", true, true); //$NON-NLS-1$
		PROJECT_ALIASSET_SHARED_RES_ALIASSET_PATTERN.addElementCombo(asPropertyset);
	}
}
