package com.sap.glx.paradigmInterface.brms.compiler;

import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
/**
 * @author I047255
 * @since 7.2
 */
public class RulesetFunctionParameterReplacer extends DefaultHandler{
	
	Map<String, String> elementVsPrefix = null;
	Map<String, String> prefixVsNameSpace = null;
	
	public RulesetFunctionParameterReplacer(Map<String, String> elementVsNSPrefix, Map<String, String> prefixVsNameSpace){
		this.elementVsPrefix = elementVsNSPrefix;
		this.prefixVsNameSpace = prefixVsNameSpace;
	}
	
	public void startElement (String uri, String localName, String qName, Attributes attributes){
		if(qName.equals("parameter")){ //$NON-NLS-1$
			String argName = null;
			String nameSpace = null;
			int length = attributes.getLength();
			for(int i=0;i<length;i++){
				String attributeName = attributes.getQName(i);
				if(attributeName.equals("name")){ //$NON-NLS-1$
					argName = attributes.getValue(i);
				}else if(attributeName.equals("namespaceuri")){ //$NON-NLS-1$
					nameSpace = attributes.getValue(i);
				}
			}
				
			if(argName != null && localName != null && nameSpace!=null){
				String prefix = this.elementVsPrefix.get(argName);
				this.elementVsPrefix.remove(argName);
				this.elementVsPrefix.put("request", prefix); //$NON-NLS-1$
			}
		}else{
			if(prefixVsNameSpace != null && qName.equals("mapping")){
				 //$NON-NLS-1$
				String preFix = null;
				String nameSpace = null;
				int length = attributes.getLength();
				for(int i=0;i<length;i++){
					String attrName = attributes.getQName(i);
					if(attrName.equals("prefix")){ //$NON-NLS-1$
						preFix = attributes.getValue(i);
					}else if(attrName.equals("namespace")){ //$NON-NLS-1$
						nameSpace = attributes.getValue(i);
					}
					
					if(preFix!=null && nameSpace!=null){
						prefixVsNameSpace.put(preFix, nameSpace);
					}
				}
			}
		}
	}
}
