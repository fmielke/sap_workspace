package com.sap.glx.paradigmInterface.brms.compiler;
/**
 * Represents element pattern to be used when merging two XML Elements into one XML Element.
 * 
 * @author I047255
 * @since 7.2
 */
class XMLElementPattern {
	
		private String xpath;
		private boolean common;
		private boolean inner;

	XMLElementPattern(String xPath, boolean common, boolean inner) {
		this.xpath = xPath;
		this.common = common;
		this.inner = inner;
	}

	String getXPath() {
		return this.xpath;
	}
	
	boolean isCommon(){
		return this.common;
	}
	
	boolean isInner(){
		return this.inner;
	}
}