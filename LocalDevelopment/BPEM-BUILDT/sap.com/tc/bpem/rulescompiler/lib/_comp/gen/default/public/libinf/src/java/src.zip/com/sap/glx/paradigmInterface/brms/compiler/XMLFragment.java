package com.sap.glx.paradigmInterface.brms.compiler;


public class XMLFragment {
	
	private String xPath;
	private String xmlString;
	private int depth;
	

	public XMLFragment(String xPath, String xmlString, int depth) {
		this.xPath = xPath;
		this.xmlString = xmlString;
		this.depth = depth;
	}

	public String getXPath() {
		return xPath;
	}

	public String getContent() {
		return xmlString;
	}
	
	public int getDepth(){
		return depth;
	}
}
