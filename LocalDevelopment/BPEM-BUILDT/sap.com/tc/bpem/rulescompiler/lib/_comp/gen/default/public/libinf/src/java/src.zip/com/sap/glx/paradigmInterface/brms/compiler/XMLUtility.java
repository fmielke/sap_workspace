package com.sap.glx.paradigmInterface.brms.compiler;

import java.util.ArrayList;
import java.util.List;
/**
 * Utility class useful for processing of XMLs and merging of XMLs based on some pattern.
 * 
 * @author I047255
 * @since 7.2
 */

class XMLUtility {
		
		// Character Constants
		private static final char XML_ELEMENT_START_CHAR = '<'; //$NON-NLS-1$
		private static final char XML_ELEMENT_END_CHAR = '>'; //$NON-NLS-1$
		private static final char XML_ELEMENT_END_SLASH_CHAR = '/'; //$NON-NLS-1$
		private static final char XML_QUESTION_MARK_CHAR = '?'; //$NON-NLS-1$
		private static final char XPATH_SEPARATOR = '/'; //$NON-NLS-1$
		
		private static final int MAX_DEPTH_FOR_MERGE = 2;
		
		// String Constants
		private static final String XML_DECLARATION_START_STRING = XML_ELEMENT_START_CHAR+""+XML_QUESTION_MARK_CHAR; //$NON-NLS-1$
		private static final String XML_DECLARATION_END_STRING = ""+XML_QUESTION_MARK_CHAR+""+XML_ELEMENT_END_CHAR; //$NON-NLS-1$
		static final String NEWLINE = "\r\n"; //$NON-NLS-1$
	
	/**
	 * Merges XMLs represented by xmlString1 and xmlString2 based upon pattern.
	 * @param xmlString1
	 * @param xmlString2
	 * @param pattern
	 * @return merged XML string
	 */
	static String mergeXMLs(String xmlString1, String xmlString2, XMLMergePattern pattern){
		// Parse strings to get xml content
		XMLContent xmlContent1 = gatherXMLContent(xmlString1, MAX_DEPTH_FOR_MERGE);
		XMLContent xmlContent2 = gatherXMLContent(xmlString2, MAX_DEPTH_FOR_MERGE);
		
		// 1. XML Declaration
		StringBuffer buffer = new StringBuffer();
		buffer.append(xmlContent1.getXMLDeclaration());
		buffer.append(NEWLINE);
		
		// 2. Start Root Element
		String rootElementName = pattern.getRootElementName();
		List<String> rootElements = xmlContent1.getElementStartTagContent(rootElementName);
		String rootElementContent = rootElements.get(0);
		buffer.append(rootElementContent);
		buffer.append(NEWLINE);
		
		// 3. Elements
		List<XMLElementPattern> elementCombos = pattern.getElementCombos();
		
		for(XMLElementPattern elementCombo : elementCombos){
			String xPath = elementCombo.getXPath();
			String elementName = xPath; 
			int index = xPath.lastIndexOf(XPATH_SEPARATOR);
			if(index>0){
				elementName = xPath.substring(index+1, xPath.length());
			}
			boolean common = elementCombo.isCommon();
			boolean inner = elementCombo.isInner();
			if(common){
				if(inner){
					// common and inner
					buffer.append(XML_ELEMENT_START_CHAR+elementName+XML_ELEMENT_END_CHAR);
					buffer.append(NEWLINE);
					
					List<String> elementsList1 = xmlContent1.getElementContentExcludingTags(xPath);
					String xmlFragment1 = appendXMLFragments(elementsList1);
					if(xmlFragment1.length()!=0){
						buffer.append(xmlFragment1);
						buffer.append(NEWLINE);
					}
					
					List<String> elementsList2 = xmlContent2.getElementContentExcludingTags(xPath);
					String xmlFragment2 = appendXMLFragments(elementsList2);
					if(xmlFragment2.length()!=0){
						buffer.append(xmlFragment2);
						buffer.append(NEWLINE);
					}
					
					buffer.append(""+XML_ELEMENT_START_CHAR+""+XML_ELEMENT_END_SLASH_CHAR+elementName+XML_ELEMENT_END_CHAR); //$NON-NLS-1$
					buffer.append(NEWLINE);
				}else{
					// common
					List<String> elementsList1 = xmlContent1.getElementContentIncludingTags(xPath);
					String xmlFragment1 = appendXMLFragments(elementsList1);
					if(xmlFragment1.length()!=0){
						buffer.append(xmlFragment1);
						buffer.append(NEWLINE);
					}
					
					List<String> elementsList2 = xmlContent2.getElementContentIncludingTags(xPath);
					String xmlFragment2 = appendXMLFragments(elementsList2);
					if(xmlFragment2.length()!=0){
						buffer.append(xmlFragment2);
						buffer.append(NEWLINE);
					}
				}
			}else{
				// individual
				List<String> elementsList = xmlContent1.getElementContentIncludingTags(xPath);
				String xmlFragment = appendXMLFragments(elementsList);
				if(xmlFragment.length()!=0){
					buffer.append(xmlFragment);
					buffer.append(NEWLINE);
				}
			}
		}
		
		// 4. End Root Element
		String rootElementEndTag = ""+XML_ELEMENT_START_CHAR+""+XML_ELEMENT_END_SLASH_CHAR+rootElementName+XML_ELEMENT_END_CHAR; //$NON-NLS-1$
		buffer.append(rootElementEndTag);
		buffer.append(NEWLINE);
		
		return buffer.toString();
	}	
	
	/**
	 * Returns XMLContent for the xmlString	
	 * @param xmlString
	 * @return XMLContent for the xmlString
	 */
	static XMLContent gatherXMLContent(String xmlString, final int maxDepth){
		XMLContent xmlContent = new XMLContent();
		_internalGatherXMLContent(xmlString, xmlContent, maxDepth);
		return xmlContent;
	}
	
	private static void _internalGatherXMLContent(String originalXmlString, XMLContent xmlContent, final int maxDepth){
		originalXmlString = originalXmlString.trim();
		int xmlDeclStartIndex = originalXmlString.indexOf(XML_DECLARATION_START_STRING);
		int xmlDeclEndIndex = originalXmlString.indexOf(XML_DECLARATION_END_STRING);
		if(xmlDeclStartIndex == 0 && xmlDeclEndIndex > 0){
			String xmlDeclaration = originalXmlString.substring(0, xmlDeclEndIndex+XML_DECLARATION_END_STRING.length());
			xmlContent.setXMLDeclaration(xmlDeclaration);
		}
		
		List<XMLFragment> fragments = new ArrayList<XMLFragment>();
		fragments.add(new XMLFragment("", originalXmlString, 1));
		
		while(fragments.size()>0){
			XMLFragment currentFragment = fragments.remove(0);
			String currentXpath = currentFragment.getXPath();
			String xmlString = currentFragment.getContent();
			int currentDepth = currentFragment.getDepth();
			if(currentDepth >maxDepth){
				continue;
			}
			
			int xmlElementStartIndex = xmlString.indexOf(XML_ELEMENT_START_CHAR);
			int xmlElementEndIndex = xmlString.indexOf(XML_ELEMENT_END_CHAR);
			if(xmlElementStartIndex >= 0 && xmlElementEndIndex>0){
				String rawElementStartTagContent = xmlString.substring(xmlElementStartIndex, xmlElementEndIndex+1);
				if(rawElementStartTagContent.endsWith(""+XML_ELEMENT_END_SLASH_CHAR+""+XML_ELEMENT_END_CHAR)){ //$NON-NLS-1$
					// case : <element attributes/>
					// End element.
					String elementName = getElementName(rawElementStartTagContent);
					
					String xPath = elementName;
					if(currentXpath != null && currentXpath.trim().length()!=0){
						xPath = currentXpath+XPATH_SEPARATOR+elementName;
					}
					int endElementIndex = rawElementStartTagContent.lastIndexOf(""+XML_ELEMENT_END_SLASH_CHAR+""+XML_ELEMENT_END_CHAR);
					String elementTagContent = rawElementStartTagContent.substring(0, endElementIndex)+" "+XML_ELEMENT_END_CHAR;
					
					xmlContent.addElementContentIncludingTags(xPath, rawElementStartTagContent);
					xmlContent.addElementContentExcludingTags(xPath, "");
					xmlContent.addElementStartTagContent(xPath, elementTagContent);
					
					xmlString = xmlString.substring(xmlElementStartIndex+rawElementStartTagContent.length());
					if(xmlString.trim().length()!=0){
						XMLFragment fragment = new XMLFragment(currentXpath, xmlString,currentDepth);
						fragments.add(fragment);
					}
				}else{
					// case : <element attributes><content></element>
					String elementName = getElementName(rawElementStartTagContent);
					String startElementTag = XML_ELEMENT_START_CHAR+elementName;
					String endElementTag = XML_ELEMENT_START_CHAR+""+XML_ELEMENT_END_SLASH_CHAR+elementName+XML_ELEMENT_END_CHAR;
					int startElementTagIndex = xmlString.indexOf(startElementTag);
					int endElementTagIndex = xmlString.indexOf(endElementTag);
					if(startElementTagIndex>=0 && endElementTagIndex>0){
						String elementContentIncludingTagWhiteSpaces = xmlString.substring(0, startElementTagIndex);
						String elementContentIncludingTag = elementContentIncludingTagWhiteSpaces+xmlString.substring(startElementTagIndex, endElementTagIndex+endElementTag.length());
						String elementContentExcludingTags = xmlString.substring(xmlElementEndIndex+1, endElementTagIndex);
						
						String xPath = elementName;
						if(currentXpath != null && currentXpath.trim().length()!=0){
							xPath = currentXpath+XPATH_SEPARATOR+elementName;
						}
						
						xmlContent.addElementContentIncludingTags(xPath, elementContentIncludingTag);
						xmlContent.addElementContentExcludingTags(xPath, elementContentExcludingTags);
						xmlContent.addElementStartTagContent(xPath, rawElementStartTagContent);
						
						int innerContentStartIndex = rawElementStartTagContent.length()+xmlElementStartIndex;
						if(endElementTagIndex < xmlString.length()){
							String xmlString2 = xmlString.substring(endElementTagIndex+endElementTag.length());
							if(xmlString2.trim().length()!=0){
								XMLFragment fragment = new XMLFragment(currentXpath, xmlString2,currentDepth);
								fragments.add(fragment);
							}
						}
						currentXpath = xPath;
						xmlString = xmlString.substring(innerContentStartIndex, endElementTagIndex);
						XMLFragment fragment = new XMLFragment(currentXpath, xmlString,(currentDepth+1));
						fragments.add(fragment);

					}else{
						if(startElementTagIndex>=0){
							xmlString = xmlString.substring(startElementTagIndex+rawElementStartTagContent.length());
							if(xmlString.trim().length()!=0){
								XMLFragment fragment = new XMLFragment(currentXpath, xmlString, currentDepth);
								fragments.add(fragment);
							}
						}
					}
				}
			}
		}
	}
	
	private static String getElementName(String rawElementStartTagContent){
		String elementName = null;
		String tokens[] = rawElementStartTagContent.split(" "); //$NON-NLS-1$
		String temp = tokens[0]; 
		int xmlStartCharIndex = temp.indexOf(XML_ELEMENT_START_CHAR);
		if(xmlStartCharIndex>=0){
			temp = temp.substring(xmlStartCharIndex+1);
		}
		int xmlEndCharIndex = temp.indexOf(XML_ELEMENT_END_CHAR);
		if(xmlEndCharIndex>0){
			temp = temp.substring(0, xmlEndCharIndex);
		}
		elementName = temp.trim();
		return elementName;
	}
	
	private static String appendXMLFragments(List<String> xmlFrgments){
		if(xmlFrgments == null || xmlFrgments.size()==0){
			return ""; //$NON-NLS-1$
		}
		StringBuffer buffer = new StringBuffer();
		for(int i=0;i<xmlFrgments.size();i++){
			String xmlFragment = xmlFrgments.get(i);
			if(i!=0 && i!=xmlFrgments.size()-1){
				buffer.append(NEWLINE);
			}
			buffer.append(xmlFragment);
			
		}
		String xmlString = buffer.toString();
		return xmlString;
	}
}
