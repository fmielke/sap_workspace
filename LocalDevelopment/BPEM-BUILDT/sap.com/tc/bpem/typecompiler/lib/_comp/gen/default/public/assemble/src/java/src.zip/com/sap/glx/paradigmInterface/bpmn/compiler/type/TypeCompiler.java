package com.sap.glx.paradigmInterface.bpmn.compiler.type;

import static com.sap.glx.constants.SharedCompilerConstants.COMMA_IDENTIFIER;
import static com.sap.glx.constants.SharedCompilerConstants.SCHEMA_IDENTIFIER;
import static com.sap.glx.constants.SharedCompilerConstants.UTF_8;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.xml.XMLConstants;
import javax.xml.namespace.QName;

import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.RenamingExportListener;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.VersioningHelper;
import com.sap.glx.paradigmInterface.buildapi.BpemBuildException;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.ICompiler;
import com.sap.glx.paradigmInterface.buildapi.INormalizedTypeFileWriter;
import com.sap.sdo.api.types.schema.Import;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.esmp.mm.xsd1.XsdComplexTypeDefinition;
import com.sap.tc.esmp.mm.xsd1.XsdConcreteComponent;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import com.sap.tc.esmp.mm.xsd1.XsdFormEnum;
import com.sap.tc.esmp.mm.xsd1.XsdNamedComponent;
import com.sap.tc.esmp.mm.xsd1.XsdTypeDefinition;
import com.sap.tc.esmp.tools.xsdexport.ExportListener;
import com.sap.tc.esmp.tools.xsdexport.Exporter;
import com.sap.tc.esmp.tools.xsdexport.Factory;
import com.sap.tc.esmp.tools.xsdexport.Schema;
import com.sap.tc.esmp.tools.xsdexport.SchemaDocument;
import com.sap.tc.esmp.tools.xsdexport.TextSchemaDocument;
import commonj.sdo.DataObject;
import commonj.sdo.helper.HelperContext;
import commonj.sdo.helper.XMLDocument;
import commonj.sdo.impl.HelperProvider;

public class TypeCompiler implements ICompiler {
    final private static String FILE_PREFIX = "t"; //$NON-NLS-1$
    final private static String FILE_EXT = ".type"; //$NON-NLS-1$

    @SuppressWarnings("unchecked")
    public boolean canCompile(final Object artifact) {

        Log.verbose("TypeCompiler.canCompile() enter."); //$NON-NLS-1$

        if (!(artifact instanceof Iterable)) {
            Log.verbose("TypeCompiler.canCompile() leave - not Iterable artifact."); //$NON-NLS-1$
            return false;
        }

        final Iterator iterator = ((Iterable) artifact).iterator();

        while (iterator.hasNext()) {
            if (!(iterator.next() instanceof XsdElementDeclaration)) {
                Log.verbose("TypeCompiler.canCompile() leave - not XsdElementDeclaration in artifact."); //$NON-NLS-1$
                return false;
            }
        }

        Log.verbose("TypeCompiler.canCompile() leave."); //$NON-NLS-1$
        return true;
    }

    public Object[] getDependencies(final IBuilderHost host, final Object artifact) {
        Log.verbose("TypeCompiler.getDependencies() enter."); //$NON-NLS-1$
        Log.verbose("TypeCompiler.getDependencies() leave."); //$NON-NLS-1$
        return new Object[0];
    }

    /**
     * This method generates the .type file. It will contains the following structure:
     * 
     * ROOT_0,TARGET_NAMESPACE=urn:sap-com:document:sap:soap:functions:mc-style
     * ROOT_0,SCHEMA_LOCATION=urn:sap-com:document:sap:soap:functions:mc-style ROOT_0,ROOTID=0 ROOT_0,SCHEMA=<xsd:schema
     * xmlns:xsd="http://www.w3.org/2001/XMLSchema"/>
     * 
     * CHILD_0,TARGET_NAMESPACE=urn:sap-com:document:sap:soap:functions:mc-style
     * CHILD_0,SCHEMA_LOCATION=urn:sap-com:document:sap:soap:functions:mc-style CHILD_0,ROOTID=0 CHILD_0,SCHEMA=<xsd:schema
     * xmlns:xsd="http://www.w3.org/2001/XMLSchema"/>
     * 
     */
    @SuppressWarnings("unchecked")
    public boolean compile(final IBuilderHost host, final Object artifact) throws Exception {

        Log.verbose("TypeCompiler.compile() enter."); //$NON-NLS-1$

        INormalizedTypeFileWriter normalizedWriter = null;

        final SortedSet<XsdElementDeclaration> elements = new TreeSet<XsdElementDeclaration>(new Comparator<XsdElementDeclaration>() {

            public int compare(XsdElementDeclaration o1, XsdElementDeclaration o2) {
                if (o1 == o2)
                    return 0;
                if (o1 == null)
                    return -1;
                if (o2 == null)
                    return 1;

                if (o1.getReferencedElementDeclaration() != null)
                    o1 = o1.getReferencedElementDeclaration();

                if (o2.getReferencedElementDeclaration() != null)
                    o2 = o2.getReferencedElementDeclaration();

                final String s1 = (o1.getNamespace() != null ? o1.getNamespace() + ":" : "") + o1.getName(); //$NON-NLS-1$ 	 //$NON-NLS-2$
                final String s2 = (o2.getNamespace() != null ? o2.getNamespace() + ":" : "") + o2.getName(); //$NON-NLS-1$	 //$NON-NLS-2$

                return s1.compareTo(s2);
            }

        });

        for (final Iterator<XsdElementDeclaration> it = ((Iterable<XsdElementDeclaration>) artifact).iterator(); it.hasNext(); elements
                .add(it.next()));

        try {
            normalizedWriter = host.getNormalizedTypeFileWriter(getFilename(elements), artifact);
            Collection<XsdNamedComponent> anonymousType = null;
            int root_id = 0;
            for (XsdElementDeclaration root_element : elements) {
                // Write the root element
                if (root_element.getReferencedElementDeclaration() != null) {
                    root_element = root_element.getReferencedElementDeclaration();
                }
                anonymousType = getRootXSDComponentForAnonymousType(root_element);
                if (anonymousType != null) {
                    exportSchemaForNamedComponents(anonymousType, normalizedWriter);
                    continue;
                }
                final Exporter exporter = Factory.getExporter(Arrays.asList(new ExportListener[] { new RenamingExportListener() }));

                try {
                    final Schema xsds = exporter.exportToTextSchema(root_element);
                    final TextSchemaDocument root = (TextSchemaDocument) xsds.getRootSchemaDocument();
                    writeSchemaElement(normalizedWriter, true, root_id, root_id, root.getTargetNamespace(), root.getSchemaLocation(), root
                            .get());

                    // Write the child elements
                    int child_id = 0;
                    final Set<String> locations = xsds.getSchemaLocations();

                    for (final String schemaLocation : locations) {
                        final SchemaDocument<String> doc = xsds.getSchemaDocument(schemaLocation);

                        final TextSchemaDocument child = (TextSchemaDocument) doc;

                        if (child == root)
                            continue;

                        writeSchemaElement(normalizedWriter, false, child_id++, root_id, child.getTargetNamespace(), child
                                .getSchemaLocation(), child.get());
                    }
                    root_id++;
                } catch (final Exception e) {
                    throw new BpemBuildException(
                            "BPM.rt_c_type.000000", //$NON-NLS-1$
                            String
                                    .format(
                                            "The XSD schemas of the transitive hull of element '{%s}%s' could not be rendered from the meta model.", root_element.getNamespace(), root_element.getName()), e); //$NON-NLS-1$
                }
            }
        } finally {
            if (normalizedWriter != null) {
                normalizedWriter.close();
                normalizedWriter = null;
            }
        }
        Log.verbose("TypeCompiler.compile() leave."); //$NON-NLS-1$
        return true;
    }

    private String getFilename(final SortedSet<XsdElementDeclaration> elements) throws BpemBuildException {
        Log.verbose("TypeCompiler.getFileName() enter."); //$NON-NLS-1$
        final StringBuilder fname = new StringBuilder();
        // create a sorted set of the elements. The sorting uses natural order of String.
        for (XsdElementDeclaration element : elements) {
            if (element.getReferencedElementDeclaration() != null)
                element = element.getReferencedElementDeclaration();
            fname
                    .append(element.getForm() != null && element.getForm().equals(XsdFormEnum.QUALIFIED) && element.getNamespace() != null ? element
                            .getNamespace()
                            + ":" : ""); //$NON-NLS-1$	 //$NON-NLS-2$
            fname.append(element.getName());
            fname.append(" ("); //$NON-NLS-1$
            fname.append(element.refMofId()); // nasty QName uniqueness violation workaround
            fname.append(") & "); //$NON-NLS-1$
        }
        Log.verbose("TypeCompiler.getFileName() leave."); //$NON-NLS-1$

        return FILE_PREFIX + VersioningHelper.computeVersion(fname.toString()) + FILE_EXT;
    }

    private void writeSchemaElement(final INormalizedTypeFileWriter normalizedWriter, final boolean root, final int id, final int rootId,
            final String targetNamespace, final String schemaLocation, final String schema) throws Exception {
        Log.verbose("TypeCompiler.writeSchemaElement() enter."); //$NON-NLS-1$
        normalizedWriter.writeln((root ? "ROOT_" : "CHILD_") + id + ",TARGET_NAMESPACE=" + targetNamespace); //$NON-NLS-1$	 //$NON-NLS-2$	 //$NON-NLS-3$
        normalizedWriter.writeln((root ? "ROOT_" : "CHILD_") + id + ",SCHEMA_LOCATION=" + schemaLocation); //$NON-NLS-1$	 //$NON-NLS-2$	 //$NON-NLS-3$
        normalizedWriter.writeln((root ? "ROOT_" : "CHILD_") + id + ",ROOTID=" + rootId); //$NON-NLS-1$	 //$NON-NLS-2$	 //$NON-NLS-3$
        normalizedWriter.write((root ? "ROOT_" : "CHILD_") + id + COMMA_IDENTIFIER + SCHEMA_IDENTIFIER);//$NON-NLS-1$    //$NON-NLS-2$   //$NON-NLS-3$
        normalizedWriter.writelnXsd(String.valueOf(rootId), schemaLocation, targetNamespace, schema);
        normalizedWriter.writeln(""); //$NON-NLS-1$
        Log.verbose("TypeCompiler.writeSchemaElement() leave."); //$NON-NLS-1$
    }

    /* Start - Methods related to packaging sub-types to be used by Rules Compiler */

    public boolean compileWithSubTypes(final IBuilderHost host, final Map<String, Collection<XsdNamedComponent>> elementsAndSubTypesMap)
            throws Exception {

        Log.verbose("TypeCompiler.compileWithSubTypes() enter."); //$NON-NLS-1$

        final SortedSet<XsdNamedComponent> sortedElements = new TreeSet<XsdNamedComponent>(new Comparator<XsdNamedComponent>() {

            public int compare(XsdNamedComponent o1, XsdNamedComponent o2) {
                if (o1 == o2)
                    return 0;
                if (o1 == null)
                    return -1;
                if (o2 == null)
                    return 1;

                if ((o1 instanceof XsdElementDeclaration) && (o2 instanceof XsdElementDeclaration)) {
                    final XsdElementDeclaration xsdElemDecl1 = (XsdElementDeclaration) o1;
                    final XsdElementDeclaration xsdElemDecl2 = (XsdElementDeclaration) o2;
                    if (xsdElemDecl1.getReferencedElementDeclaration() != null) {
                        o1 = xsdElemDecl1.getReferencedElementDeclaration();
                    }
                    if (xsdElemDecl2.getReferencedElementDeclaration() != null) {
                        o2 = xsdElemDecl2.getReferencedElementDeclaration();
                    }
                } else if ((o1 instanceof XsdElementDeclaration) && (o2 instanceof XsdTypeDefinition)) {
                    return 1;
                } else if ((o1 instanceof XsdTypeDefinition) && (o2 instanceof XsdElementDeclaration)) {
                    return -1;
                }

                final String s1 = (o1.getNamespace() != null ? o1.getNamespace() + ":" : "") + o1.getName(); //$NON-NLS-1$ 	 //$NON-NLS-2$
                final String s2 = (o2.getNamespace() != null ? o2.getNamespace() + ":" : "") + o2.getName(); //$NON-NLS-1$	 //$NON-NLS-2$

                return s1.compareTo(s2);
            }

        });

        final Collection<XsdNamedComponent> elements = elementsAndSubTypesMap.get("elements"); //$NON-NLS-1$
        final Collection<XsdNamedComponent> subTypes = elementsAndSubTypesMap.get("subtypes"); //$NON-NLS-1$

        final Collection<XsdNamedComponent> elementsAndSubTypes = new ArrayList<XsdNamedComponent>();
        elementsAndSubTypes.addAll(elements);
        elementsAndSubTypes.addAll(subTypes);

        for (final XsdNamedComponent namedComponent : elementsAndSubTypes) {
            sortedElements.add(namedComponent);
        }

        final INormalizedTypeFileWriter normalizedWriter = host.getNormalizedTypeFileWriter(
                getFilenameForElementsAndSubtypes(sortedElements), elementsAndSubTypesMap);
        exportSchemaForNamedComponents(elementsAndSubTypes, normalizedWriter);

        Log.verbose("TypeCompiler.compileWithSubTypes() leave."); //$NON-NLS-1$
        return true;
    }

    /**
     * @param elementsAndSubTypes
     * @param outputStream
     * @param printWriter
     * @param osw
     * @throws BpemBuildException
     * @throws IOException
     */
    private void exportSchemaForNamedComponents(final Collection<XsdNamedComponent> elementsAndSubTypes,
            INormalizedTypeFileWriter normalizedWriter) throws BpemBuildException, IOException {
        try {
            final Exporter exporter = Factory.getExporter(Arrays.asList(new ExportListener[] { new RenamingExportListener() }));
            final Collection<com.sap.sdo.api.types.schema.Schema> schemas = exporter.exportToSdoSchema(elementsAndSubTypes,
                    new ArrayList<QName>());

            int root_id = 0;
            DataObject rootSchemaObject = null;
            String schemaNameSpace = null;
            String schemaLocation = null;
            String text = null;
            String childNS = null;
            String childLoc = null;
            String childtext = null;
            DataObject child = null;

            for (final com.sap.sdo.api.types.schema.Schema schema : schemas) {
                rootSchemaObject = schema.getRootObject();
                schemaNameSpace = schema.getTargetNamespace();
                schemaLocation = schemaNameSpace;
                text = toText(schema, UTF_8);
                writeSchemaElement(normalizedWriter, true, root_id, root_id, schemaNameSpace, schemaLocation, text);

                final Collection<Import> imports = schema.getImport();
                int child_id = 0;
                for (final Import imprt : imports) {
                    child = imprt.getRootObject();
                    if (child != rootSchemaObject) {
                        childNS = imprt.getNamespace();
                        childLoc = imprt.getSchemaLocation();
                        childtext = toText(child, UTF_8);
                        writeSchemaElement(normalizedWriter, false, child_id++, root_id, childNS, childLoc, childtext);
                    }
                }
                root_id++;
            }
        } catch (final Exception e) {
            throw new BpemBuildException("BPM.rt_c_type.000000"); //$NON-NLS-1$

        } finally {
            if (normalizedWriter != null) {
                normalizedWriter.close();
                normalizedWriter = null;
            }
        }
    }

    private String getFilenameForElementsAndSubtypes(final SortedSet<XsdNamedComponent> elementsAndSubTypes) throws BpemBuildException {
        Log.verbose("TypeCompiler.getFilenameForElementsAndSubtypes() enter."); //$NON-NLS-1$
        final StringBuilder fname = new StringBuilder();
        // create a sorted set of the elements. The sorting uses natural order of String.
        for (final XsdNamedComponent namedComponent : elementsAndSubTypes) {
            if (namedComponent instanceof XsdElementDeclaration) {
                XsdElementDeclaration element = (XsdElementDeclaration) namedComponent;
                if (element.getReferencedElementDeclaration() != null)
                    element = element.getReferencedElementDeclaration();
                fname
                        .append(element.getForm() != null && element.getForm().equals(XsdFormEnum.QUALIFIED)
                                && element.getNamespace() != null ? element.getNamespace() + ":" : ""); //$NON-NLS-1$	 //$NON-NLS-2$
            } else {
                fname.append(namedComponent.getNamespace() != null ? namedComponent.getNamespace() + ":" : ""); //$NON-NLS-1$	 //$NON-NLS-2$
            }
            fname.append(namedComponent.getName());
            fname.append(" ("); //$NON-NLS-1$
            fname.append(namedComponent.refMofId()); // nasty QName uniqueness violation workaround
            fname.append(") & "); //$NON-NLS-1$
        }
        Log.verbose("TypeCompiler.getFilenameForElementsAndSubtypes() leave."); //$NON-NLS-1$

        return FILE_PREFIX + VersioningHelper.computeVersion(fname.toString()) + FILE_EXT;
    }

    private String toText(final DataObject schema, final String encoding) throws IOException {
        Log.verbose("TypeCompiler.toText() enter."); //$NON-NLS-1$
        final HelperContext helperContext = HelperProvider.getDefaultContext();
        final XMLDocument doc = helperContext.getXMLHelper().createDocument(schema, XMLConstants.W3C_XML_SCHEMA_NS_URI, "schema"); //$NON-NLS-1$
        doc.setEncoding(encoding);
        final StringWriter stringWriter = new StringWriter();
        helperContext.getXMLHelper().save(doc, stringWriter, null);
        final String result = stringWriter.toString();
        Log.verbose("TypeCompiler.toText() leave."); //$NON-NLS-1$
        return result;
    }

    /* End - Methods related to packaging sub-types to be used by Rules Compiler */

    /**
     * Finds the root type definition to export in case of anonymous complex data type.
     */
    private Collection<XsdNamedComponent> getRootXSDComponentForAnonymousType(final XsdElementDeclaration root_element) {
        // Gets the root global element for anonymous type
        final XsdTypeDefinition typeDefinition = root_element.getTypeDefinition();
        if (typeDefinition != null && typeDefinition.getNamespace() == null) {
            final XsdConcreteComponent rootType = typeDefinition.getRootContainer();
            if (rootType instanceof XsdComplexTypeDefinition) {
                final Collection<XsdNamedComponent> anonymousType = new ArrayList<XsdNamedComponent>();
                anonymousType.add((XsdComplexTypeDefinition) rootType);
                return anonymousType;
            }
        }
        return null;
    }

}
