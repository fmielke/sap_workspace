package com.sap.glx.paradigmInterface.bpmn.compiler.type;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.RenamingExportListener;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.VersioningHelper;
import com.sap.glx.paradigmInterface.buildapi.BpemBuildException;
import com.sap.glx.paradigmInterface.buildapi.IArtifact;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost2;
import com.sap.glx.paradigmInterface.buildapi.ICompiler2;
import com.sap.glx.paradigmInterface.buildapi.TypeArtifact;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import com.sap.tc.esmp.mm.xsd1.XsdFormEnum;
import com.sap.tc.esmp.tools.xsdexport.ExportException;
import com.sap.tc.esmp.tools.xsdexport.ExportListener;
import com.sap.tc.esmp.tools.xsdexport.Exporter;
import com.sap.tc.esmp.tools.xsdexport.Factory;
import com.sap.tc.esmp.tools.xsdexport.Schema;
import com.sap.tc.esmp.tools.xsdexport.SchemaDocument;
import com.sap.tc.esmp.tools.xsdexport.TextSchemaDocument;

public class TypeCompiler2 implements ICompiler2<Object, TypeArtifact>{

    final private static String FILE_PREFIX = "t";		 //$NON-NLS-1$
    final private static String FILE_EXT = ".type";	 	 //$NON-NLS-1$
    private static final String UTF8_CHARSET = "UTF-8";	 //$NON-NLS-1$
    
    public boolean compile(IBuilderHost2 host, TypeArtifact artifact) throws BpemBuildException {
        Object dc = artifact.getObject();
        Collection<XsdElementDeclaration> xsdElementDeclarations = host.getEsmpFacade().getAllElementsOfDC(dc);
        
        OutputStream outputStream = null;
        PrintWriter printWriter = null;
        OutputStreamWriter osw = null;

        SortedSet<XsdElementDeclaration> elements = sortXsdElementDeclarations(xsdElementDeclarations);
        
        try {
            outputStream = host.createVersionedTargetFile(getFilename(elements), artifact);

            osw = new OutputStreamWriter(outputStream, UTF8_CHARSET);
            printWriter = new PrintWriter(osw);

            int root_id = 0;
            for (XsdElementDeclaration root_element : elements) {
                // Write the root element
                if (root_element.getReferencedElementDeclaration() != null)
                    root_element = root_element.getReferencedElementDeclaration();

                Exporter exporter = Factory.getExporter(Arrays.asList(new ExportListener[] { new RenamingExportListener() }));

                Schema xsds = exporter.exportToTextSchema(root_element);

                TextSchemaDocument root = (TextSchemaDocument) xsds.getRootSchemaDocument();
                writeSchemaElement(printWriter, true, root_id, root_id, root.getTargetNamespace(), root.getSchemaLocation(), root.get());

                // Write the child elements
                int child_id = 0;
                Set<String> locations = xsds.getSchemaLocations();

                for (String schemaLocation : locations) {
                    SchemaDocument<String> doc = xsds.getSchemaDocument(schemaLocation);

                    TextSchemaDocument child = (TextSchemaDocument) doc;

                    if (child == root)
                        continue;

                    writeSchemaElement(printWriter, false, child_id++, root_id, child.getTargetNamespace(), child.getSchemaLocation(), child.get());
                }
                root_id++;
            }
        } catch (UnsupportedEncodingException e) {
			throw new BpemBuildException(e);
		} catch (ExportException e) {
			throw new BpemBuildException(e);
		} finally {
            if (printWriter != null) {
                printWriter.close();
                printWriter = null;
            }

            if (osw != null) {
                try {
					osw.close();
				} catch (IOException e) {
					throw new BpemBuildException(e);
				}
                osw = null;
            }

            if (outputStream != null) {
                try {
					outputStream.close();
				} catch (IOException e) {
					throw new BpemBuildException(e);
				}
                outputStream = null;
            }
        }
        return true;
    }
    
    public IArtifact<?>[] getDependencies(IBuilderHost2 host, TypeArtifact artifact) {
        return new IArtifact[0];
    }
    
    private SortedSet<XsdElementDeclaration> sortXsdElementDeclarations(Iterable<XsdElementDeclaration> artifact) {
        SortedSet<XsdElementDeclaration> elements = new TreeSet<XsdElementDeclaration>(new Comparator<XsdElementDeclaration>() {

            public int compare(XsdElementDeclaration o1, XsdElementDeclaration o2) {
                if (o1 == o2)
                    return 0;
                if (o1 == null)
                    return -1;
                if (o2 == null)
                    return 1;

                if (o1.getReferencedElementDeclaration() != null)
                    o1 = o1.getReferencedElementDeclaration();

                if (o2.getReferencedElementDeclaration() != null)
                    o2 = o2.getReferencedElementDeclaration();

                String s1 = (o1.getNamespace() != null ? o1.getNamespace() + ":" : "") + o1.getName();	 //$NON-NLS-1$	 //$NON-NLS-2$
                String s2 = (o2.getNamespace() != null ? o2.getNamespace() + ":" : "") + o2.getName();	 //$NON-NLS-1$	 //$NON-NLS-2$

                return s1.compareTo(s2);
            }

        });
        for (Iterator<XsdElementDeclaration> it = ((Iterable<XsdElementDeclaration>) artifact).iterator(); it.hasNext(); elements.add(it.next()));

        return elements;
    }

    private String getFilename(SortedSet<XsdElementDeclaration> elements) throws BpemBuildException {
        StringBuilder fname = new StringBuilder();
        // create a sorted set of the elements. The sorting uses natural order of String.
        for (XsdElementDeclaration element : elements) {
            if (element.getReferencedElementDeclaration() != null) 
                element = element.getReferencedElementDeclaration();
            fname.append(element.getForm() != null && element.getForm().equals(XsdFormEnum.QUALIFIED) && element.getNamespace() != null ? element.getNamespace() + ":" : "");	 //$NON-NLS-1$	 //$NON-NLS-2$
            fname.append(element.getName());
            fname.append(" (");	 	//$NON-NLS-1$
            fname.append(element.refMofId()); // nasty QName uniqueness violation workaround
            fname.append(") & ");	 //$NON-NLS-1$
        }

        return FILE_PREFIX + VersioningHelper.computeVersion(fname.toString()) + FILE_EXT;
    }

    private void writeSchemaElement(PrintWriter printWriter, boolean root, int id, int rootId, String targetNamespace, String schemaLocation, String schema) {
        printWriter.println((root ? "ROOT_" : "CHILD_") + id + ",TARGET_NAMESPACE=" + targetNamespace);	 //$NON-NLS-1$	 //$NON-NLS-2$	 //$NON-NLS-3$
        printWriter.println((root ? "ROOT_" : "CHILD_") + id + ",SCHEMA_LOCATION=" + schemaLocation);	 //$NON-NLS-1$	 //$NON-NLS-2$	 //$NON-NLS-3$
        printWriter.println((root ? "ROOT_" : "CHILD_") + id + ",ROOTID=" + rootId);	 //$NON-NLS-1$	 //$NON-NLS-2$	 //$NON-NLS-3$
        printWriter.println((root ? "ROOT_" : "CHILD_") + id + ",SCHEMA=" + schema.replaceAll("\n", " "));	 //$NON-NLS-1$	 //$NON-NLS-2$	 //$NON-NLS-3$	 //$NON-NLS-4$	 //$NON-NLS-5$
        printWriter.println("");	 //$NON-NLS-1$
    }
}
