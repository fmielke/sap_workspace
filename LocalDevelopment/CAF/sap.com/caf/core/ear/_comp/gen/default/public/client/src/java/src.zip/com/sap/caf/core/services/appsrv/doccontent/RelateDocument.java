
package com.sap.caf.core.services.appsrv.doccontent;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="srcRid" type="{http://www.sap.com/caf/sap.com/caf.core/services}Rid" minOccurs="0"/>
 *         &lt;element name="dstBOGuid" type="{http://www.sap.com/caf/sap.com/caf.core/services}Rid" minOccurs="0"/>
 *         &lt;element name="dstBOName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "srcRid",
    "dstBOGuid",
    "dstBOName"
})
@XmlRootElement(name = "relateDocument")
public class RelateDocument implements java.io.Serializable {

    protected String srcRid;
    protected String dstBOGuid;
    protected String dstBOName;

    /**
     * Gets the value of the srcRid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcRid() {
        return srcRid;
    }

    /**
     * Sets the value of the srcRid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcRid(String value) {
        this.srcRid = value;
    }

    /**
     * Gets the value of the dstBOGuid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDstBOGuid() {
        return dstBOGuid;
    }

    /**
     * Sets the value of the dstBOGuid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDstBOGuid(String value) {
        this.dstBOGuid = value;
    }

    /**
     * Gets the value of the dstBOName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDstBOName() {
        return dstBOName;
    }

    /**
     * Sets the value of the dstBOName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDstBOName(String value) {
        this.dstBOName = value;
    }

}
