package com.sap.caf.core.services.bi;


/**
 * Class representing a BI Selection
 * @author Trendafil Madarov 
 */
public class BISelection implements IBIExpression {

	private static final long serialVersionUID = 8245571270465684059L;

	private String attributeName;
	private Object fromValue;
	private Object toValue;
	private BIOperator operator;
	
	/**
	 * Returns the attribute name
     * @return the attribute name 
     * @see #setAttributeName 
	 */
	public String getAttributeName() {
		return attributeName;
	}
	
	/**
	 * Sets the attribute name
     * @param attributeName the attribute name
     * @see #getAttributeName  
	 */	
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	
	/**
	 * Returns the low value
     * @return the low value 
     * @see #setFromValue 
	 */	
	public Object getFromValue() {
		return fromValue;
	}
	
	/**
	 * Sets the low value
     * @param fromValue the low value
     * @see #getFromValue  
	 */	
	public void setFromValue(Object fromValue) {
		this.fromValue = fromValue;
	}
	
	/**
	 * Returns the high value
     * @return the high value 
     * @see #setToValue 
	 */	
	public Object getToValue() {
		return toValue;
	}
	
	/**
	 * Sets the high value
     * @param toValue the high value
     * @see #getToValue  
	 */	
	public void setToValue(Object toValue) {
		this.toValue = toValue;
	}
	
	/**
	 * Returns the BI operator
     * @return the BI operator
     * @see #setOperator 
	 */	
	public BIOperator getOperator() {
		return operator;
	}
	
	/**
	 * Sets the BI operator
     * @param operator the BI operator 
     * @see #getOperator 
	 */	
	public void setOperator(BIOperator operator) {
		this.operator = operator;
	}	
}