	
package com.sap.caf.core.services.bonode.document.document;

import static com.sap.caf.rt.util.JPAValuesConvertor.*;

@javax.persistence.Entity(name="com_sap_caf_core_services_bonode_document_document_DocumentBO")
@javax.persistence.Table(name="XAP_CAF_SER_DOCUMH")

@com.sap.caf.rt.bol.da.jpa.annotations.CAFStructure(mainStructure=true, pojoClass=com.sap.caf.core.services.types.Document.class, version="1.1.0" )
@com.sap.caf.rt.bol.da.jpa.annotations.CAFBONodeAssociations(
	associations = { @com.sap.caf.rt.bol.da.jpa.annotations.CAFBONodeAssociation(name="relatedObjectRefs",crossClass=com.sap.caf.core.services.bonode.document.document.AssociationDocumentTorelatedObjectRefs.class,targetBOEntity=com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObjectBO.class) 
		
	}
)
public class DocumentBO implements com.sap.caf.rt.bol.da.jpa.IPersistableBONode {


	private java.lang.String _createdBy;
	private java.sql.Timestamp _createdAt;
	private java.sql.Timestamp _modifiedAt;
	private java.lang.String _modifiedBy;
	private java.lang.String _contentType;
	private java.lang.String _parentFolder;
	private java.lang.Long _contentLength;
	private java.lang.String _documentId;
	private java.lang.String _title;
	private java.lang.String _description;
	private java.lang.String _link;
	private java.lang.String _key;



	public DocumentBO() {
	
	}
	
	@Deprecated
	public void setCreatedAt(java.util.Date _createdAt) {
		this._createdAt = new java.sql.Timestamp(_createdAt.getTime());
	}
	
	@Deprecated
	public void setModifiedAt(java.util.Date _modifiedAt){
		this._modifiedAt = new java.sql.Timestamp(_modifiedAt.getTime());
	}



	@javax.persistence.Column(name="CREATEDBY0")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="createdBy", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="32")})
	public java.lang.String getCreatedBy() {
		return this._createdBy;
	}
	
	
	
	public void setCreatedBy(java.lang.String _createdBy) {
		if (_createdBy != null && _createdBy.trim().length() == 0) {
			this._createdBy = null;
		} else {
			this._createdBy = _createdBy;
		}
	}
	
	@javax.persistence.Column(name="CREATEDAT0")
	@javax.persistence.Temporal(javax.persistence.TemporalType.TIMESTAMP)

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="createdAt", properties={})
	public java.sql.Timestamp getCreatedAt() {
		return this._createdAt;
	}
	
	
	
	public void setCreatedAt(java.sql.Timestamp _createdAt) {
		this._createdAt = _createdAt;
	}
	
	@javax.persistence.Column(name="MODIFIEDAT0")
	@javax.persistence.Temporal(javax.persistence.TemporalType.TIMESTAMP)

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="modifiedAt", properties={})
	public java.sql.Timestamp getModifiedAt() {
		return this._modifiedAt;
	}
	
	
	
	public void setModifiedAt(java.sql.Timestamp _modifiedAt) {
		this._modifiedAt = _modifiedAt;
	}
	
	@javax.persistence.Column(name="MODIFIEDBY0")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="modifiedBy", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="32")})
	public java.lang.String getModifiedBy() {
		return this._modifiedBy;
	}
	
	
	
	public void setModifiedBy(java.lang.String _modifiedBy) {
		if (_modifiedBy != null && _modifiedBy.trim().length() == 0) {
			this._modifiedBy = null;
		} else {
			this._modifiedBy = _modifiedBy;
		}
	}
	
	@javax.persistence.Column(name="CONTENTTYPE")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="contentType", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="128")})
	public java.lang.String getContentType() {
		return this._contentType;
	}
	
	
	
	public void setContentType(java.lang.String _contentType) {
		if (_contentType != null && _contentType.trim().length() == 0) {
			this._contentType = null;
		} else {
			this._contentType = _contentType;
		}
	}
	
	@javax.persistence.Column(name="PARENTFOLDER")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="parentFolder", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="1024"),@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="mandatory", value="true")})
	public java.lang.String getParentFolder() {
		return this._parentFolder;
	}
	
	
	
	public void setParentFolder(java.lang.String _parentFolder) {
		if (_parentFolder != null && _parentFolder.trim().length() == 0) {
			this._parentFolder = null;
		} else {
			this._parentFolder = _parentFolder;
		}
	}
	
	@javax.persistence.Column(name="CONTENTLENGTH")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="contentLength", properties={})
	public java.lang.Long getContentLength() {
		return this._contentLength;
	}
	
	
	
	public void setContentLength(java.lang.Long _contentLength) {
		this._contentLength = _contentLength;
	}
	
	@javax.persistence.Column(name="DOCUMENTID")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="documentId", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="1024"),@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="mandatory", value="true")})
	public java.lang.String getDocumentId() {
		return this._documentId;
	}
	
	
	
	public void setDocumentId(java.lang.String _documentId) {
		if (_documentId != null && _documentId.trim().length() == 0) {
			this._documentId = null;
		} else {
			this._documentId = _documentId;
		}
	}
	
	@javax.persistence.Column(name="TITLE")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="title", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="256")})
	public java.lang.String getTitle() {
		return this._title;
	}
	
	
	
	public void setTitle(java.lang.String _title) {
		if (_title != null && _title.trim().length() == 0) {
			this._title = null;
		} else {
			this._title = _title;
		}
	}
	
	@javax.persistence.Column(name="DESCRIPTION0")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="description", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="256")})
	public java.lang.String getDescription() {
		return this._description;
	}
	
	
	
	public void setDescription(java.lang.String _description) {
		if (_description != null && _description.trim().length() == 0) {
			this._description = null;
		} else {
			this._description = _description;
		}
	}
	
	@javax.persistence.Column(name="LINK")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="link", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="1024")})
	public java.lang.String getLink() {
		return this._link;
	}
	
	
	
	public void setLink(java.lang.String _link) {
		if (_link != null && _link.trim().length() == 0) {
			this._link = null;
		} else {
			this._link = _link;
		}
	}
	
	@javax.persistence.Id
	@javax.persistence.Column(name="OBJECTKEY")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="key", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="36")})
	public java.lang.String getKey() {
		return this._key;
	}
	
	
	
	public void setKey(java.lang.String _key) {
		if (_key != null && _key.trim().length() == 0) {
			this._key = null;
		} else {
			this._key = _key;
		}
	}
	

	public Object getAttribute(java.lang.String name) {
		if ("createdBy".equals(name))
			return getCreatedBy();
		if ("createdAt".equals(name))
			return getCreatedAt();
		if ("modifiedAt".equals(name))
			return getModifiedAt();
		if ("modifiedBy".equals(name))
			return getModifiedBy();
		if ("contentType".equals(name))
			return getContentType();
		if ("parentFolder".equals(name))
			return getParentFolder();
		if ("contentLength".equals(name))
			return getContentLength();
		if ("documentId".equals(name))
			return getDocumentId();
		if ("title".equals(name))
			return getTitle();
		if ("description".equals(name))
			return getDescription();
		if ("link".equals(name))
			return getLink();
		if ("key".equals(name))
			return getKey();
		return null;
	}
	
	public void setAttribute(java.lang.String name, java.lang.Object value) {
		if ("createdBy".equals(name)) {
	
			setCreatedBy( convertToJPAValue(value,java.lang.String.class,"createdBy") );
		} else if ("createdAt".equals(name)) {
	
			setCreatedAt( convertToJPAValue(value,java.sql.Timestamp.class,"createdAt") );
		} else if ("modifiedAt".equals(name)) {
	
			setModifiedAt( convertToJPAValue(value,java.sql.Timestamp.class,"modifiedAt") );
		} else if ("modifiedBy".equals(name)) {
	
			setModifiedBy( convertToJPAValue(value,java.lang.String.class,"modifiedBy") );
		} else if ("contentType".equals(name)) {
	
			setContentType( convertToJPAValue(value,java.lang.String.class,"contentType") );
		} else if ("parentFolder".equals(name)) {
	
			setParentFolder( convertToJPAValue(value,java.lang.String.class,"parentFolder") );
		} else if ("contentLength".equals(name)) {
	
			setContentLength( convertToJPAValue(value,java.lang.Long.class,"contentLength") );
		} else if ("documentId".equals(name)) {
	
			setDocumentId( convertToJPAValue(value,java.lang.String.class,"documentId") );
		} else if ("title".equals(name)) {
	
			setTitle( convertToJPAValue(value,java.lang.String.class,"title") );
		} else if ("description".equals(name)) {
	
			setDescription( convertToJPAValue(value,java.lang.String.class,"description") );
		} else if ("link".equals(name)) {
	
			setLink( convertToJPAValue(value,java.lang.String.class,"link") );
		} else if ("key".equals(name)) {
	
			setKey( convertToJPAValue(value,java.lang.String.class,"key") );
		}
	}
	
	public Object getAttribute(Object structure, String name) {
		com.sap.caf.core.services.types.Document struct = (com.sap.caf.core.services.types.Document) structure;
		
		if ("createdBy".equals(name))
			return struct.getCreatedBy();
		
		if ("createdAt".equals(name))
			return struct.getCreatedAt();
		
		if ("modifiedAt".equals(name))
			return struct.getModifiedAt();
		
		if ("modifiedBy".equals(name))
			return struct.getModifiedBy();
		
		if ("contentType".equals(name))
			return struct.getContentType();
		
		if ("parentFolder".equals(name))
			return struct.getParentFolder();
		
		if ("contentLength".equals(name))
			return struct.getContentLength();
		
		if ("documentId".equals(name))
			return struct.getDocumentId();
		
		if ("title".equals(name))
			return struct.getTitle();
		
		if ("description".equals(name))
			return struct.getDescription();
		
		if ("link".equals(name))
			return struct.getLink();
		
		if ("key".equals(name))
			return struct.getKey();
		

		return null;
	}
	
	public void setAttribute(Object structure, String name, Object value) {
		com.sap.caf.core.services.types.Document struct = (com.sap.caf.core.services.types.Document) structure;
		if ("createdBy".equals(name)) {
	
	
			struct.setCreatedBy(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("createdAt".equals(name)) {
	
	
			struct.setCreatedAt(convertFromJPAValue(value, javax.xml.datatype.XMLGregorianCalendar.class) );
	
		} else if ("modifiedAt".equals(name)) {
	
	
			struct.setModifiedAt(convertFromJPAValue(value, javax.xml.datatype.XMLGregorianCalendar.class) );
	
		} else if ("modifiedBy".equals(name)) {
	
	
			struct.setModifiedBy(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("contentType".equals(name)) {
	
	
			struct.setContentType(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("parentFolder".equals(name)) {
	
	
			struct.setParentFolder(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("contentLength".equals(name)) {
	
	
			struct.setContentLength(convertFromJPAValue(value, java.lang.Long.class) );
	
		} else if ("documentId".equals(name)) {
	
	
			struct.setDocumentId(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("title".equals(name)) {
	
	
			struct.setTitle(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("description".equals(name)) {
	
	
			struct.setDescription(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("link".equals(name)) {
	
	
			struct.setLink(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("key".equals(name)) {
	
	
			struct.setKey(convertFromJPAValue(value, java.lang.String.class) );
	
		}
	}

	@javax.persistence.Transient
	@java.lang.SuppressWarnings("unchecked")
	public java.util.Map getLanguageDependentAttributes() {	
		return java.util.Collections.EMPTY_MAP;
	}
}