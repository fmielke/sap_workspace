package com.sap.caf.core.services.bonode.document.document;

public interface DocumentServiceLocal extends com.sap.caf.core.services.bonode.document.document.DocumentService, com.sap.caf.rt.bol.IBusinessObjectNodeServiceBase{
}