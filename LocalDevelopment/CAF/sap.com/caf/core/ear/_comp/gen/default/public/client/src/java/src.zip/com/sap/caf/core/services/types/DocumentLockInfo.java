
package com.sap.caf.core.services.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DocumentLockInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentLockInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="lockOwner" type="{http://www.sap.com/caf/sap.com/caf.core/services}LongText" minOccurs="0"/>
 *         &lt;element name="allowUnlock" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentLockInfo", propOrder = {
    "lockOwner",
    "allowUnlock"
})
public class DocumentLockInfo implements com.sap.caf.rt.bol.IDependentObject, java.io.Serializable {

    protected String lockOwner;
    protected Boolean allowUnlock;

    /**
     * Gets the value of the lockOwner property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLockOwner() {
        return lockOwner;
    }

    /**
     * Sets the value of the lockOwner property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLockOwner(String value) {
        this.lockOwner = value;
    }

    /**
     * Gets the value of the allowUnlock property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAllowUnlock() {
        return allowUnlock;
    }
    
    public Boolean getAllowUnlock() {
        return allowUnlock;
    }    

    /**
     * Sets the value of the allowUnlock property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAllowUnlock(Boolean value) {
        this.allowUnlock = value;
    }

	private static final transient java.lang.String[] _CAF_PROPERTY_NAMES = new java.lang.String[] {
			"lockOwner", "allowUnlock" };

	/**
	 * Returns structure properties' names
	 * @return  properties names
	 */
	@javax.xml.bind.annotation.XmlTransient
	public java.lang.String[] getPropertyList() {
		return _CAF_PROPERTY_NAMES;
	}

	@java.lang.SuppressWarnings("unchecked")
	public java.lang.Object getProperty(java.lang.String _propertyName) {
		if (_propertyName.equals("lockOwner"))
			return getLockOwner();
		if (_propertyName.equals("allowUnlock"))
			return isAllowUnlock();
		return null;
	}

	@java.lang.SuppressWarnings("unchecked")
	public void setProperty(java.lang.String _propertyName,
			java.lang.Object _value) {
		if (_propertyName.equals("lockOwner"))
			setLockOwner((java.lang.String) _value);
		else if (_propertyName.equals("allowUnlock"))
			setAllowUnlock((java.lang.Boolean) _value);
	}

}
