package com.sap.caf.core.services.bi;

/**
 * Class representing a BI Composite expression
 * @author Trendafil Madarov 
 */
public class BICompositeExpression implements IBIExpression {

	private static final long serialVersionUID = 4044889703676686694L;
	
    private BILogicalOperator operator;
    private IBIExpression leftExpression;
    private IBIExpression rightExpression;	
	
    /**
     * Returns the value of the logical operator.     
     * @return a BILogicalOperator object representing the operator value
     * @see #setOperator  
     */
    public BILogicalOperator getOperator() {
        return operator;
    }

    /**
     * Sets the value of the logical operator.
     * @param value  a BILogicalOperator object specifying the operator value
     * @see #getOperator  
     */
    public void setOperator(BILogicalOperator value) {
        this.operator = value;
    }

    /**
     * Returns the value of the left expression.
     * @return an IBIExpression object representing the left expression value
     * @see #setLeftExpression       
     */
    public IBIExpression getLeftExpression() {
        return leftExpression;
    }

    /**
     * Sets the value of the left expression.
     * @param value  an IBIExpression object specifying the left expression value
     * @see #getLeftExpression       
     */
    public void setLeftExpression(IBIExpression value) {
        this.leftExpression = value;
    }

    /**
     * Returns the value of the right expression.
     * @return an IBIExpression object representing the right expression value
     * @see #setRightExpression       
     */
    public IBIExpression getRightExpression() {
        return rightExpression;
    }

    /**
     * Sets the value of the right expression.
     * @param value  an IBIExpression object specifying the right expression value
     * @see #getRightExpression       
     */
    public void setRightExpression(IBIExpression value) {
        this.rightExpression = value;
    }	
}