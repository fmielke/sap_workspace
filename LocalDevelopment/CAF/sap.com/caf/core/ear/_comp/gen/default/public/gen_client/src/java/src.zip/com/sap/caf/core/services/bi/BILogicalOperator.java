package com.sap.caf.core.services.bi;

/**
 * This enumeration represents possible logical operators that can be used in
 * a BI composite expression.
 * @author Trendafil Madarov 
 */
public enum BILogicalOperator {

	/**
	 * Constant representing the logical operator 'AND'
	 */	
	AND,
	
	/**
	 * Constant representing the logical operator 'OR'
	 */	
	OR		
}