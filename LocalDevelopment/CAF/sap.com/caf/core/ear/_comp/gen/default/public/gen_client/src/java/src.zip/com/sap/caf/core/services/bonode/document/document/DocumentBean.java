package com.sap.caf.core.services.bonode.document.document;
 
public abstract class DocumentBean extends com.sap.caf.rt.bol.BusinessObjectNodeServiceBase implements DocumentServiceLocal { //$JL-SER$ - static final long serialVersionUID is not declared

	public static final java.lang.String _objectGuid = "DCAA9FB1-4AE5-428A-2637-91C2BB12";
	public static final java.lang.String _PROVIDER = "sap.com";
	public static final java.lang.String _APPLICATION = "caf.core";
	public static final java.lang.String _BO_SRV_NAME = "Document";
	public static final java.lang.String _NAMESPACE = "http://www.sap.com/caf/sap.com/caf.core";
	public static final java.lang.String _FULLY_QUALIFIED_NAME = "caf.core.services.Document";	
	public static final java.lang.String _OBJECT_NAME = "sap.com/http://www.sap.com/caf/sap.com/caf.core:caf.core/Document";
	public static final java.lang.String _OBJECT_TYPE = "sap.com/http://www.sap.com/caf/sap.com/caf.core:caf.core/caf.core.services.Document";
	protected static final java.lang.String _JARM_REQUEST = "XAP:BO:" + _OBJECT_NAME;
	
    protected static final com.sap.tc.logging.Location _location = com.sap.tc.logging.Location.getLocation(com.sap.caf.core.services.bonode.document.document.DocumentBean.class);    

	protected com.sap.caf.rt.bol.da.IDataAccessService _dataAccessService;
	
	@javax.persistence.PersistenceContext(unitName="sap.com.caf.core")
	protected javax.persistence.EntityManager _entityManager;

	@javax.ejb.EJB (beanName="com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObject")
	private com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObjectService _RelatedObjectRefs_business_interface;

	public DocumentBean(){
	}
    
	@javax.annotation.PostConstruct
    protected void _init() {
    	_objectName = _OBJECT_NAME;
        try {
			java.util.Map<String, Object> _properties = new java.util.HashMap<String, Object>();
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.ENTITY_MANAGER_PROPERTY, _entityManager);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.SESSION_CONTEXT_PROPERTY, sessionContext);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_PERSISTENT_CLASS_PROPERTY, com.sap.caf.core.services.bonode.document.document.DocumentBO.class);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_PROVIDER_PROPERTY, _PROVIDER);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_APPLICATION_PROPERTY, _APPLICATION);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_SERVICE_NAME_PROPERTY, _BO_SRV_NAME);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_NAMESPACE_PROPERTY, _NAMESPACE);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_FULLY_QUALIFIED_NAME, _FULLY_QUALIFIED_NAME);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_OBJECT_NAME_PROPERTY, _OBJECT_NAME);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_OBJECT_TYPE_PROPERTY, _OBJECT_TYPE);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_GUID_PROPERTY, _objectGuid);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_MAIN_STRUCT_CLASS_PROPERTY, com.sap.caf.core.services.types.Document.class);

			_dataAccessService = com.sap.caf.rt.bol.da.DataAccessFactory.getDataAccessService(com.sap.caf.rt.bol.da.DataAccessFactory.DATASOURCE_KM, _properties);
        } catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
            _location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in PostConstruct", _e);
            throw new javax.ejb.EJBException(_e);
        }
    }
    
    @javax.annotation.PreDestroy
    protected void _destroy() {
		_dataAccessService.destroy();
    }
    
	public com.sap.caf.core.services.types.Document create(java.lang.String documentId,java.lang.String parentFolder) throws com.sap.caf.rt.exception.CAFCreateException{
		java.lang.String method = _JARM_REQUEST + ":create(java.lang.String,java.lang.String,)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();
		com.sap.caf.core.services.types.Document _boNodeStructure = null;
        
		try {
			com.sap.caf.core.services.types.ObjectFactory _objectFactory = new com.sap.caf.core.services.types.ObjectFactory();
	        _boNodeStructure = _objectFactory.createDocument();
	        _boNodeStructure.setObjectType(_OBJECT_TYPE);

			_boNodeStructure.setProperty("documentId", documentId);
			_boNodeStructure.setProperty("parentFolder", parentFolder);

	        if (!checkPermission(com.sap.caf.rt.security.util.CAFPermissionName.create, _boNodeStructure, user, _OBJECT_TYPE)) {
	            java.lang.Object[] permissionExceptionArgs = {user, com.sap.caf.rt.security.util.CAFPermissionName.create, null, _PROVIDER + "/" + _FULLY_QUALIFIED_NAME};
	            throw new com.sap.caf.rt.exception.CAFCreateException(_location, "BO_PERMISSION", permissionExceptionArgs);
	        }

			_dataAccessService.create(_boNodeStructure);
			return _boNodeStructure;
		}
		catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
			sessionContext.setRollbackOnly();
	        _location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);
            throw new com.sap.caf.rt.exception.CAFCreateException(_location, _e);
        }

	}

	public com.sap.caf.core.services.types.Document read(java.lang.String key) throws com.sap.caf.rt.exception.CAFRetrieveException{
		if (key == null) {
			throw new com.sap.caf.rt.exception.CAFRetrieveException(_location, "BO_CRUD_NULL_ARGUMENT", new String[]{"key"});
		}
		java.lang.String method = _JARM_REQUEST + ":read(java.lang.String,)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();
		try {
		    com.sap.caf.core.services.types.Document _boNodeStructure;
	      	_boNodeStructure = (com.sap.caf.core.services.types.Document) _dataAccessService.load(key);
	      	if (_boNodeStructure == null) {
	      		throw new com.sap.caf.rt.exception.CAFRetrieveException(_location, "BO_NOT_EXIST",  new Object[] {key});
	      	}
	      	_boNodeStructure.setObjectType(_OBJECT_TYPE);

		 	if (!checkPermission(com.sap.caf.rt.security.util.CAFPermissionName.read, _boNodeStructure, user, _OBJECT_TYPE)) {
				java.lang.Object[] permissionExceptionArgs = { user, com.sap.caf.rt.security.util.CAFPermissionName.read, null, _PROVIDER + "/" + _FULLY_QUALIFIED_NAME };
				throw new com.sap.caf.rt.exception.CAFRetrieveException(_location, "BO_PERMISSION", permissionExceptionArgs);
			}
		
			return _boNodeStructure;
		}
		catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
	        _location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);		
            throw new com.sap.caf.rt.exception.CAFRetrieveException(_location, _e);
        }
        
	}

	public void update(com.sap.caf.core.services.types.Document input) throws com.sap.caf.rt.exception.CAFUpdateException,com.sap.caf.rt.exception.CAFOptimisticLockException,com.sap.caf.rt.exception.CAFPessimisticLockException{
		if (input == null) {
			throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_CRUD_NULL_ARGUMENT", new String[]{"input"});
		}
		java.lang.String method = _JARM_REQUEST + ":update(com.sap.caf.core.services.types.Document)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();
		
		if (!checkPermission(com.sap.caf.rt.security.util.CAFPermissionName.update, input, user, _OBJECT_TYPE)) {
			java.lang.Object[] permissionExceptionArgs = {user, com.sap.caf.rt.security.util.CAFPermissionName.update, null, _PROVIDER + "/" + _FULLY_QUALIFIED_NAME};
			throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_PERMISSION", permissionExceptionArgs);
		}
 


		lock(input.getKey(), com.sap.caf.rt.bol.IBusinessObjectNodeServiceBase.MODE_WRITE);

		try {
			com.sap.caf.core.services.types.Document currentlyInStore = read(input.getKey());
			
			if (!almostEqual(currentlyInStore.getModifiedAt(), input.getModifiedAt())) {
				throw new com.sap.caf.rt.exception.CAFOptimisticLockException(_location, "EXCEPTION_OPTIMISTIC_LOCK_FAILED", new Object[]{_OBJECT_TYPE, input.getKey(), currentlyInStore.getModifiedAt(), input.getModifiedAt()});
			}
			input.setObjectType(_OBJECT_TYPE);
			_dataAccessService.store(input);
		} catch (com.sap.caf.rt.exception.CAFRetrieveException _e) {
		    throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_UPDATE", _e);
		} catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
			sessionContext.setRollbackOnly();
			_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);
			throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_UPDATE", _e);
		} finally {
			unlock(input.getKey(), com.sap.caf.rt.bol.IBusinessObjectNodeServiceBase.MODE_WRITE);
		}
	}

	public void delete(com.sap.caf.core.services.types.Document input) throws com.sap.caf.rt.exception.CAFDeleteException,com.sap.caf.rt.exception.CAFOptimisticLockException,com.sap.caf.rt.exception.CAFPessimisticLockException{
		if (input == null) {
			throw new com.sap.caf.rt.exception.CAFDeleteException(_location, "BO_CRUD_NULL_ARGUMENT", new String[]{"input"});
		}
		java.lang.String method = _JARM_REQUEST + ":delete(void)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();

        if (!checkPermission(com.sap.caf.rt.security.util.CAFPermissionName.delete, input, user, _OBJECT_TYPE)) {
            java.lang.Object[] permissionExceptionArgs = {user, com.sap.caf.rt.security.util.CAFPermissionName.delete, null, _PROVIDER + "/" + _FULLY_QUALIFIED_NAME};
            throw new com.sap.caf.rt.exception.CAFDeleteException(_location, "BO_PERMISSION", permissionExceptionArgs);
        }

		lock(input.getKey(), com.sap.caf.rt.bol.IBusinessObjectNodeServiceBase.MODE_WRITE);

		try {		
			input.setObjectType(_OBJECT_TYPE);
			java.lang.String[] _RelatedObjectRefs_keys = getRelatedObjectRefs(input.getKey());
			if (_RelatedObjectRefs_keys != null) {
				com.sap.caf.core.services.types.RelatedObject __assoc_structure_instance = new com.sap.caf.core.services.types.RelatedObject();
				for (java.lang.String _RelatedObjectRefs_key : _RelatedObjectRefs_keys) {
					__assoc_structure_instance.setKey(_RelatedObjectRefs_key);
					_RelatedObjectRefs_business_interface.delete(__assoc_structure_instance);
				}
			}
			 _dataAccessService.remove(input);
			com.sap.caf.rt.security.acl.CAFPermission.removeInheritedPermissionByInheriting(input.getKey());				 
        } catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
	        sessionContext.setRollbackOnly();
        	_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);
            throw new com.sap.caf.rt.exception.CAFDeleteException(_location, "BO_DELETE", _e);
        } catch (com.sap.caf.rt.exception.CAFPermissionException _e) {
	        sessionContext.setRollbackOnly();
            throw new com.sap.caf.rt.exception.CAFDeleteException(_location, "BO_DELETE", _e);
		} catch (com.sap.caf.rt.exception.CAFRetrieveException _e) {
	        sessionContext.setRollbackOnly();
            throw new com.sap.caf.rt.exception.CAFDeleteException(_location, "BO_DELETE", _e);
		} finally {
			unlock(input.getKey(), com.sap.caf.rt.bol.IBusinessObjectNodeServiceBase.MODE_WRITE);
		}
	}


	@java.lang.SuppressWarnings("unchecked")
	public java.util.List<com.sap.caf.core.services.types.Document> findAll() throws com.sap.caf.rt.exception.CAFFindException{
		java.lang.String method = _JARM_REQUEST + ":findAll(void)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();
		
        try {
            java.util.List<com.sap.caf.core.services.types.Document> _retval = (java.util.List<com.sap.caf.core.services.types.Document>) _dataAccessService.query(new com.sap.caf.rt.bol.util.QueryFilter[0], "findAll" );
			for (java.util.Iterator<com.sap.caf.core.services.types.Document> _iterator = _retval.iterator(); _iterator.hasNext();) {
				com.sap.caf.core.services.types.Document _item = _iterator.next();
				if (!checkPermission(com.sap.caf.rt.security.util.CAFPermissionName.read, _item, user, _OBJECT_TYPE))
					_iterator.remove();
			}
			for (com.sap.caf.core.services.types.Document _item : _retval) {
				_item.setObjectType(_OBJECT_TYPE);
			}
			return _retval;
        } catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
        	_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);
            throw new com.sap.caf.rt.exception.CAFFindException(_location, "BO_FIND", _e);
        }
	}


	public void addAuthUser(java.lang.String permission,java.lang.String primaryKey,java.lang.String userId) throws com.sap.caf.rt.exception.CAFBONodeException{
	}

	public void removeAuthUser(java.lang.String permission,java.lang.String primaryKey,java.lang.String userId) throws com.sap.caf.rt.exception.CAFBONodeException{
	}

	public com.sap.caf.core.services.types.Document getAuthUser(java.lang.String permission,java.lang.String primaryKey) throws com.sap.caf.rt.exception.CAFBONodeException{
		return null;
	}

	public java.lang.String addRelatedObjectRid(java.lang.String boRid,java.lang.String documentKey,java.lang.String boGuid,java.lang.String boName) throws com.sap.caf.rt.exception.CAFUpdateException{
		return null;
	}

	public void removeRelatedObjectRid(java.lang.String boRid,java.lang.String documentKey,java.lang.String boName) throws com.sap.caf.rt.exception.CAFUpdateException{
	}

	public java.lang.String relateDocument(java.lang.String srcRid,java.lang.String dstBOGuid,java.lang.String dstBOName) throws com.sap.caf.rt.exception.CAFUpdateException{
		return null;
	}

	public java.util.List<com.sap.caf.core.services.types.Document> findByTitle(java.lang.String parentFolder,java.lang.String title) throws com.sap.caf.rt.exception.CAFFindException{
		return null;
	}

	public java.util.List<com.sap.caf.core.services.types.Document> findByDocumentId(java.lang.String parentFolder,java.lang.String documentId) throws com.sap.caf.rt.exception.CAFFindException{
		return null;
	}

	public java.util.List<com.sap.caf.core.services.types.Document> findByRid(java.lang.String rid) throws com.sap.caf.rt.exception.CAFFindException{
		return null;
	}




	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	public java.lang.String[] getRelatedObjectRefs(java.lang.String sourceKey) throws com.sap.caf.rt.exception.CAFRetrieveException{
		try {
			return _dataAccessService.getCardinalityManyAssociationTargetKeys(sourceKey, "relatedObjectRefs");
		} catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
			_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}:getRelatedObjectRefs(java.lang.String)! Error message is: {1}",new Object[] {_JARM_REQUEST, _e.getMessage()}, _e);
			throw new com.sap.caf.rt.exception.CAFRetrieveException(_location, "BO_READ", _e);
	    }
	}
	
	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	public void setRelatedObjectRefs(java.lang.String sourceKey, java.lang.String[] targetKeys) throws com.sap.caf.rt.exception.CAFUpdateException {
		final boolean isComposition = true;
		
		try {
			java.lang.String user = sessionContext.getCallerPrincipal().getName();
			com.sap.caf.core.services.types.Document _boNodeStructure = read(sourceKey);
			if (!checkPermission(com.sap.caf.rt.security.util.CAFPermissionName.update, _boNodeStructure, user, _OBJECT_TYPE)) {
				java.lang.Object[] permissionExceptionArgs = {user, com.sap.caf.rt.security.util.CAFPermissionName.update, null, _PROVIDER + "/" + _FULLY_QUALIFIED_NAME};
				throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_PERMISSION", permissionExceptionArgs);
			}

			String[] currentlyAssociated = getRelatedObjectRefs(sourceKey);
			java.util.Set<String> relatedNew = new java.util.HashSet<String>();
			if (targetKeys != null && targetKeys.length != 0) {
				relatedNew.addAll((java.util.Arrays.asList(targetKeys)));
			}
			java.util.Set<String> relatedOld = null;
			
			if (currentlyAssociated != null && currentlyAssociated.length > 0) {
				relatedOld = new java.util.HashSet<String>(java.util.Arrays.asList(currentlyAssociated));
				for (int i = 0; i < currentlyAssociated.length; i++) {
					if (relatedNew.remove(currentlyAssociated[i])) {
						relatedOld.remove(currentlyAssociated[i]);
					}
				}
			}
			// remove related objects
			if (relatedOld != null && !relatedOld.isEmpty()) {
				_dataAccessService.removeCardinalityManyAssociationTargetKeys(
						sourceKey, (String[]) 
						relatedOld.toArray(new String[relatedOld.size()]), "relatedObjectRefs", isComposition);
			}
			// add related objects
			if (relatedNew.size() > 0) {
				_dataAccessService.addCardinalityManyAssociationTargetKeys(
					    sourceKey, (String[]) 
						relatedNew.toArray(new String[relatedNew.size()]), "relatedObjectRefs");				
						
			}
		} catch (com.sap.caf.rt.exception.CAFRetrieveException _e) {
			throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_UPDATE", _e);
		} catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
			sessionContext.setRollbackOnly();
			_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}:setRelatedObjectRefs(java.lang.String, java.lang.String[])! Error message is: {1}", new Object[] {_JARM_REQUEST, _e.getMessage()}, _e);
			throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_UPDATE", _e);
		}
	}
	
	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)	
	public void addRelatedObjectRefs(java.lang.String sourceKey, java.lang.String targetKey) throws com.sap.caf.rt.exception.CAFUpdateException{
		try {
			java.lang.String user = sessionContext.getCallerPrincipal().getName();
			com.sap.caf.core.services.types.Document _boNodeStructure = read(sourceKey);
			if (!checkPermission(com.sap.caf.rt.security.util.CAFPermissionName.update, _boNodeStructure, user, _OBJECT_TYPE)) {
				java.lang.Object[] permissionExceptionArgs = {user, com.sap.caf.rt.security.util.CAFPermissionName.update, null, _PROVIDER + "/" + _FULLY_QUALIFIED_NAME};
				throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_PERMISSION", permissionExceptionArgs);
			}

			_dataAccessService.addCardinalityManyAssociationTargetKeys( sourceKey, new String[] {targetKey}, "relatedObjectRefs");
		} catch (com.sap.caf.rt.exception.CAFRetrieveException _e) {
			throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_UPDATE", _e);
		} catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
			sessionContext.setRollbackOnly();
			_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}:addRelatedObjectRefs(java.lang.String, java.lang.String)! Error message is: {1}", new Object[] {_JARM_REQUEST, _e.getMessage()}, _e);
			throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_UPDATE", _e);
		}
	}
	
	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)	
	public void removeRelatedObjectRefs(java.lang.String sourceKey, java.lang.String targetKey) throws com.sap.caf.rt.exception.CAFUpdateException{
		try {
			java.lang.String user = sessionContext.getCallerPrincipal().getName();
			com.sap.caf.core.services.types.Document _boNodeStructure = read(sourceKey);
			if (!checkPermission(com.sap.caf.rt.security.util.CAFPermissionName.update, _boNodeStructure, user, _OBJECT_TYPE)) {
				java.lang.Object[] permissionExceptionArgs = {user, com.sap.caf.rt.security.util.CAFPermissionName.update, null, _PROVIDER + "/" + _FULLY_QUALIFIED_NAME};
				throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_PERMISSION", permissionExceptionArgs);
			}

			_dataAccessService.removeCardinalityManyAssociationTargetKeys( sourceKey, new String[] {targetKey}, "relatedObjectRefs", true);
		} catch (com.sap.caf.rt.exception.CAFRetrieveException _e) {
			_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in " + _JARM_REQUEST + ":removeRelatedObjectRefs(java.lang.String, java.lang.String)! Error message is: " + _e.getMessage(), _e);
			throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_UPDATE", _e);
		} catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
			sessionContext.setRollbackOnly();
			_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}:removeRelatedObjectRefs(java.lang.String, java.lang.String)! Error message is: {1}", new Object[] {_JARM_REQUEST, _e.getMessage()}, _e);
			throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_UPDATE", _e);
		}
	}
	



	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	@java.lang.SuppressWarnings("unchecked")
	public java.util.List<com.sap.caf.core.services.types.Document> findByMultipleParameters(java.util.List<com.sap.caf.rt.bol.util.QueryFilter> queryFilters, java.lang.Boolean implCheck, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException {
		java.lang.String method = _JARM_REQUEST + ":findByMultipleParameters(java.util.List<com.sap.caf.rt.bol.util.QueryFilter>, boolean, String)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();

		com.sap.caf.rt.bol.util.QueryFilter[] queryFiltersArray = null;
		if (queryFilters != null) {
			queryFiltersArray = new com.sap.caf.rt.bol.util.QueryFilter[queryFilters.size()];
			queryFilters.toArray(queryFiltersArray);
		}

		try {
    	    java.util.List<com.sap.caf.core.services.types.Document> _retval = (java.util.List<com.sap.caf.core.services.types.Document>) _dataAccessService.query(queryFiltersArray, findByName );
			for (java.util.Iterator<com.sap.caf.core.services.types.Document> _iterator = _retval.iterator(); _iterator.hasNext();) {
				com.sap.caf.core.services.types.Document _item = _iterator.next();
				if (!checkPermission(com.sap.caf.rt.security.util.CAFPermissionName.read, _item, user, _OBJECT_TYPE))
					_iterator.remove();
			}
			for (com.sap.caf.core.services.types.Document _item : _retval) {
				_item.setObjectType(_OBJECT_TYPE);
			}
        	return  _retval;
        } catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
        	_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);
            throw new com.sap.caf.rt.exception.CAFFindException(_location, "BO_FIND", _e);
        }
	} 
	
	
	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	@java.lang.SuppressWarnings("unchecked")
	public java.util.List<com.sap.caf.core.services.types.Document> findByMultipleParameters(java.util.List<com.sap.caf.rt.bol.util.QueryFilter> queryFilters, com.sap.caf.rt.bol.util.OrderBy orderBy, com.sap.caf.rt.bol.util.Paging paging, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException {
		java.lang.String method = _JARM_REQUEST + ":findByMultipleParameters(java.util.List<com.sap.caf.rt.bol.util.QueryFilter>, boolean, String)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();

		com.sap.caf.rt.bol.util.QueryFilter[] queryFiltersArray = null;
		if (queryFilters != null) {
			queryFiltersArray = new com.sap.caf.rt.bol.util.QueryFilter[queryFilters.size()];
			queryFilters.toArray(queryFiltersArray);
		}

		try {
    	    java.util.List<com.sap.caf.core.services.types.Document> _retval = (java.util.List<com.sap.caf.core.services.types.Document>) _dataAccessService.query(queryFiltersArray, orderBy, paging, findByName );
			for (java.util.Iterator<com.sap.caf.core.services.types.Document> _iterator = _retval.iterator(); _iterator.hasNext();) {
				com.sap.caf.core.services.types.Document _item = _iterator.next();
				if (!checkPermission(com.sap.caf.rt.security.util.CAFPermissionName.read, _item, user, _OBJECT_TYPE))
					_iterator.remove();
			}   	    
			for (com.sap.caf.core.services.types.Document _item : _retval) {
				_item.setObjectType(_OBJECT_TYPE);
			}
        	return  _retval;
        } catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
			_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);
            throw new com.sap.caf.rt.exception.CAFFindException(_location, "BO_FIND", _e);
        }
	} 
	
	public java.util.List<com.sap.caf.core.services.types.Document> findByMultipleParameters(com.sap.caf.rt.bol.util.QueryFilter[] queryFilters, com.sap.caf.rt.bol.util.OrderBy orderBy, com.sap.caf.rt.bol.util.Paging paging, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException {
		java.util.List<com.sap.caf.rt.bol.util.QueryFilter> _queryFiltersList = null;
		if (queryFilters != null) {
			_queryFiltersList = java.util.Arrays.asList(queryFilters);
		}
		return findByMultipleParameters(_queryFiltersList, orderBy, paging, findByName);
	}
	
	public java.util.List<com.sap.caf.core.services.types.Document> findByMultipleParameters(com.sap.caf.rt.bol.util.QueryFilter[] queryFilters, java.lang.Boolean implCheck, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException {
		java.util.List<com.sap.caf.rt.bol.util.QueryFilter> _queryFiltersList = null;
		if (queryFilters != null) {
			_queryFiltersList = java.util.Arrays.asList(queryFilters);
		}
		return findByMultipleParameters(_queryFiltersList, implCheck, findByName);
	}


	protected boolean checkPermission(java.lang.String permission, com.sap.caf.rt.bol.IBusinessObjectNodeBase object, java.lang.String user, java.lang.String objectName) {
		boolean allowAccess = true;
		try {
			if (!com.sap.caf.rt.security.acl.CAFPermission.checkAclPermission(object, user, permission, objectName)) {
				allowAccess = false;
				com.sap.tc.logging.SimpleLogger.log(com.sap.tc.logging.Severity.INFO, com.sap.tc.logging.Category.APPS_COMMON_SECURITY, _location, "CAF.core.000001", "User {0} has no {1} permission for objectId {2}", user, permission, objectName);
			}
		} catch (com.sap.caf.rt.exception.CAFPermissionException e) {
			allowAccess = false;
			_location.traceThrowableT(com.sap.tc.logging.Severity.WARNING, "Permissions check for user {0} for objectId {1} failed! Will continue with no permissions!", new Object[] {user, objectName}, e);			
		}
		return allowAccess;
	}
}