
package com.sap.caf.core.services.bonode.document.document;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.sap.caf.rt.bol.util.QueryFilter;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="permission" type="{http://www.sap.com/caf/query_filter}QueryFilter" minOccurs="0"/>
 *         &lt;element name="primaryKey" type="{http://www.sap.com/caf/query_filter}QueryFilter" minOccurs="0"/>
 *         &lt;element name="userId" type="{http://www.sap.com/caf/query_filter}QueryFilter" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "permission",
    "primaryKey",
    "userId"
})
@XmlRootElement(name = "removeAuthUser")
public class RemoveAuthUser implements java.io.Serializable {

    protected QueryFilter permission;
    protected QueryFilter primaryKey;
    protected QueryFilter userId;

    /**
     * Gets the value of the permission property.
     * 
     * @return
     *     possible object is
     *     {@link QueryFilter }
     *     
     */
    public QueryFilter getPermission() {
        return permission;
    }

    /**
     * Sets the value of the permission property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryFilter }
     *     
     */
    public void setPermission(QueryFilter value) {
        this.permission = value;
    }

    /**
     * Gets the value of the primaryKey property.
     * 
     * @return
     *     possible object is
     *     {@link QueryFilter }
     *     
     */
    public QueryFilter getPrimaryKey() {
        return primaryKey;
    }

    /**
     * Sets the value of the primaryKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryFilter }
     *     
     */
    public void setPrimaryKey(QueryFilter value) {
        this.primaryKey = value;
    }

    /**
     * Gets the value of the userId property.
     * 
     * @return
     *     possible object is
     *     {@link QueryFilter }
     *     
     */
    public QueryFilter getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryFilter }
     *     
     */
    public void setUserId(QueryFilter value) {
        this.userId = value;
    }

}
