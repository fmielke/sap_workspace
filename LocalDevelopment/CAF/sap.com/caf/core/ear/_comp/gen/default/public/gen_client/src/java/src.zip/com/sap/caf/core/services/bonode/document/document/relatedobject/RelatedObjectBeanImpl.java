package com.sap.caf.core.services.bonode.document.document.relatedobject;


@javax.ejb.Stateless(name = "com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObject")
@javax.ejb.Local({ com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObjectServiceLocal.class })
@javax.interceptor.Interceptors({ com.sap.caf.rt.interceptors.LogInterceptor.class })
public class RelatedObjectBeanImpl extends RelatedObjectBean {
}