@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.sap.com/caf/sap.com/caf.core/services")
package com.sap.caf.core.services.types;
