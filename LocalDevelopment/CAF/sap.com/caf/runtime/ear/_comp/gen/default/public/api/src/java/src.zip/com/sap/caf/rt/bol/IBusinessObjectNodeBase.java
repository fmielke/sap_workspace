package com.sap.caf.rt.bol;

import javax.xml.datatype.XMLGregorianCalendar;

/**
 * This is the base interface for all BO Node structures.
 */
public interface IBusinessObjectNodeBase extends IDependentObject {
	
	/** 
	 * Returns the key of the BO Node instance.
	 * @return key
     */
	public String getKey();
	
	/**
	 * Returns the name of the user who has created the BO Node instance.
	 * @return the name of the user 
	 */
	public String getCreatedBy();
	
	/** 
	 * Return the time when the BO Node instance has been created. 
	 * @return creation time 
	 */
	public XMLGregorianCalendar getCreatedAt();
	
	/**
	 * Returns the name of the user who has last modified the BO Node instance. 
	 * @return the name of the user 
	 */
	public String getModifiedBy();
	
	/**
	 * Return the time when the BO Node instance has been last modified. 
	 * @return modification time 
	 */
	public XMLGregorianCalendar getModifiedAt();

	/**
	 * Returns a human readable string which identifies uniquely the 
	 * BO Node to which this instance belongs.
	 * @return a string in the form of: <br>
	 * vendor/application_name/top_level_package_name/package_name2/.../class_name
	 */
	public String getObjectType();
}
