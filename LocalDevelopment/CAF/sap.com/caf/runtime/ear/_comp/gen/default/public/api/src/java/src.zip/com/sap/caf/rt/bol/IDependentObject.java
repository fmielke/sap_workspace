package com.sap.caf.rt.bol;

/**
 * This is the base interface for all structures.
 */
public interface IDependentObject {
	
	/**
	 * Provides the names of all the available properties (attributes) of the structure.
	 * @return the names of the available properties
	 */
	public String[] getPropertyList();
	
	/**
	 * Returns a property value.
	 * @param propertyName the name of the property
	 * @return the value of the property
	 * @see #setProperty(String, Object)
	 */
	public Object getProperty(String propertyName);
	
	/**
	 * Sets a property value. 
	 * @param propertyName the name of the property
	 * @param propertyValue the value of the property
	 * @see #getProperty(String)
	 */
	public void setProperty(String propertyName, Object propertyValue);
}
