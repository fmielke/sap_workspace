package com.sap.caf.rt.bol.util;

import java.util.Date;

/**
 * This class is a factory for creating instances of {@link QueryFilter}. 
 * @author I037087
 */
public class QueryFilterFactory {
	/**
	 * A separator for attributes that are from an associated BO Node.
	 */
	public static final String BO_NODE_REFERENCE_PATH_SEPARATOR = ".";
	
	/**
	 * A separator for attributes that are part of a complex structure.
	 */
	public static final String NESTED_STRUCTURE_PATH_SEPARATOR = "#";
	
	
	/**
	 * Creates an empty query filter.
	 * @return an empty query filter
	 */
	public static QueryFilter createQueryFilter() {
		return new QueryFilter();
	}
	
	/**
	 * Creates a {@link QueryFilter} for a given search value.
	 * The condition for the returned instance is <code>Condition.EQ</code>.
	 * This method is suitable for creating query filters for defined by the application developer "findByXXX" methods
	 * but not for the <code>findByMultipleParameters</code> method. For the latter you can use
	 * {@link #createFilter(String attributeSpec, Condition condition, Object value)} or
	 * {@link #createFilterForBetween(String attributeSpec, Object valueLow, Object valueHigh)}.
	 * This method is deprecated, use {@link #createFilter(Object)} instead. 
	 * @param value the following values have some special semantics:
	 * 
	 *  <ul>
	 *      <li><code>null</code> - the search clause will be "IS NULL" </li>
	 * 		<li><code>String</code> - the '*' char is treated as a wildcard chararacter.
	 * If an empty string is supplied then the return filter will be a fake filter (no constraints will be imposed by it).
	 * 		</li>
	 * 		
	 * </ul>
	 * 
	 *
	 * 	
	 * @return a {@link QueryFilter} instance to represent an equality constraint for the given <code>value</code>
	 * @see Condition
	 * 
	 */
	@Deprecated
	public static QueryFilter getQueryFilter(Object value) {
		return createFilter(value);
	}
	
	/**
	 * Creates a {@link QueryFilter} for searching in a range.
	 * @param valueLow the start of the search range
	 * @param valueHigh the end of the search range
	 * @return a {@link QueryFilter} instance for the given parameters
	 */
	public static QueryFilter createFilterForBetween(Object valueLow, Object valueHigh){
		QueryFilter result =  new QueryFilter();
		result.setValueLow(valueLow);
		result.setValueHigh(valueHigh);
		result.setCondition(Condition.BETWEEN);
		return result;
	}
	
	
	/**
	 * Creates a {@link QueryFilter} with a given condition.
	 * This method is deprecated because of inconsistent order of parameters with
	 * {@link #createFilter(String, Condition, Object)}, use {@link #createFilter(Condition, Object)} instead.
	 * @param value the search value
	 * @param condition a value from the {@link Condition} enumeration 
	 * @return a {@link QueryFilter} instance for the given parameters
	 */
	@Deprecated
	public static QueryFilter createFilter(Object value, Condition condition) {
		return createFilter(condition, value);
	}
	/**
	 * Creates a {@link QueryFilter} with a given condition.
	 * @param condition a value from the {@link Condition} enumeration 
	 * @param value the search value
	 * @return a {@link QueryFilter} instance for the given parameters
	 */
	public static QueryFilter createFilter(Condition condition, Object value){
		QueryFilter result =  createFilter(value);
		result.setCondition(condition);
		return result;
	}
	
	/**
	 * Creates a {@link QueryFilter} for a given search value.
	 * The condition for the returned instance is <code>Condition.EQ</code>.
	 * This method is suitable for creating query filters for defined by the application developer "findByXXX" methods
	 * but not for the <code>findByMultipleParameters</code> method. For the latter you can use
	 * {@link #createFilter(String attributeSpec, Condition condition, Object value)} or
	 * {@link #createFilterForBetween(String attributeSpec, Object valueLow, Object valueHigh)}.
	 *  
	 * @param value the following values have some special semantics:
	 * 
	 *  <ul>
	 *      <li><code>null</code> - the search clause will be "IS NULL" </li>
	 * 		<li><code>String</code>The '*' char is treated as a wildcard chararacter.
	 * If an empty string is supplied then the return filter will be a fake filter (no constraints will be imposed by it).
	 * 		</li>
	 * 		
	 * </ul>
	 * 
	 *
	 * 	
	 * @return a {@link QueryFilter} instance to represent an equality constraint for the given <code>value</code>
	 * @see Condition
	 */
	public static QueryFilter createFilter(Object value){
		QueryFilter qf = null;
		if (value == null || (value instanceof String) && ((String) value).trim().equals("")){
	    	qf = new QueryFilter((Object)null);
	    }
		else if (value instanceof QueryFilter) {
			qf = new QueryFilter((QueryFilter) value);
//		} 
//		else if ((value instanceof String) && ((String) value).trim().equals("")) {
//			qf = new QueryFilter((String) "*");
		} else {
			qf = new QueryFilter(value);
		}
		return qf;
		
	}
	
	/**
	 * Creates a {@link QueryFilter} for searching in a TREX system. It cannot be used for local persistency queries.
	 * @param condition the condition for this filter; see the constants QueryFilter.CONDITION_* for the possible values
	 * @param value the search value
	 * @param name the name of the attribute or category; complex attributes have to be named like "name_of_comlex_attribute.name_of_attribute"
	 * @param bAttribute true if <code>name</code> is an attribute, false if it is a category
	 * @return a {@link QueryFilter} instance for the given parameters
	 * 
	 */
	@Deprecated
	public static QueryFilter createNumericFilter(Condition condition, int value, String name, boolean bAttribute) {
		QueryFilter filter = new QueryFilter();
		
		filter.setCondition(condition);
		filter.setAttribute(name);
		filter.setValue(value);
		
		if(bAttribute)
			filter.setOperation(QueryFilter.OPERATION_ATTRIBUTE);
		else
			filter.setOperation(QueryFilter.OPERATION_CATEGORY);
		
		return filter;
	}

	/**
	 * Creates a {@link QueryFilter} for searching in a TREX system. It cannot be used for local persistency queries.
	 * There are several opportunities for the type of the search: an exact search, a wilcard search or a fuzzy search.
	 * @param action the type of the search that should be performed; see the constants QueryFilter.ACTION_* for the possible values
	 * @param value the search value; may contain wildcards (for all the possible values, please check the TREX documentation)
	 * @param name the name of the attribute or category; complex attributes have to be named like "name_of_comlex_attribute.name_of_attribute"
	 * @param bAttribute true if <code>name</code> is an attribute, false if it is a category
	 * @return a {@link QueryFilter} instance for the given parameters
	 */
	@Deprecated
	public static QueryFilter createStringFilter(String action, String value, String name, boolean bAttribute) {
		QueryFilter filter = new QueryFilter();
		
		filter.setAction(action);
		filter.setValueLow(value);
		filter.setAttribute(name);
	

		if(bAttribute)
			filter.setOperation(QueryFilter.OPERATION_ATTRIBUTE);
		else
			filter.setOperation(QueryFilter.OPERATION_CATEGORY);
		
		return filter;
	}

	/**
	 * Creates a {@link QueryFilter} for searching in a TREX system. It cannot be used for local persistency queries.
	 * The created query filter will be used to perform a freetext search over all of the attributes of a BO Node. 
	 * @param action the type of the search that should be performed; see the constants QueryFilter.ACTION_* for the possible values
	 * @param value the search value; may contain wildcards (for all the possible values, please check the TREX documentation)
	 * @return a {@link QueryFilter} instance for the given parameters
	 */
	@Deprecated
	public static QueryFilter createFreetextFilter(String action, String value) {
		QueryFilter filter = new QueryFilter();
		
		filter.setAction(action);
		filter.setValueLow(value);
	
		
		filter.setOperation(QueryFilter.OPERATION_ATTRIBUTE);
		filter.setAttribute("*");
		
		return filter;
	}

	/**
	 * Creates a {@link QueryFilter} for searching in a TREX system. It cannot be used for local persistency queries.
	 * This method is used to create a filter on a numeric attribute or a category of a BO Node. For expressions on date
	 * attributes you have to keep in mind that a java.util.Date represents a timestamp which is a time measured in milliseconds.
	 * So, for example, if you want to search for objects that have been created at a specific day, you have to define a query which
	 * contains two date filters that are combined by an AND-operator. The first timestamp points to the day you want to search for at 0:00 AM.
	 * The second timestamp represents 0:00 AM at the next day. 
	 * @param condition a value from the {@link Condition} enumeration  
	 * @param value the search date value
	 * @param name the name of the attribute or category
	 * @return a {@link QueryFilter} instance for the given parameters
	 */
	@Deprecated
	public static QueryFilter createDateFilter(Condition condition, Date value, String name) {
		QueryFilter filter = new QueryFilter();
		
		filter.setCondition(condition);
		filter.setValueLow(value);
		filter.setAttribute(name);

		
		filter.setOperation(QueryFilter.OPERATION_ATTRIBUTE);
		
		return filter;
	}

	/**
	 * Creates a bracket which can be part of a query. This method is used 
	 * in order to prepare a search clause for the <code>findByMultipleParameters</code> method.
	 * You may use {@link QueryFilter#OPEN_BRACKET} and {@link QueryFilter#CLOSE_BRACKET} instead of this method.
	 * @param type the type of the bracket; see the constants QueryFilter.OPERATION_BRACKET_* for the possible values
	 * @return a {@link QueryFilter} instance for the given parameters
	 */
	@Deprecated
	public static QueryFilter createBracket(String type) {
		QueryFilter filter = new QueryFilter();
		
		filter.setOperation(type);
		
		return filter;
	}

	/**
	 * Creates a boolean operator which can be used to combine expressions.
	 * You may use {@link QueryFilter#AND}, {@link QueryFilter#OR} and {@link QueryFilter#NOT} instead of this method.
	 * @param type the type of the operator; see the constants QueryFilter.OPERATION_* for the possible values
	 * @return a {@link QueryFilter} instance for the given parameters
	 */
	@Deprecated
	public static QueryFilter createBoolOperator(String type) {
		QueryFilter filter = new QueryFilter();
		
		filter.setOperation(type);
		
		return filter;
	}

	/**
	 * Creates a {@link QueryFilter} suitable for the <code>findByMultipleParameters</code> operation.
	 * @param attributeSpec This is the full path of the queried attribute. The attribute path is a sequence of attribute names of BO Nodes
	 * or complex structures, separated by {@link #BO_NODE_REFERENCE_PATH_SEPARATOR} or {@link #NESTED_STRUCTURE_PATH_SEPARATOR}.<br>
	 * Example: given the domain model:
	 * <pre>
	 *  Complex structure "Address" with fields:
	 *      "country" : STRING
	 *      "streetName" : STRING 
	 *  	 
	 *  BO Nodes:
	 *      BO: Department with field: 
	 *         "name" : STRING
	 *      BO: Employee with fields:
	 *         "firstName" : STRING
	 *         "lastName" : STRING
	 *         "address" : Address	
	 *  Associations:
	 *         "employees" - unidirectional one-to-many association from Department to Employee
	 * </pre>
	 * 
	 * The following attribute paths can be formed for the BO Node Department (meaning that the query will search for Departments 
	 * while satisfying the search conditions):<br>
	 * "name" - refers to the name of the Department<br>
	 * "employees.firstName" - refers to the "firstName" attribute of any employee in this department (only departments that
	 * have at least one Employee with given first name<br>
	 * "employees.address#streetName" - refers to the "streetName" attribute of any employee that works in the department<br>
	 * 
	 * @param condition a value from the {@link Condition} enumeration
	 * @param value the search value
	 * @return a {@link QueryFilter} instance for the given parameters
	 */
	public static QueryFilter createFilter(String attributeSpec, Condition condition, Object value) {
		QueryFilter qf = createFilter(condition,value);
		qf.setAttribute(attributeSpec);
		
		
		return qf;
	}

	/**
	 * Creates a {@link QueryFilter} for searching in a range.
	 * @param attributeSpec see {@link #createFilter(String, Condition, Object)} for more information
	 * @param valueLow the start of the search range
	 * @param valueHigh the end of the search range
	 * @return a {@link QueryFilter} instance for the given parameters
	 * @see #createFilter(String, Condition, Object)
	 */
	public static QueryFilter createFilterForBetween(String attributeSpec, Object valueLow, Object valueHigh){
		QueryFilter qf = new QueryFilter();
		qf.setAttribute(attributeSpec);
		qf.setCondition(Condition.BETWEEN);
		qf.setValueLow(valueLow);
		qf.setValueHigh(valueHigh);
		return qf;
	}
	
	public static Object nullToWildcard(Object value){
		if ( value == null){
			return QueryFilter.WILDCARD_SYMBOL;
		}else{
			return value;
		}
		
	}
}
