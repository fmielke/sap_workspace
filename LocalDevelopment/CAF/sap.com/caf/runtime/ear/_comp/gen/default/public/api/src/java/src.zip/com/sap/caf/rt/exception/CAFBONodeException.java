/*
 * Created on May 5, 2004
 */
package com.sap.caf.rt.exception;

import com.sap.caf.rt.util.CAFResourceAccessor;
import com.sap.exception.BaseExceptionInfo;
import com.sap.localization.LocalizableText;
import com.sap.localization.LocalizableTextFormatter;
import com.sap.localization.ResourceAccessor;
import com.sap.localization.LocalizableText.Msg;
import com.sap.tc.logging.Category;
import com.sap.tc.logging.Location;

/**
 * This exception is thrown by the CAF runtime in different BO Node related situations.
 */
@javax.xml.ws.WebFault(name = "CAFBONodeException", targetNamespace = "http://www.sap.com/caf/sap.com/caf.core/faults", faultBean = "com.sap.caf.rt.exception.FaultInfo")
public class CAFBONodeException extends CAFServiceException
{
	private static final long serialVersionUID = 529695081130293154L;

	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 */
	public CAFBONodeException(Location location)
	{
		super(location);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location)} instead.
	 */
	public CAFBONodeException()
	{
		super();
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param baseExcInfo information about the throwable which caused this exception
	 */
	public CAFBONodeException(BaseExceptionInfo baseExcInfo)
	{
		super(baseExcInfo);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param baseExcInfo information about the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBONodeException(BaseExceptionInfo baseExcInfo, boolean isRealCause)
	{
		super(baseExcInfo, isRealCause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 */
	public CAFBONodeException(Location location, Throwable cause)
	{
		super(location, cause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, Throwable)} instead.
	 */
	public CAFBONodeException(Throwable cause)
	{
		super(cause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBONodeException(Location location, Throwable cause, boolean isRealCause)
	{
		super(location, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, Throwable, boolean)} instead.
	 */
	public CAFBONodeException(Throwable cause, boolean isRealCause)
	{
		super(cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 */
	public CAFBONodeException(Location location, ResourceAccessor ra, String key)
	{
		super(location, ra, key);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, ResourceAccessor, String)} instead.
	 */
	public CAFBONodeException(ResourceAccessor ra, String key)
	{
		super(ra, key);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFBONodeException(Location location, ResourceAccessor ra, String key, Throwable cause)
	{
		super(location, ra, key, cause);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, ResourceAccessor, String, Throwable)} instead.
	 */
	public CAFBONodeException(ResourceAccessor ra, String key, Throwable cause)
	{
		super(ra, key, cause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBONodeException(Location location, ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, ResourceAccessor, String, Throwable, boolean)} instead.
	 */
	public CAFBONodeException(ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(ra, key, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFBONodeException(Location location, ResourceAccessor ra, String key, Object[] args)
	{
		super(location, ra, key, args);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, ResourceAccessor, String, Object[])} instead.
	 */
	public CAFBONodeException(ResourceAccessor ra, String key, Object[] args)
	{
		super(ra, key, args);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 */
	public CAFBONodeException(Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(location, ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, ResourceAccessor, String, Object[], Throwable)} instead. 
	 */
	public CAFBONodeException(ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBONodeException(Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, args, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, ResourceAccessor, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFBONodeException(ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(ra, key, args, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 */
	public CAFBONodeException(Location location, ResourceAccessor ra, Msg msg)
	{
		super(location, ra, msg);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, ResourceAccessor, LocalizableText.Msg)} instead.
	 */
	public CAFBONodeException(ResourceAccessor ra, Msg msg)
	{
		super(ra, msg);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFBONodeException(Location location, ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(location, ra, msg, cause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, ResourceAccessor, LocalizableText.Msg, Throwable)} instead. 
	 */
	public CAFBONodeException(ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(ra, msg, cause);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBONodeException(Location location, ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(location, ra, msg, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, ResourceAccessor, LocalizableText.Msg, Throwable, boolean)} instead. 
	 */
	public CAFBONodeException(ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(ra, msg, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param localizableText localizable message
	 */
	public CAFBONodeException(Location location, LocalizableText localizableText)
	{
		super(location, localizableText);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param localizableText localizable message
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, LocalizableText)} instead. 
	 */
	public CAFBONodeException(LocalizableText localizableText)
	{
		super(localizableText);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 */
	public CAFBONodeException(Location location, LocalizableText localizableText, Throwable cause)
	{
		super(location, localizableText, cause);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, LocalizableText, Throwable)} instead.
	 */
	public CAFBONodeException(LocalizableText localizableText, Throwable cause)
	{
		super(localizableText, cause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBONodeException(Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(location, localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFBONodeException(LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated
	 */
	public CAFBONodeException(Category category, int severity, Location location, LocalizableText localizableText, Throwable cause)
	{
		super(category, severity, location, localizableText, cause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFBONodeException(Category category, int severity, Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @deprecated
	 */
	public CAFBONodeException(Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(category, severity, location, ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFBONodeException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFBONodeException(Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, ra, key, args, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param textFormatter localizable message
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, LocalizableText)} instead.
	 */
	public CAFBONodeException(LocalizableTextFormatter textFormatter)
	{
		this((LocalizableText)textFormatter);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, LocalizableText, Throwable)} instead.
	 */
	public CAFBONodeException(LocalizableTextFormatter textFormatter, Throwable cause)
	{
		this((LocalizableText)textFormatter, cause);
	}

	/**
	 * Constructs a new CAFBONodeException.
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFBONodeException(LocalizableTextFormatter textFormatter, Throwable cause, boolean isRealCause)
	{
		this((LocalizableText)textFormatter, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBONodeException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 */
	public CAFBONodeException(Location location, String key)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
	}
	
	/**
	 * Constructs a new CAFBONodeException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, String)} instead.
	 */
	public CAFBONodeException(String key)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
	}
	
	/**
	 * Constructs a new CAFBONodeException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 */
	public CAFBONodeException(Location location, String key, Throwable cause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
	}

	/**
	 * Constructs a new CAFBONodeException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, String, Throwable)} instead.
	 */
	public CAFBONodeException(String key, Throwable cause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
	}

	/**
	 * Constructs a new CAFBONodeException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBONodeException(Location location, String key, Throwable cause, boolean isRealCause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBONodeException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, String, Throwable, boolean)} instead.
	 */
	public CAFBONodeException(String key, Throwable cause, boolean isRealCause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBONodeException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFBONodeException(Location location, String key, Object[] args)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
	}

	/**
	 * Constructs a new CAFBONodeException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, String, Object[])} instead.
	 */
	public CAFBONodeException(String key, Object[] args)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
	}

	/**
	 * Constructs a new CAFBONodeException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 */
	public CAFBONodeException(Location location, String key, Object[] args, Throwable cause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
	}

	/**
	 * Constructs a new CAFBONodeException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, String, Object[], Throwable)} instead.
	 */
	public CAFBONodeException(String key, Object[] args, Throwable cause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
	}

	/**
	 * Constructs a new CAFBONodeException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBONodeException(Location location, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBONodeException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBONodeException#CAFBONodeException(Location, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFBONodeException(String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
	}
}
