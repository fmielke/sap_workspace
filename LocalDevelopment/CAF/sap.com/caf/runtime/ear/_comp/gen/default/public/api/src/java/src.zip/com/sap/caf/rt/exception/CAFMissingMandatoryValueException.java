/*
 * Created on 2004-11-9
 */
package com.sap.caf.rt.exception;

import com.sap.caf.rt.util.CAFResourceAccessor;
import com.sap.exception.BaseExceptionInfo;
import com.sap.localization.LocalizableText;
import com.sap.localization.LocalizableTextFormatter;
import com.sap.localization.ResourceAccessor;
import com.sap.localization.LocalizableText.Msg;
import com.sap.tc.logging.Category;
import com.sap.tc.logging.Location;

/**
 * This exception is thrown when no value has been provided for a mandatory BO Node attribute.  
 */
public class CAFMissingMandatoryValueException extends CAFBaseRuntimeException
{
	private static final long serialVersionUID = 2294133473062495574L;

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 */
	public CAFMissingMandatoryValueException(Location location)
	{
		super(location);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location)} instead.
	 */
	public CAFMissingMandatoryValueException()
	{
		super();
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param baseExcInfo information about the throwable which caused this exception
	 */
	public CAFMissingMandatoryValueException(BaseExceptionInfo baseExcInfo)
	{
		super(baseExcInfo);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param baseExcInfo information about the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFMissingMandatoryValueException(BaseExceptionInfo baseExcInfo, boolean isRealCause)
	{
		super(baseExcInfo, isRealCause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 */
	public CAFMissingMandatoryValueException(Location location, Throwable cause)
	{
		super(location, cause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, Throwable)} instead.
	 */
	public CAFMissingMandatoryValueException(Throwable cause)
	{
		super(cause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFMissingMandatoryValueException(Location location, Throwable cause, boolean isRealCause)
	{
		super(location, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, Throwable, boolean)} instead.
	 */
	public CAFMissingMandatoryValueException(Throwable cause, boolean isRealCause)
	{
		super(cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 */
	public CAFMissingMandatoryValueException(Location location, ResourceAccessor ra, String key)
	{
		super(location, ra, key);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, ResourceAccessor, String)} instead.
	 */
	public CAFMissingMandatoryValueException(ResourceAccessor ra, String key)
	{
		super(ra, key);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFMissingMandatoryValueException(Location location, ResourceAccessor ra, String key, Throwable cause)
	{
		super(location, ra, key, cause);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, ResourceAccessor, String, Throwable)} instead.
	 */
	public CAFMissingMandatoryValueException(ResourceAccessor ra, String key, Throwable cause)
	{
		super(ra, key, cause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFMissingMandatoryValueException(Location location, ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, ResourceAccessor, String, Throwable, boolean)} instead.
	 */
	public CAFMissingMandatoryValueException(ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(ra, key, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFMissingMandatoryValueException(Location location, ResourceAccessor ra, String key, Object[] args)
	{
		super(location, ra, key, args);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, ResourceAccessor, String, Object[])} instead.
	 */
	public CAFMissingMandatoryValueException(ResourceAccessor ra, String key, Object[] args)
	{
		super(ra, key, args);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 */
	public CAFMissingMandatoryValueException(Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(location, ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, ResourceAccessor, String, Object[], Throwable)} instead. 
	 */
	public CAFMissingMandatoryValueException(ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFMissingMandatoryValueException(Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, args, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, ResourceAccessor, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFMissingMandatoryValueException(ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(ra, key, args, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 */
	public CAFMissingMandatoryValueException(Location location, ResourceAccessor ra, Msg msg)
	{
		super(location, ra, msg);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, ResourceAccessor, LocalizableText.Msg)} instead.
	 */
	public CAFMissingMandatoryValueException(ResourceAccessor ra, Msg msg)
	{
		super(ra, msg);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFMissingMandatoryValueException(Location location, ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(location, ra, msg, cause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, ResourceAccessor, LocalizableText.Msg, Throwable)} instead. 
	 */
	public CAFMissingMandatoryValueException(ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(ra, msg, cause);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFMissingMandatoryValueException(Location location, ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(location, ra, msg, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, ResourceAccessor, LocalizableText.Msg, Throwable, boolean)} instead. 
	 */
	public CAFMissingMandatoryValueException(ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(ra, msg, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param localizableText localizable message
	 */
	public CAFMissingMandatoryValueException(Location location, LocalizableText localizableText)
	{
		super(location, localizableText);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param localizableText localizable message
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, LocalizableText)} instead. 
	 */
	public CAFMissingMandatoryValueException(LocalizableText localizableText)
	{
		super(localizableText);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 */
	public CAFMissingMandatoryValueException(Location location, LocalizableText localizableText, Throwable cause)
	{
		super(location, localizableText, cause);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, LocalizableText, Throwable)} instead.
	 */
	public CAFMissingMandatoryValueException(LocalizableText localizableText, Throwable cause)
	{
		super(localizableText, cause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFMissingMandatoryValueException(Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(location, localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFMissingMandatoryValueException(LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated
	 */
	public CAFMissingMandatoryValueException(Category category, int severity, Location location, LocalizableText localizableText, Throwable cause)
	{
		super(category, severity, location, localizableText, cause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFMissingMandatoryValueException(Category category, int severity, Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @deprecated
	 */
	public CAFMissingMandatoryValueException(Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(category, severity, location, ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFMissingMandatoryValueException(Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, ra, key, args, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param textFormatter localizable message
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, LocalizableText)} instead.
	 */
	public CAFMissingMandatoryValueException(LocalizableTextFormatter textFormatter)
	{
		this((LocalizableText)textFormatter);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, LocalizableText, Throwable)} instead.
	 */
	public CAFMissingMandatoryValueException(LocalizableTextFormatter textFormatter, Throwable cause)
	{
		this((LocalizableText)textFormatter, cause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException.
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFMissingMandatoryValueException(LocalizableTextFormatter textFormatter, Throwable cause, boolean isRealCause)
	{
		this((LocalizableText)textFormatter, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 */
	public CAFMissingMandatoryValueException(Location location, String key)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, String)} instead.
	 */
	public CAFMissingMandatoryValueException(String key)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
	}
	
	/**
	 * Constructs a new CAFMissingMandatoryValueException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 */
	public CAFMissingMandatoryValueException(Location location, String key, Throwable cause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, String, Throwable)} instead.
	 */
	public CAFMissingMandatoryValueException(String key, Throwable cause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFMissingMandatoryValueException(Location location, String key, Throwable cause, boolean isRealCause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, String, Throwable, boolean)} instead.
	 */
	public CAFMissingMandatoryValueException(String key, Throwable cause, boolean isRealCause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFMissingMandatoryValueException(Location location, String key, Object[] args)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, String, Object[])} instead.
	 */
	public CAFMissingMandatoryValueException(String key, Object[] args)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 */
	public CAFMissingMandatoryValueException(Location location, String key, Object[] args, Throwable cause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, String, Object[], Throwable)} instead.
	 */
	public CAFMissingMandatoryValueException(String key, Object[] args, Throwable cause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFMissingMandatoryValueException(Location location, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFMissingMandatoryValueException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFMissingMandatoryValueException#CAFMissingMandatoryValueException(Location, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFMissingMandatoryValueException(String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
	}
}
