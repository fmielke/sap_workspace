package com.sap.caf.rt.bol.da.jpa;

import com.sap.caf.rt.exception.CAFBaseRuntimeException;

public class BackwardCompatibleValidator implements IDataValidator {

	public void validateStructure(IPersistableStructure persistable) {
//		DO NOTHING		
		
	}

}
