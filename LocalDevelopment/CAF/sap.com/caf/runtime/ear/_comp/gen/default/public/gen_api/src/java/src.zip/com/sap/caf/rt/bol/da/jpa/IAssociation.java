package com.sap.caf.rt.bol.da.jpa;

public interface IAssociation {
	
	public String getId();

	public void setId(String id);

	public String getSourceKey();

	public void setSourceKey(String sourceKey);
	
	public String getTargetKey();

	public void setTargetKey(String targetKey);
}
