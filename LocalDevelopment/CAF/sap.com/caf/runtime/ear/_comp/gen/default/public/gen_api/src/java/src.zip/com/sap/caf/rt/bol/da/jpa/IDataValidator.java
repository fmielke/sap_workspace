package com.sap.caf.rt.bol.da.jpa;

public interface IDataValidator {
	public void validateStructure(IPersistableStructure persistable) ;
}
