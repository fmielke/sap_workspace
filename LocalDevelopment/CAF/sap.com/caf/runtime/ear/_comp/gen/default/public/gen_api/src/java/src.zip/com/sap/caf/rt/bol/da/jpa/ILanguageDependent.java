package com.sap.caf.rt.bol.da.jpa;

public interface ILanguageDependent extends IPersistable{

	public String getLanguage();
	
	public void setLanguage(String language);
	
	public <T> IPersistable getOwner();
	
	public void setOwner(IPersistable owner);
	
	public String[] _getPropertyNames();
	
	public java.lang.String _getProperty(java.lang.String name);
	
	public void _setProperty(java.lang.String name, java.lang.String value);
	
}
