package com.sap.caf.rt.bol.da.jpa;

/**
 * IPersistable defines the base interface for all CAF persistable entities.
 * A persistable entity is required to have at least a primary key.
 * @author I033024
 */
public interface IPersistable {
	
	/**
	 * @return the primary key
	 */
	public String getKey();
	
	/**
	 * @param key the primary key
	 */
	public void setKey(String key);
}