package com.sap.caf.rt.bol.da.jpa;

import java.util.Date;

public interface IPersistableBONode extends IPersistableStructure {
	
	public String getCreatedBy();
	
	public void setCreatedBy(String createdBy);
	
	public Date getCreatedAt();
	
	public void setCreatedAt(Date createdAt);
	
	public String getModifiedBy();
	
	public void setModifiedBy(String modifiedBy);
	
	public Date getModifiedAt();
	
	public void setModifiedAt(Date modifiedAt);
	/*
	public <T> IBusinessObjectNodeBase detach();
	
	public Collection<Class> getAssociationsClasses();
	*/

}