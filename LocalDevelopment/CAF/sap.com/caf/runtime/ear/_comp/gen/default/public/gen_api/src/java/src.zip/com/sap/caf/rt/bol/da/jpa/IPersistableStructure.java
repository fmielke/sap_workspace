package com.sap.caf.rt.bol.da.jpa;

import java.util.Map;

public interface IPersistableStructure extends IPersistable {
/*
	public String[] getSimpleAttributeNames();
	
	public String[] getStructureAttributeNames();
	
	public String[] getLanguageDependentAttributeNames();
	
	public String[] getInterfaceAttributeNames();
*/	
	public Object getAttribute(String name);
	
	public void setAttribute(String name, Object value);
	
	public Object getAttribute(Object structure, String name);
	
	public void setAttribute(Object structure, String name, Object value);
	
	//public Class getAttributeClass(String attributeName);
	
	public Map getLanguageDependentAttributes();
}
