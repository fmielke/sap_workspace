package com.sap.caf.rt.bol.da.jpa;

import static com.sap.caf.rt.util.JPAValuesConvertor.convertToJPAValue;

import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.ejb.SessionContext;
import javax.persistence.EntityManager;
import javax.persistence.FlushModeType;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.sap.caf.rt.bol.IBusinessObjectNodeBase;
import com.sap.caf.rt.bol.IDependentObject;
import com.sap.caf.rt.bol.da.DataAccessFactory;
import com.sap.caf.rt.bol.da.IDataAccessService;
import com.sap.caf.rt.bol.da.jpa.annotations.CAFBONodeAssociationType;
import com.sap.caf.rt.bol.da.jpa.factory.JPAUtilsFactory;
import com.sap.caf.rt.bol.da.jpa.model.Association;
import com.sap.caf.rt.bol.da.jpa.model.Attribute;
import com.sap.caf.rt.bol.da.jpa.model.AttributeType;
import com.sap.caf.rt.bol.da.jpa.model.Structure;
import com.sap.caf.rt.bol.da.jpa.model.Version;
import com.sap.caf.rt.bol.util.OrderBy;
import com.sap.caf.rt.bol.util.Paging;
import com.sap.caf.rt.bol.util.QueryFilter;
import com.sap.caf.rt.bol.util.qf.ISearchClause;
import com.sap.caf.rt.bol.util.qf.ejb3.impl.FilterToQueryConverter;
import com.sap.caf.rt.bol.util.qf.ejb3.impl.QueryInProcess;
import com.sap.caf.rt.bol.util.qf.ejb3.runtimemeta.IInfoProvider;
import com.sap.caf.rt.exception.CAFBaseRuntimeException;
import com.sap.caf.rt.exception.CAFDataAccessException;
import com.sap.caf.rt.util.internal.Utils;
import com.sap.guid.GUIDGeneratorFactory;
import com.sap.guid.IGUIDGenerator;
import com.sap.security.api.IUser;
import com.sap.security.api.IUserFactory;
import com.sap.security.api.UMFactory;
import com.sap.sql.DuplicateKeyException;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;

public class JPADataAccessService implements IDataAccessService{
	
	private static final long serialVersionUID = -8378517522029307196L;
	
	private static final Location log = Location.getLocation(JPADataAccessService.class);

	//private final static String[] EMPTY_STRING_ARRAY = new String[0];
	
	private static final String[] ADMIN_ATTRIBUTES = new String[] {
		"createdAt", "createdBy", "key", "modifiedAt", "modifiedBy"
	};
	
	static {
		Arrays.sort(ADMIN_ATTRIBUTES);
	}
	
	private static Version CAF_1_1_0_VERSION = new Version("1.1.0");
	
	private IInfoProvider infoProvider;
	
	private IUserFactory userFactory;
	
	private EntityManager entityManager;
	
	private SessionContext sessionContext;
	
	private Class<IPersistableBONode> persistentClass;
	
	private IDataValidator validator;

	private IGUIDGenerator guidGenerator;
	
	private transient Structure boNodeEntityInfo;

	public JPADataAccessService(Map<String, Object> properties) throws CAFDataAccessException {
		this.entityManager = (EntityManager)properties.get(DataAccessFactory.ENTITY_MANAGER_PROPERTY);
		this.sessionContext = (SessionContext)properties.get(DataAccessFactory.SESSION_CONTEXT_PROPERTY);
		this.persistentClass = (Class)properties.get(DataAccessFactory.BO_NODE_PERSISTENT_CLASS_PROPERTY);
		JPAUtilsFactory factory = JPAUtilsFactory.getFactory(persistentClass);
		this.infoProvider = factory.getQueryFilterInfoProvider();
		guidGenerator = GUIDGeneratorFactory.getInstance().createGUIDGenerator();
		userFactory = getUserFactory();
		boNodeEntityInfo = factory.getMetamodelProvider().getBONodeInfo(persistentClass);
		validator = factory.getDataValidator();
	}
	
	private void doCreate(IPersistableStructure _persistable, Structure metadata) {
		_persistable.setKey(generateGUID());
		
		for (Attribute attribute : metadata.getAttributes(AttributeType.NESTED)) {
			IPersistableStructure _nestedStructure = (IPersistableStructure) _persistable.getAttribute(attribute.getName());
			if (_nestedStructure != null) {
				doCreate(_nestedStructure, attribute.getReferencedEntity());
			}
		}
		
		Map<String, ILanguageDependent> ldAttributes = _persistable.getLanguageDependentAttributes();
		for (Iterator iterator = ldAttributes.values().iterator(); iterator.hasNext();) {
			ILanguageDependent ld = (ILanguageDependent) iterator.next();
			boolean empty = true;
			for (String ldName : ld._getPropertyNames()) {
				if (ld._getProperty(ldName) != null) {
					empty = false;
					break;
				}
			}
			
			if (empty) {
				iterator.remove();
				if (ld.getKey() != null) {
					entityManager.remove(ld);
				}
			} else {
				if (ld.getKey() == null)
					ld.setKey(generateGUID());
				ld.setOwner(_persistable);
			}
			
			
		}
		
	}
	
	private IPersistableStructure doUpdate(Object detached, IPersistableStructure persistent, Structure metadata, Timestamp timestamp, String user) throws CAFDataAccessException{
		if (detached != null) {//merge
			
			if (persistent.getKey() == null) {
				persistent.setKey(generateGUID());
			}
			persistent.setAttribute("modifiedBy", Utils.truncateUserName(user));
			persistent.setAttribute("modifiedAt", timestamp);
			
			for (Attribute attribute : metadata.getAttributes().values()) {
				String attributeName = attribute.getName();
				
				switch (attribute.getType()) {
				case SIMPLE:
					if (Arrays.binarySearch(ADMIN_ATTRIBUTES, attributeName) < 0) {
						//exclude admin attributes
						persistent.setAttribute(attributeName, persistent.getAttribute(detached, attributeName));						
					}
					break;
				case NESTED:
					Object detachedChild = persistent.getAttribute(detached, attributeName);
					IPersistableStructure persistentChild = (IPersistableStructure) persistent.getAttribute(attributeName);
					
					if (persistentChild != null) { //merge
						persistentChild = doUpdate(detachedChild, persistentChild, attribute.getReferencedEntity(), timestamp, user);
						persistent.setAttribute(attributeName, persistentChild);
					} else {//insert
						if (detachedChild != null) {
							persistent.setAttribute(attributeName, detachedChild);
							persistentChild = (IPersistableStructure) persistent.getAttribute(attributeName);
							doUpdate(detachedChild, persistentChild, attribute.getReferencedEntity(), timestamp, user);
						}
					}					
					break;
				case LANGUAGE_DEPENDENT:
					String language = getLogonLanguage();
					//Map<String, Object> _persistentMap = (Map<String, Object>) _persistent.getAttribute(_attributeName);
					/*Map<String, ILanguageDependent> languageDependentMap = persistent.getLanguageDependentAttributes();
					String detachedAttribute = (String) persistent.getAttribute(detached, attributeName);
					mergeLanguageDependent(persistent, metadata.getLanguageDependentClass(), attributeName, detachedAttribute, languageDependentMap, language);*/
					LDAttributesHelper helper = new LDAttributesHelper(entityManager, guidGenerator, language);
					try {
						helper.attachLanguageDependentAttribute(persistent, (IDependentObject) detached, attributeName, metadata.getLanguageDependentClass());
					} catch (IllegalAccessException e) {
						log.traceThrowableT(Severity.ERROR, "Unable to attach LD attribute " + attributeName, e);
						throw new CAFBaseRuntimeException(log, "Unable to attach LD attribute " + attributeName, e);
					} catch (InvocationTargetException e) {
						log.traceThrowableT(Severity.ERROR, "Unable to attach LD attribute " + attributeName, e);
						throw new CAFBaseRuntimeException(log, "Unable to attach LD attribute " + attributeName, e);					}
					break;
				}
			}
		} else{ //delete
			entityManager.remove(persistent);
			persistent = null;
		}
		
		return persistent;
	}
	
	/*
	private void mergeLanguageDependent(IPersistableStructure owner, Class<ILanguageDependent> ldClass, String attributeName, String detachedAttribute, Map<String, ILanguageDependent> persistentMap, String language) throws CAFDataAccessException {
	
		if (detachedAttribute == null && persistentMap != null && !persistentMap.isEmpty()) {
			ILanguageDependent languageDependent = (ILanguageDependent) persistentMap.get(language);
			if (languageDependent != null) {
				languageDependent._setProperty(attributeName, null);
				boolean isEmpty = true;
				for (String propertyName : languageDependent._getPropertyNames()) {
					if (languageDependent._getProperty(propertyName) != null) {
						isEmpty = false;
						break;
					}
				}
				
				if (isEmpty) {
					persistentMap.remove(language);
					entityManager.remove(languageDependent);
				}
			}
		} else if (detachedAttribute != null) {
			ILanguageDependent languageDependent = persistentMap.get(language);
			if (languageDependent != null) {
				languageDependent._setProperty(attributeName, detachedAttribute);
			} else {
				try {
					languageDependent = ldClass.newInstance();
					languageDependent.setKey(generateGUID());
					languageDependent.setOwner(owner);
					languageDependent.setLanguage(language);
					languageDependent._setProperty(attributeName, detachedAttribute);
				} catch (InstantiationException e) {
					log.traceThrowableT(Severity.ERROR, "Unable to instantiate " + ldClass.getName(), e);
					throw new CAFDataAccessException(e);
				} catch (IllegalAccessException e) {
					log.traceThrowableT(Severity.ERROR, "Unable to instantiate " + ldClass.getName(), e);
					throw new CAFDataAccessException(e);
				}
				persistentMap.put(language, languageDependent);
			}
		}
		
	}
	*/

	private void removeAssociatedKeys(Class<?> associationClass, String sourceKey) {
		Query _query = entityManager.createNamedQuery(associationClass.getSimpleName() + "_removeAll");
		_query.setParameter("sourceKey", sourceKey);
		_query.setFlushMode(FlushModeType.COMMIT);
		_query.executeUpdate();
	}

	private String generateGUID() {
		return guidGenerator.createGUID().toString();
	}

	public void addCardinalityManyAssociationTargetKeys(String sourceKey, String[] targetKeys, String associationName) throws CAFDataAccessException {
		Association association = boNodeEntityInfo.getAssociation(associationName);
		checkExists(sourceKey,this.persistentClass);
		
		if (association.getType() == CAFBONodeAssociationType.LOCAL && association.getTargetEntityClass().getClassLoader() == this.persistentClass.getClassLoader()){
			checkAllKeysExist(targetKeys, association.getTargetEntityClass());
		}
		
		
		String[] currentKeys = getCardinalityManyAssociationTargetKeys(sourceKey, associationName);
		Arrays.sort(currentKeys);
			
	
		try {			
			for (String targetKey : targetKeys) {
				if (Arrays.binarySearch(currentKeys, targetKey) < 0) {
					IAssociation assoc = (IAssociation) association.getCrossClass().newInstance();
					assoc.setId(generateGUID());
					assoc.setTargetKey(targetKey);
					assoc.setSourceKey(sourceKey);
					entityManager.persist(assoc);				
				}
			}
			entityManager.flush();
		} catch (InstantiationException e) {
			log.traceThrowableT(Severity.ERROR, "Unable to instantiate " + association.getCrossClass().getName(), e);
			throw new CAFDataAccessException(log, e);
		} catch (IllegalAccessException e) {
			log.traceThrowableT(Severity.ERROR, "Unable to instantiate " + association.getCrossClass().getName(), e);
			throw new CAFDataAccessException(log, e);
		}
	}

	public String create(IBusinessObjectNodeBase boStructure) throws CAFDataAccessException {
		Collection<IBusinessObjectNodeBase> boStructures = new LinkedList<IBusinessObjectNodeBase>();
		boStructures.add(boStructure);
		return this.create(boStructures).iterator().next();
	}
	
	public Collection<String> create(Collection<? extends IBusinessObjectNodeBase> boStructures) throws CAFDataAccessException {
		IBusinessObjectNodeBase boStructure = null;
		try {
			String user = sessionContext.getCallerPrincipal().getName();
			Collection<String> retVal = new LinkedList<String>();
			Iterator<? extends IBusinessObjectNodeBase> i = boStructures.iterator();
			while (i.hasNext())
			{
				boStructure = i.next();
				IPersistableBONode boNode;
				if (isBackwardCompatibleCustomKeyValidationCheckNeeded()){
					throwExceptionIfCustomKeyViolation(boStructure, false);
				}
				boNode = (IPersistableBONode) attach(boStructure, boNodeEntityInfo, getLogonLanguage());
	
				java.sql.Timestamp timestamp = new java.sql.Timestamp(System.currentTimeMillis());
				
				boNode.setAttribute("createdAt", timestamp);
				boNode.setAttribute("createdBy", Utils.truncateUserName(user));
				boNode.setAttribute("modifiedBy", Utils.truncateUserName(user));
				boNode.setAttribute("modifiedAt", timestamp);
				doCreate(boNode, boNodeEntityInfo);
				validator.validateStructure(boNode);
				entityManager.persist(boNode);
				
				for (String adminAttributeName : ADMIN_ATTRIBUTES) {
					boNode.setAttribute(boStructure, adminAttributeName, boNode.getAttribute(adminAttributeName));
				}
				
				retVal.add(boNode.getKey());
			}
			entityManager.flush();
			return retVal;
		} catch (CAFBaseRuntimeException e) {
			log.catching(e);
			throw new CAFDataAccessException(log, e);
		} catch (PersistenceException e){
			log.catching(e);
			if (boStructure != null  &&  isKeyDuplicationError(e)){
				throwExceptionIfCustomKeyViolation(boStructure, false);
			}
			throw new CAFDataAccessException(log, e);
		}
	}
	
	private static boolean isKeyDuplicationError(PersistenceException pe){
		return pe.getCause()!=null && pe.getCause().getClass() == DuplicateKeyException.class;
	}
	
	
	public void destroy() {
	}

//	public Object findByPrimaryKey(Object objId, Class objectClass) throws CAFDataAccessException {
//		return null;
//	}

	public String[] getCardinalityManyAssociationTargetKeys(String sourceKey, String associationName) throws CAFDataAccessException {
		if (hasInvalidKey(sourceKey)){
			return null;
		}
		Class<IAssociation> associationClass = boNodeEntityInfo.getAssociation((associationName)).getCrossClass();
		Query query = entityManager.createNamedQuery(associationClass.getSimpleName() + "_getTargetKeys");
		query.setParameter("sourceKey", sourceKey);
		query.setFlushMode(FlushModeType.COMMIT);
		List<String> _results = query.getResultList();
		String[] _targetKeys = new String[_results.size()];
		return _results.toArray(_targetKeys);
	}

	/**
	 * TODO: What if more than one target key is present in the database?
	 */
	public String getCardinalityOneAssociationTargetKey(String sourceKey, String associationName) throws CAFDataAccessException {
		if (hasInvalidKey(sourceKey)){
			return null;
		}
		String[] keys = getCardinalityManyAssociationTargetKeys(sourceKey, associationName);
		if (keys != null && keys.length > 0) {
			return keys[0];
		} else {
			return null;
		}
	}

	public IBusinessObjectNodeBase load(String objId) throws CAFDataAccessException {
		if (hasInvalidKey(objId)){
			return null;
		}
		IPersistableBONode persistent = (IPersistableBONode) entityManager.find(persistentClass, objId);
		if (persistent != null) {
			return (IBusinessObjectNodeBase) detach(persistent, boNodeEntityInfo, getLogonLanguage());
		}
		return null;
	}

	public IBusinessObjectNodeBase loadByCustomKeys(IBusinessObjectNodeBase obj) throws CAFDataAccessException {
		IBusinessObjectNodeBase result = null;
		try{
			ISearchClause clause = createSearchClauseFromCustomKeys(obj);
			if (clause.isEmpty()){
				return null;
			}
			IPersistableBONode persistent = (IPersistableBONode)getJPAQuery(createSearchClauseFromCustomKeys(obj)).getSingleResult();
			result = (IBusinessObjectNodeBase) detach(persistent, boNodeEntityInfo, getLogonLanguage());
		}catch (javax.persistence.NoResultException noResExc){
			result =  null;
		}
		return result;
		
	}
	
	public ISearchClause createSearchClauseFromCustomKeys(IBusinessObjectNodeBase obj) throws CAFDataAccessException {
		ISearchClause clause = com.sap.caf.rt.bol.util.qf.system.QuerySystem.getEmptyClause();
		Collection<Attribute>  attributes = boNodeEntityInfo.getAttributes().values();
		for (Attribute attribute: attributes){
			if (attribute.isCustomKey()){
				clause.and(attribute.getName(), com.sap.caf.rt.bol.util.Condition.EQ,obj.getProperty(attribute.getName()));
			}
		}
		return clause;
	}

	public Collection<IBusinessObjectNodeBase> query(QueryFilter[] filters, String operationName) throws CAFDataAccessException {
		
		return detachCollection(getJPAQuery(filters, null).getResultList());
	}
	
	public Collection<IBusinessObjectNodeBase> query(QueryFilter[] filters, OrderBy orderBy, Paging paging, String operationName) throws CAFDataAccessException {
		Query query = getJPAQuery(filters, orderBy);
		if (paging != null) {
			query.setFirstResult(paging.getFirstResult()).setMaxResults(paging.getMaxResults());
		}
		return jpaExecuteQuery(query);
	}

	private Query getJPAQuery(QueryFilter[] filters, OrderBy orderBy) throws  CAFDataAccessException{
		ISearchClause srchClause = FilterToQueryConverter.convertFilterArray(filters).orderBy(orderBy);
		return getJPAQuery(srchClause);
	}
	private Query getJPAQuery(ISearchClause srchClause) throws CAFDataAccessException {
		QueryInProcess queryInProgress = new QueryInProcess(this.persistentClass, this.infoProvider, srchClause);
		queryInProgress.getParametersHandler().setLanguageValue(getLogonLanguage());
		Query jpaQuery = this.entityManager.createQuery(queryInProgress.getText());
		queryInProgress.getParametersHandler().setParameters(jpaQuery);
		jpaQuery.setFlushMode(FlushModeType.COMMIT);
		return jpaQuery;
	}
	
	public Collection query(QueryFilter[] filter, int startRecord, int pageSize, String operationName) throws CAFDataAccessException {
		return query(filter, null, new Paging(startRecord, pageSize), operationName);
	}
	
	
	private Collection<IBusinessObjectNodeBase> detachCollection(Collection resultList) {
		Collection<IBusinessObjectNodeBase> result = new ArrayList<IBusinessObjectNodeBase>(resultList.size());
		String language = getLogonLanguage();
		for(Object entity : resultList){
			result.add((IBusinessObjectNodeBase) detach((IPersistableBONode) entity, boNodeEntityInfo, language));
		}
		return result;
	}
	
	public void remove(IBusinessObjectNodeBase boStructure) throws CAFDataAccessException {
		Collection<IBusinessObjectNodeBase> boStructures = new LinkedList<IBusinessObjectNodeBase>();
		boStructures.add(boStructure);
		this.remove(boStructures);
	}

	public void remove(Collection<? extends IBusinessObjectNodeBase> boStructures) throws CAFDataAccessException {
		for (IBusinessObjectNodeBase boStructure : boStructures)
		{
			IPersistableBONode persistent = (IPersistableBONode) entityManager.find(persistentClass, boStructure.getKey());
			if (persistent != null) {
				for (Association association : boNodeEntityInfo.getAssociations().values()) {
					removeAssociatedKeys(association.getCrossClass(), persistent.getKey());
				}
				entityManager.remove(persistent);
			}
		}
		entityManager.flush();
	}

	public void removeCardinalityManyAssociationTargetKeys(String sourceKey, String[] targetKeys, String associationName, boolean isComposition) throws CAFDataAccessException {
		if (targetKeys != null && targetKeys.length != 0) {
			StringBuilder buf = new StringBuilder();
			Class associationClass = boNodeEntityInfo.getAssociation(associationName).getCrossClass();
			buf.append("DELETE FROM " + associationClass.getName().replace('.', '_') + " assoc WHERE assoc.sourceKey=:sourceKey and assoc.targetKey IN (");
			for (int i = 0; i < targetKeys.length; i++) {
				buf.append(":targetKey" + i);
				buf.append(",");
			}
			buf.setCharAt(buf.length() - 1, ')');
			
			Query query = entityManager.createQuery(buf.toString());
			query.setParameter("sourceKey", sourceKey);
			for (int i = 0; i < targetKeys.length; i++) {
				query.setParameter("targetKey" + i, targetKeys[i]);
			}
			int result = query.executeUpdate();
			if (result < targetKeys.length){
				log.infoT("Attempt to delete non existing associations!");
				throw new CAFDataAccessException(log, "EXCEPTION_DELETE_NON_EXISTING_AS",new Object[]{associationClass.getSimpleName() ,sourceKey, Arrays.toString(targetKeys)});
			}
			entityManager.flush();
		}
	}
	
	/**
	 * Removes all associations and creates a new one.
	 */
	public void setCardinalityOneAssociationTargetKey(String sourceKey, String targetKey, String associationName, boolean isComposition) throws CAFDataAccessException {
			Association association = boNodeEntityInfo.getAssociation(associationName);
			checkExists(sourceKey,this.persistentClass);
			
			if (targetKey != null && association.getType() == CAFBONodeAssociationType.LOCAL && association.getTargetEntityClass().getClassLoader() == this.persistentClass.getClassLoader()){
				checkExists(targetKey, association.getTargetEntityClass());
			}
			
			Query query = entityManager.createNamedQuery(association.getCrossClass().getSimpleName() + "_removeAll");
			query.setParameter("sourceKey", sourceKey);
			query.executeUpdate();
			
		try {
			if (targetKey != null) {
				IAssociation assoc = (IAssociation) association.getCrossClass().newInstance();
				assoc.setId(generateGUID());
				assoc.setTargetKey(targetKey);
				assoc.setSourceKey(sourceKey);
				entityManager.persist(assoc);
			}
			entityManager.flush();
		} catch (InstantiationException e) {
			log.traceThrowableT(Severity.ERROR, "Unable to instantiate " + association.getCrossClass().getName(), e);
			throw new CAFDataAccessException(log, e);
		} catch (IllegalAccessException e) {
			log.traceThrowableT(Severity.ERROR, "Unable to instantiate " + association.getCrossClass().getName(), e);
			throw new CAFDataAccessException(log, e);
		}
	}

	public void store(IBusinessObjectNodeBase boStructure) throws CAFDataAccessException {
		Collection<IBusinessObjectNodeBase> boStructures = new LinkedList<IBusinessObjectNodeBase>();
		boStructures.add(boStructure);
		this.store(boStructures);
	}
	
	public void store(Collection<? extends IBusinessObjectNodeBase> boStructures) throws CAFDataAccessException {
		store(boStructures, new Date(), sessionContext.getCallerPrincipal().getName());
	}

	public void store(IBusinessObjectNodeBase boStructure, Date date, String user) throws CAFDataAccessException {
		Collection<IBusinessObjectNodeBase> boStructures = new LinkedList<IBusinessObjectNodeBase>();
		boStructures.add(boStructure);
		this.store(boStructures, date, user);
	}
		
	public void store(Collection<? extends IBusinessObjectNodeBase> boStructures, Date date, String user) throws CAFDataAccessException {
		IBusinessObjectNodeBase boStructure = null;
		try {
			Iterator<? extends IBusinessObjectNodeBase> i = boStructures.iterator();
			while (i.hasNext())
			{
				boStructure = i.next();
				IPersistableBONode persistent = (IPersistableBONode) entityManager.find(persistentClass, boStructure.getKey());
				if (persistent != null) {
					if (isBackwardCompatibleCustomKeyValidationCheckNeeded()){
						throwExceptionIfCustomKeyViolation(boStructure, true);
					}
					doUpdate(boStructure, persistent, boNodeEntityInfo, new Timestamp(date.getTime()), user);
					validator.validateStructure(persistent);
					persistent.setAttribute(boStructure, "modifiedBy", persistent.getAttribute("modifiedBy"));
					persistent.setAttribute(boStructure, "modifiedAt", persistent.getAttribute("modifiedAt"));
				} else {
					log.errorT("Can not update a non existing entity: " + persistentClass.getName() + ": " + boStructure.getKey());
					assert false : "Persistent object is null";
				}
			}
			entityManager.flush();
		}
		catch (CAFBaseRuntimeException cbRE){
			log.catching(cbRE);
			throw new CAFDataAccessException(log, cbRE);
		}
		catch (PersistenceException e){
			log.catching(e);
			if (boStructure != null  &&  isKeyDuplicationError(e)){
				throwExceptionIfCustomKeyViolation(boStructure, true);
			}
			throw new CAFDataAccessException(log, e);
		}
	}
	
	private void throwExceptionIfCustomKeyViolation(IBusinessObjectNodeBase boStructure, boolean isUpdate) throws CAFDataAccessException {
			IBusinessObjectNodeBase dublicate = loadByCustomKeys(boStructure);
			boolean dublicateIsDifferent = (dublicate!=null && !dublicate.getKey().equals(boStructure.getKey()));
			if (dublicateIsDifferent){
				log.infoT("Attempt to dublicate a custom key!");
				throw new CAFDataAccessException(log, "BO_CREATE_DUBLICATE_KEY", new Object[] {dublicate.getKey()});
			}
		
	}
	
	protected IUserFactory getUserFactory() {
		return UMFactory.getUserFactory();
	}
	
	private IDependentObject detach(IPersistableStructure attached, Structure metadata, String language) {
		Class pojoClass = metadata.getPOJOClass();
		IDependentObject detached;
		try {
			detached = (IDependentObject) pojoClass.newInstance();
		} catch (InstantiationException e) {
			log.traceThrowableT(Severity.ERROR, "Unable to create an instance of " + pojoClass.getName(), e);
			throw new CAFBaseRuntimeException(log, "Unable to create an instance of " + pojoClass.getName(), e);
		} catch (IllegalAccessException e) {
			log.traceThrowableT(Severity.ERROR, "Unable to create an instance of " + pojoClass.getName(), e);
			throw new CAFBaseRuntimeException(log, "Unable to create an instance of " + pojoClass.getName(), e);
		}
		
		for (Attribute attribute : metadata.getAttributes().values()) {
			String attributeName = attribute.getName();
			switch (attribute.getType()) {
				case SIMPLE :
					attached.setAttribute(detached, attributeName, attached.getAttribute(attributeName));
					break;
				case NESTED :
					IPersistableStructure attachedChild = (IPersistableStructure) attached.getAttribute(attributeName);
					if (attachedChild != null) {
						attached.setAttribute(detached, attributeName, detach(attachedChild, attribute.getReferencedEntity(), language));
					}
					break;
				case LANGUAGE_DEPENDENT :
					LDAttributesHelper helper = new LDAttributesHelper(entityManager, guidGenerator, language);
					try {
						helper.detachLanguageDependentAttribute(attached, detached, attributeName);
					} catch (InvocationTargetException e) {
						log.traceThrowableT(Severity.ERROR, "Unable to detach LD attribute " + attributeName, e);
						throw new CAFBaseRuntimeException(log, "Unable to detach LD attribute " + attributeName, e);
					} catch (IllegalAccessException e) {
						log.traceThrowableT(Severity.ERROR, "Unable to detach LD attribute " + attributeName, e);
						throw new CAFBaseRuntimeException(log, "Unable to detach LD attribute " + attributeName, e);					}
					//Map ldAttributesMap = attached.getLanguageDependentAttributes();// <language_name, ILanguageDependent>
					//String value = detachLanguageDependentAttribute(ldAttributesMap, attributeName, language);
					//attached.setAttribute(detached, attributeName, value);
					break;
			}// switch end
		}//for end
		
		return detached;
	}
	
	/*
	private String detachLanguageDependentAttribute(Map ldAttributesMap, String attributeName, String language) {
		String value = null;
		//requested lanuage		
		ILanguageDependent ldAttributes = (ILanguageDependent) ldAttributesMap.get(language);
		if (ldAttributes != null) {
			value = ldAttributes._getProperty(attributeName);
			if (value != null)
				return value;
		}
		
		//VM language
		ldAttributes = (ILanguageDependent) ldAttributesMap.get(Locale.getDefault().getLanguage());
		if (ldAttributes != null) {
			value = ldAttributes._getProperty(attributeName);
			if (value != null) {
				return value;
			}
		}
		
		//English
		ldAttributes = (ILanguageDependent) ldAttributesMap.get("en");
		if (ldAttributes != null) {
			value = ldAttributes._getProperty(attributeName);
		}
		
		return value;
	}
	*/
	protected java.lang.String getLogonLanguage() {
		
		java.lang.String user = sessionContext.getCallerPrincipal().getName();
		
		java.lang.String logonLanguage = null;
		try {
			IUser us = userFactory.getUserByLogonID(user);
			java.util.Locale loc = us.getLocale();
			if (loc == null)
				loc = java.util.Locale.getDefault();

			logonLanguage = loc.getLanguage();
		} catch (com.sap.security.api.UMException ue) {
			log.traceThrowableT(Severity.ERROR, "Unable to find user " + user, ue);
			CAFBaseRuntimeException _caf_ex = new CAFBaseRuntimeException(log, "BO_USER_NOT_FOUND", new java.lang.Object[] {user}, ue);			
			throw _caf_ex;
		}   
		
		return logonLanguage;
	}
	

	
	private IPersistableStructure attach(IDependentObject structure, Structure metadata, String language) {
		IPersistableStructure persistable;
		try {
			persistable = (IPersistableStructure) metadata.getEntityClass().newInstance();
		} catch (InstantiationException e) {
			log.traceThrowableT(Severity.ERROR, "Unable to create an instance of " + persistentClass.getName(), e);
			throw new CAFBaseRuntimeException(log, "Unable to create an instance of " + persistentClass.getName(), e);
		} catch (IllegalAccessException e) {
			log.traceThrowableT(Severity.ERROR, "Unable to create an instance of " + persistentClass.getName(), e);
			throw new CAFBaseRuntimeException(log, "Unable to create an instance of " + persistentClass.getName(), e);
		}
		
		for (Attribute attribute : metadata.getAttributes().values()) {
			String attributeName = attribute.getName();
			
			switch(attribute.getType()) {
				case SIMPLE :
					persistable.setAttribute(attributeName, structure.getProperty(attributeName));
					break;
				case NESTED :
					IDependentObject subStructure = (IDependentObject) structure.getProperty(attributeName);
					if (subStructure != null) {
						persistable.setAttribute(attributeName, attach(subStructure, attribute.getReferencedEntity(), language));
					}
					break;
			}
		}

		//language dependent attributes
		Collection<Attribute> ldAttributes = metadata.getAttributes(AttributeType.LANGUAGE_DEPENDENT);
		if (!ldAttributes.isEmpty()) {
			Class ldClass = metadata.getLanguageDependentClass();
			assert ldClass.isInterface() : "A language dependent class can not be interface - " + ldClass.getName() + "!";
			ILanguageDependent ld;
			try {
				ld = (ILanguageDependent) ldClass.newInstance();
				ld.setLanguage(language);
			} catch (InstantiationException e) {
				log.traceThrowableT(Severity.ERROR, "Unable to create an instance of " + ldClass.getName(), e);
				throw new CAFBaseRuntimeException(log, "Unable to create an instance of " + ldClass.getName(), e);
			} catch (IllegalAccessException e) {
				log.traceThrowableT(Severity.ERROR, "Unable to create an instance of " + ldClass.getName(), e);
				throw new CAFBaseRuntimeException(log, "Unable to create an instance of " + ldClass.getName(), e);
			}
			Map<String, ILanguageDependent> ldAttributesMap = persistable.getLanguageDependentAttributes();// <language_name, ILanguageDependent>
			ldAttributesMap.put(getLogonLanguage(), ld);
			for (Attribute attribute : ldAttributes) {
				ld._setProperty(attribute.getName(), (String) structure.getProperty(attribute.getName()));
			}
		}
		return persistable;
	}
	
	private void checkExists(String key, Class<?> thePersistentClass) throws CAFDataAccessException {
		if ( hasInvalidKey(key) || entityManager.find(thePersistentClass, key) == null){
			throw new CAFDataAccessException (log, "BO_NOT_EXIST", new Object[] {key});
		}
	}
	
	private void checkAllKeysExist (String[] keys, Class<?> thePersistentClass) throws CAFDataAccessException {
		if (keys.length==0){
			return ;
		}
		boolean allExist = false;
		if (!hasInvalidKey(keys)){
			String entitySchemaName = PersistentClassHelper.getEntitySchemaName(thePersistentClass);
			StringBuilder jpaQLText = new StringBuilder("SELECT COUNT(obj) FROM ").append(entitySchemaName).append(" obj WHERE obj.key IN (");
			String comma = "";
			for (int i=0; i<keys.length;i++){
				jpaQLText.append(comma).append("?").append(i+1);
				comma = ",";
			}
			jpaQLText.append(")");
			Query jdoQuery = entityManager.createQuery(jpaQLText.toString());
			for (int i=0;i<keys.length;i++){
				jdoQuery.setParameter(i+1, convertToJPAValue(keys[i], String.class));
			}
			
			allExist = (keys.length == (Long)jdoQuery.getSingleResult());
		}
		if (!allExist){
			
			throw new CAFDataAccessException(log, "EXCEPTION_NON_EXISTING_BO_NODES",new Object[] {Arrays.toString( keys ),thePersistentClass.getSimpleName()});
		}
			
	}
	private static boolean hasInvalidKey(String... keys){
		for (String key: keys){
			if (key==null || key.trim().length() == 0){
				return true;
			}
		}
		return false;
	}
	
	/*
	 * This method should be removed in the future, when CAF 1.0 Applications are not supported anymore
	 */
	private boolean isBackwardCompatibleCustomKeyValidationCheckNeeded(){
		return CAF_1_1_0_VERSION.isHigher(this.boNodeEntityInfo.getVersion());
	}
	
	public Collection<IBusinessObjectNodeBase> jpaExecuteQuery(Query query)
	{
		List jpaEntities = query.getResultList();
		Collection<IBusinessObjectNodeBase> result = detachCollection(jpaEntities);
		return result;
	}
	
	public int jpaExecuteUpdate(Query query)
	{
		return query.executeUpdate();
	}
	
	public Query jpaCreateQuery(String jpaql)
	{
		return this.entityManager.createQuery(jpaql);
	}
}

