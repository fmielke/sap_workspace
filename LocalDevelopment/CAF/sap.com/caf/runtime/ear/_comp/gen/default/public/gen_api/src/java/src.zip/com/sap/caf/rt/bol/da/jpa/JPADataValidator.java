package com.sap.caf.rt.bol.da.jpa;

import com.sap.caf.rt.bol.da.jpa.model.Attribute;
import com.sap.caf.rt.bol.da.jpa.model.AttributeType;
import com.sap.caf.rt.bol.da.jpa.model.Structure;
import com.sap.caf.rt.exception.CAFMissingMandatoryValueException;
import com.sap.caf.rt.exception.CAFValueTooLongException;
import com.sap.tc.logging.Location;


public class JPADataValidator implements IDataValidator{
	
	private final static Location location = Location.getLocation(JPADataValidator.class);
	private Structure structure ;
	public final static int UNLIMITTED_LENGHT = -1;
	public JPADataValidator(Structure structure){
		this.structure = structure;
	}

	public void validateStructure(IPersistableStructure persistable) {
		validateStructureDownDeep(persistable,this.structure,"");	
	}
	
	private void validateStructureDownDeep(IPersistableStructure persistable, Structure theStructure,String namePrefix){
		
		for (Attribute attribute: theStructure.getAttributes().values()){
			Object value = persistable.getAttribute(attribute.getName());
			if ((attribute.getProperty(Attribute.KEY_MANDATORY)!=null) ){
				if (value == null){
					throw new CAFMissingMandatoryValueException(location,"BO_MANDATORY_VALUE_MISSING", new Object[]{namePrefix + attribute.getName()});
				}
			}
			if ((value!=null) && (value instanceof String)){
				String stringValue = (String)value;
				String length = (String)attribute.getProperty(Attribute.KEY_LENGHT);
				if( length != null){
					int len = Integer.parseInt(length);
					if (len != UNLIMITTED_LENGHT && stringValue.length()>len){
						throw new CAFValueTooLongException(location,"EXCEPTION_VALUE_TOO_LONG", new Object[]{namePrefix + attribute.getName(), stringValue,stringValue.length(),len});
					}
				}	
			}
			if (attribute.getType()==AttributeType.NESTED && value != null){
				validateStructureDownDeep((IPersistableStructure)value,attribute.getReferencedEntity(), namePrefix + attribute.getName() + "#");
			}	
		}
	}

}
