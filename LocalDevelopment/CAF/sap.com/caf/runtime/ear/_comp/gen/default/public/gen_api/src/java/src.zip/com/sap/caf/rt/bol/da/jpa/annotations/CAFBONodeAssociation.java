package com.sap.caf.rt.bol.da.jpa.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface CAFBONodeAssociation {
	String name();
	Class targetBOEntity() default java.lang.Object.class;
	Class crossClass() default java.lang.Object.class;
	CAFBONodeAssociationType type() default CAFBONodeAssociationType.LOCAL;
}
