package com.sap.caf.rt.bol.da.jpa.annotations;

public enum CAFBONodeAssociationType {
	LOCAL, REMOTE, CUSTOM
}
