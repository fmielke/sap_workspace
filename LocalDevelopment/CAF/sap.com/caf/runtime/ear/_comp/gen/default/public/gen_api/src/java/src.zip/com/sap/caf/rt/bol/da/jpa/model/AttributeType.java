package com.sap.caf.rt.bol.da.jpa.model;

public enum AttributeType {
	SIMPLE, LANGUAGE_DEPENDENT, NESTED
}
