package com.sap.caf.rt.bol.da.km;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;

import com.sap.caf.km.da.RidUtils;
import com.sap.caf.km.ejb.data.document.DocumentProxyEJBLocal;
import com.sap.caf.km.ejb.data.util.INodeContent;
import com.sap.caf.km.ejb.data.util.INodeHeader;
import com.sap.caf.km.ejb.data.util.KMNodeException;
import com.sap.caf.resources.CAFApplicationProperties;
import com.sap.caf.rt.bol.IBusinessObjectNodeBase;
import com.sap.caf.rt.bol.da.DataAccessFactory;
import com.sap.caf.rt.bol.da.IDataAccessService;
import com.sap.caf.rt.bol.da.km.internal.KMDataAccess;
import com.sap.caf.rt.bol.pk.PrimaryKeyFactory;
import com.sap.caf.rt.bol.util.Condition;
import com.sap.caf.rt.bol.util.OrderBy;
import com.sap.caf.rt.bol.util.Paging;
import com.sap.caf.rt.bol.util.QueryFilter;
import com.sap.caf.rt.bol.util.QueryFilterFactory;
import com.sap.caf.rt.exception.CAFDataAccessException;
import com.sap.caf.rt.exception.CAFFindException;
import com.sap.caf.rt.util.DateUtils;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;

/**
 * The <code>DocumentDataAccessService</code> is used to manage objects that are 
 * backended on KM side. Currently it is <code>sap.com/caf.core/DocumentService</code> only. 
 *
 * @author unattributed
 * @version 1.0, 01/01/04
 */
public class DocumentDataAccessService implements IDataAccessService {  //$JL-SER$
	private static final long serialVersionUID = 1;
	
	private static final Location location = Location.getLocation(DocumentDataAccessService.class);	
	private static final String JNDI_NAME_RELOBJECT = "/sap.com/caf~core~ear/LOCAL/com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObject/com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObjectServiceLocal";
													   
	private IDataAccessService jpaDataAccessService;
	private Class mainStruct;
	
	//Name of DocumentContent Object
//	private String m_sDocContentName = "sap.com/caf.core/DocumentContent";
	private boolean useDocContent = false;
	
	public void setUseDocContent(boolean rc){
		this.useDocContent = rc;
	}
	
	public DocumentDataAccessService(Map<String, Object> properties) throws CAFDataAccessException {
		try {
			this.mainStruct = (Class)properties.get(DataAccessFactory.BO_NODE_MAIN_STRUCT_CLASS_PROPERTY);
			jpaDataAccessService = DataAccessFactory.getDataAccessService(DataAccessFactory.DATASOURCE_JPA, properties);
		}
		catch(Exception ex) {
			location.traceThrowableT(Severity.ERROR, "Cannot get instance of document proxy bean", ex);
			throw new CAFDataAccessException(location, "Cannot get instance of document proxy bean");
		}
	}
	
	DocumentDataAccessService(IDataAccessService jpaDataAccessService) throws CAFDataAccessException {
		this.jpaDataAccessService = jpaDataAccessService;
	}

	/**
	 * @see com.sap.caf.rt.bol.da.IDataAccessService#destroy()
	 */
	public void destroy() {
	}

	/**
	 * @see com.sap.caf.rt.bol.da.IDataAccessService#create(com.sap.caf.rt.bol.IBusinessObjectNodeBase)
	 */
	public String create(IBusinessObjectNodeBase bo) throws CAFDataAccessException {
		Collection<IBusinessObjectNodeBase> bos = new LinkedList<IBusinessObjectNodeBase>();
		bos.add(bo);
		return this.create(bos).iterator().next();
	}
	
	public Collection<String> create(Collection<? extends IBusinessObjectNodeBase> bos) throws CAFDataAccessException {
		for (IBusinessObjectNodeBase bo : bos)
		{
			try {
					//store into KM
					KMDataAccess.getDocumentProxyService().createDocumentHeader(
							(String)bo.getProperty("documentId"),
							(String)bo.getProperty("parentFolder"),
							(String)bo.getProperty("title"),
							(String)bo.getProperty("description"),
							(String)bo.getProperty("link"),
							getRelatedObjectRids(bo.getKey())
						);
				
					//store document content
	//				if (m_sDocContentName.equals(bo.getObjectType())) {
					if (useDocContent){
						uploadDocumentContent(bo);
					}
			} catch (Exception ex) {
					location.traceThrowableT(Severity.ERROR, ex.getMessage(), ex);
					throw new CAFDataAccessException(location, ex);	
			}
		}
		//store into JDO
		Collection<String> retVal = jpaDataAccessService.create(bos);
		return retVal;
	}

	/**
	 * @see com.sap.caf.rt.bol.da.IDataAccessService#remove(com.sap.caf.rt.bol.da.IDataAccessContext, com.sap.caf.rt.bol.IBusinessObjectNodeBase)
	 */
	public void remove(IBusinessObjectNodeBase bo) throws CAFDataAccessException {
		Collection<IBusinessObjectNodeBase> bos = new LinkedList<IBusinessObjectNodeBase>();
		bos.add(bo);
		this.remove(bos);
	}
	
	public void remove(Collection<? extends IBusinessObjectNodeBase> bos) throws CAFDataAccessException {
		for (IBusinessObjectNodeBase bo : bos)
		{
			try {
				String documentId = (String)bo.getProperty("documentId");
				String parentFolder = (String)bo.getProperty("parentFolder");
				
				//Load Document if only KEY specified
				if (documentId==null && parentFolder==null) {
					bo = (IBusinessObjectNodeBase)load(bo.getKey());
					documentId = (String)bo.getProperty("documentId");
					parentFolder = (String)bo.getProperty("parentFolder");				
				}
				
				//delete from KM
				String docRepository = CAFApplicationProperties.getKMTmpRepositoryFolder();
				String rootBORid = RidUtils.getBORootFolder(docRepository, parentFolder + "/");
				if (rootBORid!=null) {
					KMDataAccess.getDocumentProxyService().deleteDocument(documentId, parentFolder);
					KMDataAccess.getFolderProxyService().deleteEmptyFolders(RidUtils.getName(rootBORid), RidUtils.getPath(rootBORid));
				}
				
	/*			
				KMDataAccess.getDocumentProxyService()
					.deleteDocument(documentId, parentFolder);
				
				jdoDataAccessService.remove(arg0);	
	*/				
			}
			catch(Exception ex) {
				location.traceThrowableT(Severity.ERROR, ex.getMessage(), ex);
				throw new CAFDataAccessException(location, ex);
			}
		}
		jpaDataAccessService.remove(bos);
	}

	/**
	 * @see com.sap.caf.rt.bol.da.IDataAccessService#query(java.lang.Class, com.sap.caf.rt.bol.util.IntQueryFilter[], java.lang.String)
	 * 
	 * The specified search is implemented for parentFolder/documentId 
	 * and parentFolder/documentTitle IntQueryFilter pairs
	 * 
	 * For parentFolder/documentId pair search in CAF JDO is performed and if nothing
	 * is found then search on KM is performed. If document is found on KM it 
	 * will be created in CAF JDO <br>
	 * For parentFolder/documentTitle pair search in KM is performed then
	 * for each found document method performs search in CAF JDO by documentId and 
	 * parentFolder attributes. If representation of KM document isn't found in 
	 * CAF JDO it will be created otherwice found Document KEY is used 
	 */
	public Collection<IBusinessObjectNodeBase> query(QueryFilter[] filters, String operationName) throws CAFDataAccessException {
		
		int fLength = filters.length;
		if (fLength>3) {
			return loadObjectsFromKM( jpaDataAccessService.query(filters, operationName) );
		}
		
		Collection result=null;
		String documentId=null;
		String parentFolder=null;
		String documentTitle=null;
		
		for (int i=0; i<fLength; i++) {
			String attr =  filters[i].getAttribute();			
			if ("documentId".equals(attr)) {
				documentId = (String)filters[i].getValueLow();
			} else if ("parentFolder".equals(attr)) {
				parentFolder = (String)filters[i].getValueLow();
			} else if ("title".equals(attr)) {
				documentTitle = (String)filters[i].getValueLow();
			} //else 
				//	break;		
		}
		
		if (documentId!=null && parentFolder!=null) {
		//search for document using documentId and parentFolder
			
			//search for document in JDO
			result = loadObjectsFromKM( jpaDataAccessService.query(filters, operationName) );
			
			//if nothing is found try to search Document on KM
			if (result.size()==0) {
				try {
						IBusinessObjectNodeBase doc = createDependentObject(documentId, parentFolder, null);
						
						doc = (IBusinessObjectNodeBase)loadObjectFromKM(doc);

						//create document in JDO						
						if (doc!=null) {							
//							createInJDO(doc);
							createInJPA(doc);
						}
											
						result.add(doc);
				} catch (Exception ex) {
					location.throwing(ex);
				}
			}
		} else if (documentTitle!=null && parentFolder!=null) {
		//search for document using parentFolder and document title			
			
			try {
				result = new ArrayList();
				Collection km_result = KMDataAccess.getDocumentProxyService().findDocument(parentFolder, documentTitle);
			
				//check is document exists in JDO
				Iterator i=km_result.iterator();
				while (i.hasNext()) {
					IBusinessObjectNodeBase doc = createDependentObjectByRid((String)i.next());
					documentId = (String)doc.getProperty("documentId");
								
					//check if such document is already created in JDO				
					Collection jpa_result = 
						jpaDataAccessService.query(createQueryToJDOSearch(documentId, parentFolder), operationName);
				
					if (jpa_result.size()>0) {
						result.add( loadObjectFromKM( (IBusinessObjectNodeBase)jpa_result.iterator().next() ) );
					} else {
						createInJPA(doc);
						result.add( loadObjectFromKM(doc) );
					}
				}				
				
			} catch (Exception ex) {
				location.throwing(ex);
			}
		} else {
			//Not specified search
			result = loadObjectsFromKM( jpaDataAccessService.query(filters, operationName) );
		}
		
		return result;
	}

	/**
	 * @see com.sap.caf.rt.bol.da.IDataAccessService#load(java.lang.Object, java.lang.Class)
	 */
	public IBusinessObjectNodeBase load(String objId) throws CAFDataAccessException {
		try {
			IBusinessObjectNodeBase obj = jpaDataAccessService.load(objId);
			
			//create new instance of Class in order to get instance that not registered in JDO manager
			IBusinessObjectNodeBase newObj = createDependentObject(
															obj.getProperty("documentId"),
															obj.getProperty("parentFolder"),
															obj.getProperty("key"));
			 
			//load document from km			
			newObj = loadObjectFromKM(newObj);
						
			return newObj;
			
		} catch(Exception ex) {
			location.traceThrowableT(Severity.ERROR, ex.getMessage(), ex);
			throw new CAFDataAccessException(location, ex);
		}			
	}

	/**
	 * The method loads document from JDO only without quiries to KM.
	 * 
 	 * @param clazz          a Class of the object that should be loaded.
 	 * @param parentFolder  a String parent folder identifier.
 	 * @param documentId    a String value of document identifier. 
 	 * @return an instance of @link IBusinessObjectNodeBase representing document
 	 * @throws CAFDataAccessException if operation fails. 
	 */
	public Object loadFromJDO(String parentFolder, String documentId) throws CAFDataAccessException {
							
			try {
 				//check if such document is already created in JDO				
				Collection jdo_result = 
						jpaDataAccessService.query(createQueryToJDOSearch(documentId, parentFolder), null);

				IBusinessObjectNodeBase doc = null;						
				if (jdo_result.size()>0) {
						doc = (IBusinessObjectNodeBase)jdo_result.iterator().next();
				}
				return doc;												
			} catch (Exception ex) {
				location.traceThrowableT(Severity.ERROR, ex.getMessage(), ex);
				throw new CAFDataAccessException(location, ex);
			}
	}

	/**
	 * @see com.sap.caf.rt.bol.da.IDataAccessService#store(com.sap.caf.rt.bol.da.IDataAccessContext, com.sap.caf.rt.bol.IBusinessObjectNodeBase)
	 */
	public void store(IBusinessObjectNodeBase bo) throws CAFDataAccessException {
		Collection<IBusinessObjectNodeBase> bos = new LinkedList<IBusinessObjectNodeBase>();
		bos.add(bo);
		this.store(bos);
	}
	
	public void store(Collection<? extends IBusinessObjectNodeBase> bos) throws CAFDataAccessException {
		jpaDataAccessService.store(bos);
		for (IBusinessObjectNodeBase bo : bos)
		{
			try {
					KMDataAccess.getDocumentProxyService().saveDocumentHeader(
											(String)bo.getProperty("documentId"), 
											(String)bo.getProperty("parentFolder"), 
											(String)bo.getProperty("title"), 
											(String)bo.getProperty("description"), 
											(String)bo.getProperty("link"),
											getRelatedObjectRids(bo.getKey())
										);
					//store document content
	//				if (m_sDocContentName.equals(bo.getObjectType())) {
					if (useDocContent){
						uploadDocumentContent(bo);
					}
					
			} catch (Exception ex) {
				location.traceThrowableT(Severity.ERROR, ex.getMessage(), ex);
				throw new CAFDataAccessException(location, ex);
			}
		}
	}

	private Collection getRelatedObjectRids(String key) throws CAFDataAccessException {
		String[] relObjKeys = jpaDataAccessService.getCardinalityManyAssociationTargetKeys(key, "relatedObjectRefs");
		Collection<String> relObjRids = null;
		if (relObjKeys!=null && relObjKeys.length>0) {
			try {
				Context jndiContext = new InitialContext();
				Object relObjLocal = jndiContext.lookup(JNDI_NAME_RELOBJECT);
				Method relObjLocalReadMethod = relObjLocal.getClass().getMethod("read", new Class[] {String.class});
				relObjRids = new ArrayList<String>(relObjKeys.length);
				for(int i=0; i<relObjKeys.length; i++) {
					IBusinessObjectNodeBase relObj = (IBusinessObjectNodeBase) relObjLocalReadMethod.invoke(
							relObjLocal, new Object[] {relObjKeys[i]});
					relObjRids.add((String)relObj.getProperty("refObjectRid"));
				}
			} catch (Exception ex) {
				location.traceThrowableT(Severity.ERROR, ex.getMessage(), ex);
				throw new CAFDataAccessException(location, ex);
			}
		}
		return relObjRids;
	}
	
	/**
	 * Load collection of Document from KM
	 * 
	 * @param col	Collection of Document's with specified parentFolder 
	 * 				and documentId attributes.
	 * @return		Collection of Documents
	 * @throws CAFDataAccessException
	 */	
	private Collection loadObjectsFromKM(Collection col) throws CAFDataAccessException {
		Iterator i = col.iterator();
		Collection result = new ArrayList();
		while (i.hasNext()) {
			try {
				IBusinessObjectNodeBase obj = loadObjectFromKM((IBusinessObjectNodeBase)i.next());
				if (obj!=null)
					result.add(obj);
			}catch(CAFDataAccessException e){
				location.throwing(e);
			}
		}
		return result;
	}
	
	/**
	 * Load Document from KM
	 * 
	 * @param obj	Instance of Document with specified parentFolder 
	 * 				and documentId attributes 
	 */
	private IBusinessObjectNodeBase loadObjectFromKM(IBusinessObjectNodeBase obj) throws CAFDataAccessException {
	try {
		DocumentProxyEJBLocal docProxy = KMDataAccess.getDocumentProxyService();
			INodeHeader header =	docProxy.readDocumentHeader((String)obj.getProperty("documentId"),
										(String)obj.getProperty("parentFolder"));

			//load document atributes
			obj.setProperty("title", header.getDisplayName());
			obj.setProperty("description",header.getDescription());
			obj.setProperty("createdAt", DateUtils.fromDate( header.getCreationdate().getTime()) );
			obj.setProperty("createdBy", header.getCreatedBy());
			obj.setProperty("modifiedAt", DateUtils.fromDate( header.getLastmodifieddate().getTime()) );
			obj.setProperty("modifiedBy", header.getLastmodifiedBy());
			obj.setProperty("link", header.getLink());
	
			//load document content if DocumentContent is requested
//			if (m_sDocContentName.equals(obj.getObjectType())) {
			if (useDocContent){
				INodeContent data = docProxy.readDocumentContent((String)obj.getProperty("documentId"), 
						(String)obj.getProperty("parentFolder"));
					
				obj.setProperty("contentEncoding", data.getContentEncoding());
				obj.setProperty("contentType", data.getContentType());
				obj.setProperty("contentLength", new Long(data.getContentLength()));				
				obj.setProperty("content", data.getContent());					
			} else {
				INodeContent contentParams = docProxy.readDocumentContentParams((String)obj.getProperty("documentId"), 
						(String)obj.getProperty("parentFolder"));
				obj.setProperty("contentEncoding", contentParams.getContentEncoding());
				obj.setProperty("contentType", contentParams.getContentType());
				obj.setProperty("contentLength", new Long(contentParams.getContentLength()));
			}

			return obj;
		}
		catch (Exception ex) {
			location.traceThrowableT(Severity.ERROR, ex.getMessage(), ex);
			throw new CAFDataAccessException(location, ex);
		}
	}

	
	/**
	 * Uploads document content into KM
	 * 
	 * @param bo	DocumentContent object Instance to upload
	 */
	private void uploadDocumentContent(IBusinessObjectNodeBase bo) throws KMNodeException, CAFFindException {
		KMDataAccess.getDocumentProxyService()
				.saveDocumentContent((String)bo.getProperty("documentId"),
									 (String)bo.getProperty("parentFolder"),
									 ((Long)bo.getProperty("contentLength")).longValue(),
									 (String)bo.getProperty("contentType"),
									 (String)bo.getProperty("contentEncoding"),
									 (byte[])bo.getProperty("content"));																
	}
	
	/**
	 * Create object in JDO. 
	 * The method generates KEY for object.
	 * 
	 * @param bo	Object to create
	 * @throws CAFDataAccessException
	 */
	private void createInJPA(IBusinessObjectNodeBase bo) throws CAFDataAccessException {
		bo.setProperty("key", PrimaryKeyFactory.getInstance().getPrimaryKey());
		jpaDataAccessService.create(bo);
	}
	
	/**
	 * Create IBusinessObjectNodeBase Object with specified documentId and parentFolder attributes
	 * 
	 * @param clazz			Class to create
	 * @param documentId	Value of documentId attribute
	 * @param parentFolder	Value of parentFolder attribute
	 * @param key			Value of key attribute
	 */
	private IBusinessObjectNodeBase createDependentObject(Object documentId, Object parentFolder, Object key) throws InstantiationException, IllegalAccessException {
		IBusinessObjectNodeBase obj = (IBusinessObjectNodeBase)mainStruct.newInstance();
		obj.setProperty("documentId", (String)documentId );
		obj.setProperty("parentFolder", (String)parentFolder );
		obj.setProperty("key", (String)key );
		
		return obj;											
	}
	
	/**
	 * Create query filters to JDO search for document by 
	 * parentFolder and documentId
	 * 
	 * @param documentId		KM Document Id to search
	 * @param parentFolder		KM Folder RID to search in
	 * @return
	 */
	private static QueryFilter[] createQueryToJDOSearch(String documentId, String parentFolder) {
		QueryFilter fParentFolder = QueryFilterFactory.createFilter("parentFolder", Condition.EQ, parentFolder);				
		QueryFilter fDocumentId = QueryFilterFactory.createFilter("documentId",Condition.EQ,documentId);;
		
		return new QueryFilter[] {fParentFolder,QueryFilterFactory.createBoolOperator(QueryFilter.OPERATION_AND), fDocumentId}; 
	}
	
	private IBusinessObjectNodeBase createDependentObjectByRid(String rid) throws IllegalAccessException, InstantiationException {
		IBusinessObjectNodeBase obj = (IBusinessObjectNodeBase)this.mainStruct.newInstance();
		
		obj.setProperty("documentId", RidUtils.getName(rid));
		obj.setProperty("parentFolder", RidUtils.getPath(rid));
		 
		return obj;
	}
	
	public IBusinessObjectNodeBase loadByCustomKeys(IBusinessObjectNodeBase obj) throws CAFDataAccessException {
		return null;
	}

	public String getCardinalityOneAssociationTargetKey(String sourceKey, String associationName) throws CAFDataAccessException {
		return jpaDataAccessService.getCardinalityOneAssociationTargetKey(sourceKey, associationName);
	}

	public void setCardinalityOneAssociationTargetKey(String sourceKey, String targetKey, String associationName, boolean isComposition) throws CAFDataAccessException {
		jpaDataAccessService.setCardinalityOneAssociationTargetKey(sourceKey, targetKey, associationName, isComposition);
	}

	public String[] getCardinalityManyAssociationTargetKeys(String sourceKey, String associationName) throws CAFDataAccessException {
		return jpaDataAccessService.getCardinalityManyAssociationTargetKeys(sourceKey, associationName);
	}

	public void addCardinalityManyAssociationTargetKeys(String sourceKey, String[] targetKeys, String associationName) throws CAFDataAccessException {
		jpaDataAccessService.addCardinalityManyAssociationTargetKeys(sourceKey, targetKeys, associationName);
	}

	public void removeCardinalityManyAssociationTargetKeys(String sourceKey, String[] targetKeys, String associationName, boolean isComposition) throws CAFDataAccessException {
		jpaDataAccessService.removeCardinalityManyAssociationTargetKeys(sourceKey, targetKeys, associationName, isComposition);
	}
	
	void setJDODataAccessService(IDataAccessService jdoDataAccessService)
	{
		this.jpaDataAccessService = jdoDataAccessService;
	}

	/**
	 * OrderBy and Paging are not implemented for this data access service
	 */
	public Collection<? extends IBusinessObjectNodeBase> query(QueryFilter[] filters, OrderBy orderBy, Paging paging,
			String operationName) throws CAFDataAccessException {
		return query(filters, operationName);
	}
}