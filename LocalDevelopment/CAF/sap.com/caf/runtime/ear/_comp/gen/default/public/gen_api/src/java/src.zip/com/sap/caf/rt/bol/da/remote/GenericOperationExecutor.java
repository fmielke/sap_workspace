package com.sap.caf.rt.bol.da.remote;

import java.util.List;
import java.util.Locale;

import com.sap.caf.foundation.mm.cafmm.ICAFOperation;
import com.sap.caf.rt.connectivity.ConnectivityFactory;
import com.sap.caf.rt.connectivity.IExternalOperationExecutor;
import com.sap.caf.rt.connectivity.exception.CAFExtExecException;
import com.sap.caf.rt.connectivity.exception.CAFMappingException;
import com.sap.caf.rt.exception.CAFDataAccessException;
import com.sap.caf.rt.exception.CAFServiceException;
import com.sap.caf.rt.metamodel.MetaModel;
import com.sap.caf.rt.metamodel.MetaModel.MetadataSource;
import com.sap.tc.logging.Location;

/**
 * Class used for execution of generic external operations.
 * 
 * @author I028506 Trendafil Madarov
 *
 */
public class GenericOperationExecutor {
	private static final Location location = Location.getLocation(GenericOperationExecutor.class);

	private static GenericOperationExecutor instance;
	private IExternalOperationExecutor executor;
	private GenericOperationExecutor() {		
		executor = ConnectivityFactory.getExternalOperationExecutor();
	}
	
	/**
	 * Returns the singleton instance of the class
	 * @return returns the singleton instance of the class
	 */
	public static GenericOperationExecutor getInstance() {
		if (instance==null) {
			instance = new GenericOperationExecutor();						
		}
		return instance;
	}
	
	public Object execute(List params, String internalOperationGUID, Locale locale, ClassLoader classLoader) throws CAFServiceException {
		List result;
		try {
			ICAFOperation internalOperation = MetaModel.getInstance().getOperationByGUID(internalOperationGUID, MetadataSource.MMR);
			if (!hasOperationMapping(internalOperation)) { 
				throw new CAFServiceException(location, "SERVICE_OPERATION_NOT_MAPPED",  new Object[] {internalOperation.getName()});
			}
			ICAFOperation externalOperation = internalOperation.getInternalMapping().getExternalMappingHostOperation();
			if (externalOperation==null) {
				throw new CAFServiceException(location, "Internal operation is not mapped to an external operation.");
			}
			result = executor.execute(params, internalOperation, externalOperation, locale, 
					classLoader);
		} catch (CAFMappingException e) {
			throw new CAFServiceException(location, e);
		} catch (CAFExtExecException e) {
			throw new CAFServiceException(location, e);			
		} catch (CAFDataAccessException e) {
			throw new CAFServiceException(location, e);			
		}
		if ((result==null) || (result.size()==0)) {
			return null;
		} else {
			return result.get(0);
		}
	}	
	
	/**
	 * Checks if specified operation is mapped to another operation. 
	 * @param cafOperation caf operation
	 * @return true if has operation mapping, false otherwise.
	 */
	public boolean hasOperationMapping(ICAFOperation cafOperation) {
		return cafOperation.getInternalMapping() != null;
	}
}