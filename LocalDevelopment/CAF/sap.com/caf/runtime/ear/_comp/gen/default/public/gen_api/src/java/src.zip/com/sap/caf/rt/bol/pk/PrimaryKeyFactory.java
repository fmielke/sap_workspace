package com.sap.caf.rt.bol.pk;

import com.sap.caf.rt.exception.CAFDataAccessException;
import com.sap.guid.GUIDGeneratorFactory;

/**
 * @author d025479
 */
public class PrimaryKeyFactory {

	private static PrimaryKeyFactory primKeyFactory = null;

	private PrimaryKeyFactory() throws CAFDataAccessException {
	}
	
	/** This getInstance method provides singleton access to the
	*   PrimaryKeyFactory.
	*/
	public static synchronized PrimaryKeyFactory getInstance()
		throws CAFDataAccessException {
		if (primKeyFactory == null)
			primKeyFactory = new PrimaryKeyFactory();
		return primKeyFactory;
	}

	/** This method returns a GUID as technical primary key of the Business Object,
	 *  This key is used as identity of the persistent object
	 *  (primary key of the database tables and of the JDO instance) and as logical
	 *  foreign key in relations between business objects and dependent objects
	*/
	public String getPrimaryKey() {
		String guid =
			GUIDGeneratorFactory
				.getInstance()
				.createGUIDGenerator()
				.createGUID()
				.toString();
		return guid;
	}
}
