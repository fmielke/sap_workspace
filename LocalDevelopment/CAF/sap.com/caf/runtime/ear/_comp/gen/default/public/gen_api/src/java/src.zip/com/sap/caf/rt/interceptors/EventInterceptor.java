package com.sap.caf.rt.interceptors;

import java.lang.reflect.Method;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

import com.sap.caf.resources.CAFApplicationProperties;
import com.sap.caf.rt.bol.IBusinessObjectNodeBase;
import com.sap.caf.rt.services.eventing.EventCache;
import com.sap.caf.rt.services.eventing.OperationType;
import com.sap.caf.rt.services.eventing.ValueObjectChangedData;
import com.sap.security.api.UMFactory;
import com.sap.tc.logging.Location;


/**
 * Class for registering events, when BO Node state is changed. The following states
 * are monitoring: create, update and delete. The events capture the old and/or  
 * new value of the BO Node main structure. If the eventing is not provided  
 * by the StateChangeProvider the interceptor proceed the invocation chan.
 * 
 * @author I031910
 *
 */
public class EventInterceptor {
    
    
	private static Location loc = Location.getLocation(EventInterceptor.class);
	
	/**
	 * Constructor of event interceptor.
	 *
	 */
	public EventInterceptor() {
	}
	
	
	/**
	 * Register state change events. The events must be registered after
	 * create, update and delete BONode methods are invoked.
	 * 
	 */
	@AroundInvoke
	public Object registerEvents(InvocationContext ctx) throws Exception {
		if (!isEnable()) {
			return ctx.proceed();
		}
		
		Method method = ctx.getMethod();
		
		Object result = null;
		String originator = UMFactory.getLogonAuthenticator().getLoggedInUser().getName();
		String methodName = method.getName();
		if ("create".equals(methodName)) {
			// call create 
			result = ctx.proceed();
			IBusinessObjectNodeBase boNode = (IBusinessObjectNodeBase) result;
			
			ValueObjectChangedData changeData = new ValueObjectChangedData(null, boNode);
			EventCache.getInstance().put(changeData, OperationType.CREATE, originator);
		} else if ("update".equals(methodName)) {
			// before update, call read
			Object target = ctx.getTarget();
			IBusinessObjectNodeBase param = (IBusinessObjectNodeBase)ctx.getParameters()[0];
			Method read = target.getClass().getMethod("read", new Class[]{String.class});
			
			IBusinessObjectNodeBase oldValue = 
				(IBusinessObjectNodeBase)read.invoke(target, new Object[] {param.getKey()});
			
			// call update
			result = ctx.proceed();

			IBusinessObjectNodeBase newValue = 
				(IBusinessObjectNodeBase)read.invoke(target, new Object[] {param.getKey()});

			ValueObjectChangedData changeData = new ValueObjectChangedData(oldValue, newValue);
			EventCache.getInstance().put(changeData, OperationType.UPDATE, originator);
		} else if ("delete".equals(methodName)) {
			Object target = ctx.getTarget();
			IBusinessObjectNodeBase param = (IBusinessObjectNodeBase)ctx.getParameters()[0];
			Method read = target.getClass().getMethod("read", new Class[]{String.class});			
			IBusinessObjectNodeBase oldValue = 
				(IBusinessObjectNodeBase)read.invoke(target, new Object[] {param.getKey()});
			
			// call delete 
			result = ctx.proceed();
			
			ValueObjectChangedData changeData = new ValueObjectChangedData(oldValue, null);
			
			EventCache.getInstance().put(changeData, OperationType.DELETE, originator);
		} else if (methodName.startsWith("add") || methodName.startsWith("remove") || methodName.startsWith("set")) {
			String methodSuffix = null;
			if (methodName.startsWith("add") || methodName.startsWith("set")) {
				methodSuffix = methodName.substring(3);	
			} else if (methodName.startsWith("remove")) {
				methodSuffix = methodName.substring(6);	
			}
			 
			String relationName = methodSuffix;
			String sourceKey = (String) ctx.getParameters()[0];
			
			Object target = ctx.getTarget();
			Method getter = target.getClass().getMethod("get"+methodSuffix, new Class[]{String.class});
			Object oldValue =  getter.invoke(target, sourceKey);
 
			// call update
			result = ctx.proceed();
			
			Object newValue = getter.invoke(target, sourceKey);
			
			Method read = target.getClass().getMethod("read", new Class[]{String.class});
			IBusinessObjectNodeBase source = 
				(IBusinessObjectNodeBase)read.invoke(target, new Object[] {sourceKey});
			
			ValueObjectChangedData changeData = new ValueObjectChangedData(source, relationName, oldValue, newValue);
			EventCache.getInstance().put(changeData, OperationType.UPDATE, originator);
		} else {
			result = ctx.proceed();	
		}
		
		return result;
		
	}
	
	/**
	 * Returns true if event is configured to accept state change events.
	 * @see com.sap.caf.rt.bol.context.CAFContext.PUBLISH_ENABLED
	 * @return true if eventing is enabled, false otherwise.
	 */
	public boolean isEnable() {
		return CAFApplicationProperties.getPublishEnabled();
	}
	
}
