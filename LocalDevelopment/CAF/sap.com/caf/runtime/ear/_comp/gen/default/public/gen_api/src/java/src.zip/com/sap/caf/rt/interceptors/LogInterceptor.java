package com.sap.caf.rt.interceptors;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;

public class LogInterceptor {

	@javax.annotation.Resource
	private javax.ejb.SessionContext sessionContext;
	
	private final Map<Class<?>, Location> locations;

	public LogInterceptor() {
		this.locations = new ConcurrentHashMap<Class<?>, Location>();
	}
	
	@AroundInvoke
	@SuppressWarnings("unused")
	private Object aroundInvoke(InvocationContext invocationContext) throws Exception {
		Object[] parameters = invocationContext.getParameters();
		Class<?> targetClass = invocationContext.getMethod().getDeclaringClass();

		Location location = this.locations.get(targetClass);
		if (location == null)
		{
			// Here we risk getting more than one Location's for a given class but that is not a problem.
			// It is important that Location's are not constructed in big quantities in a short amount of time.
			// That is why synchronization is not required.
			location = Location.getLocation(targetClass);
			this.locations.put(targetClass, location);	
		}
		
		String methodSignature = null;
		if (location.beWarning())
		{
			StringBuilder buf = new StringBuilder();
			buf.append(invocationContext.getMethod().getName());
			buf.append('(');
			if (parameters != null && parameters.length != 0) {
				for (Class<?> parameter : invocationContext.getMethod().getParameterTypes()) {
					buf.append(parameter.getSimpleName()).append(',');
				}
				buf.deleteCharAt(buf.length() - 1);
			}
			buf.append(')');
	
			// TODO check the usage of Method.toString() and Method.toGenericString()
			methodSignature = buf.toString();
		}

		Object retval = null;
		try {
			retval = invocationContext.proceed();
			return retval;
		} catch (RuntimeException ex) {
			location.traceThrowableT(Severity.WARNING, methodSignature, "Error invoking " + methodSignature, ex);			
			throw ex;
		} catch (Exception ex) {
			location.traceThrowableT(Severity.WARNING, methodSignature, "Error invoking " + methodSignature, ex);			
			throw ex;
		}
	}

}
