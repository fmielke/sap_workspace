/*
 * Created on Aug 13, 2003
 */
package com.sap.caf.rt.security.acl;

/**
 * @author I028584
 */

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.naming.NamingException;

import com.sap.caf.rt.bol.IBusinessObjectNodeBase;
import com.sap.caf.rt.exception.CAFDataAccessException;
import com.sap.caf.rt.exception.CAFPermissionException;
import com.sap.caf.rt.metamodel.MetaModel.MetadataSource;
import com.sap.caf.rt.security.ipermission.InheritedPermission;
import com.sap.caf.rt.security.ipermission.InheritedPermissionsUtils;
import com.sap.caf.rt.security.srv.ServicePermission;
import com.sap.caf.rt.security.util.CAFBusinessRuleList;
import com.sap.caf.rt.security.util.CAFPermissionCache;
import com.sap.caf.rt.security.util.CAFPermissionName;
import com.sap.caf.rt.security.util.CAFPermissionUtil;
import com.sap.security.api.IPrincipal;
import com.sap.security.api.IPrincipalFactory;
import com.sap.security.api.IUser;
import com.sap.security.api.IUserFactory;
import com.sap.security.api.PrincipalNotAccessibleException;
import com.sap.security.api.UMException;
import com.sap.security.api.UMFactory;
import com.sap.security.api.acl.IAcl;
import com.sap.security.api.acl.IAclEntry;
import com.sap.security.api.acl.IAclManager;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;

/**
 * Programming Guide for ACL Permission Check and Service Permission Check. ACL Permission Check allows 
 * performing permission check based on individual business object instance. Service permission check 
 * allows checking whether a user is allowed to access the service method that is provided by service object.
 * <p>
 * ACL Permission Check allows checking whether the login user has been granted the authorization to access 
 * the object instance. Two levels of permission check are applied. The first one applies to the instance. 
 * Here are the lists of the permissions 
 * used by CAF; "read", "create", "update", "delete", "fullcontrol".
 * Whoever has the "read" permission can retrieve the instance. Whoever has the "create" permission can create 
 * a new instance. Whoever has the "update" permission can retrieve and modify the instance. Whoever has 
 * the "delete" permission can retrieve the instance as well as delete the instance.
 * Whoever is "fullcontrol" permission can retrieve, create, modify and delete the instance. 
 * <p>
 * The second permission check is based on business rule. While CAF provides rule maintenance screen, 
 * here are some notes to high light.
 * The operators for condition of the rule as follows:<br>
 * "EQ" - equal to the low attribute value<br>
 * "NE" - not equal to the low attribute value<br> 
 * "LT" - less than the low attribute value<br>
 * "LE" - less equal to the low attribute value<br>
 * "GT" - greater than the low attribute value<br>
 * "GE" - greater equal to the low attribute value<br>
 * "BT" - greater equal to the low attribute value and less equal to the high attribute value<br>
 * <P>
 * The supported data types of the attribute in condition are defined as follows:<br>
 * "int" - the attribute of the object is "int" data type<br>
 * "String" - the attribute of the object is "String" data type<br>
 * "Date" - the attribute of the object is "Date" data type. The "Date" class is from java.util package. While it parses to the "String"
 * 			from "Date" object, FormatDate.getInstance().format(Date) has to be used.<br>
 * "Collection" - the attribute of the object is a "Collection" data type. A "Collection" data type in CAF means that the instance has the
 * 			cardinality 1:n. In other word, it is a java util.Set class.  However, we only support one level of Collection despite the possibility
 * 			of n-level Collection. In other word, the objects store in the "Collection" must be "int", "String, or "Date" data type.<br>
 * <P>
 * All business rules and attribute list are cache during the run time to improve the efficiency. The cache scope is per VM and its life span of the
 * cache is per server. Hence, it is important to reload the cache after any business rule or attribute list are modified during the run time. 
 * To reload the cache, one must call the API CAFPermission.resetCache().<br>
 * <P>
 * Service permission check requires quite a bit of configuration during the installation. Please refer to "CAF Permission User Configuration Guide" 
 * for details. In the design time, the designer assigns a permission to service method during the service object creation. There are six permissions.
 * "read", "write", "modify", "delete" and "fullcontrol". "read" is a member of "modify" and "delete". "write" is a member of "modify".
 * "modify" and "delete" is a member of "fullcontrol". There are five UME roles that are created during the configuration. They are<br>
 * "CAFServiceReadRole"<br>
 * "CAFServiceWriteRole"<br>
 * "CAFServiceDeleteRole"<br>
 * "CAFServiceModifyRole"<br>
 * "CAFServiceFullcontrolRole"<br>
 *  <p>
 * If the login user is intended to access a service method that is assign to a particual permission, 
 * the login user must have the proper UME role in order to access the service method. Please refer to 
 * the name of the CAF role that is corresponding to the permission level.
 * 
 * For example,the role "CAFServiceWriteRole" is assigned to "write" permission that is 
 * allowed to "read" and "write" permission.
 */
public class CAFPermission {  
	public static final int MODE_CHECK_ONLY_FOR_INSTANCE = 2;
	public static final int MODE_CHECK_ONLY_FOR_BUSINESS_RULES = 4;
	public static final int MODE_CHECK_PROPAGATED_PERMISSIONS = 8;
	public static final int MODE_CHECK_ALL = MODE_CHECK_ONLY_FOR_INSTANCE + MODE_CHECK_ONLY_FOR_BUSINESS_RULES + MODE_CHECK_PROPAGATED_PERMISSIONS;

	private static final String APPLICATION_ID = "CAF";

	private static final Location location = Location.getLocation(CAFPermission.class);

	private static IAclManager s_aclManager = UMFactory.getAclManager(APPLICATION_ID);
	private static IUserFactory s_userFactory = UMFactory.getUserFactory();
	private static IPrincipalFactory s_principalFactory = UMFactory.getPrincipalFactory();

	static {
		try {
			createDefaultPermissionHierarchy();
		} catch (Exception e) {
			String method = "Static block";
			location.traceThrowableT(Severity.ERROR,"AUTH_PERMISSION_ERROR",new Object[]{method,e.getMessage()},e);
		};
	}
	
	/**
	 * <p>
	 * Check permission for the userId. Check instance permission based on the user id and permission name
	 * first. If the user id has the permission to access the instance, simply returns true, otherwise,
	 * check permission based on business rules. 
	 * @param object instance of the target object.
	 * @param userID user Id of the IUser that is subjected for permission check
	 * @param permissionName is the permission such as "read" or 'write' etc that the user is attempted to 
	 * the object
	 * @param objectType identifies the object class
	 * @return boolean 'true'indicatess the permission is granted, 'false' indicates the permission is denied  
	 * @exception PermissionException
	 * <p>
	 */
	
	public static boolean checkAclPermission(IBusinessObjectNodeBase object, String principalID, String permissionName, 
		String objectType, int mode) throws CAFPermissionException {
			final String method = "checkAclPermission(Object, String, String, String)" ;

			IPrincipal principal = null;
			try{	
				principal = getPrincipal(principalID) ;
			}catch(UMException e){
				location.traceThrowableT(Severity.ERROR,"AUTH_PERMISSION_ERROR",new Object[]{method,e.getMessage()},e);
				throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR",new Object[]{method,e.getMessage()}, e);

			}
			return checkAclPermission(object, principal, permissionName, objectType, null, mode) ;
	}
	
	public static boolean checkAclPermission(IBusinessObjectNodeBase object, String principalID, String permissionName,
		String objectType) throws CAFPermissionException {
		return checkAclPermission(object, principalID, permissionName, objectType, MODE_CHECK_ALL);
	}
	
	private static boolean isInstancePermitted(String instanceKey, IPrincipal principal, String permissionName) throws CAFPermissionException {
		return instanceKey != null ? hasAclPermission(principal, instanceKey, permissionName) : false;
	}

	private static boolean isBusinessRulePermitted(IBusinessObjectNodeBase object, String objectType, String permissionName, String boRuleID, IPrincipal principal) throws CAFPermissionException, Exception {
		
		CAFBusinessRuleList ruleList = CAFPermissionCache.getInstance().getBusinessRules(objectType, MetadataSource.BOTH);
		
		if (ruleList == null) {
			return false;	
		}
		
		List businessRulesList = ruleList.getBusinessRulesList();
				
		Object[] attrCache = ruleList.getEmptyAttributeCache();
		for (int i=0, rulesCount = businessRulesList.size(); i< rulesCount; i++) {
					
			boolean isObjectFulfillBusinessRuleCondition = false;
					
			if (object==null) {
				isObjectFulfillBusinessRuleCondition = true;
			} else {
				isObjectFulfillBusinessRuleCondition =
					ruleList.objectFulfillBusinessRuleCondition(object, permissionName, i, attrCache, principal); 
			}
					  
			if (isObjectFulfillBusinessRuleCondition) {
						
				String ruleID = ruleList.getBusinessRule(i).getRuleID();

				//check permissions for boRuleID only
				if ((boRuleID != null)&&(!boRuleID.equals(ruleID))){
					continue ;
				}

        if (hasAclPermission(principal, ruleID, permissionName)) {
          return true;
        }
			}
		}
		return false;
	}
	
	private static boolean isOneOfRelatedObjectsPermitted(IBusinessObjectNodeBase object, String permissionName, IPrincipal principal, Set<String> passedKeys) throws Exception {
		if (!CAFPermissionName.create.equals(permissionName) && object != null) {
			Set<InheritedPermission> inheritedPermissions = InheritedPermissionsUtils.getInheritedPermissions(object.getKey());
			String businessObjectKey = ((IBusinessObjectNodeBase)object).getKey();
			passedKeys.add(businessObjectKey);
			
			Iterator<InheritedPermission> i = inheritedPermissions.iterator();
			while (i.hasNext()) {
				InheritedPermission inheritedPermission = i.next();
				String inheritedPermissionKey = inheritedPermission.getPropagatingBONodeInstanceID();
				String inheritedPermissionObjectTypeName = inheritedPermission.getPropagatingBONodeObjectType();
			
				if (passedKeys.contains(inheritedPermissionKey)) {
					CAFPermissionException pe = new CAFPermissionException(location, "AUTH_CYCLING_IN_PROPAGATED_PERMS", new Object [] {passedKeys.toString()} );
					location.traceThrowableT(Severity.INFO,pe.getLocalizedMessage(),pe);
					//throw pe;
				}
			
				try {
					IBusinessObjectNodeBase relatedObject = CAFPermissionUtil.getDependentObject(inheritedPermissionKey, inheritedPermissionObjectTypeName, MetadataSource.BOTH);
	
					if (isInstancePermitted(inheritedPermissionKey, principal, permissionName)) {
						return true;
					} 
				
					if (isBusinessRulePermitted(relatedObject, inheritedPermissionObjectTypeName, permissionName, null, principal)) {
						return true;
					}
			
					if (isOneOfRelatedObjectsPermitted(relatedObject, permissionName, principal, passedKeys)) {
						return true;
					}
				} catch (Exception e) {
					location.traceThrowableT(Severity.INFO,e.getMessage(),e);
				}	
			}
		}
		return false;
	}
	/**
	 * <p>
	 * Check permission for the userId. Check instance permission based on the principal and permission name
	 * first. If the principal  has the permission to access the instance, simply returns true, otherwise,
	 * check permission based on business rules. 
	 * @param object instance of the target object.
	 * @param principal principal that is subjected for permission check
	 * @param permissionName is the permission such as "read" or 'write' etc that the user is attempted to 
	 * the object
	 * @param objectType identifies the object class
	 * @param boRuleID business rule id - check permission based on this rule only  
	 * @param checkAclPermissions - 'true' alows to check instance permission only, 'false' alows to check 
	 * permission for both - instance and rule based   
	 * @return boolean 'true'indicatess the permission is granted, 'false' indicates the permission is denied  
	 * @exception PermissionException
	 * <p>
	 */
	public static boolean checkAclPermission(IBusinessObjectNodeBase object, IPrincipal principal, String permissionName, 
		String objectType, String boRuleID, int mode) throws CAFPermissionException {
		
		final String method = "checkAclPermission(Object, String, String,  String, String, boolean)";

		try {        
			if((mode == 0 ) || 
			   ((mode & MODE_CHECK_ONLY_FOR_BUSINESS_RULES 
			          & MODE_CHECK_ONLY_FOR_INSTANCE 
			          & MODE_CHECK_PROPAGATED_PERMISSIONS) != 0)){
						
						CAFPermissionException e = new CAFPermissionException(location, "AUTH_MODE_PARAMETER_WRONG");
						location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			          	throw e;
			          }
			
			// Check permission based on business rules. Check each business rule for the object type
			if (MODE_CHECK_ONLY_FOR_BUSINESS_RULES == (mode & MODE_CHECK_ONLY_FOR_BUSINESS_RULES)) {
				if (isBusinessRulePermitted(object, objectType, permissionName, boRuleID, principal)) {
					return true;
				}
			} 

			// Check propagated permissions
			if (MODE_CHECK_PROPAGATED_PERMISSIONS == (mode & MODE_CHECK_PROPAGATED_PERMISSIONS)) {
				if (isOneOfRelatedObjectsPermitted(object, permissionName, principal, new HashSet<String>())) {
					return true;
				}
			}

			// Check instance permission based on ACL
			// This check should be last because it is the slowest one.
			if (MODE_CHECK_ONLY_FOR_INSTANCE == (mode & MODE_CHECK_ONLY_FOR_INSTANCE)) {
				if ((object != null) && (isInstancePermitted(object.getKey(), principal, permissionName))) {
					return true;
				} 
			}

		} catch (ClassCastException ce) { //$JL-EXC$
			try {
				CAFPermission.resetCache();
			} catch (Exception pex) {
				location.traceThrowableT(Severity.ERROR, pex.getMessage(), pex);
			}
		} catch (CAFPermissionException e) {
			throw e;
		} catch (UMException e) {
			location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
		} catch (Exception e) {
			location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			Object[] param = { method, e.getMessage()};
			throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR", param, e);
		}
		return false;
	}
	
	/**
	 * <p>
	 * Check service method access permission for the  login user. If the login user has the role that defines the permission then
	 * it simply returns true, otherwise, false is returned.
	 * @param usr is the login user string that is subjected for permission check. It is passes from the generated code when the
	 * service method is created. Here is one of the example how it is generated. i.e. "new ServicePermission("read")"
	 * @param ServicePermission is the ServicePermission class that defines permission name and its value.
	 * @return boolean 'true' indicates the permission is granted, 'false' indicates the permission is denied  
	 * @exception PermissionException
	 * <p>
	 */
	public static boolean checkServicePermission(String usr, ServicePermission sp) throws CAFPermissionException {
		final String method = "checkServicePermission(String, ServicePermission)";

		try {
			IUser iusr = CAFPermission.getUser(usr);
			return iusr.hasPermission(sp);
		} catch (UMException e) {
			location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR",new Object[]{method,e.getMessage()}, e);
		}
	}

	/** 
	 * <p>
	 * Invalid cache so the parameter set and business rule condition can be reloaded. This API is intended to call when
	 * business rule, condition or parameter set has been modified during the run time.
	 * @param null - apply the entire cache for CAF
	 * @return void
	 * @exception PermissionException
	 * <p>
	 */
	public static void resetCache() throws CAFPermissionException {
		CAFPermissionCache.getInstance().invalidateAttributes();
		CAFPermissionCache.getInstance().invalidateBusinessRules();
	}
	
	/** 
	 * <p>
	 * Add owner permission for user id. The ACL must not exist for the object id. The user id will be assigned as the owner.
	 * @param userID is assigned with the owner permission of the instance. The permission for the owner is always "owner" permission
	 * @param objectID is an unique id to identify the object instance
	 * @return void
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static void createOwnerPermission(String userId, String objectId) throws CAFPermissionException {
		final String method = "createOwnerPermission(String, String)";

		try {
			IUser iusr = getUser(userId);
			try {
				if (s_aclManager.getAcl(objectId) != null){
					throw new CAFPermissionException(location, "Owner has existed for object Id = " + objectId, new String [] {}); 			
				}
			} catch (UMException e) {
				location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			}

			s_aclManager.createAcl(iusr, objectId);
			
		} catch (UMException e) {
			location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR",new Object[]{ method,e.getMessage()}, e);
		}
	}
	
	public static void removeOwnerPermission(String objectId) throws CAFPermissionException {
		final String method = "removeOwnerPermission(String)";
		 
		try {
			IAcl iacl = getACL(objectId);
			// We are not sure whether the current user is an owner of the ACL
			// but we want to delete the ACL no matter what (since the BO node instance it was used for is being deleted).
			IPrincipal owner = null;
            Iterator i = iacl.getOwners().iterator();
            while (i.hasNext())
            {
                owner = (IPrincipal)i.next();
                if (owner instanceof IUser)
                {
                    break;
                }
                owner = null;
            }
            if (owner != null)  // Otherwise we could not find an owner and the ACL will leak.
            {
                s_aclManager.removeAcl(owner, objectId);
            }
	  	} catch (UMException e) {
	   		location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
	   		throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR", new Object[] {method, e.getMessage()}, e);
	  	}
	}
	
	/** 
	 * <p>
	 * Add a permission to a principal 
	 * @param loginUserID is the login user.
	 * @param objectID is an unique id to identify the object instance
	 * @param permissionName is the permission grants to the principal
	 * @param iPrincipal is the principal object. It can be a user, group or a role,
	 * @return void
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static void createPermission(String loginUserID, String objectID, String permissionName, IPrincipal iPrincipal) throws CAFPermissionException {
		final String method = "createPermission(String, String, String, IPrincipal)";

		try {
			IUser iusr = getUser(loginUserID);
			IAcl acl = getACL(objectID, true);

			acl.createAclEntry(iusr, iPrincipal, permissionName, false);
			
		} catch (UMException e) {
			location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR",new Object[]{ method, e.getMessage()}, e);
		}
	}
	
	/** 
	 * <p>
	 * Add a permission to a principal for business rule
	 * @param loginUserID is the login user.
	 * @param businessRuleID is an unique id to identify the business rule
	 * @param permissionName is the permission grants to the principal
	 * @param iPrincipal is the principal object. It can be a user, group or a role,
	 * @return void
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static void createPermissionForBusinessRule(String loginUserID, String businessRuleID, String permissionName, IPrincipal iPrincipal) throws CAFPermissionException {
		final String method = "createPermissionForBusinessRule(String, String, String, IPrincipal)";

		try {
			IUser iusr = getUser(loginUserID);
			IAcl acl = getACL(businessRuleID);

			if (acl == null) {
				CAFPermission.createOwnerPermission(loginUserID, businessRuleID);
			
				//create fullcontrol permission for current user
				CAFPermission.createPermission(loginUserID, businessRuleID, CAFPermissionName.fullcontrol, loginUserID) ;
				
				acl = getACL(businessRuleID);				
			}

			acl.createAclEntry(iusr, iPrincipal, permissionName, false);
			
		} catch (UMException e) {
			location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR",new Object[]{ method, e.getMessage()}, e);
		}
	}

	/** 
	 * <p>
	 * Add a permission to a user 
	 * @param loginUserID is the login user.
	 * @param objectID is an unique id to identify the object instance
	 * @param permissionName is the permission grants to the principal
	 * @param assignedUserID is the user id that is assigned to the permission.
	 * @return void
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static void createPermission(String loginUserID, String objectID, String permissionName, String assignedUserID) throws CAFPermissionException {
		final String method = "createPermission(String, String, String, String)";

		try {
			IUser assignedUsr = getUser(assignedUserID);
			createPermission(loginUserID, objectID, permissionName, assignedUsr);
		} catch (UMException e) {
			Object[] param = { method, e.getMessage()};
			CAFPermissionException pe = new CAFPermissionException(location, "AUTH_PERMISSION_ERROR", param);
			throw pe;
		}
	}
	
	/** 
	 * <p>
	 * Add permissions to principals. A principal can be assigned with one or more permissions. For example, user_xx can have both "read"
	 * and "delete" permission. This API allows to assign multiple permissions to multiple principals.
	 * @param loginUserID is the login user.
	 * @param objectID is an unique id to identify the object instance
	 * @param principalList is an arrayList that store HashMap objects. The HashMap is a collection of
	 * principals and permission name pair. The key of the HashMap is a principal and the value of the HashMap is a permission name.
	 * For example, if the user "user_xx" and "user_yy" have been assigned with permission name such as "read",
	 * then the HashMap will have two entries as user_xx/read and user_yy/read pairs. Or two HashMap objects are created. One for
	 * user_xx/read and the other is for user_yy/read. 
	 * @return void
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static void createPermissionAll(String loginUserID, String objectID,List principalList) throws CAFPermissionException {
		final int size = principalList.size();
		for (int i=0; i<size; i++) {
			HashMap hm = (HashMap) principalList.get(i);
			Iterator iter = hm.keySet().iterator();
			while (iter.hasNext()) {
				IPrincipal ipr = (IPrincipal) iter.next();
				String permissionName = (String) hm.get(ipr);
				createPermission(loginUserID, objectID, permissionName, ipr);
			}
		}
	}
	
	/** 
	 * <p>
	 * Modify permission for a principal 
	 * @param loginUserID is the login user.
	 * @param objectID is an unique id to identify the object instance
	 * @param oldPermissionName is the permission granted to the principal. This permission will be modified after this API.
	 * @param permissionName is the new permission that is intended to grant to the principal
	 * @param iPrincipal is the principal object. It can be a user, group or a role,
	 * @return void
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static void modifyPermission(String loginUserID, String objectID, String oldPermissionName, String newPermissionName, IPrincipal iPrincipal) throws CAFPermissionException {
		final String method = "modifyPermission(String, String, String, String, IPrincipal)";

		try {
			IUser iusr = getUser(loginUserID);
			IAcl acl = getACL(objectID, true);

			List ar1 = acl.getAclEntries(iPrincipal);
			modifyACEntries (acl, iusr, iPrincipal, ar1, oldPermissionName, newPermissionName);
		} catch (UMException e) {
			location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			Object[] param = { method, e.getMessage()};
			throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR", param, e);
		}
	}
	
	/** 
	 * <p>
	 * Modify permission for a user 
	 * @param loginUserID is the login user.
	 * @param objectID is an unique id to identify the object instance
	 * @param oldPermissionName is the permission granted to the principal. This permission will be modified after this API.
	 * @param permissionName is the new permission that is intended to grant to the principal
	 * @param assignedUserID is the user id that is assigned to the permission.
	 * @return void
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static void modifyPermission(String loginUserID, String objectID, String oldPermissionName, String newPermissionName, String assignedUserID) throws CAFPermissionException {
		final String method = "modifyPermission(String, String, String, String, String)";

		try {
			IUser assignedUser = getUser(assignedUserID);
			modifyPermission(loginUserID, objectID, oldPermissionName, newPermissionName, assignedUser);
		} catch (UMException e) {
			Object[] param = { method, e.getMessage()};
			CAFPermissionException pe = new CAFPermissionException(location, "AUTH_PERMISSION_ERROR", param);
			throw pe;
		}
	}
	
	/** 
	 * <p>
	 * Remove permissions from principals. If permissionName and prinicpal object are provided, only permissions with the
	 * same permissionName and principal are removed. If permissionName is space or null, 
	 * all permissions for the specific principal are removed. If the principal is a a null object,
	 * all permissions for all principals with the permissionName are removed. If the permissionName and principal are both null object,
	 * then all permissions (regardless permission name or principal) are removed. 
	 * @param loginUserID is the login user.
	 * @param objectID is an unique id to identify the object instance
	 * @param permissionName is the permission intended to be removed. It has to be a legal permission or space or null. 
	 * @param iPrincipal is the principal object. It can be a user, group or a role. It also can be a null object.
	 * @return void
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static void removePermission(String loginUserID, String objectID, String permissionName, IPrincipal iPrincipal) throws CAFPermissionException {
		final String method = "removePermission(String, String, String, IPrincipal)";

		try {
			IUser iusr = getUser(loginUserID);
			IAcl iAcl = getACL(objectID, true);
			
			List ar1;
			if (iPrincipal == null){
				ar1 =iAcl.getAclEntries();
			} else {
				ar1 = iAcl.getAclEntries(iPrincipal);
			}
			removeACEntries (iAcl, iusr, ar1, permissionName);
//			if (iPrincipal == null && (permissionName == null || permissionName.length() == 0)) {
//				getAclManagerInstance().removeAcl(_iusr, iAcl);
//			}
		} catch (UMException e) {
			location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR", new Object[] {method, e.getMessage()}, e);
		}
	}
	
	/** 
	 * <p>
	 * Remove permissions from principals for business rule. 
	 * @param loginUserID is the login user.
	 * @param objectID is an unique id to identify the object instance
	 * @param permissionName is the permission intended to be removed. It has to be a legal permission or space or null. 
	 * @param iPrincipal is the principal object. It can be a user, group or a role. It also can be a null object.
	 * @return void
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static void removePermissionForBusinessRule(String loginUserID, String objectID, String permissionName, IPrincipal iPrincipal) throws CAFPermissionException {
		final String method = "removePermissionForBusinessRule(String, String, String, IPrincipal)";

		try {
			IUser iusr = getUser(loginUserID);
			IAcl iAcl = getACL(objectID);
			
			if (iAcl == null) {
				return;
			}
			
			List ar1;
			if (iPrincipal == null){
				if (permissionName == null) {	// remove the whole ACL instead of just all the ACEs
					ar1 = null;
					removeACL(loginUserID, objectID);
				} else {
					ar1 =iAcl.getAclEntries();
				}
			} else {
				ar1 = iAcl.getAclEntries(iPrincipal);
			}
			if (ar1 != null) {
				removeACEntries (iAcl, iusr, ar1, permissionName);
			}

		} catch (UMException e) {
			location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR", new Object[] {method, e.getMessage()}, e);
		}
	}

	/** 
	 * <p>
	 * Remove permissions from a user. If permissionName and assigned user id are provided, only permissions with the
	 * same permissionName and assigned user id are removed. If permissionName is space or null, 
	 * all permissions for the specific assigned user id are removed. If the assigned user id is a a null object or empty string,
	 * all permissions for all principals with the permissionName are removed. If the permissionName and assigned user id are both null object,
	 * then all permissions (regardless permission name or principal) are removed. 
	 * @param loginUserID is the login user.
	 * @param objectID is an unique id to identify the object instance
	 * @param permissionName is the permission intended to be removed. It has to be a legal permission or space or null. 
	 * @param assignedUserID is the user id that is assigned to the permission.. It also can be a null object or empty string.
	 * @return void
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static void removePermission(String loginUserID, String objectID, String permissionName, String assignedUserID) throws CAFPermissionException {
		final String method = "removePermission(String, String, String, String)";

		try {
			IUser assignedUser = null;
			if (assignedUserID != null && assignedUserID.length() != 0) {
				assignedUser = getUser(assignedUserID);
			}
				
			removePermission(loginUserID, objectID, permissionName, assignedUser);
		} catch (UMException e) {
			location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR",new Object[] { method, e.getMessage()}, e);
		}
	}
	
	/** 
	 * <p>
	 * Retrieve permissions of principals. If permissionName and prinicpal object are provided, only permissions with the
	 * same permissionName and principal are retrieved. If permissionName is space or null, 
	 * all permissions for the specific principal are retrieved. If the principal is a a null object,
	 * all permissions for all principals with the permissionName are retrieved. If the permissionName and principal are both null object,
	 * then all permissions (regardless permission name or principal) are retrieved. 
	 * @param loginUserID is the login user.
	 * @param objectID is an unique id to identify the object instance
	 * @param permissionName is the permission intended to be removed. It has to be a legal permission or space or null. 
	 * @param iPrincipal is the principal object. It can be a user, group or a role. It also can be a null object.
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static Map<IPrincipal, Set<String>> retrievePermission(String loginUserID, String objectID, String permissionName, IPrincipal iPrincipal) throws CAFPermissionException {
		final String method = "retrievePermission(String, String, String , IPrincipal)";

		try {
			List ar1 = new ArrayList();
			IAcl acl = getACL(objectID);
			
			if (iPrincipal == null){
				ar1 = acl.getAclEntries();
			}				
			else {
				ar1 = acl.getAclEntries(iPrincipal);
			}
			
			return retrieveACEntries (ar1, permissionName);
		} catch (UMException e) {
			location.traceThrowableT(Severity.ERROR,e.getMessage(),e);			
			throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR",new Object[]{method, e.getMessage()}, e);
		}
	}
	
	/** 
	 * <p>
	 * Retrieve permissions of assignedUserID. If permissionName and assignedUserID string are provided, only permissions with the
	 * same permissionName and assignedUserID are retrieved. If permissionName is space or null, 
	 * all permissions for the specific assignedUserID are retrieved. If the assignedUserID is a a null object or zero length,
	 * all permissions for all principal with the permissionName are retrieved. If the permissionName and assignedUserID are both null object,
	 * then all permissions (regardless permission name or assignedUserID) are retrieved. 
	 * @param loginUserID is the login user.
	 * @param objectID is an unique id to identify the object instance
	 * @param permissionName is the permission intended to be removed. It has to be a legal permission or space or null. 
	 * @param assignedUserID is the user id string. It can be a null object or zero string.
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static Map<IPrincipal, Set<String>> retrievePermission(String loginUserID, String objectID, String permissionName, String assignedUserID) throws CAFPermissionException {
		final String method = "retrievePermission(String, String, String, String)";

		try {
			IUser assignedUser = null;
			if (assignedUserID != null && assignedUserID.length() != 0) {
				assignedUser = getUser(assignedUserID);
			}
				
			return retrievePermission(loginUserID, objectID, permissionName, assignedUser);
		} catch (UMException e) {
			Object[] param = { method, e.getMessage()};
			CAFPermissionException pe = new CAFPermissionException(location, "AUTH_PERMISSION_ERROR", param);
			throw pe;
		}
	}
	
	/** 
	 * <p>
	 * Create Default Permission Hierarchy only call once for the lifetime
	 * The permission hierarchy is top node of (owner and fullcontrol) and the mid node of (readwrite and delete) 
	 * and the bottom node of (read and write). If a user would like to read a data and modify it back, the user should
	 * have (readwrite).
	 * @exception CAFPermissionException
	 * <p>
	 */
	public static synchronized void createDefaultPermissionHierarchy() throws CAFPermissionException {
		final String method = "createDefaultPermissionHierarchy()";

		try { 
			List permissions = s_aclManager.getAllPermissions();
			if (!permissions.contains(CAFPermissionName.read)) {
				s_aclManager.addPermission(CAFPermissionName.fullcontrol, null);
				s_aclManager.addPermission(CAFPermissionName.owner, null);
				s_aclManager.addPermission(CAFPermissionName.create, null);
				s_aclManager.addPermission(CAFPermissionName.update, null);
				s_aclManager.addPermission(CAFPermissionName.delete, null);
				s_aclManager.addPermission(CAFPermissionName.read, null);				
				s_aclManager.addPermission(CAFPermissionName.write, null);
				s_aclManager.addPermission(CAFPermissionName.remove, null);

				s_aclManager.addPermissionMember(CAFPermissionName.update, CAFPermissionName.read);
				s_aclManager.addPermissionMember(CAFPermissionName.update, CAFPermissionName.write);
				
				s_aclManager.addPermissionMember(CAFPermissionName.delete, CAFPermissionName.read);
				s_aclManager.addPermissionMember(CAFPermissionName.delete, CAFPermissionName.remove);
			}
		} catch (UMException e) {
			location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR",new Object[] {method,e.getMessage()}, e);
		}	
	}
	
	private static void removeACEntries(IAcl iAcl, IPrincipal loggedInUser,List ar, String permissionName) throws UMException {
		final int size = ar.size();
		final boolean removeAll = permissionName == null || permissionName.length() == 0;
		for (int i=0; i<size; i++) { 
			IAclEntry entry = (IAclEntry) ar.get(i);
			if (removeAll || entry.getPermission().equals(permissionName)) {
				iAcl.removeAclEntry(loggedInUser, entry);			
			}
		}
	} 

	private static Map<IPrincipal, Set<String>> retrieveACEntries(List ar, String permissionName) throws CAFPermissionException {
		Map<IPrincipal, Set<String>> resultList = new HashMap<IPrincipal, Set<String>>();
		final int size = ar.size();
		for (int i=0; i<size; i++) {
			IAclEntry ace = (IAclEntry) ar.get(i);
			if (permissionName == null ||
				permissionName.length() == 0 ||
				ace.getPermission().equals(permissionName))	{
				   Set<String> permissionNames = resultList.get(ace.getPrincipal());
				   if (permissionNames == null)
				   {
					   permissionNames = new HashSet<String>();
					   try
					   {
						   IPrincipal principal = ace.getPrincipal();
						   principal.getDisplayName();	// This will throw a PrincipalNotAccessibleException if the principal doen not exist.
						   resultList.put(principal, permissionNames);
					   }
					   catch (PrincipalNotAccessibleException e)
					   {	// $JL-EXC$ Ignore non-existing principals.
					   }
				   }
				   permissionNames.add(ace.getPermission());
			}
		}
		return resultList;
	}
	
	private static void modifyACEntries(IAcl iAcl, IPrincipal ipr, IPrincipal iPrincipal, List ar, String oldPermissionName, String newPermissionName) throws UMException {
	   final int size = ar.size();
	   for	(int i=0; i<size; i++) {
		   IAclEntry ace = (IAclEntry) ar.get(i);
		   if (ace.getPermission().equals(oldPermissionName)) {			
			   iAcl.removeAclEntry(ipr, ace);	
			   iAcl.createAclEntry(ipr, iPrincipal, newPermissionName, false);
		   }
	   }
	}
	
	private static synchronized IUser getUser (String userID) throws UMException {
		IUser usr = null;

		if (!userID.startsWith("USER.")){
			try{
				usr = s_userFactory.getUserByUniqueName(userID);
				if (usr != null){
					return usr;
				}
			}catch(UMException e){
				location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			}
		}

		try {
			usr = s_userFactory.getUser(userID);	
		} catch (UMException e) { //$JL-EXC$
			usr = s_userFactory.getUserByUniqueName(userID);
		}
		return usr;
	}

	public static synchronized IPrincipal getPrincipal (String principalId) throws UMException {
		IPrincipal prcl = null;
		if (!principalId.startsWith("USER.")){
			try {
				prcl = s_userFactory.getUserByUniqueName(principalId);
				if (prcl != null){
					return prcl;
				}
			} catch (UMException e) {
				location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
			}
		}

		try {
			prcl = s_principalFactory.getPrincipal(principalId);
		} catch (UMException _e) { //$JL-EXC$
   			prcl = s_userFactory.getUserByUniqueName(principalId);	
		}
		
		return prcl;
	}

	private static boolean hasAclPermission(IPrincipal principal, String objectID, String permissionName) throws CAFPermissionException {
		boolean isAllowed;
		try {
			//IPrincipal _iusr = getPrincipal(principalID);
			IAcl iAcl = s_aclManager.getAcl(objectID);
			if (iAcl == null) {
				return false;
			}
			isAllowed =  iAcl.hasPermission(principal, permissionName);
		} catch (Exception e) {
			throw new CAFPermissionException(location, "AUTH_ACL_ACCESS", new Object[] {objectID, principal, permissionName},e);
		}
		return isAllowed;
	}
	
	public static IAcl getACL(String objectID) throws UMException, CAFPermissionException {
		IAcl acl = s_aclManager.getAcl(objectID);
		return acl;
	}	
	
	private static IAcl getACL(String objectID, boolean mustExist) throws UMException, CAFPermissionException {
		IAcl acl = s_aclManager.getAcl(objectID);
		if (acl==null && mustExist) {
			throw new CAFPermissionException(location, "AUTH_NO_ACL",new Object[] { objectID });
		}
		return acl;
	}	

	public static Collection<String> getAllowedPermission(String principalID, IBusinessObjectNodeBase object, String objectType) throws CAFPermissionException {
		try { 
			Iterator iter = CAFPermissionName.getAllNames();
			Collection<String> result  = new ArrayList<String>();

			while (iter.hasNext()) 
			{
				CAFPermissionName permission = (CAFPermissionName)iter.next();
				String name = permission.getName();
				
				if (checkAclPermission(object,principalID,name,objectType)) 
				{
					result.add(name);					
				}
			}
			return result;
		} catch (Exception e) {
			throw new CAFPermissionException(location, e);
		}
	}

	public static void removeACL(String loginUserID, String objectID) throws CAFPermissionException {
		final String method = "removeACL(IUser, String)";
 
		try {
			IUser iusr = getUser(loginUserID);
		  	s_aclManager.removeAcl(iusr, objectID) ;
	  	} catch (UMException e) {
	   		location.traceThrowableT(Severity.ERROR,e.getMessage(),e);
	   		throw new CAFPermissionException(location, "AUTH_PERMISSION_ERROR", new Object[] {method, e.getMessage()}, e);
	  	}
	}


	public static void addInheritedPermission(String propagatingKey, String inheritingKey, String propagatingObjectType)
		throws CAFPermissionException
	{
		final String method = "addInheritedPermission(IBusinessObjectNodeBase, IBusinessObjectNodeBase)";
		try
		{
			InheritedPermissionsUtils.addInheritedPermission(propagatingKey, inheritingKey, propagatingObjectType);
		}
		catch (NamingException e)
		{
			location.traceThrowableT(Severity.ERROR, method, e);
			throw new CAFPermissionException(location, e);
		}
		catch (SQLException e)
		{
			location.traceThrowableT(Severity.ERROR, method, e);
			throw new CAFPermissionException(location, e);
		}
		catch (CAFDataAccessException e)
		{
			location.traceThrowableT(Severity.ERROR, method, e);
			throw new CAFPermissionException(location, e);
		}
	}
	
	public static void removeInheritedPermission(String propagatingKey, String inheritingKey)
		throws CAFPermissionException
	{
		final String method = "removeInheritedPermission(IBusinessObjectNodeBase, IBusinessObjectNodeBase)";
		try
		{
			InheritedPermissionsUtils.removeInheritedPermission(propagatingKey, inheritingKey);
		}
		catch (NamingException e)
		{
			location.traceThrowableT(Severity.ERROR, method, e);
			throw new CAFPermissionException(location, e);
		}
		catch (SQLException e)
		{
			location.traceThrowableT(Severity.ERROR, method, e);
			throw new CAFPermissionException(location, e);
		}
	}
	
	public static void removeInheritedPermissionByPropagating(String propagatingKey)
		throws CAFPermissionException
	{
		final String method = "removeInheritedPermissionByPropagating(IBusinessObjectNodeBase)";
		try
		{
			InheritedPermissionsUtils.removeInheritedPermissionByPropagating(propagatingKey);
		}
		catch (NamingException e)
		{
			location.traceThrowableT(Severity.ERROR, method, e);
			throw new CAFPermissionException(location, e);
		}
		catch (SQLException e)
		{
			location.traceThrowableT(Severity.ERROR, method, e);
			throw new CAFPermissionException(location, e);
		}
	}
	
	public static void removeInheritedPermissionByInheriting(String inheritingKey)
		throws CAFPermissionException
	{
		final String method = "removeInheritedPermissionByInheriting(IBusinessObjectNodeBase)";
		try
		{
			InheritedPermissionsUtils.removeInheritedPermissionByInheriting(inheritingKey);
		}
		catch (NamingException e)
		{
			location.traceThrowableT(Severity.ERROR, method, e);
			throw new CAFPermissionException(location, e);
		}
		catch (SQLException e)
		{
			location.traceThrowableT(Severity.ERROR, method, e);
			throw new CAFPermissionException(location, e);
		}
	}
}
