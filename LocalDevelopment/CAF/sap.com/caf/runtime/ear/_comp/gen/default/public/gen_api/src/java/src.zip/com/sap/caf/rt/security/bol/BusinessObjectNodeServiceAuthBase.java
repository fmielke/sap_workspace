/*
 * Created on May 10, 2004
 */
package com.sap.caf.rt.security.bol;

import java.util.Map;
import java.util.Set;

import javax.jws.WebMethod;

import com.sap.caf.rt.bol.BusinessObjectNodeServiceBase;
import com.sap.caf.rt.bol.IBusinessObjectNodeBase;
import com.sap.caf.rt.exception.CAFBONodeException;
import com.sap.caf.rt.security.acl.CAFPermission;
import com.sap.ejb.annotations.ExcludeFromImport;
import com.sap.security.api.IPrincipal;
import com.sap.tc.logging.Location;

/**
 * @author trendafil-m
 * @author I028584
 */
public abstract class BusinessObjectNodeServiceAuthBase extends BusinessObjectNodeServiceBase {

	private static final Location location = Location.getLocation(BusinessObjectNodeServiceAuthBase.class);
	
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void addPermission(IPrincipal principal, String permission, String user, String key) throws CAFBONodeException {
		
		try {
			CAFPermission.createPermission(user, key, permission, principal);
		} catch (RuntimeException e) {
			throw e; 
		} catch (Exception e) {
   			CAFBONodeException _caf_ex = new CAFBONodeException(location, e);
			throw _caf_ex;
		}
	}
		
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void removePermission(IPrincipal principal, String permission, String user, String key) throws CAFBONodeException {
		try {
			CAFPermission.removePermission(user, key, permission, principal);
		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
   			CAFBONodeException _caf_ex = new CAFBONodeException(location, e);
			throw _caf_ex;
		}
	}

	@WebMethod(exclude=true)
	@ExcludeFromImport
	public Map<IPrincipal, Set<String>> getPrincipalPermissions(IPrincipal principal, String permission, String user, String key) throws CAFBONodeException {
		try {
			return CAFPermission.retrievePermission(user, key, permission, principal);
		} catch (RuntimeException e) {
			throw e;
        } catch (Exception e) {
   			CAFBONodeException _caf_ex = new CAFBONodeException(location, e);
			throw _caf_ex;
		}
	}
	
	protected boolean checkPermission(String permission, IBusinessObjectNodeBase object, String user, String objectName) {
		return this.checkPermission(permission, object, user, objectName, CAFPermission.MODE_CHECK_ALL);
	}
}