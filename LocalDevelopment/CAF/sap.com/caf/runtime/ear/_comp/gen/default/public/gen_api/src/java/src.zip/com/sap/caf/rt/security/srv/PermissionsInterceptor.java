package com.sap.caf.rt.security.srv;

import javax.ejb.EJBException;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

import com.sap.caf.rt.exception.CAFPermissionException;
import com.sap.caf.rt.security.acl.CAFPermission;
import com.sap.tc.logging.Location;

public class PermissionsInterceptor {
	
	private static final Location log = Location.getLocation(PermissionsInterceptor.class);
	
    @javax.annotation.Resource
	private javax.ejb.SessionContext sessionContext;

	public PermissionsInterceptor() {
	}
	
	@AroundInvoke
	@SuppressWarnings("unused")
	private Object aroundInvoke(InvocationContext invocationContext) throws Exception {
		String user = sessionContext.getCallerPrincipal().getName();
		Class targetClass = invocationContext.getTarget().getClass();
		
		String permissionName = null;
		
		try {
			StringBuilder buf = new StringBuilder();
			buf.append((String) targetClass.getField("_OBJECT_NAME").get(invocationContext.getTarget()));
			buf.append('/').append(invocationContext.getMethod().getName()).append(".*");
			permissionName = buf.toString();
		} catch (Exception e) {
			String message = "Unable to obtain field _OBJECT_NAME from bean class " + targetClass.getName() + "!";
			log.fatalT(message + "The error message was " + e.getMessage());
			throw new EJBException(message, e);
		}
		
        if (!CAFPermission.checkServicePermission(user, new ServicePermission(permissionName))) {
            throw new CAFPermissionException("APPSRV_AUTH_PERMISSION_ERROR", new Object[] {});
        }

        return invocationContext.proceed();
	}
}
