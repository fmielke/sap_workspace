package com.sap.caf.rt.services.eventing;

import java.util.HashMap;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.Transaction;

import com.sap.caf.rt.services.eventing.internal.CompoundEvent;
import com.sap.caf.rt.services.eventing.internal.EntityChangedEvent;
import com.sap.caf.rt.services.eventing.internal.FramewEventsLocal;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;

/**
 * Caches <code>EntityChangedEvent</code> objects until corresponding transaction
 * has been completed. Implements Singelton pattern
 * 
 * @author D040882
 * @author viachaslau_kudzinau@epam.com C5047333
 */
public class EventCache {
	
	public static final String MSG_PRODUCER_JNDI = "sap.com/caf~runtime~ear/LOCAL/FramewEvents/com.sap.caf.rt.services.eventing.internal.FramewEventsLocal";
	
	private final static Location LOC = Location.getLocation(EventCache.class);

	private Map<Object, CompoundEvent> m_events;
	
	private static EventCache s_cache;
	private static ITransactionProvider transactionProvider;

	private static FramewEventsLocal eventService;
	
	private EventCache() {
		m_events = new HashMap<Object, CompoundEvent>();
		if (transactionProvider == null) {
			transactionProvider = new TransactionProvider();
		}
		if (eventService == null) {
		    try {
	            Context context = new InitialContext();
	            eventService = (FramewEventsLocal)context.lookup(MSG_PRODUCER_JNDI);
	        } catch (NamingException e) {
	        	LOC.traceThrowableT(Severity.FATAL, "Unable to lookup important eventing component. CAF Auditing will not function!", e);
	        	throw new EventException("Unable to lookup important eventing component. CAF Auditing will not function!", e);
	        }
		}
	}
	
	
	
	/**
	 * @return The <code>EventCache</code> instance
	 */
	public static EventCache getInstance() {
		if (s_cache == null) {
			s_cache = new EventCache();
		}
		return s_cache;
	}
	
	/**
	 * Creates or uses existing event about changes of an entity instance.
	 * Merges the latest changes to the old once being kept in <code>EntityChangedEvent</code> 
	 * The event is published upon transaction completion or rollbacking 
	 * 
	 * @param data 				Changes of entity properties
	 * @param operation		Operation being performed on the entity 
	 * @param originator  An id of the user who originates the changes 
	 * @throws EventException
	 * 
	 * @see EntityChangedEvent#mergeChangedData(ValueObjectChangedData, int, String)
	 */
	public void put(ValueObjectChangedData data, OperationType operation, String originator) throws EventException {
		try {
			Transaction tx = transactionProvider.getCurrentTransaction();
			EntityChangedEvent event;
			synchronized(m_events) {
				String key = data.getSource().getKey();
				event = getRecentEvent(tx, key);
				if(event==null) {		
					event = registerEvent(tx, key);
				}
			}
			event.mergeChangedData(data, operation, originator);
		}
		catch (Exception e) {//$JL-EXC$
			LOC.traceThrowableT(Severity.ERROR, "Error while putting data into the event cache", e);
			throw new EventException("Error while putting data into the event cache", e);
		}
	}
	

	
	private EntityChangedEvent registerEvent(Transaction tx, String objKey) throws EventException {
		String txKey = tx.toString();
		CompoundEvent compoundEvent = m_events.get(txKey);
		if (compoundEvent == null) {
			compoundEvent = new CompoundEvent(txKey, eventService);
			try {
				tx.registerSynchronization(compoundEvent);
			} catch (Exception e) {
				LOC.traceThrowableT(Severity.ERROR, "Error while trying to register auditing event to the current transaction", e);
				throw new EventException("Error while trying to register auditing event to the current transaction", e);
			}
			m_events.put(txKey, compoundEvent);
		}
		EntityChangedEvent event = new EntityChangedEvent(objKey);
		compoundEvent.addEvent(event);
		return event;
	}
	
	private EntityChangedEvent getRecentEvent(Transaction tx, String objectKey) {
		String txKey = tx.toString();
		CompoundEvent compoundEvent = m_events.get(txKey);
		if (compoundEvent == null) {
			return null;
		}
		return (EntityChangedEvent) compoundEvent.getEvent(objectKey);
	}

	/**
	 * @see com.sap.caf.rt.services.eventing.IEventCache#getRecentEvent(java.lang.String)
	 */
	public EntityChangedEvent getRecentEvent(String objectKey) throws EventException {
		return getRecentEvent(transactionProvider.getCurrentTransaction(), objectKey);
	}
	
	/**
	 * Removes an event of the event cache, called after the event being thrown
	 * @param eventId An id of the event to be removed
	 */
	public void removeEvent(Object eventId) {
		synchronized (m_events) {	
			m_events.remove(eventId);
		}
	}

	public static void setTransactionProvider(ITransactionProvider transactionProvider) {
		EventCache.transactionProvider = transactionProvider;
	}
	
	public static void setEventService(FramewEventsLocal eventService) {
		EventCache.eventService = eventService;
	}

	public CompoundEvent getCompoundEvent(String txKey) {
		return m_events.get(txKey);
	}
	
	public static void reset() {
		s_cache = null;
		transactionProvider = null;
		eventService = null;
	}
}
