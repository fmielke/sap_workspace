package com.sap.caf.rt.services.eventing;


/**
 * CAF Eventing API custom exception class
 * @author viachaslau_kudzinau@epam.com
 */
public class EventException  extends RuntimeException {//$JL-SER$

	/**
	 * Create an instance of the exception based on the parameters
	 * 
	 * @param message	A localization message resource key
	 * @param e	An exception
	 */
	public EventException(String message, Throwable e) {
		super(message, e);
	}
	
	/**
	 * Create an instance of the exception based on the parameters
	 * 
	 * @param message	A localization message resource key
	 * @param e	An exception
	 */
	public EventException(String message) {
		super(message);
	}
}
