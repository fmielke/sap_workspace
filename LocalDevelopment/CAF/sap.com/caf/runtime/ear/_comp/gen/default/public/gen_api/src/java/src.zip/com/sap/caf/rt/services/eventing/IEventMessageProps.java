package com.sap.caf.rt.services.eventing;

import com.sap.caf.rt.services.eventing.internal.EntityChangedEvent;

/**
 * Contains JMS message property names and values
 * 
 * @author viachaslau_kudzinau@epam.com
 */
public interface IEventMessageProps {

	/**
	 * Operation property name
	 * @see OperationType
	 */
	final String OPERATION = "operation";

	/**
	 * Operation property values
	 */
	final String OPER_CREATE = "create";
	final String OPER_UPDATE = "update";
	final String OPER_DELETE = "delete";

	/**
	 * Entity instance key property name
	 */	
	final String OBJECT_KEY = "objectKey";

	/**
	 * A name of the property which contains entity name
	 */
	final String ENTITY_NAME = "entityName";

	/**
	 * A name of the property containing user id of the event originator  
	 */
	final String ORIGINATOR = "originator";

	/**
	 * A name of the property with commited/rolled back flag
	 */
	final String COMMITTED = "committed";
	 
}
