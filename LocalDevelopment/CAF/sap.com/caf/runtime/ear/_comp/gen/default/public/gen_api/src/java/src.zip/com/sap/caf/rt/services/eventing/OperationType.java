package com.sap.caf.rt.services.eventing;

public enum OperationType {
	CREATE,
	UPDATE,
	DELETE
}
