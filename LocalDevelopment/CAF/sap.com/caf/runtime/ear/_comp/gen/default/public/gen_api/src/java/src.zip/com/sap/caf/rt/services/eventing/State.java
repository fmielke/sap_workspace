package com.sap.caf.rt.services.eventing;

public enum State {
	NONE,
	CREATED,
	UPDATED,
	DELETED
}
