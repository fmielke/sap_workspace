package com.sap.caf.rt.services.eventing;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.sap.caf.rt.bol.IBusinessObjectNodeBase;
import com.sap.caf.rt.bol.IDependentObject;
import com.sap.tc.logging.Location;

/**
 * Represents the changes made to an entity instance.
 * 
 * @author D040882
 * @author viachaslau_kudzinau@epam.com
 */
public class ValueObjectChangedData {
	
	private IBusinessObjectNodeBase m_source;
	
//	private static final String PREFIX_OLD = "old";
//	private static final String PREFIX_NEW = "new";
	
//	private static final String NS_DELIM = ":";
	
//	/** A namespace for old properties inside a property map. */
//	public static final String NS_OLD = PREFIX_OLD+NS_DELIM;
//	/** A namespace for new properties inside a property map. */
//	public static final String NS_NEW = PREFIX_NEW+NS_DELIM;

	
	private HashMap<String, Object> m_newProps = new LinkedHashMap<String, Object>();
	private HashMap<String, Object> m_oldProps = new LinkedHashMap<String, Object>();
	private static final Location LOC = Location.getLocation(ValueObjectChangedData.class);

	/**
	 * Creates the object.
	 * 
	 * @param source <code>IBusinessObject</code> containg the object  
	 */
	public ValueObjectChangedData(IBusinessObjectNodeBase oldValue, IBusinessObjectNodeBase newValue) {

		m_source = oldValue != null ? oldValue : newValue;		
		
		if (oldValue != null) {
			setOldValue(oldValue);	
		}
		
		if (newValue != null) {
			setNewValue(newValue);	
		}
		
	}
	
	public ValueObjectChangedData(IBusinessObjectNodeBase source, String relationName, Object oldValue, Object newValue) {
		m_source = source;
		
		m_oldProps.put(relationName, oldValue);
		m_newProps.put(relationName, newValue);
	}

	
	/**
	 * Returns An entity instance containg the ValueObjectChangedData.
	 * 
	 * @return A business entity instance.
	 */
	public IBusinessObjectNodeBase getSource() {
		return m_source;
	}
	
	/**
	 * Registers an old propery value with the given namespace.
	 * 
	 * @param propName a property name
	 * @param propValue a property value
	 */	
	protected void registerOldValue(String propName, Object propValue) {
		if (propValue==null) { // don't need to store empty values
			return;
		}
		String propKey=propName;
		if (m_oldProps.get(propKey)!=null) { // already have old value set
			return;
		}
		setProperty(m_oldProps, propKey, propValue);
	}
	
	/**
	 * Registers a new propery value
	 * 
	 * @param namespace a namespace to register the old property with
	 * @param propName a property name
	 * @param propValue a property value
	 */	
	protected void registerNewValue(String propName, Object propValue) {
		String propKey = propName;
		setProperty(m_newProps, propKey, propValue);
	}

	/**
	 * Returns old property values as a <code>java.util.Map</code>.
	 * 
	 * @return map with old properties.
	 */
	public Map<String, Object> getOldProperties() {
		return m_oldProps;
	}

	/**
	 * Returns new property values as a <code>java.util.Map</code>.
	 * 
	 * @return map with new properties.
	 */
	public Map<String, Object> getNewProperties() {
		return m_newProps;
	}

	// auxiliary methods
	private static void setProperty(HashMap<String, Object> props, String propKey, Object propValue) {
		if (propValue==null) {
			if (props.containsKey(propKey)) {
				props.remove(propKey);
			}
			return;
		}
		
//		if (propValue instanceof Collection) {
//			Collection<?> newPropValue = clonePropValue(propKey, (Collection<?>)propValue);
//			if (newPropValue!=null) {
//				props.put(propKey, newPropValue);
//			}
//		}
		else if (isComplexProp(propValue)) {
			setProperties(props, propKey, (IDependentObject)propValue, hasPropDeleted(propValue));
		}
		else if (!(propValue instanceof Serializable)) {
				LOC.debugT("Could not set property [{0}], its value [{1}] does NOT implement java.io.Serializable", 
					new Object[]{propKey, propValue});
		}
//eliminates the use of com.sap.jdo.common.sco.Date (subclass of java.util.Date), may cause JMS problems
		else if(propValue instanceof java.util.Date){
			java.util.Date newPropValue = new java.util.Date(((java.util.Date)propValue).getTime());
			props.put(propKey, newPropValue);
		}
		else 
		{
			props.put(propKey, propValue);
		}
	}

	private static void setProperties(HashMap<String, Object> props, String supPropKey, 
		IDependentObject complexSubProp, boolean bRemove) 
	{
		if (complexSubProp!=null) {
			String subPropNames[] = complexSubProp.getPropertyList(); 
			for(int i = 0; i < subPropNames.length; i++){
				String subPropName = subPropNames[i];
				StringBuffer subPropKey = new StringBuffer(48);
				subPropKey.append(supPropKey).append('.').append(subPropName);
				setProperty(props, subPropKey.toString(), (bRemove? null: complexSubProp.getProperty(subPropName)));										
			}
		}
	}

//	private static Collection<?> clonePropValue(String propKey, Collection<?> oldPropValue) {
//		if (oldPropValue==null || oldPropValue.isEmpty()) {
//			return null;
//		}
//		Collection<Object> newPropValue = new ArrayList<Object>(oldPropValue.size());
//		for(Iterator<?> itr = oldPropValue.iterator(); itr.hasNext(); ) {
//			Object subPropValue = itr.next();
//			if (subPropValue==null) {
//				continue;
//			}
//			if (isComplexProp(subPropValue)) {
//				HashMap<String, Object> newSubPropValue = new HashMap<String, Object>();
//				setProperties(newSubPropValue, propKey, (IDependentObject)subPropValue, false);
//				subPropValue = newSubPropValue;
//			}
//			else if (isRelatedEntity(subPropValue)) {
//				subPropValue = ((IAssociation) subPropValue).getTargetKey();
//			} else if (!(subPropValue instanceof Serializable)) {
//				LOC.debugT("Could not set property [{0}], its value [{1}] does NOT implement java.io.Serializable", 
//					new Object[]{propKey, subPropValue});
//				continue;
//			}
////eliminates the use of com.sap.jdo.common.sco.Date (subclass of java.util.Date), may cause JMS problems
//			else if(subPropValue instanceof java.util.Date){
//				java.util.Date newSubPropValue = new java.util.Date(((java.util.Date)subPropValue).getTime());
//				subPropValue = newSubPropValue;
//			}			
//			newPropValue.add(subPropValue);
//		}
//		return newPropValue;
//	}

	private static boolean isComplexProp(Object propValue) {
		return propValue instanceof IDependentObject && !(propValue instanceof IBusinessObjectNodeBase);	
	}
	
	private static boolean hasPropDeleted(Object propValue) {	
		// TODO: implement with JPA means
		// return (propValue instanceof PersistenceCapable) && ((PersistenceCapable) propValue).jdoIsDeleted();
		return false;
	}
	
	public void setOldValue(IBusinessObjectNodeBase boStructure) {
		registerOldValues(boStructure);
	}
	
	public void setNewValue(IBusinessObjectNodeBase boStructure) {
		registerNewValues(boStructure);
	}
	
	
	/**
	 * Register all source properties as new values. 
	 */
	private void registerNewValues(IBusinessObjectNodeBase boStructure) {
		// register all new values
		String[] names = boStructure.getPropertyList();
		for (int i=0; i< names.length; i++) {
			String name = names[i];
			Object value = boStructure.getProperty(name);
			registerNewValue(name, value);
		}
	}
	
	/**
	 * Register all source properties as old values. 
	 */
	private void registerOldValues(IBusinessObjectNodeBase boStructure) {
		// register all new values
		String[] names = boStructure.getPropertyList();
		for (int i=0; i< names.length; i++) {
			String name = names[i];
			Object value = boStructure.getProperty(name);
			registerOldValue(name, value);
		}
	}
}
