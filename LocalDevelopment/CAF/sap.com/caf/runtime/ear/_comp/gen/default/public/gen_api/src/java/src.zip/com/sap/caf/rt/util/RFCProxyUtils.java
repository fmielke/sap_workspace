package com.sap.caf.rt.util;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class RFCProxyUtils {

	public static java.sql.Date toDate(Object calendarObj) {
    	if (calendarObj==null) return null;
    	XMLGregorianCalendar calendar = (XMLGregorianCalendar) calendarObj;   	
    	return new java.sql.Date(calendar.toGregorianCalendar().getTimeInMillis());
    }              
    
	public static java.sql.Time toTime(Object calendarObj) {
    	if (calendarObj==null) return null;    	
    	XMLGregorianCalendar calendar = (XMLGregorianCalendar) calendarObj;
    	return new java.sql.Time(calendar.toGregorianCalendar().getTimeInMillis());
    }    
    
	public static XMLGregorianCalendar fromDate(Object dateObj) throws DatatypeConfigurationException {
    	if (dateObj==null) return null;
    	java.sql.Date date = (java.sql.Date) dateObj;
    	GregorianCalendar calendar = new GregorianCalendar();
    	calendar.setTime(date);
    	
    	int year = calendar.get(Calendar.YEAR);
    	int month = calendar.get(Calendar.MONTH)+1;
    	int day = calendar.get(Calendar.DAY_OF_MONTH);
    	int offset = calendar.get(Calendar.ZONE_OFFSET) /(1000*60);
    	
    	return DatatypeFactory.newInstance().newXMLGregorianCalendarDate(year, month, day, offset);
    }    
    
	public static XMLGregorianCalendar fromTime(Object timeObj) throws DatatypeConfigurationException {
    	if (timeObj==null) return null;
    	java.sql.Time time = (java.sql.Time) timeObj;
    	GregorianCalendar calendar = new GregorianCalendar();
    	calendar.setTime(time);
    	int hour = calendar.get(Calendar.HOUR_OF_DAY);
    	int minute = calendar.get(Calendar.MINUTE);
    	int second = calendar.get(Calendar.SECOND);
    	int millisecond = calendar.get(Calendar.MILLISECOND);
    	int offset = calendar.get(Calendar.ZONE_OFFSET) /(1000*60);
    	
    	
    	return DatatypeFactory.newInstance().newXMLGregorianCalendarTime(hour, minute, second, millisecond, offset);
    }	
	
}
