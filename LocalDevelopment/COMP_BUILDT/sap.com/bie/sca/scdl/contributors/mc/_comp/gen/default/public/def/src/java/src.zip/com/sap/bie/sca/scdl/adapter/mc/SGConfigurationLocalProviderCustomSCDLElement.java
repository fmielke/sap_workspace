package com.sap.bie.sca.scdl.adapter.mc;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.gen.mc.McNamespaceConstants;

public class SGConfigurationLocalProviderCustomSCDLElement extends CustomScdlElement {

	public SGConfigurationLocalProviderCustomSCDLElement() {
		super(new QName(McNamespaceConstants.SAPCONFIG_NAMESPACE_VALUE, "localProvider", McNamespaceConstants.SAPCONFIG_NAMESPACE_NAME));
	}
}
