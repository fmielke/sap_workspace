package com.sap.bie.sca.scdl.adapter.mc;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.gen.mc.McNamespaceConstants;

public class ServiceGroupClassifValueCustomSCDLElement extends CustomScdlElement {
	public ServiceGroupClassifValueCustomSCDLElement(String namespaceValue, String nameValue, String codeValue) {
		super(new QName(McNamespaceConstants.SAPCONFIG_NAMESPACE_VALUE, "value", McNamespaceConstants.SAPCONFIG_NAMESPACE_NAME));
		
		addChild(new ServiceGroupClassifValueChildElements(new QName(McNamespaceConstants.SAPCONFIG_NAMESPACE_VALUE, "namespace", McNamespaceConstants.SAPCONFIG_NAMESPACE_NAME), namespaceValue));
		addChild(new ServiceGroupClassifValueChildElements(new QName(McNamespaceConstants.SAPCONFIG_NAMESPACE_VALUE, "name", McNamespaceConstants.SAPCONFIG_NAMESPACE_NAME), nameValue));
		addChild(new ServiceGroupClassifValueChildElements(new QName(McNamespaceConstants.SAPCONFIG_NAMESPACE_VALUE, "code", McNamespaceConstants.SAPCONFIG_NAMESPACE_NAME), codeValue));
	}
}
