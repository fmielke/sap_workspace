package com.sap.bie.sca.scdl.adapter.mc;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.gen.mc.McNamespaceConstants;

public class ServiceGroupsCustomSCDLElement extends CustomScdlElement {
	public ServiceGroupsCustomSCDLElement() {
		super(new QName(McNamespaceConstants.SAPCONFIG_NAMESPACE_VALUE, "serviceGroups", McNamespaceConstants.SAPCONFIG_NAMESPACE_NAME));
	}
}
