/**
 * 
 */
package com.sap.bie.sca.scdl.adapter;

import java.util.Collection;

/**
 * Provides methods to contribute custom elements to an element of the SCA model. Every
 * sca element which allows extensions through custom elements, has to implement this
 * interface. A custom element is an xml child element that is not defined in the SCA
 * assembly model, but either by an technology specific extension or completely proprietary.
 * Every element that can have custom child elements automatically supports custom attributes
 * as well.
 * 
 * @author d038406
 *
 */
public interface ICustomizableElement extends ICustomizableAttributes {
	/**
	 * Returns all custom elemens defined for this element.
	 * 
	 * @return
	 */
	Collection<ICustomScdlElement> getCustomElements();
}
