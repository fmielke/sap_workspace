package com.sap.bie.sca.scdl.adapter.impl;

import static com.sap.bie.sca.scdl.gen.util.ContractChecker.emptyStringCheckParam;
import static com.sap.bie.sca.scdl.gen.util.ContractChecker.nullCheckParam;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedSet;

import com.sap.bie.sca.scdl.adapter.IAttributeValue;
import com.sap.bie.sca.scdl.adapter.IBinding;
import com.sap.bie.sca.scdl.adapter.IComponentElement;
import com.sap.bie.sca.scdl.adapter.IInterface;

public class ComponentElement extends CustomizableElement implements IComponentElement 
{	
	private final Map<IAttributeValue, SortedSet<IAttributeValue>> clasifications = new HashMap<IAttributeValue, SortedSet<IAttributeValue>>();
	private final String name;
	private IInterface scdlInterface;
	private IBinding binding;
	
	public ComponentElement(final String name) 
	{
		emptyStringCheckParam(name, "name"); //$NON-NLS-1$
		this.name = name;
	}
	
	public void setBinding(final IBinding binding) {
		nullCheckParam(binding, "binding"); //$NON-NLS-1$
		this.binding = binding;
	}
	
	public IBinding getBinding() {
		return binding;
	}

	public String getName() {
		return name;
	}
	
	public void setScainterface(final IInterface scdlInterface) 
	{
		nullCheckParam(scdlInterface, "scdlInterface"); //$NON-NLS-1$
		this.scdlInterface = scdlInterface;
	}

	public IInterface getScainterface() {
		return scdlInterface;
	}

	public void addScdlContributionClassification(final IAttributeValue key, final SortedSet<IAttributeValue> classifications) {
		clasifications.put(key, classifications);
	}

	public Map<IAttributeValue, SortedSet<IAttributeValue>> getScdlContributionClassifications() {
		return Collections.unmodifiableMap(clasifications);
	}
}
