package com.sap.bie.sca.scdl.adapter.impl;

import java.util.Collection;

import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;
import com.sap.bie.sca.scdl.adapter.ICustomizableElement;

/**
 * Default implementation of {@link ICustomizableElement}
 * 
 * @author I036509
 */
public class CustomizableElement extends CustomizableAttributes implements ICustomizableElement
{
	private final NoNullsList<ICustomScdlElement> customElements = new NoNullsList<ICustomScdlElement>(); 

	/**
	 * Adds custom element to the list of elements
	 * @param customScdlElement
	 * @return result of {@link Collection#add(Object)}
	 * @throws NullPointerException in case <code>customScdlElement</code> is <code>null</code>
	 */
	public boolean addCustomElement(final ICustomScdlElement customScdlElement) {
		return customElements.add(customScdlElement);
	}

	public Collection<ICustomScdlElement> getCustomElements() {
		return customElements.unmodifiable();
	}
	
	@SuppressWarnings("nls")
	@Override
	public String toString() 
	{
		final StringBuilder sb = new StringBuilder();
		sb.append("attributes [\n\t").append(super.toString()); //$NON-NLS-1$
		
		sb.append("elements [");		 //$NON-NLS-1$
		for (ICustomScdlElement element : customElements) {
			sb.append("\n\t").append(element.toString());			 //$NON-NLS-1$
		}
		sb.append(']');
		
		return sb.toString();
	}
}
