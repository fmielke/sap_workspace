package com.sap.bie.sca.scdl.adapter;

/**
 * Interface to provide the value of a custom attribute. It can occur that the
 * value of the attribute belongs to its own namespace. Therefore, the contributor
 * can provide it along with the attribute value.
 * Example:
 * <root xmlns:ns1="http://custom.namespace.com">
 * 		<element attribute="ns1:value"/>
 * </root>
 * 
 * @author D040882
 *
 */
public interface IAttributeValue {
	/**
	 * 
	 * Return the namespace to which the value provided by {@link getValue()}
	 * belongs. May return <code>null</code>. The returned value will be 
	 * ignored if {@link getNamespacePrefix()} returns <code>null</code>.
	 * 
	 * @return
	 * 
	 */
	String getNamespace();

	/**
	 * 
	 * Return the namespace prefix for the namespace returned in {@link
	 * getNamespace()}. May return <code>null</code>. If this method returns 
	 * <code>null</code>, the value of the method {@link getNamespace()} 
	 * will be ignored.
	 * 
	 * @return
	 * 
	 */
	String getNamespacePrefix();
	
	/**
	 * Returns the value of the custom attribute. Implementors MUST NOT return
	 * <code>null</code>.
	 * @return
	 */
	String getValue();
}
