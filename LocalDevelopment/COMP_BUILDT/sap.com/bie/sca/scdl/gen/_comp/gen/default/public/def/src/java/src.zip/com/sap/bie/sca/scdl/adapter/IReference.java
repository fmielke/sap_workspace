/**
 * 
 */
package com.sap.bie.sca.scdl.adapter;


/**
 * Represents the reference element in the SCA assembly model.
 * 
 * @author d038406
 *
 */
public interface IReference extends IComponentElement {
	
}
