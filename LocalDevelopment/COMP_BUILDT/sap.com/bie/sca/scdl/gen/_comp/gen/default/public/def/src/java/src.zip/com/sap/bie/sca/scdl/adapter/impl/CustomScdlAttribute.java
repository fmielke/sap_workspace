package com.sap.bie.sca.scdl.adapter.impl;

import static com.sap.bie.sca.scdl.gen.util.ContractChecker.nullCheckParam;

import java.text.MessageFormat;
import javax.xml.namespace.QName;
import com.sap.bie.sca.scdl.adapter.IAttributeValue;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;

/**
 * Default implementation of {@link ICustomScdlAttribute} interface
 * 
 * @author I036509
 */
public class CustomScdlAttribute implements ICustomScdlAttribute 
{
	private final QName qName;
	private final IAttributeValue value;
	
	/**
	 * Constructor
	 * @param qName the qualified name of the attribute - {@link QName#getLocalPart()} maps to attribute
	 * tag name, {@link QName#getPrefix()} maps to attribute tag name prefix in XML.
	 * @param value - maps to attribute value in XML
	 * @throws NullPointerException in case some of arguments is <code>null</code>
	 */
	public CustomScdlAttribute(final QName qName, final IAttributeValue value) 
	{
		nullCheckParam(qName, "qName"); //$NON-NLS-1$
		nullCheckParam(value, "value"); //$NON-NLS-1$

		this.qName = qName;
		this.value = value;
	}

	public String getAttributeName() {
		return qName.getLocalPart();
	}

	public String getAttributeNamespace() {
		return qName.getNamespaceURI();
	}

	public String getAttributeNamespacePrefix() {
		return qName.getPrefix();
	}

	public IAttributeValue getAttributeValue() {
		return value;
	}
	
	@Override
	public String toString() 
	{
		final String pattern = "CustomScdlAttribute [{0}]: {1}"; //$NON-NLS-1$
		return MessageFormat.format(pattern, qName, value);		
	}
}
