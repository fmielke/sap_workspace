package com.sap.bie.sca.scdl.adapter.impl;

import java.util.Collection;

import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.ICustomizableAttributes;

/**
 * Default implementation of {@link ICustomizableAttributes}
 * 
 * @author I036509
 */
public class CustomizableAttributes implements ICustomizableAttributes
{
	private final NoNullsList<ICustomScdlAttribute> attributes = new NoNullsList<ICustomScdlAttribute>();

	/**
	 * Adds attribute to attributes list
	 * @param attr
	 * @throws NullPointerException in case some of parameters is <code>null</code>
	 */
	public void addAttribute(ICustomScdlAttribute attr) {	
		attributes.add(attr);
	}

	public Collection<ICustomScdlAttribute> getCustomAttributes() {
		return attributes.unmodifiable();
	}
	
	@SuppressWarnings("nls")
	@Override
	public String toString() 
	{
		final StringBuilder sb = new StringBuilder();
		sb.append("CustomAttributes"); //$NON-NLS-1$
		
		for (ICustomScdlAttribute attribute : attributes) {
			sb.append("\n\t").append(attribute.toString()); //$NON-NLS-1$
		}
		
		return attributes.toString();
	}
}
