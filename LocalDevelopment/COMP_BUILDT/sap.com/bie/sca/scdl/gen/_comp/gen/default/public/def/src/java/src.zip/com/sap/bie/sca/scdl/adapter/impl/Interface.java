package com.sap.bie.sca.scdl.adapter.impl;

import static com.sap.bie.sca.scdl.gen.util.ContractChecker.emptyStringCheckParam;
import static com.sap.bie.sca.scdl.gen.util.ContractChecker.nullCheckParam;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IInterface;

/**
 * Default implementation for {@link IInterface}
 * 
 * @author I036509
 */
public class Interface extends CustomizableElement implements IInterface
{
	private static final String INTERFACE = "interface"; //$NON-NLS-1$
	
	private final QName name;
	
	/**
	 * Constructs the object using the type added to 'interface' tag
	 * @param type
	 * @throws NullPointerException in case <code>type</code> is <code>null</code>
	 * @throws IllegalArgumentException in case <code>type</code> is empty string
	 */
	public Interface(final String type) {
		
		emptyStringCheckParam(type, "type"); //$NON-NLS-1$
		this.name = new QName(INTERFACE + '.' + type);
	}
	
	/**
	 * Constructs the object using qualified name
	 * @param qName
	 * @throws NullPointerException in case <code>qName</code> is <code>null</code>
	 */
	public Interface(final QName qName) {
		
		nullCheckParam(qName, "qName"); //$NON-NLS-1$
		this.name = qName;
	}	

	public QName getName() {
		return name;
	}
}
