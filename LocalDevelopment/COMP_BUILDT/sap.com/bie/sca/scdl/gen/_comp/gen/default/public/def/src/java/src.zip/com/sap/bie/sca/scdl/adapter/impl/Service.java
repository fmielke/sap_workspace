package com.sap.bie.sca.scdl.adapter.impl;

import com.sap.bie.sca.scdl.adapter.IService;

public class Service extends ComponentElement implements IService 
{
	private static final String SERVICE = "service"; //$NON-NLS-1$
	
	private final boolean isPromoted;
	
	public Service(String name, boolean isPromoted) {
		super(name);
		this.isPromoted=isPromoted;
	}
	public Service(final boolean isPromoted) {
		this(SERVICE, isPromoted);
	}

	public boolean isPromoted() {
		return isPromoted;
	}
}
