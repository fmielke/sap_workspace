package com.sap.bie.sca.scdl.adapter.impl;

import java.util.Collection;

import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;
import com.sap.bie.sca.scdl.adapter.IWire;

public class Wire extends CustomizableElement implements IWire {

	private String source=null;
	private String target=null;
	
	public Wire(String source, String target) {
		this.source=source;
		this.target=target;
	}
	
	public String getSource() {
		return source;
	}

	public String getTarget() {
		return target;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setTarget(String target) {
		this.target = target;
	}
	
}
