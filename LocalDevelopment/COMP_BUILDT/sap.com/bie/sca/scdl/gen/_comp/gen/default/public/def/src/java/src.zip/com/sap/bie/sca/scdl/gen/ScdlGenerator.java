package com.sap.bie.sca.scdl.gen;

import java.io.File;
import java.util.Collection;

import org.apache.tools.ant.BuildException;

import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.bie.sca.scdl.gen.util.CompositeScdlExporter;
import com.sap.bie.sca.scdl.gen.util.ScdlContributorExtensionService;
import com.sap.bie.sca.scdl.merge.ScdlContributionsMerger;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.moin.ant.task.MoinAntTask;

//TODO 1. 	Check if mixed case works (i.e. wires and services created at DT in same
//			DC together with references
//     2.   Currently save is done for each atomic meta model create during import, this 
//			should be changed do only save at the end when the entire model is created.
//	   3.	Change metamodel import so that generated metamodel entities get stable GUIDs.

/**
 * 
 * This is the controller for the EC DC BPExt. It triggers the steps needed for
 * import and transformation of the EC Design Time metamodel.
 * 
 * @author D038406
 * 
 */
public class ScdlGenerator extends MoinAntTask {
	
	private static final String DC_SUBTYPE_EJBMODULE = "EJBModule"; //$NON-NLS-1$
	private static final String DC_SUBTYPE_WEBMODULE = "WebModule"; //$NON-NLS-1$
	private static final String DC_TYPE_J2EE = "J2EE"; //$NON-NLS-1$

	protected static final String SCDL_GEN_LOG_PREFIX = "		[SCDL_GEN] "; //$NON-NLS-1$
	protected static final String THISGENERATION = "Common SCDL Generation"; //$NON-NLS-1$

	private IGlobalPluginUtil gpu = (IGlobalPluginUtil) BuildSessionManager.getFromBuildSession(IGlobalPluginUtil.class.getName());
	private IPluginBuildInfo pluginBuildInfo = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
	
	@Override
	protected void executeSafe() throws BuildException {
		initialiseBuildController();

		// 1. Get the contributions
		Collection<IComposite> contributedComposites = getContributions();
		if (contributedComposites.size() < 1) {
			return;
		}

		// 2. Call Merger
		ScdlContributionsMerger scdlMerger = new ScdlContributionsMerger();
		scdlMerger.setDcName(pluginBuildInfo.getDCName());
		Collection<IComposite> composites = scdlMerger.mergeScdlContributions(contributedComposites);

		// 3. Export to SCDL
		exportScdl(composites);
	}	

	/**
	 * 
	 * checks that the build controller fields have been initialized by the
	 * build fwk and initialises additional internally needed fields.
	 * 
	 */
	protected void initialiseBuildController() {
		Log.info(SCDL_GEN_LOG_PREFIX + "Initializing Scdl Generation..."); //$NON-NLS-1$		
		
		Log.info(SCDL_GEN_LOG_PREFIX + "Initialization successfully completed."); //$NON-NLS-1$
	}

	/**
	 * @return
	 */
	protected final String getFullDcName() {
		return getDcvendor() + "/" + getDcname(); //$NON-NLS-1$
	}

	/**
	 * @return
	 */
	private String getDcname() {
		return this.pluginBuildInfo.getDCName();
	}

	/**
	 * @return
	 */
	private String getDcvendor() {
		return this.pluginBuildInfo.getDCVendor();
	}

	/**
	 * Triggers the export to scdl, i.e. the generation of the deployment format
	 * from the moin metadata.
	 * 
	 * @param composites
	 */
	protected void exportScdl(final Collection<IComposite> composites) {
		Log.info(SCDL_GEN_LOG_PREFIX + "Starting composite export to SCDL..."); //$NON-NLS-1$
		String baseOutputPath = pluginBuildInfo.getTempDir()+ "/" + ScdlGeneratorBuildFileCreator.SCDL_OUTPUT; //$NON-NLS-1$
		CompositeScdlExporter compositeExorter = new CompositeScdlExporter(baseOutputPath, composites, isAssemblyModuleDcType());
		compositeExorter.run();
		if(pluginBuildInfo.getDCType()!=null && pluginBuildInfo.getDCSubType()!=null && pluginBuildInfo.getDCType().equals("J2EE") && pluginBuildInfo.getDCSubType().equals("WebModule")) { //$NON-NLS-1$ //$NON-NLS-2$
			pluginBuildInfo.getFolderAttributeManager().addFolderAttributes(new File(baseOutputPath), "war-content"); //$NON-NLS-1$
		}
		Log.info(SCDL_GEN_LOG_PREFIX + "Conversion successfully completed!"); //$NON-NLS-1$          
	}
	
	/**
	 * 
	 * Check here if the dc type is an assembled module or not (such as JEE EJB
	 * Module DCs).
	 * 
	 * @return
	 */
	private boolean isAssemblyModuleDcType() {
		String type = this.pluginBuildInfo.getCurrentDevelopmentComponent().getType();
		String subType = this.pluginBuildInfo.getCurrentDevelopmentComponent().getSubType();

		if (type.equals(DC_TYPE_J2EE)) {
			if (subType.equals(DC_SUBTYPE_EJBMODULE) 
					|| subType.equals(DC_SUBTYPE_WEBMODULE)) {
				return true;
			}
		}

		return false;
	}
	
	private Collection<IComposite> getContributions() {
		Log.info(SCDL_GEN_LOG_PREFIX + "Starting retrieval of information from contributors..."); //$NON-NLS-1$
		ScdlContributorExtensionService.setCon(getTaskData().getConnection());
		Collection<IComposite> contributedComposites = ScdlContributorExtensionService.getContributions();
		Log.info(SCDL_GEN_LOG_PREFIX + "Information retrieval from contributors successfully completed!"); //$NON-NLS-1$
		return contributedComposites;
	}
}
