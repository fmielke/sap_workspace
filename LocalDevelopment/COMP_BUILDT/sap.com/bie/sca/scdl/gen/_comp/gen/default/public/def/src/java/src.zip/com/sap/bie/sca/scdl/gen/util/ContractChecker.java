/**
 * 
 */
package com.sap.bie.sca.scdl.gen.util;

import java.text.MessageFormat;

/**
 * A Util class to check common issues with input parameters passed in a method
 * call.
 * 
 * @author d038406
 * 
 */
public class ContractChecker {

	// TODO unify this with the ContractChecker used in the tool coding
	/**
	 * Checks wheter the param is null.
	 * 
	 * @param paramValue
	 *            - the object reference to be checked.
	 * 
	 * @throws IllegalArgumentException
	 *             in case the parameter passed in is null.
	 * 
	 */
	public static void nullCheckParam(final Object paramValue) {
		if (paramValue == null) {
			throw new IllegalArgumentException("method parameter is null"); //$NON-NLS-1$
		}
	}	
	
	public static void nullCheckParam(final Object paramValue, final String paramName)
	{
		if (paramName == null) {
			throw new NullPointerException("paramName must not be null"); //$NON-NLS-1$ 
		}
		
		if (paramValue == null) {
			throw new NullPointerException(paramName + " must not be null"); //$NON-NLS-1$ 
		}
	}


	/**
	 * Checks whether the provided string is longer then the argument passed.
	 * 
	 * @param strToCheck
	 *            - the string which length is checked.
	 * @param lengthToBeGreaterThen
	 *            - the number of characters the string has to be longer then.
	 */
	public static void stringLengthGreaterThenCheck(final String strToCheck, int lengthToBeGreaterThen) {
		if (!(strToCheck.length() > lengthToBeGreaterThen)) {
			throw new IllegalArgumentException("input string length shorter then " + lengthToBeGreaterThen); //$NON-NLS-1$
		}
	}
	
	public static void emptyStringCheckParam(final String param, final String varName) 
	{
		nullCheckParam(param, varName);
		
		if (param.trim().length() == 0) {
			throw new IllegalArgumentException(MessageFormat.format("Parameter {0} is empty string or contains only white spaces", varName)); //$NON-NLS-1$
		}
	}
}
