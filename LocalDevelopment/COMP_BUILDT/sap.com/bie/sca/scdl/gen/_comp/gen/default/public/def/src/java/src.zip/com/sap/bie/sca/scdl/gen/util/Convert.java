package com.sap.bie.sca.scdl.gen.util;

import org.w3c.dom.Element;


abstract class Convert {
	
	private final Element root;

	Convert(final Element root) {
		ContractChecker.nullCheckParam(root);
		this.root = root;
	}
	
	abstract void run();
	
	public Element getRoot() {
		return root;
	}
}
