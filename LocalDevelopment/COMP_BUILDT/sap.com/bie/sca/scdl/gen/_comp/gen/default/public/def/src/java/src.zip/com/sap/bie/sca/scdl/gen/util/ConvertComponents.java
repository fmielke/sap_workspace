package com.sap.bie.sca.scdl.gen.util;

import java.util.Collection;

import org.w3c.dom.Element;

import com.sap.bie.sca.scdl.adapter.IComponent;
import com.sap.bie.sca.scdl.adapter.IComponentElement;
import com.sap.bie.sca.scdl.classifications.ClassificationsProcessor;

/**
 * All Components are treated alike, there is no primary component Components
 * differ with respect to their content
 * 
 * Components are always stored in a .composite file.
 * 
 * @author d038406
 * 
 */
final class ConvertComponents extends Convert {

	private static final String XML_ATTRIBUTE_CLASSIFICATION_LINK = "classificationLink";  //$NON-NLS-1$
	private static final String XML_NAMESPACE_CLASSIFICATION_LINK = "http://www.sap.com/webas/2007/03/esoa/config/system"; //$NON-NLS-1$
	private static final String XML_NS_PREFIX_CLASSIFICATION_LINK = "esoa"; //$NON-NLS-1$
	private static final String XML_TAG_REFERENCE = "reference"; //$NON-NLS-1$
	private static final String XML_TAG_SERVICE = "service"; //$NON-NLS-1$
	private static final String XML_TAG_COMPONENT = "component"; //$NON-NLS-1$

	private final Collection<IComponent> components;
	private final String classificationFilesDir;

	/**
	 * @param baseOutputPath
	 * @param connection
	 * @param containerName
	 */
	public ConvertComponents(final Collection<IComponent> components, final Element root, final String classificationFilesDir) {
		super(root);
		ContractChecker.nullCheckParam(components);
		ContractChecker.nullCheckParam(classificationFilesDir);
		this.components = components;
		this.classificationFilesDir = classificationFilesDir;
	}

	/**
	 * 
	 */
	public final void run() {

		for (IComponent component : components) {
			Element componentScdlXmlElement = ScdlExportService.createXmlTagWithNameAttribute(getRoot(), getRoot(), XML_TAG_COMPONENT,
					component.getName());
			if(component.getImplementation()!=null && component.getImplementation().getCustomElements()!=null) {
				createImplementationTag(component, componentScdlXmlElement);
			}

			if(component.getServices()!=null && component.getServices().size() > 0) {
				createComponentInterfaceElement(component.getServices(), componentScdlXmlElement, XML_TAG_SERVICE);
			}
			
			if(component.getReferences()!=null && component.getReferences().size() > 0) {
				createComponentInterfaceElement(component.getReferences(), componentScdlXmlElement, XML_TAG_REFERENCE);
			}
			
			if(component.getCustomElements()!=null && component.getCustomElements().size() > 0) {
				ScdlExportService.handleScaCustomElements(getRoot(), component.getCustomElements(),
						componentScdlXmlElement);
			}
			
			if(component.getCustomAttributes()!=null && component.getCustomAttributes().size() > 0) {
				ScdlExportService.handleAttributes(getRoot(), component.getCustomAttributes(), componentScdlXmlElement);
			}
		}
	}
	
	/**
	 * 
	 * create the xml representation of componentInterfaceElements.
	 * 
	 * @param component
	 * @param componentScdlXmlElement
	 */
	private void createComponentInterfaceElement(final Collection<? extends IComponentElement> componentInterfaceElements,
			final Element componentScdlXmlElement, final String xmlElementName) {
		for (com.sap.bie.sca.scdl.adapter.IComponentElement componentInterfaceElement : componentInterfaceElements) {
			Element componentInterfaceScdlXmlElement = ScdlExportService.createXmlTagWithNameAttribute(getRoot(), componentScdlXmlElement,
					xmlElementName, componentInterfaceElement.getName()); 
			if (componentInterfaceElement.getScdlContributionClassifications()!=null && !componentInterfaceElement.getScdlContributionClassifications().isEmpty()) {				
				String attrName = ScdlExportService.handleNamespaceForAttribute(getRoot(), XML_ATTRIBUTE_CLASSIFICATION_LINK, 
						XML_NAMESPACE_CLASSIFICATION_LINK, XML_NS_PREFIX_CLASSIFICATION_LINK);
				componentInterfaceScdlXmlElement.setAttribute(attrName, ClassificationsProcessor.getInstance(
						this.classificationFilesDir).process(componentInterfaceElement.getScdlContributionClassifications()));			
			}
			if(componentInterfaceElement.getScainterface()!=null) {
				createInterfaceTag(componentInterfaceElement, componentInterfaceScdlXmlElement);
			}
			if ((componentInterfaceElement.getBinding()!=null) && (componentInterfaceElement.getBinding().getCustomElements() != null)) {
				ScdlExportService.handleScaCustomElements(getRoot(), componentInterfaceElement.getBinding().getCustomElements(),
						componentInterfaceScdlXmlElement);
			}
			if (componentInterfaceElement.getCustomElements() != null) {
				ScdlExportService.handleScaCustomElements(getRoot(), componentInterfaceElement.getCustomElements(),
						componentInterfaceScdlXmlElement);
			}
			if(componentInterfaceElement.getCustomAttributes() != null && componentInterfaceElement.getCustomAttributes().size() > 0) {
				ScdlExportService.handleAttributes(getRoot(), componentInterfaceElement.getCustomAttributes(), componentInterfaceScdlXmlElement);
			}
		}
	}

	/**
	 * 
	 * Create the implementation tag as child of the component tag.
	 * 
	 * @param mmComponent
	 *            - The component metamodel element (data source).
	 * @param componentScdlXmlElement
	 *            - The component xml element (data destination).
	 */
	private void createImplementationTag(final IComponent component, final Element componentScdlXmlElement) {
		ScdlExportService.handleScaCustomElements(getRoot(), component.getImplementation().getCustomElements(),
				componentScdlXmlElement);
	}

	/**
	 * 
	 * Create the interface tag as child of the reference tag.
	 * 
	 * @param srv
	 *            - The reference metamodel element (data source).
	 * @param scaInterfaceParent
	 *            - The reference xml element (data destination).
	 */
	private void createInterfaceTag(final IComponentElement interfaceContainer, final Element scaInterfaceParent) {
		ScdlExportService.handleScaCustomElements(getRoot(), interfaceContainer.getScainterface().getCustomElements(),
				scaInterfaceParent);
	}
}