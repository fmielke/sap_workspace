package com.sap.bie.sca.scdl.gen.mc;

public class IllegalMcDependenciesDetected extends Exception {
	private static final long serialVersionUID = 1L;

	public IllegalMcDependenciesDetected(String message) {
		super(message);
	}
}
