package com.sap.bie.sca.scdl.gen.mc;

import com.sap.bie.sca.scdl.mc.gen.impl.McReferenceGeneratorImpl;
import com.sap.bie.sca.scdl.mc.mm.MoinMcMetamodelInteractionImpl;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.moin.repository.Connection;

public class McReferenceGeneratorFactory {
	private static McReferenceGeneratorFactory factory;
	
	private McReferenceGeneratorFactory() {
		
	}
	
	public static McReferenceGeneratorFactory getInstance() {
		if(factory==null) {
			factory = new McReferenceGeneratorFactory();
		}
		
		return factory;
	}
	
	/**
	 * Factory method for instantiating a Mass Configuration SCDL Reference generator for 
	 * a given SCDL component.
	 * 
	 * @param conn - the MOIN connection which will be used by the MC generator to get Mass
	 * Configuration metadata out of MOIN
	 * @param globalPluginUtil - each contributor of SCDL generation procedure receives an 
	 * instance of this object by default therefore it is used and needed in the MC generator 
	 * as well.
	 * @param pluginBuildInfo - each contributor of SCDL generation procedure receives an 
	 * instance of this object by default therefore it is used and needed in the MC generator 
	 * as well. Especially this parameter is needed to identify the metadata of the currently
	 * build DC and eventually to scope the MOIN queries.
	 * @return a new instance of the Mass Configuration generator of SCDL references ready
	 * for use
	 */
	public IMcReferenceGenerator newMCReferenceGenerator(final Connection conn, IGlobalPluginUtil globalPluginUtil, IPluginBuildInfo pluginBuildInfo) {
		return new McReferenceGeneratorImpl(new MoinMcMetamodelInteractionImpl(pluginBuildInfo, conn));
	}
	
	/**
	 * Factory method for instantiating a Mass Configuration Metamodel interactor which can 
	 * be used to perform predefined queries on the MC metamodel for the currently built dc.
	 * 
	 * @param conn - the MOIN connection which will be used by the MC generator to get Mass
	 * Configuration metadata out of MOIN
	 * @param pluginBuildInfo - each contributor of SCDL generation procedure receives an 
	 * instance of this object by default therefore it is used and needed in the MC generator 
	 * as well. Especially this parameter is needed to identify the metadata of the currently
	 * build DC and eventually to scope the MOIN queries.
	 * @return a new instance of the Mass Configuration metamodel interactor ready
	 * for use to perform queries on the MC metamodel
	 */
	public IMcMetamodelInteraction newMcModelInteractor(final Connection conn, IPluginBuildInfo pluginBuildInfo) {
		return new MoinMcMetamodelInteractionImpl(pluginBuildInfo, conn);
	}
}
