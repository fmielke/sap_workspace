package com.sap.bie.sca.scdl.gen.mc;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.sap.tc.buildplugin.api.IDataContext;
import com.sap.tc.buildplugin.gen.AbstractGenerator;
import com.sap.tc.buildplugin.gen.GeneratorException;
import com.sap.tc.buildplugin.util.IAntToolkit;

public class Xlf2PropConverterFlattener extends AbstractGenerator {
	@SuppressWarnings("unchecked")
	@Override
	public void execute(IAntToolkit antWriter, 
			IDataContext localContext, 
			Map<String, List> inputPaths, 
			Map<String, Object> outputPaths,
			Map<String, List> usedPaths, 
			Map<String, Object> parameters) throws GeneratorException, IOException {
		IAntToolkit.Element elem = antWriter.createElement("copy"); //$NON-NLS-1$
		elem.addAttribute("flatten", "true"); //$NON-NLS-1$ //$NON-NLS-2$
		elem.addAttribute("includeemptydirs", "false"); //$NON-NLS-1$ //$NON-NLS-2$
		elem.addAttribute("todir", outputPaths.get("default")); //$NON-NLS-1$ //$NON-NLS-2$

		List xlf_temp = inputPaths.get("default"); //$NON-NLS-1$ 
		for (Object o : xlf_temp) {
			IAntToolkit.Element filesetChild = elem.createChild("fileset"); //$NON-NLS-1$
			filesetChild.addAttribute("dir", o); //$NON-NLS-1$
		}
		
		elem.render();
	}
}
