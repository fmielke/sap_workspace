package com.sap.bie.sca.scdl.mc.gen.impl;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IAttributeValue;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;

/**
 * Represents a custom attribute that is added to xi binding element
 */
public class XiCustomScdlAttribute implements ICustomScdlAttribute {

	private final String attributeName;
	private QName qName;
	XiAttributeValue attributeValue;

	XiCustomScdlAttribute(final QName qName, String name, String value) {
		this.qName = qName;
		this.attributeName = name;
		this.attributeValue = new XiAttributeValue(this.qName, value);;
	}

	@Override
	public IAttributeValue getAttributeValue() {
		return this.attributeValue;
	}

	@Override
	public String getAttributeNamespacePrefix() {
		return qName.getLocalPart();
	}

	@Override
	public String getAttributeNamespace() {
		return qName.getNamespaceURI();
	}

	@Override
	public String getAttributeName() {
		return attributeName;
	}

	
	class XiAttributeValue implements IAttributeValue {
		private QName qName;
		private String value;

		public XiAttributeValue(final QName qName, String value) {
			this.qName = qName;
			this.value = value;
		}

		@Override
		public String getNamespace() {
			return this.qName.getLocalPart();
		}

		@Override
		public String getNamespacePrefix() {
			return this.qName.getPrefix();
		}

		@Override
		public String getValue() {
			return this.value;
		}

	}
	
}
