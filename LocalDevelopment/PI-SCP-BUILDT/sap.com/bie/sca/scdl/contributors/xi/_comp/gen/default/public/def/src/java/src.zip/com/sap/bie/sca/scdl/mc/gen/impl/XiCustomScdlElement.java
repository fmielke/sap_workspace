package com.sap.bie.sca.scdl.mc.gen.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.xml.namespace.QName;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;

/**
 * Represents a custom element in xi binding inside the scdl file
 */
public class XiCustomScdlElement implements ICustomScdlElement {

	private QName qname;

	final List<ICustomScdlAttribute> attributes = new ArrayList<ICustomScdlAttribute>();

	public XiCustomScdlElement(QName qname, List<ICustomScdlAttribute> attributes) {
		this.qname = qname;
		this.attributes.addAll(attributes);
	}

	@Override
	public String getElementName() {
		return qname.getLocalPart();
	}

	@Override
	public String getNamespace() {
		return qname.getNamespaceURI();
	}

	@Override
	public String getNamespacePrefix() {
		return qname.getPrefix();
	}

	@Override
	public Collection<ICustomScdlAttribute> getCustomAttributes() {
		return Collections.unmodifiableCollection(attributes);
	}

	@Override
	public List<ICustomScdlElement> getChildren() {
		return Collections.emptyList();
	}

}
