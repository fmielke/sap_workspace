package com.sap.bie.sca.scdl.mc.util;

import com.sap.tc.buildplugin.api.IPluginBuildInfo;

/**
 * Utility class to format the default service name according to XI guidelines
 */
public final class ServiceNameUtility {

	private ServiceNameUtility(){}
	
	public static String getServiceName(final IPluginBuildInfo pluginBuildInfo){
		if(pluginBuildInfo == null) return null;
		String senderServiceValue = pluginBuildInfo.getDCVendor()+"_"+pluginBuildInfo.getDCName() ;
		
		if (senderServiceValue.length() > 60) {
			//return last 60 characters
			int count = senderServiceValue.length() - 60;
			senderServiceValue = senderServiceValue.substring(count, senderServiceValue.length() - 1);
		}
		
		return PatternMatcher(senderServiceValue);
	}
	
	/*
	 * As per the XI guideline Sender service name should contain only
	 * alphanumeric characters. This method remove the non alpha numeric chars.
	 */
	private static String PatternMatcher(String source) {
		source = source.replace('/','_');
		source = source.replace('!','_');
		source = source.replace('$','_');
		source = source.replace('-','_');
		source = source.replace('.','_');
		source = source.replaceAll(("[^a-zA-Z0-9_]"), "");
		return source;
	}
	
}
