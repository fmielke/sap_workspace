package com.sap.tc.buildplugin.pdef;

import com.sap.tc.buildplugin.scdef.ScdefTaskGenerator;


public class PdefTaskGenerator extends ScdefTaskGenerator {

    @Override
	protected String getTaskName() {
    	return "PdefGeneratorTask";
    }

}
