package com.sap.tc.buildplugin.pdef;

import static com.sap.sld.api.wbem.sap.SLDElementNames.C_SAP_Product;
import static com.sap.sld.api.wbem.sap.SLDElementNames.C_SAP_ProductLine;
import static com.sap.sld.api.wbem.sap.SLDElementNames.P_IdentifyingNumber;
import static com.sap.sld.api.wbem.sap.SLDElementNames.P_Name;
import static com.sap.sld.api.wbem.sap.SLDElementNames.P_PPMSNumber;
import static com.sap.sld.api.wbem.sap.SLDElementNames.P_Vendor;
import static com.sap.sld.api.wbem.sap.SLDElementNames.P_Version;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import com.sap.cim.api.admin.ICIMExport;
import com.sap.cim.api.admin.ICIMExportResultItem;
import com.sap.cim.api.admin.ICIMImport;
import com.sap.cim.api.admin.ICIMPreparationStatus;
import com.sap.cim.api.core.CIMStartup;
import com.sap.cim.api.core.ICIMDomainContext;
import com.sap.cim.api.core.ICIMDomainManager;
import com.sap.cim.api.core.WBEMLocalTransactionClient;
import com.sap.sld.api.std.soft.SLD_Product;
import com.sap.sld.api.std.soft.SLD_ProductVersion;
import com.sap.sld.api.std.soft.SLD_SoftwareComponent;
import com.sap.sld.api.std.soft.SLD_SoftwareComponentVersion;
import com.sap.sld.api.std.soft.SLD_SoftwareUnit;
import com.sap.sld.api.wbem.cim.CIMDeclaration;
import com.sap.sld.api.wbem.cim.CIMElement;
import com.sap.sld.api.wbem.cim.CIMInstance;
import com.sap.sld.api.wbem.cim.CIMObjectWithReference;
import com.sap.sld.api.wbem.cim.CIMProperty;
import com.sap.sld.api.wbem.cim.CIMReference;
import com.sap.sld.api.wbem.cim.CIMType;
import com.sap.sld.api.wbem.cim.CIMBaseProperty.Kind;
import com.sap.sld.api.wbem.cim.CIMDeclaration.CIMGroup;
import com.sap.sld.api.wbem.cim.CIMReference.CIMKey;
import com.sap.sld.api.wbem.exception.CIMException;
import com.sap.sld.api.wbem.sap.SLDElementNames;
import com.sap.sld.api.wbem.transform.CIMXmlParser;
import com.sap.sld.api.wbem.transform.CIMXmlWriter;
import com.sap.tc.buildplugin.scdef.EdenBuildPluginConstants;
import com.sap.tc.buildplugin.scdef.ScdefDCUtil;
import com.sap.tc.buildplugin.scdef.ScdefValidator;
import com.sap.tc.buildplugin.util.BuildPluginException;

public class PdefValidator extends ScdefValidator
{
  // Buffer size for file copy
  private final static int BYTE_BUFFER_SIZE = 1024;

  @Override
  protected void generate(
		  HashMap<String, File> inputFileMap,
		  File gendir,
		  File tempdir,
		  List<File> sourceDirList, List<File> compilePPDirList) throws BuildPluginException, CIMException, IOException {
    HashMap<String, String> productValuesMap = getProductValueMap(inputFileMap);

    // generate CR and LD only if the DC does not contain complete product model
    if(!ScdefDCUtil.dcContainsCompleteProductModel())
    {
    	generateProductCR(inputFileMap, productValuesMap, gendir, sourceDirList, compilePPDirList);
    	generateProductLD(productValuesMap, gendir);
    }
    generateDeploymentDescriptor(tempdir);
  }

  @Override
  protected StringBuffer getDeploymentDescriptorContent() throws IOException {
    StringBuffer buffer = new StringBuffer(200);
    if(ScdefDCUtil.dcContainsCompleteProductModel())
    {
    	buffer.append("<SDA>\n");
    	buffer.append("  <SoftwareType>J2EE</SoftwareType>\n");
    	buffer.append("  <engine-deployment-descriptor version=\"2.0\">\n");
    	buffer.append("    <substitution-variable>\n");
    	buffer.append("      <variable-name>com.sap.sld.GatewayHost</variable-name>\n");
    	buffer.append("    </substitution-variable>\n");
    	buffer.append("    <substitution-variable>\n");
    	buffer.append("      <variable-name>com.sap.sld.GatewayService</variable-name>\n");
    	buffer.append("    </substitution-variable>\n");
    	buffer.append("  </engine-deployment-descriptor>\n");
    	buffer.append("</SDA>\n");
    }
    else
    {
	    buffer.append("<SDA>\n");
	    buffer.append("  <SoftwareType>CONTENT</SoftwareType>\n");
	    buffer.append("  <sl-sda-deployment-descriptor>\n");
	    buffer.append("    <sl-sda-logical-type>CR-SDA</sl-sda-logical-type>\n");
	    buffer.append("      <model-file>" + CIM_MODEL_OUTPUT_FILENAME  + "</model-file>\n");
	    buffer.append("      <cr-files>\n");
	    buffer.append("        <cr-file>" + CR_CONTENT_OUTPUT_FILENAME + "</cr-file>\n");
	    buffer.append("      </cr-files>\n");
	    buffer.append("      <ld-files>\n");
	    buffer.append("        <ld-file>" + LD_CONTENT_OUTPUT_FILENAME + "</ld-file>\n");
	    buffer.append("      </ld-files>\n");
	    
	    ArrayList<String> funDcMapPathes = getFunDcMapPathes();
	    if (! funDcMapPathes.isEmpty()) {
	      buffer.append("      <dc-mapping-files>\n");
          for (String thisPath : funDcMapPathes) {
            buffer.append("        <dc-mapping-file>" + thisPath + "</dc-mapping-file>\n");
          }
	      buffer.append("      </dc-mapping-files>\n");
	    }
	    
	    buffer.append("  </sl-sda-deployment-descriptor>\n");
	    buffer.append("</SDA>\n");
    }
    return buffer;
  }

  /**
   * @return Names of input files that may be relevant for generation and must be looked up in source directories
   */
  @Override
  protected List<String> getInputFilenameList()
  {
    return getPdefInputFilenameList();
  }

  /**
   * @return Names of input files that may be relevant for generation and must be looked up in source directories
   */
  protected List<String> getPdefInputFilenameList()
  {
    final List<String> fileNameList = new ArrayList<String>();
    fileNameList.add(CONTENTZIP_INPUT_FILENAME);
    fileNameList.add(DESCRIPTION_INPUT_FILENAME);
    fileNameList.add(EdenBuildPluginConstants.CR_CONTENT_FILENAME);
    fileNameList.add(MODEL_INPUT_FILENAME);
    return fileNameList;
  }

  /**
   * Compute HashMap object to be used for generation of output content, either from content.zip or .description file handed in (one of them must be defined)
   * Contains the following keys
   * PROP_NAME             * mandatory *
   * PROP_VERSION          * mandatory *
   * PROP_VENDOR           * mandatory *
   * PROP_ELEMENT_TYPE_ID  * may be undefined *
   * PROP_GUID             * may be undefined *
   * @param fileMap Map of files to process for filling the result.
   * @return HashMap containing entries for name, version and vendor (mandatory), and maybe also for elementTypeID and guid
   * @throws IOException
   * @throws BuildPluginException
   * @throws FileNotFoundException
   */
  private HashMap<String, String> getProductValueMap(
    HashMap<String, File> inputFileMap
    ) throws IOException, BuildPluginException, FileNotFoundException
  {
    final String methodName = "getProductValueMap";
    loggMethodStart(methodName);
    loggHashMap("InputFileMap", inputFileMap);

    final HashMap<String, String> result = new HashMap<String, String>();
    final File contentzipFile = inputFileMap.get(CONTENTZIP_INPUT_FILENAME);
    final File descriptionFile = inputFileMap.get(DESCRIPTION_INPUT_FILENAME);
    final File crcontentFile = inputFileMap.get(EdenBuildPluginConstants.CR_CONTENT_FILENAME);

    File cimXmlParserInputFile = null;
    if (crcontentFile != null) {
      // Explicit CR-Content file present, use this for parsing
      cimXmlParserInputFile = crcontentFile;
    } else {
      if (contentzipFile != null) {
        // IDE generated content.zip file present
        cimXmlParserInputFile = contentzipFile;
      }
    }

    // Choose which files to read
    if (cimXmlParserInputFile != null)
    {
      loggMessage("Reading product info from: " + cimXmlParserInputFile.getAbsolutePath());
      // Content file is present, exported by IDE from connected SLD
      CIMDeclaration parseResult = null;
      try
      {
        boolean productFound = false;
        boolean productLineFound = false;
        ZipFile zippy = new ZipFile(cimXmlParserInputFile.getAbsolutePath());

        ZIP_ENTRY_LOOP:
        for (
            Enumeration<? extends ZipEntry> entries = zippy.entries();
            entries.hasMoreElements();)
        {
          ZipEntry entry = entries.nextElement();
          if (entry.getName().endsWith(POSTFIX_XML))
          {
            CIMXmlParser cimParser = new CIMXmlParser();
            parseResult = (CIMDeclaration) cimParser.parse(zippy.getInputStream(entry));
            loggMessage(parseResult.toString());
            for (Iterator<CIMGroup> cimGroupIter = parseResult.iterateGroups();
                 cimGroupIter.hasNext();)
            {
              CIMGroup group = cimGroupIter.next();
              loggMessage(group.toString());
              for (Iterator<CIMElement> groupIter = group.iterateObjects(); groupIter.hasNext();) {
                boolean somethingExtracted = false;
                CIMElement element = groupIter.next();
                if (element instanceof CIMObjectWithReference)
                {
                  CIMObjectWithReference ref = (CIMObjectWithReference) element;
                  CIMInstance inst = ref.getInstance();
                  if (inst != null) {
                    if (! productFound && inst.getElementName().equals(C_SAP_Product)) {
                      createEntryInValueMap(result, MAP_KEY_NAME, inst.getValue(P_Name), true);
                      createEntryInValueMap(result, MAP_KEY_VERSION, inst.getValue(P_Version), true);
                      createEntryInValueMap(result, MAP_KEY_VENDOR, inst.getValue(P_Vendor), true);
                      createEntryInValueMap(result, MAP_KEY_PRODUCT_IDENTIFYING_NUMBER, inst.getValue(P_IdentifyingNumber), false);
                      somethingExtracted = true;
                      productFound = true;
                    } else {
                      if (! productLineFound && inst.getElementName().equals(C_SAP_ProductLine)) {
                        String ppmsNumber = inst.getValue(P_PPMSNumber);
                        createEntryInValueMap(result, MAP_KEY_PRODUCTLINE_PPMS_NUMBER, ppmsNumber, false);
                        somethingExtracted = true;
                        productLineFound = true;
                      }
                    }
                    if (somethingExtracted) {
                      loggMessage("Extracted: " + element.getClass() + " : " + element.toString());
                    }
                    if (productFound && productLineFound) {
                      break ZIP_ENTRY_LOOP;
                    }
                  }
                }
              }
            }
          }
        }
      }
      catch (CIMException e)
      {
        throw new BuildPluginException("Failed to create CIMXmlParser", e);
      }
    }
    else
    {
      // Fall back to .description properties file
      loggMessage("Reading product info from: " + descriptionFile.getAbsolutePath());
      readNameVersionVendorFromDescription(result, descriptionFile);
    }
    loggHashMap("ProductValueMap", result);
    loggMethodEnd(methodName);
    return result;
  }

  protected void generateProductLD(HashMap<String, String> productValuesMap, File gendir) throws BuildPluginException, CIMException, IOException
  {
    final String methodName = "generateProductLD";
    loggMethodStart(methodName);

    ZipOutputStream ostream = null;
    try
    {
      // Create basic CIMInstance for current SoftwareComponent
      CIMInstance cimInst = new CIMInstance(
        SLDElementNames.C_SAP_Product);
      CIMProperty cimPropName = new CIMProperty(
        SLDElementNames.P_Name,
        CIMType.STRING,
        productValuesMap.get(MAP_KEY_NAME));
      CIMProperty cimPropVend = new CIMProperty(
        SLDElementNames.P_Vendor,
        CIMType.STRING,
        productValuesMap.get(MAP_KEY_VENDOR));
      CIMProperty cimPropVers = new CIMProperty(
        SLDElementNames.P_Version,
        CIMType.STRING,
        productValuesMap.get(MAP_KEY_VERSION));

      // Special handling for product IdentifyingNumber: Use zero if undefined
      String identifyingNumber = productValuesMap.get(MAP_KEY_PRODUCT_IDENTIFYING_NUMBER);
      if (identifyingNumber == null) {
        identifyingNumber = "0";
      }
      CIMProperty cimPropIdentNumber = new CIMProperty(
        SLDElementNames.P_IdentifyingNumber,
        CIMType.STRING,
        identifyingNumber);

      cimInst.setBaseProperty(cimPropName);
      cimInst.setBaseProperty(cimPropVend);
      cimInst.setBaseProperty(cimPropVers);
      cimInst.setBaseProperty(cimPropIdentNumber);

      // Create reference from CIMInstance
      CIMReference cimRef = new CIMReference(null, null, C_SAP_Product);
      for (Iterator<?> iter = cimInst.iterateProperties(Kind.PROPERTY); iter.hasNext();)
      {
        CIMProperty property = (CIMProperty) iter.next();
        cimRef.setKey(new CIMKey(property.getElementName(), property.getType(), property.getValue()));
      }

      // Create object-with-reference compound, group and declaration, then assemble
      CIMObjectWithReference cimObjWRef = new CIMObjectWithReference(cimRef, cimInst);
      CIMGroup cimGroup = new CIMGroup();
      cimGroup.add(cimObjWRef);
      CIMDeclaration cimDecl = new CIMDeclaration();
      cimDecl.add(cimGroup);

      // Create output file for generation content
      File ofile = new File(gendir, LD_CONTENT_OUTPUT_FILENAME);
      ostream = new ZipOutputStream(new FileOutputStream(ofile));
      ostream.putNextEntry(new ZipEntry(ZIP_ENTRY_NAME));

      // Write to build output file
      CIMXmlWriter xmlWriter = new CIMXmlWriter(true);
      xmlWriter.write(ostream, cimDecl);
    }
    catch (IOException e)
    {
      throw new BuildPluginException(e.getMessage(), e);
    }
    finally {
      if (ostream != null) {
        ostream.close();
      }
    }
    loggMethodEnd(methodName);
  }


  private void generateProductCR(
		  HashMap<String, File> inputFileMap,
		  HashMap<String, String> prodValuesMap,
		  File gendir,
		  List<File> sourceDirList, List<File> compilePPDirList) throws BuildPluginException, CIMException
  {
    final String methodName = "generateProductCR";
    loggMethodStart(methodName);

    try
    {
      // Collect software component properties in HashMap
      ArrayList<HashMap<String, String>> allSoftcompValueMaps = new ArrayList<HashMap<String, String>>();
      List<File> ppRoots = compilePPDirList;
      for (File root : ppRoots)
      {
        List<File> softcompDirList = new ArrayList<File>();
        softcompDirList.add(root);
        HashMap<String, File> softcompFileMap = new HashMap<String, File>();
        softcompFileMap = getInputFileMap(softcompDirList, getScdefInputFilenameList());
        HashMap<String, String> softcompValueMap = getSoftcompValueMap(softcompFileMap);
        allSoftcompValueMaps.add(softcompValueMap);
      }

      // Create output file in temporary generation directory.
      File crContentOutputFile = new File(gendir, CR_CONTENT_OUTPUT_FILENAME);

      if (inputFileMap.containsKey(EdenBuildPluginConstants.CR_CONTENT_FILENAME)) {
        // Fixed content for CR-SDA is present, use it without further processing
        File inputFile = inputFileMap.get(EdenBuildPluginConstants.CR_CONTENT_FILENAME);
        copyFileToFile(inputFile, crContentOutputFile);
        loggFileCopy(CR_CONTENT_OUTPUT_FILENAME, inputFile, crContentOutputFile);
      } else {
        // Open stream to SLD model either in input file map of DC or in data area of plugin.
        InputStream inputStream = getModelInputStream("ModelImport", inputFileMap);

        // Create the necessary CIMContent and return export results
        ICIMExportResultItem[] exportResults;
        try {
	        exportResults = createCIMContentAndExport(
	          prodValuesMap,
	          allSoftcompValueMaps,
	          inputStream);
	    }
        finally {
        	inputStream.close();
        }

        // Write export content to output stream
        FileOutputStream outputStream = new FileOutputStream(crContentOutputFile);
        for (int i = 0; i < exportResults.length; i++) {
          outputStream.write(exportResults[i].getResultBytes());
        }
        outputStream.close();
      }

      // Copy contents of model to model output file path
      InputStream inputStream = null;
      OutputStream outputStream = null;
      try {
	      final File modelOutputFile = new File(gendir, CIM_MODEL_OUTPUT_FILENAME);
	      inputStream = getModelInputStream("ModelCopy", inputFileMap);
	      outputStream = new FileOutputStream(modelOutputFile);
	      copyInputStreamToOutputStream(inputStream, outputStream);
      }
      finally {
    	  try {
	    	  if (inputStream != null) {
	    		  inputStream.close();
	    	  }
    	  }
	      catch (IOException e) {
	    	  // $JL-EXC$
	    	  loggMessage("IOException when closing input stream during model file creation, continuing ...");
	      }
	      try {
	    	  if (outputStream != null) {
	    		  outputStream.close();
	    	  }
	      }
	      catch (IOException e) {
	    	  // $JL-EXC$
	    	  loggMessage("IOException when closing output stream during model file creation, continuing ...");
	      }
      }
    }
    catch (IOException e)
    {
      throw new BuildPluginException(e.getMessage(), e);
    }
    loggMethodEnd(methodName);
  }

  // Create the CIM content and write it to a file
  private ICIMExportResultItem[] createCIMContentAndExport(
    HashMap<String, String> prodValuesMap,
    ArrayList<HashMap<String, String>> allSoftcompValueMaps,
    InputStream modelImportStream) throws CIMException
  {
    final String methodName = "createCIMContentAndExport";
    loggMethodStart(methodName);

    PluginUser user = new PluginUser();
    ICIMDomainManager domainManager;
    domainManager = CIMStartup.getStandaloneDomainManager();
    if (domainManager == null)
    {
      domainManager = CIMStartup.createStandaloneDomainManager();
    }

    ICIMDomainContext domainContext = null;
    ICIMExportResultItem[] exportResults;
    try {
      domainContext = domainManager.initializeVirtualDomain("plugin", null);
      domainContext.activateObjectManager();
      WBEMLocalTransactionClient client = domainContext.createWBEMLocalClient(user);
      ICIMImport importManager = domainContext.getImportManager();
      ICIMPreparationStatus preparationStatus = importManager.prepareImport(modelImportStream, client.getTargetNamespace(), user);
      if (preparationStatus.isImportCompatible()) {
        importManager.performImport(preparationStatus);
      }
      try {
        importManager.join();
      }
      catch (InterruptedException e) {
        throw new CIMException("Caught unexpected InterruptedException", null, e);
      }

      // User product properties to build up items up to software unit
      final String prodName = prodValuesMap.get(MAP_KEY_NAME);
      final String prodVendor = prodValuesMap.get(MAP_KEY_VENDOR);
      final String prodVersion = prodValuesMap.get(MAP_KEY_VERSION);
      final String prodProductIdentifyingNumber = prodValuesMap.get(MAP_KEY_PRODUCT_IDENTIFYING_NUMBER);
      final String prodProductLinePPMSNumber = prodValuesMap.get(MAP_KEY_PRODUCTLINE_PPMS_NUMBER);

      // Determine if we have access to PPMS numbers or not
      final boolean hasNoPPMSNumbers = (prodProductIdentifyingNumber == null || prodProductIdentifyingNumber.equals("0"));
      loggMessage(hasNoPPMSNumbers ? "No PPMS numbers available in product" : "Using PPMS numbers from product");

      // Act different depending on availability of PPMS information
      SLD_ProductVersion vers = null;
      if (hasNoPPMSNumbers) {
        // At customer, no PPMS numbers
        SLD_Product prod = SLD_Product.createProduct(
          client,
          prodName,
          prodVendor);
        prod.save();
        vers = prod.addProductVersion(
          prodName,
          prodVendor,
          prodVersion);
        vers.save();
      } else {
        // At SAP, use PPMS numbers
        SLD_Product prod = SLD_Product.createProduct(
          client,
          prodName,
          prodVendor);
        prod.setPPMSNumber(prodProductLinePPMSNumber);
        prod.save();
        vers = prod.addSAPProductVersion(
          prodName,
          prodVendor,
          prodVersion,
          prodProductIdentifyingNumber);
        vers.save();
      }

      // Iterate software component parts and add to software unit each of them
      final SLD_SoftwareUnit unit = vers.addSoftwareUnit("null");
      unit.save();
      addSoftwareComponentsToSoftwareUnit(allSoftcompValueMaps, client, unit);

      ICIMExport exportManager = domainContext.getExportManager();
      exportManager.performInstanceBackup(client.getTargetNamespace(), user);
      try
      {
        exportManager.join();
      }
      catch (InterruptedException e1)
      {
        throw new CIMException(e1);
      }
      // Since a private virtual domain was used, getStatus() will never return <null>
      // So we can leave out the <null> check
      exportResults = domainContext.getExportManager().getStatus().getExportResults();
    }
    finally {
      if (domainContext != null) {
        domainManager.destroyDomain(domainContext.getDomain());
      }
    }
    loggMethodEnd(methodName);
    return exportResults;
  }

  private void addSoftwareComponentsToSoftwareUnit(
    ArrayList<HashMap<String, String>> allSoftcompValueMaps,
    WBEMLocalTransactionClient client,
    final SLD_SoftwareUnit unit) throws CIMException
  {
    final String methodName = "addSoftwareComponentsToSoftwareUnit";
    loggMethodStart(methodName);

    for (HashMap<String, String> nextMap : allSoftcompValueMaps)
    {
      loggHashMap("Next softcomp map to add", nextMap);
      String name = nextMap.get(MAP_KEY_NAME);
      String vendor = nextMap.get(MAP_KEY_VENDOR);
      String version = nextMap.get(MAP_KEY_VERSION);
      String elementTypeId = nextMap.get(MAP_KEY_ELEMENT_TYPE_ID);
      String guid = nextMap.get(MAP_KEY_GUID);
      loggMessage("unit: " + unit);
      loggMessage("name: " + name);
      loggMessage("vendor: " + vendor);
      loggMessage("version: " + version);
      loggMessage("elementTypeId: " + elementTypeId);
      loggMessage("GUID: " + guid);
      SLD_SoftwareComponent softComp = SLD_SoftwareComponent.createSoftwareComponent(
        client,
        name,
        vendor);
      softComp.save();
      if (elementTypeId == null) {
        elementTypeId = "0";
        loggMessage("elementTypeId: " + elementTypeId);
      }
      if (guid == null) {
        guid = "0";
        loggMessage("GUID: " + guid);
      }
      // Software component version can only be created if elementTypeId (ppms number) and guid is defined
      SLD_SoftwareComponentVersion softCompVers = softComp.addSoftwareComponentVersion(
        name,
        vendor,
        version,
        elementTypeId,
        guid,
        unit);
      softCompVers.save();
      unit.addSoftwareComponentVersion(softCompVers);
      unit.save();
    }
    loggMethodEnd(methodName);
  }

  protected InputStream getResourceInputStream(String taskDescription, String path)
  {
    InputStream istream = this.getClass().getClassLoader().getResourceAsStream(path);
    final String prefix = (istream != null) ? "Resource opened for " : "Resource not found for ";
    loggMessage(prefix + taskDescription + ": " + path);
    return istream;
  }

  private void copyResourceToFile (String resource, File outputFile) throws IOException, BuildPluginException {
    // Input stream from plug-in resource
    InputStream inputStream = getResourceInputStream("Copy", resource);
    if (inputStream == null) {
      throw new BuildPluginException(resource + ": Resource not found for Copy");
    }
    copyInputStreamToOutputStream(inputStream, new FileOutputStream(outputFile));
  }

  protected void copyFileToFile (File inputFile, File outputFile) throws IOException, BuildPluginException {
    copyInputStreamToOutputStream(new FileInputStream(inputFile), new FileOutputStream(outputFile));
  }

  private void copyInputStreamToOutputStream(
    InputStream inputStream,
    OutputStream outputStream) throws FileNotFoundException, IOException
  {
    int bytesRead;
    byte[] theBytes = new byte[BYTE_BUFFER_SIZE];
    BufferedInputStream bin = new BufferedInputStream(inputStream);
    BufferedOutputStream bout = new BufferedOutputStream(outputStream);
    // Do the copy
    while ((bytesRead = bin.read(theBytes, 0, BYTE_BUFFER_SIZE)) != -1) {
      bout.write(theBytes, 0, bytesRead);
    }
    // Close both buffered streams, flushes automatically
    bin.close();
    bout.close();
  }
  
  /**
   * Deliver an InputStream that may serve as CIM model input. In case the model file is
   * contained in the <code>inputFileMap</code> the returned stream is created from the indicated
   * location. In case it is not, the model file in the plugin's own data folder is used. 
   * @param task The description of the task for which the input stream is needed.
   * @param inputFileMap The map containing the input files of the current build plugin run.
   * @return An InputStream to be used for model input. 
   * @throws FileNotFoundException If the <code>inputFileMap</code> contains the file, but it is actually not found on stream creation.
   */
  protected InputStream getModelInputStream (
		  String task,
	      HashMap<String, File> inputFileMap) throws BuildPluginException {
		InputStream result;
		if (inputFileMap.containsKey(MODEL_INPUT_FILENAME)) {
			// Model file in source directory - use this version
			loggMessage("Opening model input stream from DC source file for task: " + task);
			File inputFile = inputFileMap.get(MODEL_INPUT_FILENAME);
			try {
			  result = new FileInputStream(inputFile);
			}
			catch (FileNotFoundException e) {
				// File not found although in file map - should never happen
				throw new BuildPluginException(
						"Failed to create model input stream although model file is in filemap",
						e);
			}
		} else {
			// Use model file from build plug-in data area
			loggMessage("Opening model input stream from plugin resource for task: " + task);
			result = getResourceInputStream(task, MODEL_DATA_PATH);
		}
		return result;
	}

 }
