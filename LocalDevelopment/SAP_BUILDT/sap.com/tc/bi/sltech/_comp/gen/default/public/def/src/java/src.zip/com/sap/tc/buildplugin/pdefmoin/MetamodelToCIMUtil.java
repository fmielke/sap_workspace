package com.sap.tc.buildplugin.pdefmoin;

import java.util.HashMap;
import java.util.Iterator;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.EMap;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.emf.ecore.*;
import org.eclipse.emf.ecore.util.EcoreUtil;

import com.sap.lm.slmodel.SlmodelPackage;
import com.sap.lm.slmodel.SoftwareFeature;
import com.sap.sld.api.wbem.cim.*;
import com.sap.sld.api.wbem.cim.CIMBaseProperty.Kind;
import com.sap.sld.api.wbem.client.WBEMClient;
import com.sap.sld.api.wbem.client.WBEMClientUtil;
import com.sap.sld.api.wbem.exception.CIMException;
import com.sap.sld.api.wbem.sap.SLDElementNames;

/**
 * Util class for transformation from MOIN to CIM and CIM to MOIN.
 */
public class MetamodelToCIMUtil
{
	private final WBEMClient					client;

	private static final String					TAG_NAME	= "CIMClass";							//$NON-NLS-1$
	private static HashMap<String, ElementName>	MOIN_TO_CIM	= new HashMap<String, ElementName>();

	public MetamodelToCIMUtil(WBEMClient client)
	{
		this.client = client;
	}

	/**
	 * Creates a new instance template for the class corresponding to the ElementName
	 * 
	 * @see CIMClass#createInstanceTemplateComplete()
	 * @param name
	 *            the ElementName of the class for creating the instance
	 * @return the new instance template
	 * @throws CIMException
	 */
	private CIMInstance getInstanceTemplate(ElementName name) throws CIMException
	{
		CIMClass cimClass = WBEMClientUtil.getClassComplete(client, name);
		CIMInstance cimInstance = cimClass.createInstanceTemplateComplete();
		return cimInstance;
	}

	/**
	 * Returns the CIMReference for the CIMInstance
	 * 
	 * @see CIMInstance#buildInstanceReference(CIMClass)
	 * @param instance
	 * @return the CIMReference for the CIMInstance
	 * @throws CIMException
	 */
	private CIMReference getCIMReference(CIMInstance instance) throws CIMException
	{
		CIMClass cimClass = WBEMClientUtil.getClassComplete(client, instance.getElementName());
		return instance.buildInstanceReference(cimClass);
	}

	/**
	 * Creates a new CIMInstance for the EObjects and sets all the properties.
	 * 
	 * @param object
	 *            - refObject, subtype of the MOIN class CIM_ManagedElement
	 * @return a new CIMInstance corresponding to the MON class with all properties set. Can not
	 *         return <code>null</code>
	 * @throws CIMException
	 */
	public CIMInstance getCIMInstanceFromRefObject(EObject object) throws CIMException
	{
		ElementName classElementName = getClassElementNameFromRefObject(object);
		CIMInstance instance = getInstanceTemplate(classElementName);
		CIMClass cimClass = WBEMClientUtil.getClassComplete(client, classElementName);
		// only Kind.PROPERTY, there is no Kind.ARRAY in MOIN
		Iterator<CIMBaseProperty> properties = cimClass.iterateProperties(Kind.PROPERTY);
		while (properties.hasNext())
		{
			CIMProperty property = (CIMProperty) properties.next();
			ElementName propertyName = property.getElementName();
			EStructuralFeature feature = object.eClass().getEStructuralFeature(propertyName.toString());
			if (feature != null && feature instanceof EAttribute)
			{
				try
				{
					Object value = object.eGet(feature);

					if (value != null)
					{
						final EDataType eDataType = ((EAttribute) feature).getEAttributeType();
						final EFactory eFactory = eDataType.getEPackage().getEFactoryInstance();
						String stringValue = eFactory.convertToString(eDataType, value);

						// value comes from a value maps
						CIMValueArray valueMap = property.getQualifierValueArray(SLDElementNames.Q_ValueMap);
						if (valueMap != null)
						{
							// String value is only display value of the value map
							if (!valueMap.containsValue(stringValue, property.getType()))
							{
								if (value instanceof Enumerator)
								{
									Enumerator enumValue = (Enumerator) value;
									stringValue = Integer.toString(enumValue.getValue());

									// int value is not value of the value map, this property can't
									// be set
									if (!valueMap.containsValue(stringValue, property.getType()))
									{
										stringValue = null;
									}
								}
							}
						}
						if (stringValue != null)
						{
							instance.setValue(propertyName, stringValue);
						}
					}
				}
				catch (IllegalArgumentException ex)
				{
					// $JL-EXC$
					// this property does not exist in the metamodel
				}
			}
		}

		return instance;
	}

	/**
	 * Creates a new CIMInstance for the EObject and set all the property references.
	 * 
	 * @param object
	 *            - refObject, subtype of the MOIN class CIM_BaseAssociation
	 * @return a new CIMInstance corresponding to the MON class with all references set. Can not
	 *         return <code>null</code>
	 * @throws CIMException
	 */
	public CIMInstance getCIMAssociationFromRefObject(EObject object) throws CIMException
	{
		CIMInstance assoc = getInstanceTemplate(getClassElementNameFromRefObject(object));
		// TODO need Kind.PROPERTY too
		Iterator<CIMBaseProperty> properties = assoc.iterateProperties(Kind.REFERENCE);
		while (properties.hasNext())
		{
			CIMPropertyReference property = (CIMPropertyReference) properties.next();
			ElementName propertyName = property.getElementName();
			EStructuralFeature feature = object.eClass().getEStructuralFeature(propertyName.toString());
			if (feature != null)
			{
				try
				{
					Object value = object.eGet(feature);
					if (value instanceof EObject)
					{
						CIMInstance reference = getCIMInstanceFromRefObject((EObject) value);
						assoc.setReference(propertyName, getCIMReference(reference));
					}
				}
				catch (IllegalArgumentException ex)
				{
					// $JL-EXC$
					// this property does not exist in the metamodel
				}
			}
		}

		return assoc;
	}

	/**
	 * /** Returns the ElementName of the corresponding CIMClass ElementName for the EObject.
	 * 
	 * @param object
	 *            . If it is instance of SoftwareFeature class and the identifying number property
	 *            is a valid PPMS-ID SLDElementNames#C_SAP_CoherentSoftwareUnit is returned.
	 * 
	 * @return can not return <code>null</code>
	 * @throws CIMException
	 *             - thrown if no CIM class exist for this EObject
	 */
	public static ElementName getClassElementNameFromRefObject(EObject object) throws CIMException
	{
		String mofId = EcoreUtil.getURI(object.eClass()).toString();
		ElementName className = getCIMClassNameFromModel(mofId);
		if (object instanceof SoftwareFeature)
		{
			SoftwareFeature sf = (SoftwareFeature) object;
			if (isValidPPMSID(sf.getIdentifyingNumber()))
			{
				className = SLDElementNames.C_SAP_CoherentSoftwareUnit;
			}
		}

		return className;
	}

	public static boolean isValidPPMSID(String ppmsid)
	{
		// valid if it consists of 20 digits
		if (ppmsid == null)
		{
			return false;
		}
		final int PPMSID_LENGTH = 20;
		if (ppmsid.length() != PPMSID_LENGTH)
		{
			return false;
		}
		for (int i = 0; i < ppmsid.length(); i++)
		{
			if (!Character.isDigit(ppmsid.charAt(i)))
			{
				return false;
			}
		}
		return true;
	}

	/**
	 * Returns the ElementName of the corresponding CIMClass ElementName for the EObject.
	 * 
	 * @param mofId
	 *            - the mofId of the corresponding Metamodel Class
	 * @param conn
	 *            - MOIN connection
	 * @return can not return <code>null</code>
	 * @throws CIMException
	 *             - thrown if no CIM class exist for this EObject
	 */
	public static synchronized ElementName getCIMClassNameFromModel(String mofId) throws CIMException
	{
		ElementName elementName = MOIN_TO_CIM.get(mofId);

		if (elementName == null)
		{
			initCIMClassNamesFromTag();
			elementName = MOIN_TO_CIM.get(mofId);
			if (elementName == null)
			{
				throw new CIMException("No CIMClass found for this business object with mofId {0}", new Object[] { mofId }); //$NON-NLS-1$
			}
		}

		return elementName;
	}

	/**
	 * Reads the value of the Tag {@link MetamodelToCIMUtil#TAG_NAME} for each Metamodel class and
	 * saves this data into a map Each MOIN class of the SL Model contains the ElementName of the
	 * corresponding CIMClass. This property is saved i a Tag associated to the MOIN class.
	 * 
	 * @param conn
	 *            - MOIN connection
	 */
	private static void initCIMClassNamesFromTag()
	{
		EList<EClassifier> classifiers = SlmodelPackage.eINSTANCE.getEClassifiers();
		for (EClassifier classifier : classifiers)
		{
			if (classifier instanceof EClass)
			{
				EAnnotation annotation = classifier.getEAnnotation(TAG_NAME);
				if (annotation != null)
				{

					EMap<String, String> details = annotation.getDetails();
					// TODO need to change the model and to give a the key a right name
					ElementName elementName = new ElementName(details.get("ElementName"));
					MOIN_TO_CIM.put(EcoreUtil.getURI(classifier).toString(), elementName);
				}
			}
		}
	}
}
