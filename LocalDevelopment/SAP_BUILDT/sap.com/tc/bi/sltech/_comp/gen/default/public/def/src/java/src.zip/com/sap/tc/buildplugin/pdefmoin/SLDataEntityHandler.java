package com.sap.tc.buildplugin.pdefmoin;

import java.util.Collection;
import java.util.List;

import com.sap.tc.buildplugin.pp.AbstractEntityHandler;
import com.sap.tc.buildplugin.pp.EntityDataProvider;
import com.sap.tc.buildplugin.pp.IEntityFileSet;
import com.sap.tc.buildplugin.pp.PackException;
import com.sap.tc.buildplugin.pp.PackerDestination;
import com.sap.tc.buildplugin.pp.api.IEntity;
import com.sap.tc.buildplugin.pp.util.FileSet;
import com.sap.tc.buildplugin.pp.util.PathIdentifier;
import com.sap.tc.buildplugin.scdef.EdenBuildPluginConstants;

public class SLDataEntityHandler
	extends AbstractEntityHandler
{
	public void determineFileList(IEntityFileSet efs, IEntity entity,
			EntityDataProvider provider) throws PackException {

		// Kuer, passt zu <packer><configuration location="sldata">.. in .bpfext
		//PackerDestination pd = PackerDestination.fromString("sldata");
		// Log.info("Hello world!");

		// Direkt aus Source-Verzeichnissen einpacken...
		List<PathIdentifier> sourcePaths = provider.getDCSourcePaths();
		for (PathIdentifier pi : sourcePaths) {
			FileSet fs = provider.createFileSet(pi);
			fs.addInclude(EdenBuildPluginConstants.MOIN_INPUT_FILENAME);
			efs.addFileSet(PackerDestination.FILESYSTEM, fs);
		}

		// Generierte Ergebnisse einpacken
		// geht nicht weil unterschiedliche Generatoren eingesetzt werden:
		// Collection<PathIdentifier> outputPaths = provider.getGeneratorOutputPaths("generatorID");

		// aber alle Aufrufe setzen dieses Attribut:
		Collection<PathIdentifier> packdirPaths = provider.getPaths(EdenBuildPluginConstants.ATTR_SLDATA_PACKDIR);
		for (PathIdentifier pi : packdirPaths) {
			FileSet fs = provider.createFileSet(pi);
			fs.addInclude(EdenBuildPluginConstants.CR_CONTENT_FILENAME);
			efs.addFileSet(PackerDestination.FILESYSTEM, fs); // oder mit Praefix: , "lib/sl/");
		}

		Collection<PathIdentifier> tempdirPaths = provider.getPaths(EdenBuildPluginConstants.ATTR_SLDATA_TEMPDIR);
		for (PathIdentifier pi : tempdirPaths) {
			FileSet fs = provider.createFileSet(pi);
			fs.addInclude(EdenBuildPluginConstants.NW_PRODUCTS_XML);
			fs.addInclude(EdenBuildPluginConstants.NW_PRODUCTS_EXTEND_XML);
			fs.addInclude(EdenBuildPluginConstants.UT_DEF_XML);
			fs.addInclude(EdenBuildPluginConstants.USAGES_DATA_XML);
			fs.addInclude(EdenBuildPluginConstants.ITSCENARIOS_XML);
			fs.addInclude(EdenBuildPluginConstants.JEXCLUDE_XML);
			efs.addFileSet(PackerDestination.FILESYSTEM, fs); // oder mit Praefix: , "lib/sl/");
		}
    }
}
