package com.sap.tc.buildplugin.pdefmoin;

import java.util.Collection;

import com.sap.tc.buildplugin.pp.AbstractEntityHandler;
import com.sap.tc.buildplugin.pp.EntityDataProvider;
import com.sap.tc.buildplugin.pp.IEntityFileSet;
import com.sap.tc.buildplugin.pp.PackException;
import com.sap.tc.buildplugin.pp.PackerDestination;
import com.sap.tc.buildplugin.pp.api.IEntity;
import com.sap.tc.buildplugin.pp.util.FileSet;
import com.sap.tc.buildplugin.pp.util.PathIdentifier;
import com.sap.tc.buildplugin.scdef.EdenBuildPluginConstants;

public class SLXmlAssemblyEntityHandler
	extends AbstractEntityHandler
{
	public void determineFileList(IEntityFileSet efs, IEntity entity,
			EntityDataProvider provider) throws PackException {

        // Pack several generated XML files from tempdir into assembly public part 
		Collection<PathIdentifier> tempdirPaths = provider.getPaths(EdenBuildPluginConstants.ATTR_SLDATA_TEMPDIR);
		for (PathIdentifier pi : tempdirPaths) {
			FileSet fs = provider.createFileSet(pi);
			fs.addInclude(EdenBuildPluginConstants.NW_PRODUCTS_XML);
			fs.addInclude(EdenBuildPluginConstants.NW_PRODUCTS_EXTEND_XML);
			fs.addInclude(EdenBuildPluginConstants.UT_DEF_XML);
			fs.addInclude(EdenBuildPluginConstants.USAGES_DATA_XML);
			fs.addInclude(EdenBuildPluginConstants.ITSCENARIOS_XML);
			fs.addInclude(EdenBuildPluginConstants.JEXCLUDE_XML);
			efs.addFileSet(PackerDestination.FILESYSTEM, fs); // oder mit Praefix: , "lib/sl/");
		}
    }
}
