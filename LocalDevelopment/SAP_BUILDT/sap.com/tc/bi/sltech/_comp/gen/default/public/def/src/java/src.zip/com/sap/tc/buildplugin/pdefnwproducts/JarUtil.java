package com.sap.tc.buildplugin.pdefnwproducts;

import java.io.*;
import java.util.List;
import java.util.jar.*;

import com.sap.tc.buildplugin.util.BuildPluginException;

public class JarUtil
{
	static final int	BUFFER	= 2048;

	/**
	 * Creates a new jar file, adding all files contained in the list
	 *
	 * @param jarFile - name of the jar file
	 * @param files - files to be included in the jar
	 */
	public static void createJarArchiv(File jarFile, List<File> files) throws BuildPluginException
	{
		try
		{
			BufferedInputStream origin = null;
			FileOutputStream dest = new FileOutputStream(jarFile);

			Manifest manifest = new Manifest();
			manifest.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");

			JarOutputStream out = new JarOutputStream(dest, manifest);

			byte data[] = new byte[BUFFER];

			for (File file : files)
			{
				FileInputStream fi = new FileInputStream(file);
				origin = new BufferedInputStream(fi, BUFFER);
				JarEntry entry = new JarEntry(file.getName());
				out.putNextEntry(entry);
				int count;
				while ((count = origin.read(data, 0, BUFFER)) != -1)
				{
					out.write(data, 0, count);
				}
				origin.close();
			}
			out.close();
			dest.close();
		}
		catch (FileNotFoundException e)
		{
			throw new BuildPluginException("Jar file not found ", e);
		}
		catch (IOException e)
		{
			throw new BuildPluginException("IO exception while generating jar file ", e);
		}
	}

}
