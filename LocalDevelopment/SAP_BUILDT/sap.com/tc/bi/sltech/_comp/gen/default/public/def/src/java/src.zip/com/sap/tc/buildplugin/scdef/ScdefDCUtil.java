package com.sap.tc.buildplugin.scdef;

import java.util.Iterator;

import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.pp.api.IDCAttribute;

public class ScdefDCUtil
{

	/**
	 * Returns true, if the DC attribute "complete_product_model" exists and its value is "true"
	 * This means that this DC contains the complete product model.
	 */
	public static boolean dcContainsCompleteProductModel()
	{
		IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
		for (Iterator<IDCAttribute> iterator = pbi.getDCAttributes().iterator(); iterator.hasNext();)
		{
			IDCAttribute attribute = iterator.next();
			if (EdenBuildPluginConstants.DC_ATTRIBUTE_COMPLETE_PRODUCT.equals(attribute.getTypeName()))
			{
				return Boolean.parseBoolean(attribute.getValue());
			}
		}

		return false;
	}

	/**
	 * Returns true, if the DC attribute "generate_nw_products" exists and its value is "true". This
	 * means that the nw_products.xml will be generated.
	 */
	public static boolean generateNwProducts()
	{
		IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
		for (Iterator<IDCAttribute> iterator = pbi.getDCAttributes().iterator(); iterator.hasNext();)
		{
			IDCAttribute attribute = iterator.next();
			if (EdenBuildPluginConstants.GENERATE_NW_PRODUCTS.equals(attribute.getTypeName()))
			{
				return Boolean.parseBoolean(attribute.getValue());
			}
		}

		return false;
	}
}
