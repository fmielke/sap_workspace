/**
 * 
 */
package com.sap.tc.buildplugin.scdef;

import java.io.File;
import java.util.*;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

import com.sap.tc.buildplugin.util.BuildPluginException;

/**
 * Anttask for SC definition generation.
 */
public class ScdefGeneratorTask extends Task
{

	private final List<Sdir>	sourceDirs;
	private final List<Cdir>	compilePPDirs;
	private File				packdir;
	private File				tempdir;

	/**
	 * 
	 */
	public ScdefGeneratorTask()
	{
		super();
		sourceDirs = new ArrayList<Sdir>();
		compilePPDirs = new ArrayList<Cdir>();
	}

	public Sdir createSdir()
	{
		Sdir result = new Sdir();
		sourceDirs.add(result);
		return result;
	}

	public void addSdir(Sdir dir)
	{
		sourceDirs.add(dir);
	}

	public Cdir createCdir()
	{
		Cdir result = new Cdir();
		compilePPDirs.add(result);
		return result;
	}

	public void addCdir(Cdir dir)
	{
		compilePPDirs.add(dir);
	}

	public void setPackdir(File f)
	{
		packdir = f;
	}

	public void setTempdir(File f)
	{
		tempdir = f;
	}

	@Override
	public void execute() throws BuildException
	{

		// Call EDEN build plugin
		List<File> sourceDirList = new ArrayList<File>();
		for (Sdir sdir : sourceDirs)
		{
			sourceDirList.add(sdir.getSdir());
		}

		List<File> compilePPDirList = new ArrayList<File>();
		for (Cdir cdir : compilePPDirs)
		{
			compilePPDirList.add(cdir.getCdir());
		}

		EdenBuildPlugin val = getPluginInstance();
		try
		{
			val.execute(this, sourceDirList, compilePPDirList, packdir, tempdir);
		}
		catch (BuildPluginException e)
		{
			throw new BuildException(e);
		}

	}

	/**
	 * The instance of the EdenBuildPlugin responsible for processing of this kind of build.
	 * Subclasses may override (in fact, normally will override to enhance capabilities).
	 * 
	 * @return
	 */
	protected EdenBuildPlugin getPluginInstance()
	{
		return new ScdefValidator();
	}

	/**
	 * only *.sldata files have to be indexed.
	 * 
	 * @see com.sap.tc.emf.ox.build.EmfTask#getValidFileSuffixes()
	 */
	protected Set<String> getValidFileSuffixes()
	{
		Set<String> set = new HashSet<String>();
		set.add(EdenBuildPluginConstants.VALID_FILE_SUFFIX_FOR_EMF_TASK);
		return set;
	}

}
