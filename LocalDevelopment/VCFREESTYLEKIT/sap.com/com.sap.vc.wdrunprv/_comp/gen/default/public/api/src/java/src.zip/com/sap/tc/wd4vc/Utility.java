package com.sap.tc.wd4vc;

public interface Utility {

	public static final String SEPERATOR = "/"; //$NON-NLS-1$
	public static final String CONTEXT_ROOT = "webdynpro/resources/"; //$NON-NLS-1$
	public static final String ENCODING = "UTF-8"; //$NON-NLS-1$
	/**
	 * Properties of the application.
	 */
	public static final String VENDOR = "vendor"; //$NON-NLS-1$
	public static final String SCNAME = "SCName"; //$NON-NLS-1$
	public static final String DCNAME = "DCName"; //$NON-NLS-1$
	public static final String NAME = "name"; //$NON-NLS-1$
	public static final String URN = "urn"; //$NON-NLS-1$
	public static final String ISMAINUNIT = "isMainUnit"; //$NON-NLS-1$
	public static final String DEFAULT_VENDOR = "sap.com"; //$NON-NLS-1$
	/**
	 * Constants used to get the dependencies of an application 
	 */
	public static final String DEPENDENCY = "dependency"; //$NON-NLS-1$
	public static final String NEWDEPENDENCY = "NewDependencies.xml"; //$NON-NLS-1$
	/**
	 * The two different clients for an application
	 */	
	public static final String WDHTMLRTPROVIDER = "WD4VCRuntimeProvider"; //$NON-NLS-1$
	public static final String WDFLEXRTPROVIDER = "WDFlexRuntimeProvider"; //$NON-NLS-1$
	/**
	 * The URLs generated for the WD applications will contain this String.
	 * VC DT will replace this String with http://<host>:<port>
	 */
	public static final String SERVER_ID = "##SERVERID##";  //$NON-NLS-1$
	
	/**
	 * Static URL for Flex
	 * ##SERVERID##/FlexClientWAR/FlexClient.html?URL=##SERVERID##/webdynpro/dispatcher/sap.com/irina_impl/Charttest1?sap-wd-client=SmartClient
	 */
	public static final String FLEX_CLIENT_URL = "##SERVERID##/FlexClientWAR/FlexClient.jsp?URL="; //$NON-NLS-1$
	
	/**
	 * URL Params for Flex client
	 */
	public static final String FLEX_URL_PARAMS = "?sap-wd-client=SmartClient"; //$NON-NLS-1$
	

}
