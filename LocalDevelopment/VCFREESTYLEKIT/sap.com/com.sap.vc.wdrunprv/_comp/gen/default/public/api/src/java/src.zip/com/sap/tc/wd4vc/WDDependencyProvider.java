package com.sap.tc.wd4vc;

import com.sap.ds.env.repository.services.Dependency;
import com.sap.visualcomposer.dependency.VCAbstractDependencyCalculator;

public class WDDependencyProvider extends VCAbstractDependencyCalculator{

	private final String SC_NAME = ""; //$NON-NLS-1$
	private final String SC_VENDOR = "sap.com"; //$NON-NLS-1$
	private final String RUNTIME_PROVIDER_DC_NAME = "com.sap.vc.wdrunprv";  //$NON-NLS-1$
	private final String RUNTIME_PROVIDER_DC_VENDOR = "sap.com";  //$NON-NLS-1$
	private final String WD4VC_RUNTIME_DC_NAME = "tc/wd4vc/launcher";  //$NON-NLS-1$
	private final String WD4VC_RUNTIME_DC_VENDOR = "sap.com";  //$NON-NLS-1$
	private final String RUNTIME_PROVIDER_ID = "WD4VCRuntimeProvider";  //$NON-NLS-1$
	
	public Dependency[] getDependencies() {
		Dependency[] deps = new Dependency[2];
		deps[0] = new Dependency(SC_NAME, SC_VENDOR, RUNTIME_PROVIDER_DC_NAME, RUNTIME_PROVIDER_DC_VENDOR); 
		deps[0].setBuildTimeDependency(true);
		deps[0].setRunTimeDependency(false);
		deps[0].setDesignTimeDependency(false);
		deps[1] = new Dependency(SC_NAME, SC_VENDOR, WD4VC_RUNTIME_DC_NAME, WD4VC_RUNTIME_DC_VENDOR); 
		deps[1].setBuildTimeDependency(false);
		deps[1].setRunTimeDependency(true);
		deps[1].setDesignTimeDependency(false);
		deps[1].setDeployTimeDependency(true);
		return deps;
	}

	public String getRuntimeId() {
		return RUNTIME_PROVIDER_ID; 
	}

	public void initialize() {
	}

	public void shutdown() {
	}

}
