package com.sap.tc.wd4vc;
import static com.sap.tc.wd4vc.Utility.WDFLEXRTPROVIDER; 

public class WDFlexRuntimeProvider extends WDRuntimeProvider {

	/**
	 * Returns the Runtime Provider ID for this Module Builder
	 * @return	RuntimeProvider ID
	 */
	protected String getRuntimeProviderID() {
		return WDFLEXRTPROVIDER;
	}
	
}
