package com.sap.tc.wd4vc;

import static com.sap.tc.wd4vc.Utility.CONTEXT_ROOT;
import static com.sap.tc.wd4vc.Utility.DEFAULT_VENDOR;
import static com.sap.tc.wd4vc.Utility.DEPENDENCY;
import static com.sap.tc.wd4vc.Utility.FLEX_CLIENT_URL;
import static com.sap.tc.wd4vc.Utility.FLEX_URL_PARAMS;
import static com.sap.tc.wd4vc.Utility.ISMAINUNIT;
import static com.sap.tc.wd4vc.Utility.SEPERATOR;
import static com.sap.tc.wd4vc.Utility.SERVER_ID;
import static com.sap.tc.wd4vc.Utility.WDFLEXRTPROVIDER;
import static com.sap.tc.wd4vc.Utility.WDHTMLRTPROVIDER;
import static com.sap.tc.wd4vc.Utility.ENCODING;
import static com.sap.tc.wd4vc.Utility.FLEX_CLIENT_URL;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.omg.CORBA.portable.OutputStream;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.visualcomposer.generationfwk.api.IUnitHandler;
import com.sap.visualcomposer.generationfwk.api.Result;
import com.sap.visualcomposer.generationfwk.api.Unit;
import com.sap.visualcomposer.generationfwk.api.exception.TransformationException;
import com.sap.visualcomposer.generationfwk.archive.api.AbstractModuleBuilder;
import com.sap.visualcomposer.generationfwk.archive.api.Module;
import com.sap.visualcomposer.generationfwk.archive.api.ModuleBuildResult;
import com.sap.visualcomposer.generationfwk.archive.api.ApplicationInfo;
import com.sap.visualcomposer.generationfwk.archive.api.ApplicationUrlInfo;
import com.sap.visualcomposer.generationfwk.compile.CompilationResult;
import com.sap.visualcomposer.generationfwk.compile.CompileResultDescriptor;
import com.sap.visualcomposer.generationfwk.xgl.api.Translation;
import com.sap.visualcomposer.generationfwk.xgl.api.XGL;
import com.sap.visualcomposer.wd4vc.archive.exception.WDArchiveException;
import com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler;
import com.sap.visualcomposer.wd4vc.archive.extapi.WDArchiveBuilderFactory;
import com.sap.visualcomposer.wd4vc.archive.extapi.WDArchiveHandlerFactory;
import com.sap.visualcomposer.wd4vc.archive.utils.GUIDGenerator;
import com.sap.visualcomposer.wd4vc.archive.utils.Logger;
import com.sap.visualcomposer.wd4vc.archive.utils.WDArchiveEntities;
import com.sap.visualcomposer.wd4vc.archive.utils.XGLDocument;

public class WDModuleBuilder extends AbstractModuleBuilder{

	/**
	 * Properties of the application
	 */
	private static final Location location = Location.getLocation(WDModuleBuilder.class);
	private boolean isMainUnit = false;
	private String vendor = null;
	private String dcName = null;
	private String name = null;
	private String urn = null;
	private String scName = null;
	private String prefix = null;
	private String authenticationRequired = "true"; //$NON-NLS-1$
	private String XGL = "XGL"; //$NON-NLS-1$
	private String TRANSLATIONS ="TRANSLATIONS" ; //$NON-NLS-1$
	private String HTML= "Html"; //$NON-NLS-1$
	private String FLEX= "Flex" ; //$NON-NLS-1$
	private String EMPTY = ""; //$NON-NLS-1$
	/**
	 * The errorMessage will be set in the case of an error during any of the archive building phases.
	 * And the message will be set to the ModuleBuildResult.
	 */
	private String errorMessage = null;
	/**
	 * Map used to get the properties of the application
	 */
	private Map propertiesMap = null;

	//private boolean firstTime = true;
	/**
	 * Collection of type XGLDocument.
	 * XGLDocument holds the properties, XGL string and the dependency string.
	 */
	private List<XGLDocument> fileList = null;
	/**
	 * Handler to create the archive
	 */
	private IWDArchiveHandler handler = null;

	private java.util.Set <String> mainUnits = null;
	private XGL xglObject = null;
	private List parsersList = null;
	private String warLocation = null;
	private Module wdModule = null;
	private ModuleBuildResult moduleBuildResult = null;
	private String message;

	/**
	 * Builds the archive using the compilation results.
	 * Sets the output values such as the archive location, application names, module name and the context root.
	 *
	 * @param compilationResults Array of compiled results with the properties, XGL string and the dependencies string.
	 * @return ModuleBuildResult Module object with the information about the created archive.
	 */
	public ModuleBuildResult doBuildModule(CompilationResult[] compilationResults) {
		wdModule = new Module();
		moduleBuildResult = new ModuleBuildResult(wdModule);
		// Changed on 12 Aug 2007 - CSN 3262007
		// set the ID of the Runtime Provider
		moduleBuildResult.setResponsibleProvider(getRuntimeProviderID());

		//gets the compilation results and initializes the required objects for archive creation
		if(!initialize(compilationResults))
		{
			Logger.log(Severity.ERROR, location, errorMessage, dcName);
			moduleBuildResult.setStatus(Result.STATUS_ERROR);
			moduleBuildResult.setMessage(errorMessage);
			return moduleBuildResult;
		}

		//creates archive with the given handler
		try {
			createArchive();
		} catch(WDArchiveException wde) {
			errorMessage = "Failed to build archive for the DC: " + //$NON-NLS-1$
			dcName + " --> " + wde.getLocalizedMessage(); //$NON-NLS-1$
			Logger.log(Severity.ERROR, location, errorMessage, dcName);
			moduleBuildResult.setStatus(Result.STATUS_ERROR);
			moduleBuildResult.setMessage(errorMessage);
			return moduleBuildResult;
		}

		Logger.trace(Severity.INFO, location, "Setting the output values", dcName); //$NON-NLS-1$
		//set output values
		setOutputValues();

		// Changed on 12 Aug 2007 - CSN 3262007
		// No longer required, since it is set by fwk
//		moduleBuildResult.setId(dcName);

		return moduleBuildResult;
	}

	public Result performGeneration(Object source, Object target) throws TransformationException {
		// Do nothing
		return null;
	}

	/**
	 * Generates URLs for HTML Client.
	 * The application names for HTML would be suffixed by <code>_HTML</code>
	 *
	 * TODO: This is a temporary solution for Alpha2 release
	 *
	 * @param mainUnits		Mainunits Identified for this application
	 * @param appURLs		Application URLs as generated by the WDAr
	 */
	protected Map<String, String> generateAppURLs(Set<String> mainUnits, Map<String, String> appNames, Map<String, String> inputURLs) {
		HashMap<String, String> nameURLMap = new HashMap <String, String>();

		if(mainUnits != null && inputURLs != null) {
			String appName = null;
			String clientURL = null;
			if(!mainUnits.isEmpty()) {
				Iterator<String> iterator = mainUnits.iterator();
				String mainUnitID = null;
				while(iterator.hasNext()) {
					mainUnitID = iterator.next();
					appName = appNames.get(mainUnitID);
					// HTML client URL
					clientURL = SERVER_ID + inputURLs.get(mainUnitID);
					nameURLMap.put(appName, clientURL);
				}
			}
		}
		return nameURLMap;
	}

	/**
	 * Generates URLs for HTML Client.
	 * The application names for HTML would be suffixed by <code>_HTML</code>
	 *
	 * TODO: This is a temporary solution for Alpha2 release
	 *
	 * @param mainUnits		Mainunits Identified for this application
	 * @param appURLs		Application URLs as generated by the WDAr
	 */
	protected ApplicationInfo generateAppInfo(Set<String> mainUnits, Map<String, String> appNames, Map<String, String> inputURLs) {
		ApplicationInfo appInfo = new ApplicationInfo();

		if(mainUnits != null && inputURLs != null) {
			String appName = null;
			String clientURL = null;
			if(!mainUnits.isEmpty()) {
				Iterator<String> iterator = mainUnits.iterator();
				String mainUnitID = null;
				while(iterator.hasNext()) {
					mainUnitID = iterator.next();
					appName = appNames.get(mainUnitID);
					// HTML client URL
					String htmlClientURL = SERVER_ID + inputURLs.get(mainUnitID);
					String flexClientURL = FLEX_CLIENT_URL + SERVER_ID + inputURLs.get(mainUnitID) + FLEX_URL_PARAMS;
					ApplicationUrlInfo info = new ApplicationUrlInfo(appName, HTML, htmlClientURL, EMPTY);
					ApplicationUrlInfo info2 = new ApplicationUrlInfo(appName, FLEX, flexClientURL, EMPTY);
					appInfo.addApplicationUrlInfo(info);
					appInfo.addApplicationUrlInfo(info2);
				}
			}
		}
		return appInfo;
	}



	/**
	 * Validates the properties map and sets the properties
	 * @return
	 */
	private boolean handleProperties()
	{
		String isMainUnitString = "true"; //$NON-NLS-1$
		List<Unit> impls = xglObject.getDependencyFacade().getSelfData().getAllImplementations();
		if (impls == null || impls.isEmpty())
		{
			errorMessage = "No implementations found.  Model properties cannot be obtained."; //$NON-NLS-1$
			return false;
		}

		Unit implUnit = impls.get(0);
		if(implUnit == null)
		{
			errorMessage = "Implementation not found.  Model properties cannot be obtained."; //$NON-NLS-1$
			return false;
		}
		if(propertiesMap == null)
		{
			errorMessage = "Configuration Properties are not populated for building archive"; //$NON-NLS-1$
			return false;
		}
		isMainUnitString = (String)propertiesMap.get(ISMAINUNIT);
		isMainUnit = isMainUnitString != null && isMainUnitString.contains("true"); //$NON-NLS-1$
		vendor = implUnit.getDcVendor();
		scName = implUnit.getScName();
		dcName = implUnit.getDcName();
		name = implUnit.getDisplayName();
		urn = implUnit.getUrn();
		prefix = implUnit.getDcPrefix();
		// check for Model properties
		if(isMainUnitString == null || vendor == null || scName == null || dcName == null || name == null || urn == null) {

			errorMessage = "Error while building archive.  One or more Model properties missing for archive generation"; //$NON-NLS-1$
			return false;
		}

		return true;
	}

	/**
	 * Converts the given stream to a string
	 * @param iStream
	 * @return String
	 * @throws IOException
	 */
	private String read(InputStream iStream) throws IOException
	{
		StringBuffer stringHolder = new StringBuffer();
		byte bytes[];
		bytes = new byte[iStream.available()];
		int count = iStream.read(bytes);
		while (count > 0) {
			stringHolder.append(new String(bytes, ENCODING));
			count = iStream.read(bytes);
		}
		return stringHolder.toString();

	}

	/**
	 * reads the XGL, dependency files and properties and puts them onto a list
	 * @return
	 */
	private boolean populateXGLList()
	{
		InputStream iStream = null;
	//	InputStream iDepStream = null;
		String xglString = null;
		String depString = null;
	//	String dependencyPath = "C:\\temp";
		XGLDocument document = new XGLDocument();
		//get the properties
		propertiesMap = xglObject.getConfigurations(getRuntimeProviderID());
		if(propertiesMap == null || propertiesMap.isEmpty())
		{
			if(this instanceof WDFlexModuleBuilder)
				propertiesMap = xglObject.getConfigurations(WDHTMLRTPROVIDER);
			else
				propertiesMap = xglObject.getConfigurations(WDFLEXRTPROVIDER);
		}
		if(!handleProperties())
			return false;
		try {
			iStream = xglObject.getXGL();
		//	iDepStream = xglObject.getResource(DEPENDENCY);
			try {
				depString = createDependencyStringXML();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(iStream == null || iStream.available() == 0) {
				errorMessage = "Error Occurred while building archive. " + //$NON-NLS-1$
						"XGL information missing for Model/Component:" + name; //$NON-NLS-1$
				return false;
			}
			xglString = read(iStream);
		//	depString = read(iDepStream);
		} catch(IOException io) {
			errorMessage = "Error occurred while building archive.  " + io.getLocalizedMessage(); //$NON-NLS-1$
			return false;
		}
		document.setMainUnit(isMainUnit);
		document.setName(name);
		document.setUrn(urn);
		document.setXglString(xglString);
		document.setDependenciesString(depString);
		document.setTranslationsParser(parsersList);
		fileList.add(document);
		return true;
	}


	/**
	 * Creates the handler required for archive generation and sets it's properties
	 *
	 */
	private void createHandler()
	{
		warLocation = getOutputLocation();
		handler = WDArchiveHandlerFactory.createNewArchiveHandler();
		mainUnits = new HashSet <String>();
		XGLDocument doc = null;
		int fileSize = fileList.size();
		for(int i=0; i<fileSize ; i++) {
	    	doc = fileList.get(i);
	    	if(doc!=null && doc.isMainUnit())
	    		mainUnits.add(doc.getUrn());
	    }
		Map <String, String> props = new HashMap <String, String>();
		if(vendor == null || "".equalsIgnoreCase(vendor) || vendor.contains("\"\"")) //$NON-NLS-1$ //$NON-NLS-2$
			vendor = DEFAULT_VENDOR;
		props.put(IWDArchiveHandler.WDAPP_PROP_VENDOR, vendor);
		props.put(IWDArchiveHandler.WDAPP_PROP_PREFIX, prefix);
		props.put(IWDArchiveHandler.WDAPP_AUTHENTICATION, authenticationRequired);
		Logger.trace(Severity.INFO, location, "Populating handler with the properties required for creating the archive", dcName); //$NON-NLS-1$
		handler.setXGLModelName(dcName);
		handler.setXGLList(fileList);
	   	handler.setXGLMainUnits(mainUnits);
		handler.setDestinationFolder(warLocation);
		handler.setApplicationProperties(props);

	}

	/**
	 * initializes the list of xgl and the properties required for building the archive
	 * @param compilationResults
	 * @return
	 */
   private boolean initialize(CompilationResult[] compilationResults) {
      CompileResultDescriptor[] descriptors = null;
      CompileResultDescriptor descriptor = null;
      fileList = new ArrayList<XGLDocument>();
      Map resultMap = null;
      List applicationsNames = new ArrayList<String>();
      List duplicateNames = new ArrayList<String>();
      StringBuffer errorBuffer = new StringBuffer();
      if (compilationResults != null) {
        for (int i = 0; i < compilationResults.length; i++) {
          if (compilationResults[i] != null) {
            descriptors = compilationResults[i].getCompilationResult();
            if (descriptors != null && descriptors.length > 0) {
              descriptor = descriptors[0];
              if (descriptor != null) {
                resultMap = (Map) descriptor.getContent();
                xglObject = (XGL) resultMap.get(XGL);
                parsersList = (List) resultMap.get(TRANSLATIONS);
                if (!populateXGLList())
                  return false;

                // CSN #1058656 desc: Duplicate model names in the same DC
                // In case DC contains duplicate model names, the creation of
                // archives should not take place and modeler is displayed error
                // message.VC design board shows a general error message, the modeler can
                //view the log for error message
                // Globalization not considered. GFW does not support handling exceptions in VC

                if (isMainUnit) {
                  if (applicationsNames.contains(name)) {
                    duplicateNames.add(name);
                    errorBuffer.append(name);
                    errorBuffer.append(" ; "); //$NON-NLS-1$
                  } else
                    applicationsNames.add(name);
                }
              }
            }
          }
        }

        if (errorBuffer.length() > 0 || duplicateNames.size() > 0) {
          errorMessage = "The DC name " + //$NON-NLS-1$
          dcName.substring(0,dcName.lastIndexOf('_')) +
          " contains duplicate Model(s): " //$NON-NLS-1$
              + errorBuffer.deleteCharAt(errorBuffer.length()-2).toString();
          return false;
        }
      }

      return true;
    }
	/**
	 * creates the archive using the information provided by the handler
	 * @throws WDArchiveException
	 */
	private void createArchive() throws WDArchiveException
	{
		Logger.trace(Severity.INFO, location, "Creating the archive handler", dcName); //$NON-NLS-1$
		//create the handler to provide the necessary information for building the archive
		createHandler();
		Logger.trace(Severity.INFO, location, "Starting the archive creation", dcName); //$NON-NLS-1$
		WDArchiveBuilderFactory.newInstance().newArchiveBuilder().createWDArchive(handler);
	}
	/**
	 * sets the output values after the creation of the archive
	 *
	 */
	private void setOutputValues()
	{   String newDCName = dcName.replace('/', '~');
		Logger.trace(Severity.INFO, location, "Generating the application URLs", newDCName); //$NON-NLS-1$

		//generate the Application URLs for HTML
		//Map<String, String> nameURLMap = generateAppURLs(mainUnits, handler.getWDApplicationNames(), handler.getWDApplicationURLs());
		ApplicationInfo appInfo = generateAppInfo(mainUnits, handler.getWDApplicationNames(), handler.getWDApplicationURLs());

		wdModule.setModuleName(handler.getWDArchiveName());
		if(!(prefix == null || "".equalsIgnoreCase(prefix.trim()))) //$NON-NLS-1$
			wdModule.setContextRoot(CONTEXT_ROOT + vendor + SEPERATOR + prefix + "~" + newDCName.toLowerCase(Locale.ENGLISH)); //$NON-NLS-1$
		else
			wdModule.setContextRoot(CONTEXT_ROOT + vendor + SEPERATOR + newDCName.toLowerCase(Locale.ENGLISH));
		Logger.trace(Severity.INFO, location, "Setting all te application names and URLs", newDCName); //$NON-NLS-1$
		// set all the application names and URLs
		//wdModule.setAppNames((HashMap) nameURLMap);
		wdModule.setApplInfo(appInfo);
		wdModule.setLocation(warLocation);
		Logger.trace(Severity.INFO, location, "Archive successfully created and the output values are set", newDCName); //$NON-NLS-1$
	}
	/**
	 * Returns the Runtime Provider ID for this Module Builder
	 * @return	RuntimeProvider ID
	 */
	protected String getRuntimeProviderID() {
		return WDHTMLRTPROVIDER;
	}



	private InputStream resourceReader(String resourceName) {
		return getClass().getClassLoader().getResourceAsStream(resourceName);
	}

	private String createDependencyStringXML() throws WDArchiveException, IOException {
		String depString = null;
		String templateFileName = WDArchiveEntities.TEMPLATE_FOLDER + WDArchiveEntities.TEMPLATE_DEPENDENCY_STRING;
		if(templateFileName != null) {

			InputStream inputSource =resourceReader(templateFileName);
			if(inputSource != null)
			{
				try {
					depString = updateDependencyStringXML(inputSource);
				} catch (Exception e) {
					message = "Error while reading dependencyString from input Source"+"\n Details: "+e.getLocalizedMessage(); //$NON-NLS-1$ //$NON-NLS-2$
					Logger.log(Severity.ERROR, location, message, dcName);
				}
			}
			else
				depString= read(xglObject.getResource(DEPENDENCY));
		}
		return depString;
	}

	private String updateDependencyStringXML(InputStream iStream) throws Exception {
		String depString = null;

		if(iStream == null || iStream.available() == 0) {
			errorMessage = "Error Occurred while building archive. " + //$NON-NLS-1$
			"Dependency information missing for Model/Component:" + name; //$NON-NLS-1$
			return errorMessage;
		}

		if(iStream != null) {
			Document document = null;
			DocumentBuilderFactory builderFactory = null;
			DocumentBuilder dBuilder = null;
			NodeList interfaceList = null;
			NodeList implList = null;
			int childNodesLength = 0;
			Node selfNode= null;
			Node implementationNode = null;
			Node interfaceNode = null;
			Node nodePart = null;
			Node defaultNode = null;
			IUnitHandler importsHandler=null;

			try {
				builderFactory = DocumentBuilderFactory.newInstance();
				builderFactory.setNamespaceAware(true);
				builderFactory.setValidating(false);
				dBuilder =  builderFactory.newDocumentBuilder();
				document = dBuilder.parse(iStream);

				// Parsing the Self Data
				Unit selfImplUnit= xglObject.getDependencyFacade().getSelfData().getAllImplementations().get(0);
				Unit selfInterfaceUnit = xglObject.getDependencyFacade().getSelfData().getInterface();


				selfNode = document.getElementsByTagName(WDArchiveEntities.SELFTAG).item(0);

				interfaceList = selfNode.getChildNodes();
				childNodesLength = interfaceList.getLength();

				for (int i = 0; i < childNodesLength; i++) {
					if((interfaceNode = interfaceList.item(i)).getNodeName().equals(WDArchiveEntities.INTERFACETAG))
						break;
				}
				fillContent(selfInterfaceUnit, interfaceNode);

				implList = selfNode.getChildNodes();
				childNodesLength = implList.getLength();

				for (int i = 0; i < childNodesLength; i++) {
					if((implementationNode = implList.item(i)).getNodeName().equals(WDArchiveEntities.IMPLTAG))
						break;
				}
				fillContent(selfImplUnit, implementationNode);

				// Parsing Imports Data

				Node appNode = document.getElementsByTagName(WDArchiveEntities.IMPORTSTAG).item(0);

				List<IUnitHandler> importsList = xglObject.getDependencyFacade().getImportsData();
				if(importsList == null || importsList.isEmpty()) {
					defaultNode = document.getElementsByTagName(WDArchiveEntities.IMPORTTAG).item(0);
					defaultNode.getParentNode().removeChild(defaultNode);
				} else {
					Iterator importsHandlerIter = importsList.iterator();
					boolean firstTime = true;
					while (importsHandlerIter.hasNext()) {
						importsHandler = (IUnitHandler) importsHandlerIter.next();
						Unit importsInterfaceUnit = importsHandler.getInterface();
						Unit importsImplUnit = importsHandler.getAllImplementations().get(0);

						if(firstTime) {
							// fill the values for the default node
							defaultNode = document.getElementsByTagName(WDArchiveEntities.IMPORTTAG).item(0);
							nodePart = defaultNode;
							firstTime = false;
						} else {
							// add a new child node to the 'Imports' node
							nodePart = defaultNode.cloneNode(true);
							appNode.appendChild(nodePart);
						}

						interfaceList = nodePart.getChildNodes();
						childNodesLength = interfaceList.getLength();

						for (int i = 0; i < childNodesLength; i++) {
							if((interfaceNode = interfaceList.item(i)).getNodeName().equals(WDArchiveEntities.INTERFACETAG))
								break;
						}
						fillContent(importsInterfaceUnit, interfaceNode);

						// @TO DO : For multiple implementations.
						implList = nodePart.getChildNodes();
						childNodesLength = implList.getLength();

						for (int i = 0; i < childNodesLength; i++) {
							if((implementationNode = implList.item(i)).getNodeName().equals(WDArchiveEntities.IMPLTAG))
								break;
						}
						fillContent(importsImplUnit, implementationNode);
					}
				}

				// write it back to file
				depString = convertDOMToString(document);

			} catch (SAXException e) {
				message = "Error while parsing dependencyString"+"\n Details: "+e.getLocalizedMessage(); //$NON-NLS-1$ //$NON-NLS-2$
				Logger.log(Severity.ERROR, location, message, dcName);
				throw new WDArchiveException(message);
			} catch (IOException e) {
				message = "Error while creating dependencyString"+"\n Details: "+e.getLocalizedMessage(); //$NON-NLS-1$ //$NON-NLS-2$
				Logger.log(Severity.ERROR, location, message, dcName);
				throw new WDArchiveException(message);
			} catch (ParserConfigurationException e) {
				message = "Error while creating dependencyString"+"\n Details: "+e.getLocalizedMessage(); //$NON-NLS-1$ //$NON-NLS-2$
				Logger.log(Severity.ERROR, location, message, dcName);
				throw new WDArchiveException(message);
			} catch (FactoryConfigurationError e) {
				message = "Error while creating dependencyString"+"\n Details: "+e.getLocalizedMessage(); //$NON-NLS-1$ //$NON-NLS-2$
				Logger.log(Severity.ERROR, location, message, dcName);
				throw new WDArchiveException(message);
			}
		}
		return depString;
	}

	private void fillContent(Unit unitHandler, Node interfaceNode) {
		if(unitHandler != null && interfaceNode != null) {
			// get the attributes
			NamedNodeMap attributes = interfaceNode.getAttributes();
			Node nodeAttr = null;

			/*
			 * Setting the node Values with Attributes
			 */

			nodeAttr = attributes.getNamedItem(WDArchiveEntities.DEPENDENCIESATTRDC); // "dc"
			nodeAttr.setNodeValue(unitHandler.getDc());

			nodeAttr = attributes.getNamedItem(WDArchiveEntities.DEPENDENCIESATTRDCNAME); //"dcname"
			nodeAttr.setNodeValue(unitHandler.getDcName());

			nodeAttr = attributes.getNamedItem(WDArchiveEntities.DEPENDENCIESATTRDCPREFIX);//  "dcprefix"
			nodeAttr.setNodeValue(unitHandler.getDcPrefix());

			nodeAttr = attributes.getNamedItem(WDArchiveEntities.DEPENDENCIESATTRDCVENDOR);//   "dcvendor"
			nodeAttr.setNodeValue(unitHandler.getDcVendor());

			nodeAttr = attributes.getNamedItem(WDArchiveEntities.DEPENDENCIESATTRDISPAYNAME);//   "displayname"
			nodeAttr.setNodeValue(unitHandler.getDisplayName());

			nodeAttr = attributes.getNamedItem(WDArchiveEntities.DEPENDENCIESATTRPACKAGEPREFIX);//   "packageprefix"
			nodeAttr.setNodeValue(unitHandler.getPackagePrefix());

			nodeAttr = attributes.getNamedItem(WDArchiveEntities.DEPENDENCIESATTRREPOSITORY);//   "repository"
			nodeAttr.setNodeValue(unitHandler.getRepository());

			nodeAttr = attributes.getNamedItem(WDArchiveEntities.DEPENDENCIESATTRSC);//   "sc"
			nodeAttr.setNodeValue(unitHandler.getSc());

			nodeAttr = attributes.getNamedItem(WDArchiveEntities.DEPENDENCIESATTRSCNAME);//   "scname"
			nodeAttr.setNodeValue(unitHandler.getScName());

			nodeAttr = attributes.getNamedItem(WDArchiveEntities.DEPENDENCIESATTRSCVENDOR);//  "scvendor"
			nodeAttr.setNodeValue(unitHandler.getScVendor());

			nodeAttr = attributes.getNamedItem(WDArchiveEntities.DEPENDENCIESATTRURN);//  "urn"
			nodeAttr.setNodeValue(unitHandler.getUrn());
		}
	}

	/*
	 * Converts the parsed document into String
	 */

	private String convertDOMToString(Document document)
	throws Exception
	{
		StringWriter sw = new StringWriter();
		TransformerFactory tFactory = TransformerFactory.newInstance();
		Transformer transformer = tFactory.newTransformer();

		transformer.setOutputProperty(OutputKeys.INDENT, "yes"); //$NON-NLS-1$
		transformer.setOutputProperty(OutputKeys.METHOD, "xml"); //$NON-NLS-1$
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no"); //$NON-NLS-1$

		if (document.getXmlEncoding() != null)
			transformer.setOutputProperty(OutputKeys.ENCODING, document.getXmlEncoding());

		DOMSource source = new DOMSource(document);
		StreamResult result = new StreamResult(sw);

		transformer.transform(source, result);

		return sw.toString();
	}
}



