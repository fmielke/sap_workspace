package com.sap.tc.wd4vc;

import static com.sap.tc.wd4vc.Utility.WDFLEXRTPROVIDER;
import static com.sap.tc.wd4vc.Utility.WDHTMLRTPROVIDER;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.sap.s2x.validation.ValidationException;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.visualcomposer.generationfwk.api.Result;
import com.sap.visualcomposer.generationfwk.api.TranslationParser;
import com.sap.visualcomposer.generationfwk.api.Unit;
import com.sap.visualcomposer.generationfwk.api.VCProvider;
import com.sap.visualcomposer.generationfwk.compile.CompilationResult;
import com.sap.visualcomposer.generationfwk.compile.CompileResultDescriptor;
import com.sap.visualcomposer.generationfwk.xgl.api.Translation;
import com.sap.visualcomposer.generationfwk.xgl.api.XGL;
import com.sap.visualcomposer.wd4vc.archive.utils.Logger;

public class WDRuntimeProvider extends VCProvider {

	private static final Location location = Location
			.getLocation(WDRuntimeProvider.class);

	/**
	 * Compiles the Model or Component. WD4VC runtime process the XGL that is
	 * obtained from the VC after compiling the corresponding Model. Hence
	 * further processing is not requried by the WD Runtime Provider.
	 * Nevertheless, it is required to validate the input which is mainly the
	 * XGL.
	 * 
	 * @param xglObject
	 *            The XGL and related information for the Model/Component being
	 *            compiled
	 */

	/**
	 * The errorMessage will be set in the case of an error during any of the
	 * archive building phases. And the message will be set to the
	 * ModuleBuildResult.
	 */
	private String errorMessage = null;
	private String XGL = "XGL"; //$NON-NLS-1$
	private String TRANSLATIONS ="TRANSLATIONS" ; //$NON-NLS-1$

	String modelURN = null;

	String modelName = null;

	public CompilationResult doCompile(XGL xglObject) {
		Unit implUnit = null;
		CompilationResult result = new CompilationResult();
		result.setStatus(Result.STATUS_ERROR);
		// Changed on 12 Aug 2007 - CSN 3262007
		// set the ID of the Runtime Provider
		result.setResponsibleProvider(getRuntimeProviderID());

		Map configProperties = null;
		if (xglObject != null) {
			// get the config properties from the design time
			configProperties = xglObject
					.getConfigurations(getRuntimeProviderID());
			List<Unit> impls = xglObject.getDependencyFacade().getSelfData()
					.getAllImplementations();

			// CSN # 1952175 Build of model in DTR fails in IDE
			if (impls.isEmpty() || (implUnit = impls.get(0)) == null) {
				Logger
						.log(
								Severity.ERROR,
								location,
								"Implementation not found.  Model properties cannot be obtained.", //$NON-NLS-1$
								"Current DC"); //$NON-NLS-1$
				result.setMessage("Implementation not found.  Model properties cannot be obtained."); //$NON-NLS-1$
				return result;
			}
			if (configProperties == null || configProperties.isEmpty()) {
				if (this instanceof WDFlexRuntimeProvider)
					configProperties = xglObject
							.getConfigurations(WDHTMLRTPROVIDER);
				else
					configProperties = xglObject
							.getConfigurations(WDFLEXRTPROVIDER);
			}
			if (configProperties != null) {
				// get the modelURN for the component being compiled
				modelURN = implUnit.getUrn();
				// get the modelName for the component being compiled
				modelName = implUnit.getDisplayName();
				if (xglObject.getXGL() == null) {
					// XGL String is not generated
					Logger.log(Severity.ERROR, location,
							"XGL not generated for model Name: " + modelName //$NON-NLS-1$
									+ " URN: " + modelURN, modelURN); //$NON-NLS-1$
					result.setMessage("XGL not generated for model Name: " //$NON-NLS-1$
							+ modelName + " URN: " + modelURN); //$NON-NLS-1$
				} else {
					// set the required values for CompileResultDescriptor
					// These values are used by the ModuleBuilder for the
					// archive generation
					CompileResultDescriptor descriptor = new CompileResultDescriptor();
					Map compilationResult = new HashMap();
					compilationResult.put(XGL, xglObject); 
					compilationResult.put(TRANSLATIONS, 
							getTranslationParserList(xglObject));

					// setting the map as descriptor content
					// Properties conversion is only available in VCProvider
					descriptor.setContent(compilationResult);
					descriptor.setIsVisible(false);
					// Add the CompileResultDescriptor to the CompilationResult
					result.setStatus(Result.STATUS_SUCCESS);
					result.addCompilationResult(descriptor);
					result.setId(modelURN);

					// Changed on 12 Aug 2007 - CSN 3262007
					// set the display name of the model
					result.setName(modelName);
				}
			} else {
				// None of the properties from design time are populated
				Logger
						.log(
								Severity.ERROR,
								location,
								"Error during compilation. Configuration properties not populated.", //$NON-NLS-1$
								""); //$NON-NLS-1$
				result
						.setMessage("Error during compilation. Configuration properties not populated."); //$NON-NLS-1$
			}
		} else {
			// Input to Compiler is NULL
			Logger.log(Severity.ERROR, location,
					"Error during compilation. Invalid input.", ""); //$NON-NLS-1$ //$NON-NLS-2$
			result.setMessage("Error during compilation. Invalid input."); //$NON-NLS-1$
		}
		return result;
	}

	private List getTranslationParserList(XGL xglObject) {
		List parserList = new ArrayList();
		Translation[] translations = xglObject.getTranslations();
		if (translations != null) {
			try {
				List transParserList = parseXlf(translations);
				Iterator iterator = transParserList.iterator();
				while (iterator.hasNext()) {
					TranslationParser parser = (TranslationParser) iterator
							.next();
					parserList.add(parser);
				}
			} catch (IOException ioE) {
				errorMessage = "Failed to retrieve translation object: " //$NON-NLS-1$
						+ xglObject + " --> " + ioE.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, errorMessage, modelURN);
			} catch (ParserConfigurationException pcE) {
				errorMessage = "Parser Configuration Error: " + xglObject //$NON-NLS-1$
						+ " --> " + pcE.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, errorMessage, modelURN);
			} catch (SAXException sE) {
				errorMessage = "Exception occured during parsing: " + xglObject //$NON-NLS-1$
						+ " --> " + sE.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, errorMessage, modelURN);
			} catch (ValidationException vE) {
				errorMessage = "Exception occured during parsing: " + xglObject //$NON-NLS-1$
						+ " --> " + vE.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, errorMessage, modelURN);
			}
		}
		return parserList;
	}

	/**
	 * Returns the Runtime Provider ID for this Module Builder
	 * 
	 * @return RuntimeProvider ID
	 */
	protected String getRuntimeProviderID() {
		return WDHTMLRTPROVIDER;
	}

}
