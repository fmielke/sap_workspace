/*
 * Created on Jan 8, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.tc.wd4vc.archive.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.sap.visualcomposer.wd4vc.archive.exception.WDArchiveException;
import com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler;
import com.sap.visualcomposer.wd4vc.archive.extapi.WDArchiveBuilderFactory;
import com.sap.visualcomposer.wd4vc.archive.extapi.WDArchiveHandlerFactory;
import com.sap.visualcomposer.wd4vc.archive.utils.XGLDocument;
import com.sap.visualcomposer.wd4vc.archive.utils.XGLParser;

/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
@SuppressWarnings("nls")
public class ArchiveTester {

	private static String mTempFolder = "C:\\temptest\\test";
	private static List<XGLDocument> XGLString = new ArrayList<XGLDocument>();
	ArchiveTester()
	{
		try {
			String xgl, dep;
			String urn[] = new String[]{"vc-Local-user-dc5-nested","vc-Local-user-dc5-rachel","vc-Local-user-dc5-bapi_bank_getdetail","vc-Local-user-dc5-wsgetholidayname" };
			String name[] = new String[]{"Nested","Rachel","BAPI_BANK_GETDETAIL","GetHolidayDate"};
			for(int i=0; i<4;i++)
			{
				InputStream iStream = new FileInputStream(mTempFolder + File.separator + "XGL"+i+".xml");
				InputStream iDepStream = new FileInputStream(mTempFolder + File.separator + "dep"+i+".xml");
				XGLDocument doc = new XGLDocument();
				byte bytes[] = new byte[iStream.available()];
				byte depBytes[] = new byte[iDepStream.available()];
				iStream.read(bytes);
				iDepStream.read(depBytes);
				xgl = new String(bytes); // $JL-I18N$
				dep = new String(depBytes); // $JL-I18N$
				doc.setDependenciesString(dep);
				doc.setXglString(xgl);
				doc.setMainUnit(true);
				doc.setName(name[i]);
				doc.setUrn(urn[i]);
				if(i == 2 || i == 3)
					doc.setMainUnit(false);
				XGLString.add(doc);
				iStream.close();
				iDepStream.close();
			}
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}
		
	}
	public static void generate() {
		IWDArchiveHandler handler = WDArchiveHandlerFactory.createNewArchiveHandler();
		//handler.setPrefix("wd4vc");
		String modelName = null;
		modelName = "testdc_impl";
		handler.setXGLModelName(modelName);
		//handler.setXGLModelID("MID");
		handler.setXGLList(XGLString);
		java.util.Set<String> mainUnits = new HashSet<String>();
		
		for(int i=0; i<XGLString.size(); i++)
	    {
	    	XGLDocument doc = XGLString.get(i);
	    	if(doc!=null)
	    	{
	    		if(doc.isMainUnit())
	    			{XGLParser parser = new XGLParser((XGLString.get(i)).getXglString());
	    			mainUnits.addAll(parser.identifyMainUnits());
	    			}
	    	}
		
		}
	    		
		handler.setXGLMainUnits(mainUnits);
		handler.setDestinationFolder(mTempFolder);
		Map<String, String> props = new HashMap<String, String>();
		//props.put(IWDArchiveHandler.WDAPP_PROP_LOGLOCATION, "com.sap.erp.xss");
		//props.put(IWDArchiveHandler.WDAPP_PROP_NAMESPACE, "tc");
		props.put(IWDArchiveHandler.WDAPP_PROP_VENDOR, "sap.com");
		handler.setApplicationProperties(props);
		handler.setDeployWDAppWithSource(false);
		try {
			WDArchiveBuilderFactory.newInstance().newArchiveBuilder().createWDArchive(handler);
		} catch(WDArchiveException e1) {
			e1.printStackTrace();
		}
		System.out.println("\nEAR Archive Name: \t" + handler.getWDArchiveName());
		System.out.println("\nSource Archive Name: \t" + handler.getWDSourceArchiveName());
		System.out.println("\nURL Parameters: \t" + handler.getWDApplicationURLParameters());
		System.out.println("\nApplication URLs: \t" + handler.getWDApplicationURLs());
	}

	public static void main(String args[]) {
		
			new ArchiveTester().generate();
		}

}
