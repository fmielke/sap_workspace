/*
 * Created on Dec 14, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.exception;

/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WDArchiveException extends Exception {

	private Exception mException;

	public WDArchiveException(String message) {
		super(message);
		mException = null;
	}

	public WDArchiveException(Exception exception) {
		super();
		mException = exception;
	}
    
	public WDArchiveException(String message, Exception e) {
		super(message);
		mException = e;
	}
    
	public String getMessage() {
		String message = super.getMessage();
			
		if (message == null && mException != null) 
			return mException.getMessage();
		return message;
	}
    
	public Exception getException() {
		return mException;
	}

	public String toString() {
		if (mException != null) 
			return mException.toString();
		return super.toString();
	}
    
}
