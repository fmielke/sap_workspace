/*
 * Created on Nov 30, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.extapi;

import com.sap.visualcomposer.wd4vc.archive.exception.WDArchiveException;

/**
 * Defines the API to obtain Web Dynpro Archive handler created for the 
 * XGraph String representing the VC Model created in the Story Board. 
 * Using this class the deployment service on the VC side can obtain the 
 * handle to the Web Dynpro Archive and the required details for the 
 * deployment.
 * An instance of this class can be obtained from the 
 * {@link com.sap.visualcomposer.wd4vc.archive.extapi.WDArchiveBuilderFactory#newArchiveBuilder() 
 * WDArchiveBuilderFactory.newArchiveBuilder} method. Once an instance of 
 * this class is obtained, a Web Dynpro archive can be created for a 
 * XGraph representing the VC Model in the VC Story Board.
 * 
 * @author I026466
 *
 */
public abstract class WDArchiveBuilder {

	/**
	 * Create the WebDynpro deployable archive<code>(.EAR)</code>. The details as specified by the 
	 * <code>IWDArchiveHandler</code> corresponds to a VC Model defined in the VC Story Board.
	 * 
	 * <p> <code>IWDArchiveHandler</code> provides the following details for the archive creation:
	 * <UL>
	 *   <L1> Model properties like Vendor Name, Namespace required to identify the 
	 * 			fully qualified name of the deployable object
	 * 	 <L1> Model Name which signifying the name of the WebDynpro deployable object name
	 * 	 <L1> XGraph String representing the VC Model
	 *   <L1> Set of MainUnit IDs defining the VC Model
	 *   <L1> Other miscellaneous parameters required for generating the archive
	 * </UL>	    
	 * 
	 * @param handler
	 * @throws WDArchiveException
	 */
	public abstract void createWDArchive(IWDArchiveHandler handler) throws WDArchiveException;

}
