/*
 * Created on Nov 30, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.extapi;

import com.sap.visualcomposer.wd4vc.archive.impl.WDArchiveBuilderFactoryImpl;

/**
 * Defines a factory API that enables the deployment service on the
 * VC Story Board to obtain an archive builder that creates the
 * Web Dynpro archive for a specified XGraph representing a VC Model in
 * the VC Story Board.
 * 
 * @author I026466
 *
 */
public abstract class WDArchiveBuilderFactory {

	/**
	 * Obtain a new instance of a <code>WDArchiveBuilderFactory</code>. 
	 * This static method creates a new factory instance.
	 * 
	 * Once the deployment service has obtained a reference to a
	 * <code>WDArchiveBuilderFactory</code> it can use the factory to
	 * btain archive builder instances.
	 *
	 * @return	An instance of the archive builder factory
	 */
	public static WDArchiveBuilderFactory newInstance() {
		return new WDArchiveBuilderFactoryImpl();
	}

	/**
	 * Creates a new instance of a {@link com.sap.visualcomposer.wd4vc.archive.extapi.WDArchiveBuilder}
	 *
	 * @return A new instance of a WDArchiveBuilder.
	 */
	public abstract WDArchiveBuilder newArchiveBuilder();
	
}
