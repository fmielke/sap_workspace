/*
 * Created on Nov 30, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.extapi;

import com.sap.visualcomposer.wd4vc.archive.impl.WDArchiveHandlerImpl;

/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WDArchiveHandlerFactory {

	public static IWDArchiveHandler createNewArchiveHandler() {
		return new WDArchiveHandlerImpl();
	}

}
