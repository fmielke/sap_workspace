/*
 * Created on Nov 30, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.impl;

import com.sap.visualcomposer.wd4vc.archive.extapi.WDArchiveBuilder;
import com.sap.visualcomposer.wd4vc.archive.extapi.WDArchiveBuilderFactory;

/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WDArchiveBuilderFactoryImpl extends WDArchiveBuilderFactory {

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchiveBuilderFactory#newDocumentBuilder()
	 */
	public WDArchiveBuilder newArchiveBuilder() {
		return new WDArchiveBuilderImpl();
	}

}
