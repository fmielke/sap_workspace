/*
 * Created on Nov 30, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.impl;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.visualcomposer.generationfwk.api.TranslationParser;
import com.sap.visualcomposer.wd4vc.archive.exception.WDArchiveException;
import com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler;
import com.sap.visualcomposer.wd4vc.archive.extapi.WDArchiveBuilder;
import com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler;
import com.sap.visualcomposer.wd4vc.archive.utils.GUIDGenerator;
import com.sap.visualcomposer.wd4vc.archive.utils.JARBuilder;
import com.sap.visualcomposer.wd4vc.archive.utils.Logger;
import com.sap.visualcomposer.wd4vc.archive.utils.Utils;
import com.sap.visualcomposer.wd4vc.archive.utils.WDAppURLGenerator;
import com.sap.visualcomposer.wd4vc.archive.utils.WDArchiveEntities;
import com.sap.visualcomposer.wd4vc.archive.utils.XGLDocument;

/**
 * @author I026466
 * 
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WDArchiveBuilderImpl extends WDArchiveBuilder {

	// Input values
	private static final Location location = Location
			.getLocation(WDArchiveBuilderImpl.class);

	private WDArchivehandler mArchiveHandler;

	private String mXGLModelName;

	private List mXGLList;

	private String mDependencyString;

	// Local variables required for processing
	private String mDeployableObjectName;

	private String mDeployableArchiveName;

	private String mWDApplicationPackageName;

	private Map<String, String> mMainUnitsMap;

	private Map<String, String> mModelMap;

	private Map<String, String> mWDApplicationProperties;

	private Map<File, String> mPropertyFiles;

	private String mRootFolder;

	private String mRootAppFolder;

	private Map<File, String> mWARFiles;

	private List<File> mDependencyFiles;

	private String message;

	// Output Values
	private String mVendorName;

	private String mPrefix;

	private boolean isPrefix;

	private Map<String, String> mWDApplicationNames;

	private String mWDApplicationURLParameters;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchiveBuilder#createWDArchive(com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler)
	 */
	/**
	 * Creates the archive using the information present in the handler.
	 * 
	 * @param handler
	 *            handler to create the archive.
	 */
	public void createWDArchive(IWDArchiveHandler handler)
			throws WDArchiveException {
		mArchiveHandler = (WDArchivehandler) handler;
		initialize();
		createWAR();
		setOutputValues();
	}

	/**
	 * Uses the archive handler and identifies properties like application
	 * properties, model name, deployable object name, package name,
	 * applications, URL parameters, the XGL and the dependency strings.
	 * 
	 * @throws WDArchiveException
	 */
	private void initialize() throws WDArchiveException {
		if (mArchiveHandler == null) {
			message = "Invalid inputs for archive creation. Handler is empty."; //$NON-NLS-1$
			Logger.log(Severity.ERROR, location, message, "DC"); //$NON-NLS-1$
			throw new WDArchiveException(message);
		}

		// destination folder for archive creation
		mRootFolder = mArchiveHandler.getDestinationFolder();
		if (mRootFolder == null || mRootFolder.equals("")) { //$NON-NLS-1$
			message = "Missing destination/target folder for archive creation."; //$NON-NLS-1$
			Logger.log(Severity.ERROR, location, message, "DC"); //$NON-NLS-1$
			throw new WDArchiveException(message);
		}

		// model name
		mXGLModelName = mArchiveHandler.getXGLModelName();
		if (mXGLModelName == null || mXGLModelName.equals("")) { //$NON-NLS-1$
			message = "Incomplete input, missing VCModel Name."; //$NON-NLS-1$
			Logger.log(Severity.ERROR, location, message, "DC"); //$NON-NLS-1$
			throw new WDArchiveException(message);
		}

		// XGL String
		mXGLList = mArchiveHandler.getXGLList();
		if (mXGLList == null || mXGLList.isEmpty()) {
			message = "Incomplete input, XGL String."; //$NON-NLS-1$
			Logger.log(Severity.ERROR, location, message, mXGLModelName);
			throw new WDArchiveException(message);
		}

		// XGL MainUnits
		Logger.trace(Severity.INFO, location,
				"Reading the application properties", mXGLModelName); //$NON-NLS-1$
		readApplicationProperties();

		// initialize
		mMainUnitsMap = new HashMap<String, String>();
		mModelMap = new HashMap<String, String>();
		mWDApplicationNames = new HashMap<String, String>();
		mWARFiles = new HashMap<File, String>();
		mDependencyFiles = new ArrayList<File>();

		Logger
				.trace(
						Severity.INFO,
						location,
						"Identifying the deployableObjectName, WDApplicationPackageName, WDApplications and WDApplicationURLParameters", //$NON-NLS-1$
						mXGLModelName);
		identifyDeployableObjectName();
		identifyWDApplicationPackageName();
		identifyWDApplications();
		identifyWDApplicationURLParameters();
	}

	/**
	 * Populates the application properties
	 * 
	 * @throws WDArchiveException
	 */

	private void readApplicationProperties() throws WDArchiveException {
		// Application properties
		mWDApplicationProperties = mArchiveHandler.getApplicationProperties();
		if (mWDApplicationProperties == null
				|| mWDApplicationProperties.isEmpty()) {
			message = "Application properties are not specified"; //$NON-NLS-1$
			Logger.log(Severity.ERROR, location, message, mXGLModelName);
			throw new WDArchiveException(message);
		}

		if (mWDApplicationProperties
				.containsKey(IWDArchiveHandler.WDAPP_PROP_VENDOR))
			mVendorName = mWDApplicationProperties
					.get(IWDArchiveHandler.WDAPP_PROP_VENDOR);
		if (mVendorName == null || mVendorName.trim().equals("")) { //$NON-NLS-1$
			message = "Model property VENDOR is not specified"; //$NON-NLS-1$
			Logger.log(Severity.ERROR, location, message, mXGLModelName);
			throw new WDArchiveException(message);
		}
		if (!isVendorNameValid(mVendorName)) {
			message = "Invalid model property, VENDOR: " + mVendorName; //$NON-NLS-1$
			Logger.log(Severity.ERROR, location, message, mXGLModelName);
			throw new WDArchiveException(message);
		}
		if (mWDApplicationProperties
				.containsKey(IWDArchiveHandler.WDAPP_PROP_PREFIX)) {
			mPrefix = mWDApplicationProperties
					.get(IWDArchiveHandler.WDAPP_PROP_PREFIX);
			if (mPrefix == null || "".equalsIgnoreCase(mPrefix.trim())) //$NON-NLS-1$
				isPrefix = false;
			else
				isPrefix = true;
		}
	}

	/**
	 * Sets the output values after creating the archive
	 * 
	 */
	private void setOutputValues() {
		Logger.trace(Severity.INFO, location,
				"Creation of WAR file done.  Setting the output values", //$NON-NLS-1$
				mXGLModelName);
		mArchiveHandler.setVendorName(mVendorName);
		mArchiveHandler.setDevelopmentComponentName(mDeployableArchiveName);
		mArchiveHandler.setJ2EEDeployableObjectName(mDeployableObjectName);
		mArchiveHandler.setWDApplicationNames(mWDApplicationNames);
		mArchiveHandler
				.setWDApplicationURLParameters(mWDApplicationURLParameters);
		Map<String, String> appURLs;
		if (isPrefix) {
			mArchiveHandler.setWDArchiveName(mVendorName + "~" + mPrefix + "~" //$NON-NLS-1$ //$NON-NLS-2$
					+ mDeployableArchiveName + WDArchiveEntities.WAR_FILE_EXTN);
			appURLs = WDAppURLGenerator.generateURLs(mVendorName, mPrefix + "~" //$NON-NLS-1$
					+ mDeployableArchiveName, mMainUnitsMap);
		} else {
			mArchiveHandler.setWDArchiveName(mVendorName + "~" //$NON-NLS-1$
					+ mDeployableArchiveName + WDArchiveEntities.WAR_FILE_EXTN);
			appURLs = WDAppURLGenerator.generateURLs(mVendorName,
					mDeployableArchiveName, mMainUnitsMap);
		}
		mArchiveHandler.setWDApplicationURLs(appURLs);
	}

	/**
	 * TODO: Currently only one parameter is identified as the application URL
	 * Parameter. Need to have a more refined way to identify these parameters
	 * 
	 */
	private void identifyWDApplicationURLParameters() {
		String logLocation = mWDApplicationProperties
				.get(IWDArchiveHandler.WDAPP_PROP_LOGLOCATION);

		// check for null. If null, no URL parameters
		if (logLocation == null) {
			mWDApplicationURLParameters = ""; //$NON-NLS-1$
		} else {
			if (logLocation.indexOf('~') != -1)
				logLocation = logLocation.replace('~', '.');
			if (logLocation.indexOf('/') != -1)
				logLocation = logLocation.replace('/', '.');

			mWDApplicationURLParameters = IWDArchiveHandler.WDAPP_PROP_LOGLOCATION
					+ "=" + logLocation; //$NON-NLS-1$
		}

		// handle the other URL parameters for connectivity and Debug
		String connectivityType = mWDApplicationProperties
				.get(WDArchiveEntities.CONNECTIVITYTYPE);
		if (connectivityType == null)
			mWDApplicationURLParameters = mWDApplicationURLParameters
					+ WDArchiveEntities.CONNECTIVITYURL
					+ WDArchiveEntities.PORTAL;
		else if (!(connectivityType.trim().equalsIgnoreCase(
				WDArchiveEntities.CMI) || connectivityType.trim()
				.equalsIgnoreCase(WDArchiveEntities.PORTAL)))
			mWDApplicationURLParameters = mWDApplicationURLParameters
					+ WDArchiveEntities.CONNECTIVITYURL
					+ WDArchiveEntities.PORTAL;
		else
			mWDApplicationURLParameters = mWDApplicationURLParameters
					+ WDArchiveEntities.CONNECTIVITYURL + connectivityType;
		String enableDebug = mWDApplicationProperties
				.get(WDArchiveEntities.ENABLEDEBUG);
		if (enableDebug == null)
			mWDApplicationURLParameters = mWDApplicationURLParameters
					+ WDArchiveEntities.ENABLEDEBUGURL + "false"; //$NON-NLS-1$
		else if (!(enableDebug.trim().equalsIgnoreCase("true") || enableDebug //$NON-NLS-1$
				.trim().equalsIgnoreCase("false"))) //$NON-NLS-1$
			mWDApplicationURLParameters = mWDApplicationURLParameters
					+ WDArchiveEntities.ENABLEDEBUGURL + "false"; //$NON-NLS-1$
		else
			mWDApplicationURLParameters = mWDApplicationURLParameters
					+ WDArchiveEntities.ENABLEDEBUGURL + enableDebug;
	}

	private void identifyWDApplicationPackageName() {
		String dcName = mDeployableArchiveName.replace('~', '.');
		String vendor = reverseString(mVendorName);
		if (isPrefix) {
			String prefix = mPrefix.replace('~', '.');
			mWDApplicationPackageName = vendor + "." + prefix + "." + dcName; //$NON-NLS-1$ //$NON-NLS-2$
		} else
			mWDApplicationPackageName = vendor + "." + dcName; //$NON-NLS-1$
	}

	private void identifyDeployableObjectName() {

		String deployableArchiveName = Utils.toLower(Utils
				.formatText(mXGLModelName));
		//CSN 1445892: DC Name to support '/' character
		//Replacing '/' with '~' while creating DeployableArchiveName
		mDeployableArchiveName = deployableArchiveName.replace('/', '~');
		if (isPrefix)
			mDeployableObjectName = mPrefix + "/" + mDeployableArchiveName; //$NON-NLS-1$
		else
			mDeployableObjectName = mDeployableArchiveName;
		// mDeployableObjectName = mDeployableArchiveName.replace('~',
		// '/');//Earlier Code Commented
	}

	private void identifyWDApplications() {
		XGLDocument doc = null;
		int xglListSize = mXGLList.size();
		for (int i = 0; i < xglListSize; i++) {
			doc = (XGLDocument) mXGLList.get(i);
			mModelMap.put(doc.getUrn(), doc.getName());
			if (doc.isMainUnit()) {
				mWDApplicationNames.put(doc.getUrn(), doc.getName());
				mMainUnitsMap.put(doc.getUrn(), doc.getName());
			}
		}
		mWDApplicationNames = mMainUnitsMap;
	}

	/**
	 * Creates the necessary files and folders needed for the archive
	 * 
	 * @throws WDArchiveException
	 */
	private void createFilesAndFolders() throws WDArchiveException {
		String root = mRootFolder + File.separator + System.currentTimeMillis();

		// create a temporary folder for the application
		mRootAppFolder = root + File.separator + "Archive"; //$NON-NLS-1$
		File fRoot = new File(mRootAppFolder);
		fRoot.mkdirs();

		// create a folder to hold the contents of the war archive
		String pathToJar = WDArchiveEntities.META_INF_FOLDER;
		File file = null;
		String wdaPath = null;
		wdaPath = mRootAppFolder + File.separator + mDeployableArchiveName;
		File wdaFolder = new File(wdaPath);
		wdaFolder.mkdir();
		wdaPath = mRootAppFolder;
		wdaFolder = fRoot;

		// create the contents of the WAR Archive
		Logger.trace(Severity.INFO, location,
				"Creating the Applications folder", mXGLModelName); //$NON-NLS-1$
		// Applications folder
		File applicationsFolder = new File(wdaPath + File.separator
				+ WDArchiveEntities.APPLICATIONS);
		applicationsFolder.mkdir();
		// add this to the wda files list
		mWARFiles.put(applicationsFolder, ""); //$NON-NLS-1$

		createWDApplicationsFolder(wdaFolder.getAbsolutePath(),
				WDArchiveEntities.APPLICATIONS);

		Logger.trace(Severity.INFO, location,
				"Creating the ComponentInterfaces folder", mXGLModelName); //$NON-NLS-1$
		// ComponentInterfaces folder
		File compInterfaces = new File(wdaPath + File.separator
				+ WDArchiveEntities.COMPONENTINTERFACES);
		compInterfaces.mkdirs();
		// add this to the wda files list
		mWARFiles.put(compInterfaces, ""); //$NON-NLS-1$

		Logger.trace(Severity.INFO, location, "Creating the Components folder", //$NON-NLS-1$
				mXGLModelName);
		// Components folder
		File compsFolder = new File(wdaPath + File.separator
				+ WDArchiveEntities.COMPONENTS);
		compsFolder.mkdir();
		// add this to the war files list
		mWARFiles.put(applicationsFolder, ""); //$NON-NLS-1$

		Logger.trace(Severity.INFO, location,
				"Creating the WAR META-INF folder", mXGLModelName); //$NON-NLS-1$
		// WAR META-INF folder
		File wdaMetaInf = new File(wdaPath + File.separator
				+ WDArchiveEntities.META_INF_FOLDER);
		wdaMetaInf.mkdir();
		mWARFiles.put(wdaMetaInf, ""); //$NON-NLS-1$
		file = createManifest(wdaMetaInf.getAbsolutePath());
		mWARFiles.put(file, pathToJar);

		Logger.trace(Severity.INFO, location,
				"Creating the WAR WEB-INF folder", mXGLModelName); //$NON-NLS-1$
		// WEB-INF folder
		String portalPath = wdaPath + File.separator
				+ WDArchiveEntities.WEB_INF_FOLDER;
		File portalFolder = new File(portalPath);
		portalFolder.mkdir();
		mWARFiles.put(portalFolder, ""); //$NON-NLS-1$

		Logger.trace(Severity.INFO, location,
				"Creating the the contents for the WEB-INF folder", //$NON-NLS-1$
				mXGLModelName);
		// create the contents for the WEB-INF Folder
		pathToJar = WDArchiveEntities.WEB_INF_FOLDER;

		Logger.trace(Severity.INFO, location,
				"Creating the webdynpro.xml file", mXGLModelName); //$NON-NLS-1$
		// create the webdynpro.xml
		file = createWebdynproXML(portalPath);
		mWARFiles.put(file, pathToJar);

		Logger.trace(Severity.INFO, location, "Creating the web.xml file", //$NON-NLS-1$
				mXGLModelName);
		file = createWebXML(portalPath);
		mWARFiles.put(file, pathToJar);

		Logger.trace(Severity.INFO, location, "Creating the lib folder", //$NON-NLS-1$
				mXGLModelName);
		// lib folder
		File libFolder = new File(wdaPath + File.separator
				+ WDArchiveEntities.LIB);
		libFolder.mkdir();
		mWARFiles.put(libFolder, pathToJar);

		try {
			// wddeployablearchivename.jar in the lib folder
			if (isPrefix) {
				Logger.trace(Severity.INFO, location, "Creating the " //$NON-NLS-1$
						+ mVendorName + "~" + mPrefix + "~" //$NON-NLS-1$ //$NON-NLS-2$
						+ mDeployableArchiveName + ".jar in the lib folder", //$NON-NLS-1$
						mXGLModelName);
				file = createAppJarWithAppPackage(wdaPath + File.separator
						+ mVendorName + "~" + mPrefix + "~" //$NON-NLS-1$ //$NON-NLS-2$
						+ mDeployableArchiveName
						+ WDArchiveEntities.JAR_FILE_EXTN,
						mWDApplicationPackageName);
			} else {
				Logger.trace(Severity.INFO, location, "Creating the " //$NON-NLS-1$
						+ mVendorName + "~" + mDeployableArchiveName //$NON-NLS-1$
						+ ".jar in the lib folder", mXGLModelName); //$NON-NLS-1$
				file = createAppJarWithAppPackage(wdaPath + File.separator
						+ mVendorName + "~" + mDeployableArchiveName //$NON-NLS-1$
						+ WDArchiveEntities.JAR_FILE_EXTN,
						mWDApplicationPackageName);
			}
		} catch (Exception e) {
			message = "Error during creation of files and folders. " //$NON-NLS-1$
					+ e.getLocalizedMessage();
			Logger.log(Severity.ERROR, location, message, mXGLModelName);
			throw new WDArchiveException(message);
		}

		mWARFiles.put(file, pathToJar + "/" + WDArchiveEntities.LIB); //$NON-NLS-1$

		Logger.trace(Severity.INFO, location, "Creating the webdynpro folder", //$NON-NLS-1$
				mXGLModelName);
		// webdynpro folder
		String webDynproPath = wdaPath + File.separator
				+ WDArchiveEntities.WEBDYNPRO_FOLDER;
		File webDynproFolder = new File(webDynproPath);
		webDynproFolder.mkdir();
		mWARFiles.put(webDynproFolder, pathToJar);

		pathToJar = pathToJar + "/" + WDArchiveEntities.WEBDYNPRO_FOLDER; //$NON-NLS-1$

		Logger.trace(Severity.INFO, location,
				"Creating the Applications folder within webdynpro folder", //$NON-NLS-1$
				mXGLModelName);
		// Applications folder within webdynpro folder
		File applications = new File(wdaPath + File.separator
				+ WDArchiveEntities.APPLICATIONS);
		applications.mkdir();
		mWARFiles.put(applications, pathToJar);

		createWDApplicationsFolder(wdaFolder.getAbsolutePath(), pathToJar + "/" //$NON-NLS-1$
				+ WDArchiveEntities.APPLICATIONS);
		createAllWDApplicationXMLs(wdaFolder.getAbsolutePath(), pathToJar + "/" //$NON-NLS-1$
				+ WDArchiveEntities.APPLICATIONS);

		Logger
				.trace(
						Severity.INFO,
						location,
						"Creating the ComponentInterfaces folder within webdynpro folder", //$NON-NLS-1$
						mXGLModelName);
		File componentInterfaces = new File(wdaPath + File.separator
				+ WDArchiveEntities.COMPONENTINTERFACES);
		componentInterfaces.mkdir();
		mWARFiles.put(componentInterfaces, pathToJar);

		Logger.trace(Severity.INFO, location,
				"Creating the Components folder within webdynpro folder", //$NON-NLS-1$
				mXGLModelName);
		File components = new File(wdaPath + File.separator
				+ WDArchiveEntities.COMPONENTS);
		components.mkdir();
		mWARFiles.put(components, pathToJar);

		Logger.trace(Severity.INFO, location,
				"Creating the Configs folder within webdynpro folder", //$NON-NLS-1$
				mXGLModelName);
		File configs = new File(wdaPath + File.separator
				+ WDArchiveEntities.CONFIGS);
		mWARFiles.put(configs, pathToJar);
		configs.mkdir();

		Logger.trace(Severity.INFO, location,
				"Creating the config folder [" + mDeployableArchiveName //$NON-NLS-1$
						+ "] for the Versionable Model Object", mXGLModelName); //$NON-NLS-1$
		// create the config folder for the Versionable Model Object
		File XGLFolder = new File(wdaPath + File.separator
				+ mWDApplicationPackageName);
		XGLFolder.mkdirs();
		mWARFiles.put(XGLFolder, pathToJar + "/" + WDArchiveEntities.CONFIGS); //$NON-NLS-1$
		// create VMO xml
		file = createComponentModelXML(wdaPath);
		mWARFiles.put(file, pathToJar + "/" + WDArchiveEntities.CONFIGS + "/" //$NON-NLS-1$ //$NON-NLS-2$
				+ XGLFolder.getName());

		Iterator iterator = mDependencyFiles.iterator();
		if (iterator != null) {
			while (iterator.hasNext()) {
				file = (File) iterator.next();
				mWARFiles.put(file, pathToJar + "/" + WDArchiveEntities.CONFIGS //$NON-NLS-1$
						+ "/" + XGLFolder.getName()); //$NON-NLS-1$
			}
		}

	}

	private void createWDApplicationsFolder(String targetFolder,
			String pathToJar) {
		if (targetFolder != null) {
			Iterator<String> iterator = mMainUnitsMap.keySet().iterator();
			String mainUnitID = null;
			String wdAppName = null;
			File wdAppFolder = null;
			while (iterator.hasNext()) {
				mainUnitID = iterator.next();
				wdAppName = mMainUnitsMap.get(mainUnitID);
				Logger.trace(Severity.INFO, location, "Creating the " //$NON-NLS-1$
						+ wdAppName + " folder within the Applications folder", //$NON-NLS-1$
						mXGLModelName);
				wdAppName = mWDApplicationPackageName + "." + wdAppName; //$NON-NLS-1$
				wdAppFolder = new File(targetFolder + File.separator
						+ wdAppName);
				wdAppFolder.mkdir();
				// add this to the war files list
				mWARFiles.put(wdAppFolder, pathToJar);
			}
		}
	}

	private void createAllWDApplicationXMLs(String targetFolder,
			String pathToJar) throws WDArchiveException {
		if (targetFolder != null && pathToJar != null) {
			Iterator<String> iterator = mMainUnitsMap.keySet().iterator();
			String mainUnitID = null;
			String wdAppName = null;
			String wdAppFolderName = null;
			File wdAppFolder = null;
			File wdAppFile = null;
			while (iterator.hasNext()) {
				mainUnitID = iterator.next();
				wdAppName = mMainUnitsMap.get(mainUnitID);
				wdAppFolderName = mWDApplicationPackageName + "." + wdAppName; //$NON-NLS-1$
				Logger.trace(Severity.INFO, location, "Creating the " //$NON-NLS-1$
						+ wdAppFolderName, mXGLModelName);
				wdAppFolder = new File(targetFolder + File.separator
						+ wdAppFolderName);
				wdAppFolder.mkdir();
				mWARFiles.put(wdAppFolder, pathToJar);
				wdAppFile = createWDApplicationXML(targetFolder, wdAppName);
				mWARFiles.put(wdAppFile, pathToJar + "/" + wdAppFolderName); //$NON-NLS-1$
			}
		}
	}

	private File createAppJarWithAppPackage(String jarName, String appPackage)
			throws Exception {
		String modelUrn = null;
		Properties properties = null;

		if (jarName != null && appPackage != null) {
			List<String> fileList = new ArrayList<String>();
			mPropertyFiles = new HashMap<File, String>();

			// Iterate the XGLDocuments
			Iterator docsIterator = mXGLList.iterator();
			XGLDocument xglDocument = null;
			List parserList = null;
			Iterator parserListIterator = null;
			TranslationParser parser = null;
			File propertiesFile = null;
			FileOutputStream oStream = null;

			while (docsIterator.hasNext()) {
				xglDocument = (XGLDocument) docsIterator.next();

				// get XGLDocument URN
				modelUrn = xglDocument.getUrn();

				// get the TranslationParser list for this document
				parserList = xglDocument.getTranslationsParser();

				if (parserList != null) {
					parserListIterator = parserList.iterator();
					while (parserListIterator.hasNext()) {
						parser = (TranslationParser) parserListIterator.next();
						properties = parser.getPropertiesFormat();
						propertiesFile = new File(mRootAppFolder
								+ File.separator + modelUrn + "_" //$NON-NLS-1$
								+ parser.getSourceLanguage() + ".properties"); //$NON-NLS-1$
						oStream = new FileOutputStream(propertiesFile);
						properties.store(oStream, null);
						mPropertyFiles.put(propertiesFile, appPackage.replace(
								'.', '/'));
						oStream.close();
					}
				}
			}

			// if no properties file
			if (mPropertyFiles.isEmpty()) {
				fileList.add(mDeployableArchiveName);
				return JARBuilder.createEmptyJar(jarName, fileList);
			}

			// create the app jar with properties files
			return JARBuilder.createJar(jarName, mPropertyFiles, true);
		}
		return null;
	}

	/**
	 * Creates the required archive with .war extension
	 * 
	 * @return File The .war archive file
	 * @throws WDArchiveException
	 */
	private File createWAR() throws WDArchiveException {
		Logger.trace(Severity.INFO, location,
				"Start creating the files and folders...", mXGLModelName); //$NON-NLS-1$
		createFilesAndFolders();
		String warFileName = null;
		if (isPrefix)
			warFileName = mRootFolder + File.separator + mVendorName + "~" //$NON-NLS-1$
					+ mPrefix + "~" + mDeployableArchiveName //$NON-NLS-1$
					+ WDArchiveEntities.WAR_FILE_EXTN;
		else
			warFileName = mRootFolder + File.separator + mVendorName + "~" //$NON-NLS-1$
					+ mDeployableArchiveName + WDArchiveEntities.WAR_FILE_EXTN;
		Logger.trace(Severity.INFO, location, "Creating the war file [" //$NON-NLS-1$
				+ warFileName + "]", mXGLModelName); //$NON-NLS-1$
		return JARBuilder.createJar(warFileName, mWARFiles, true);
	}

	private File createWDApplicationXML(String targetFolder,
			String applicationName) throws WDArchiveException {
		File resource = null;
		if (targetFolder != null && applicationName != null) {
			String GUID = GUIDGenerator.createGUID(16);
			InputStream inputSource = resourceReader(WDArchiveEntities.TEMPLATE_FOLDER
					+ WDArchiveEntities.TEMPLATE_WD_APPLICATION_RR_XML);
			if (inputSource != null) {
				int chunkSize = 0;
				byte[] bytes = null;
				try {
					Reader inReader = new InputStreamReader(inputSource); // $JL-I18N$
					chunkSize = inputSource.available();
					StringBuffer buffer = new StringBuffer(chunkSize);
					char[] readBuffer = new char[chunkSize];
					int n = inReader.read(readBuffer);
					while (n > 0) {
						buffer.append(readBuffer);
						n = inReader.read(readBuffer);
					}
					inputSource.close();
					bytes = buffer.toString().getBytes(); // $JL-I18N$

				} catch (IOException e) {
					message = "Error while reading data for application " //$NON-NLS-1$
							+ applicationName + "\n Details: " //$NON-NLS-1$
							+ e.getLocalizedMessage();
					Logger
							.log(Severity.ERROR, location, message,
									mXGLModelName);
					throw new WDArchiveException(message);
				} finally {
					try {
						inputSource.close();
					} catch (IOException ioe) {
						message = "Error while reading data for application " //$NON-NLS-1$
								+ applicationName + "\n Details: " //$NON-NLS-1$
								+ ioe.getLocalizedMessage();
						Logger.log(Severity.ERROR, location, message,
								mXGLModelName);
						throw new WDArchiveException(message);
					}

				}
				// Replace the GUID
				bytes = replaceToken(bytes, WDArchiveEntities.GUIDSTR, GUID);

				// Replace the fully qualified name of the WebDynpro application
				//bytes = replaceToken(bytes, WDArchiveEntities.WDAPPNAMESTR,
				//		mWDApplicationPackageName + "." + applicationName);
				bytes =replaceString(bytes,WDArchiveEntities.WDAPPNAMESTR, mWDApplicationPackageName + "." + applicationName); //$NON-NLS-1$

				File appXML = new File(targetFolder + File.separator
						+ applicationName);
				appXML.mkdir();
				String fileName = targetFolder + File.separator
						+ applicationName + File.separator
						+ WDArchiveEntities.WDRR;

				Logger.trace(Severity.INFO, location,
						"Writing into the wdrr.xml of " + applicationName, //$NON-NLS-1$
						mXGLModelName);
				// write it to the corresponding application xml file
				resource = resourceWriter(bytes, fileName);

				// check if there are any application properties to be defined
				if (mWDApplicationProperties != null
						&& !mWDApplicationProperties.isEmpty())
					addApplicationProperties(fileName);
			}
		}
		return resource;
	}

	/**
	 * <wdrr:aggregation name="ApplicationProperties">
	 * <wdapp:IWDApplicationPropertyInfo wdrr:state="A" wdrr:orderIndex="0"
	 * wdrr:original="true" value="true" name="sap.authentication" />
	 * </wdrr:aggregation>
	 * 
	 * @param fileName
	 */
	private void addApplicationProperties(String fileName)
			throws WDArchiveException {
		if (fileName != null) {
			File wdApplicationXML = new File(fileName);
			Map<String, String> applicationProperties = mWDApplicationProperties;

			Document document = null;
			DocumentBuilderFactory builderFactory = null;
			DocumentBuilder dBuilder = null;
			try {

				builderFactory = DocumentBuilderFactory.newInstance();
				builderFactory.setNamespaceAware(true);
				builderFactory.setValidating(false);
				dBuilder = builderFactory.newDocumentBuilder();
				document = dBuilder.parse(wdApplicationXML);

				Node applicationNode = null;
				Node propAggregationNode = null;
				Node defaultAppPropNode = null;
				Node appPropNode = null;
				String propName = null;
				String propValue = null;
				NamedNodeMap attributes = null;
				Node nodeAttr = null;

				// get the WDApplication Node
				applicationNode = document.getElementsByTagName(
						WDArchiveEntities.WDAPPINFOTAG).item(0);

				// identify the Property aggregation node
				NodeList childNodes = applicationNode.getChildNodes();
				int childNodesLength = childNodes.getLength();
				for (int i = 0; i < childNodesLength; i++) {
					if ((propAggregationNode = childNodes.item(i))
							.getNodeName()
							.equals(WDArchiveEntities.WDRRAGGRTAG))
						break;
				}

				// get the IWDApplicationPropertyInfo node
				defaultAppPropNode = document.getElementsByTagName(
						WDArchiveEntities.WDAPPPROPINFOTAG).item(0);

				// Iterate through the application properties and add
				// corresponding IWDApplicationPropertyInfo element
				Iterator<String> iterator = applicationProperties.keySet()
						.iterator();
				int orderIndex = 1;
				while (iterator.hasNext()) {
					// get the application property and its value
					propName = iterator.next();
					propValue = applicationProperties.get(propName);

					// clone the property node
					appPropNode = defaultAppPropNode.cloneNode(true);

					// get the attributes
					attributes = appPropNode.getAttributes();

					// update the attribute 'value'
					nodeAttr = attributes
							.getNamedItem(WDArchiveEntities.VALUEATTR);
					nodeAttr.setNodeValue(propValue);

					// update the attribute 'name'
					nodeAttr = attributes
							.getNamedItem(WDArchiveEntities.NAMEATTR);
					nodeAttr.setNodeValue(propName);

					// update the attribute 'orderIndex'
					nodeAttr = attributes
							.getNamedItem(WDArchiveEntities.ORDERINDEXTAG);
					nodeAttr.setNodeValue(orderIndex + ""); //$NON-NLS-1$
					orderIndex++;

					// append this application property element to its parent
					// node
					propAggregationNode.appendChild(appPropNode);
				}

				// write it back to file
				writeDOMtoFile(document, wdApplicationXML.getAbsolutePath());

			} catch (SAXException e) {
				message = "Error while adding application properties for application" //$NON-NLS-1$
						+ fileName + "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (IOException e) {
				message = "Error while adding application properties for application" //$NON-NLS-1$
						+ fileName + "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (ParserConfigurationException e) {
				message = "Error while adding application properties for application" //$NON-NLS-1$
						+ fileName + "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (FactoryConfigurationError e) {
				message = "Error while adding application properties for application" //$NON-NLS-1$
						+ fileName + "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			}
		}
	}

	private File createWebXML(String targetFolder) throws WDArchiveException {
		File resource = null;
		if (targetFolder != null) {
			InputStream inputSource = resourceReader(WDArchiveEntities.TEMPLATE_FOLDER
					+ WDArchiveEntities.TEMPLATE_WEB_XML);
			if (inputSource != null) {
				int chunkSize = 0;
				byte[] bytes = null;
				try {
					chunkSize = inputSource.available();
					bytes = new byte[chunkSize];
					inputSource.read(bytes);
				} catch (IOException e) {
					message = "Error while reading data for Configuration Model " //$NON-NLS-1$
							+ targetFolder
							+ "\n Details: " //$NON-NLS-1$
							+ e.getLocalizedMessage();
					Logger
							.log(Severity.ERROR, location, message,
									mXGLModelName);
					throw new WDArchiveException(message);
				} finally {
					try {
						inputSource.close();
					} catch (IOException ioe) {
						message = "Error while reading data for Configuration Model " //$NON-NLS-1$
								+ targetFolder
								+ "\n Details: " //$NON-NLS-1$
								+ ioe.getLocalizedMessage();
						Logger.log(Severity.ERROR, location, message,
								mXGLModelName);
						throw new WDArchiveException(message);
					}

				}
				String fileName = targetFolder + File.separator
						+ WDArchiveEntities.WEB_XML;
				resource = resourceWriter(bytes, fileName);

			}
		}

		return resource;
	}

	private File createWebdynproXML(String targetFolder)
			throws WDArchiveException {
		File resource = null;
		if (targetFolder != null) {
			InputStream inputSource = resourceReader(WDArchiveEntities.TEMPLATE_FOLDER
					+ WDArchiveEntities.TEMPLATE_WEBDYNPRO_XML);
			if (inputSource != null) {
				String fileName = targetFolder + File.separator
						+ WDArchiveEntities.WEBDYNPRO_XML;
				resource = updateWebdynproXML(inputSource, fileName);
			}
		}
		return resource;
	}

	private File updateWebdynproXML(InputStream iStream, String fileName)
			throws WDArchiveException {
		File webdynproXML = null;
		if (iStream != null && fileName != null) {
			webdynproXML = new File(fileName);

			Document document = null;
			DocumentBuilderFactory builderFactory = null;
			DocumentBuilder dBuilder = null;
			try {
				builderFactory = DocumentBuilderFactory.newInstance();
				builderFactory.setNamespaceAware(true);
				builderFactory.setValidating(false);
				dBuilder = builderFactory.newDocumentBuilder();
				document = dBuilder.parse(iStream);
				Node appNode = document.getElementsByTagName(
						WDArchiveEntities.APPLTAG).item(0);

				Node nodePart = null;
				Node defaultNode = null;
				String wdAppName = null;
				String shortName = null;
				String mainUnitID = null;
				NamedNodeMap attributes = null;
				Node nodeAttr = null;

				if (mMainUnitsMap == null || mMainUnitsMap.isEmpty()) {
					defaultNode = document.getElementsByTagName(
							WDArchiveEntities.PARTTAG).item(0);
					defaultNode.getParentNode().removeChild(defaultNode);
				} else {
					Iterator<String> iterator = mMainUnitsMap.keySet()
							.iterator();
					boolean firstTime = true;
					while (iterator.hasNext()) {
						// get the WD application name
						mainUnitID = iterator.next();
						shortName = mMainUnitsMap.get(mainUnitID);

						if (firstTime) {
							// fill the values for the default node
							defaultNode = document.getElementsByTagName(
									WDArchiveEntities.PARTTAG).item(0);
							nodePart = defaultNode;
							firstTime = false;
						} else {
							// add a new child node to the 'applications' node
							nodePart = defaultNode.cloneNode(true);
							appNode.appendChild(nodePart);
						}

						// get the attributes
						attributes = nodePart.getAttributes();

						// update the attribute 'shortName'
						nodeAttr = attributes
								.getNamedItem(WDArchiveEntities.SHORTNAMEATTR);
						nodeAttr.setNodeValue(shortName);
						// update the attribute 'name'
						wdAppName = mWDApplicationPackageName + "." + shortName; //$NON-NLS-1$

						nodeAttr = attributes
								.getNamedItem(WDArchiveEntities.NAMEATTR);
						nodeAttr.setNodeValue(wdAppName);
					}
				}

				// write it back to file
				writeDOMtoFile(document, webdynproXML.getAbsolutePath());

			} catch (SAXException e) {
				message = "Error while creating webdynpro.xml" + webdynproXML //$NON-NLS-1$
						+ "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (IOException e) {
				message = "Error while creating webdynpro.xml" + webdynproXML //$NON-NLS-1$
						+ "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (ParserConfigurationException e) {
				message = "Error while creating webdynpro.xml" + webdynproXML //$NON-NLS-1$
						+ "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (FactoryConfigurationError e) {
				message = "Error while creating webdynpro.xml" + webdynproXML //$NON-NLS-1$
						+ "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			}
		}
		return webdynproXML;
	}

	private File createComponentModelXML(String targetFolder)
			throws WDArchiveException {
		File resource = null;
		if (targetFolder != null) {
			String GUID = GUIDGenerator.createGUID(16);
			InputStream inputSource = resourceReader(WDArchiveEntities.TEMPLATE_FOLDER
					+ WDArchiveEntities.TEMPLATE_XGLMODEL_XML);
			if (inputSource != null) {
				int chunkSize = 0;
				byte[] bytes = null;
				try {
					chunkSize = inputSource.available();
					bytes = new byte[chunkSize];
					inputSource.read(bytes);
				} catch (IOException e) {
					message = "Error while while reading data for Configuration Model " //$NON-NLS-1$
							+ targetFolder
							+ "\n Details: " //$NON-NLS-1$
							+ e.getLocalizedMessage();
					Logger
							.log(Severity.ERROR, location, message,
									mXGLModelName);
					throw new WDArchiveException(message);
				} finally {
					try {
						inputSource.close();
					} catch (IOException ioe) {
						message = "Error while reading data for Configuration Model " //$NON-NLS-1$
								+ targetFolder
								+ "\n Details: " //$NON-NLS-1$
								+ ioe.getLocalizedMessage();
						Logger.log(Severity.ERROR, location, message,
								mXGLModelName);
						throw new WDArchiveException(message);
					}

				}

				// Replace the GUID
				bytes = replaceToken(bytes, WDArchiveEntities.GUIDSTR, GUID);
				String fileName = targetFolder + File.separator 
				        + "wdrr" +  //$NON-NLS-1$
				        WDArchiveEntities.XML_FILE_EXTN;

				Logger.trace(Severity.INFO, location,
						"Creating the ComponentModel.xml [" + fileName + "]", //$NON-NLS-1$ //$NON-NLS-2$
						mXGLModelName);
				// write it to the corresponding ComponentModel.xml file
				resource = resourceWriter(bytes, fileName);

				// for every MainUnit add a corresponding 'wdapp:XGLMainUnit'
				// node under the
				// node 'wdrr:aggregation' in the ComponentModel.xml
				updateComponentModelXML(fileName, mXGLList, targetFolder);
			}
		}
		return resource;
	}

	private void updateComponentModelXML(String fileName, List XGLList,
			String targetFolder) throws WDArchiveException {
		if (fileName != null && XGLList != null && XGLList.size() > 0) {
			File componentModelXML = new File(fileName);
			Document document = null;
			DocumentBuilderFactory builderFactory = null;
			DocumentBuilder dBuilder = null;
			XGLDocument xglDocument = null;
			try {

				builderFactory = DocumentBuilderFactory.newInstance();
				builderFactory.setNamespaceAware(true);
				builderFactory.setValidating(false);
				dBuilder = builderFactory.newDocumentBuilder();
				document = dBuilder.parse(componentModelXML);

				Node addedNode = null;
				Node defaultNode = null;
				Node addedDependenciesNode = null;
				Node defaultDependenciesNode = null;
				String wdAppName = null;
				String mainUnitID = null;
				NamedNodeMap attributes = null;
				Node nodeAttr = null;
				String dependencyFileName = new String();
				File dependencyFile = null;
				String xglUrnName = null;
				String xglString = null;
				NodeList childNodes = null;
				int xglSize = 0;
				int childNodesLength = 0;
				int nodeSize = 0;

				// set the XGLString value
				defaultNode = document.getElementsByTagName(
						WDArchiveEntities.WDAPPXGLDOCTAG).item(0);
				attributes = defaultNode.getAttributes();
				nodeAttr = attributes
						.getNamedItem(WDArchiveEntities.XGLSTRATTR);
				xglDocument = (XGLDocument) XGLList.get(0);
				xglString = xglDocument.getXglString();
				nodeAttr.setNodeValue(xglString);

				// set the urn value
				xglUrnName = xglDocument.getUrn();
				nodeAttr = attributes.getNamedItem(WDArchiveEntities.URN);
				nodeAttr.setNodeValue(xglUrnName);

				// set the name value
				nodeAttr = attributes.getNamedItem(WDArchiveEntities.NAMEATTR);
				nodeAttr.setNodeValue(mWDApplicationPackageName + "." //$NON-NLS-1$
						+ xglUrnName);
				// set the dependencies targetName
				defaultDependenciesNode = document.getElementsByTagName(
						WDArchiveEntities.WDRRENTRY).item(0);
				attributes = defaultDependenciesNode.getAttributes();
				nodeAttr = attributes
						.getNamedItem(WDArchiveEntities.TARGETNAMEATTR);
				mDependencyString = xglDocument.getDependenciesString();
				dependencyFileName = xglUrnName;
				dependencyFile = createDependencyFile(mDependencyString,
						dependencyFileName, targetFolder);
				mDependencyFiles.add(dependencyFile);
				nodeAttr.setNodeValue(mWDApplicationPackageName + "." //$NON-NLS-1$
						+ dependencyFileName);
				xglSize = XGLList.size();
				for (int i = 1; i < xglSize; i++) {
					addedNode = defaultNode.cloneNode(true);
					defaultNode.getParentNode().appendChild(addedNode);
					attributes = addedNode.getAttributes();
					nodeAttr = attributes
							.getNamedItem(WDArchiveEntities.XGLSTRATTR);
					xglDocument = (XGLDocument) XGLList.get(i);
					xglString = xglDocument.getXglString();
					nodeAttr.setNodeValue(xglString);

					// set the urn value
					xglUrnName = xglDocument.getUrn();
					nodeAttr = attributes.getNamedItem(WDArchiveEntities.URN);
					nodeAttr.setNodeValue(xglUrnName);

					// set the name value
					nodeAttr = attributes
							.getNamedItem(WDArchiveEntities.NAMEATTR);
					nodeAttr.setNodeValue(mWDApplicationPackageName + "." //$NON-NLS-1$
							+ xglUrnName);

					// set the order index value
					nodeAttr = attributes
							.getNamedItem(WDArchiveEntities.ORDERINDEXTAG);
					nodeAttr.setNodeValue(i + ""); //$NON-NLS-1$

					childNodesLength = addedNode.getChildNodes().getLength();
					for (int j = 0; j < childNodesLength; j++) {
						childNodes = addedNode.getChildNodes();
						if (childNodes.item(j) != null
								&& (WDArchiveEntities.ASSOCIATIONSTR)
										.equalsIgnoreCase(childNodes.item(j)
												.getLocalName())) {
							childNodes = childNodes.item(j).getChildNodes();
							nodeSize = childNodes.getLength();
							for (int k = 0; k < nodeSize; k++) {
								if (childNodes.item(k) != null
										&& (WDArchiveEntities.ENTRYSTR)
												.equalsIgnoreCase(childNodes
														.item(k).getLocalName())) {
									addedDependenciesNode = childNodes.item(k);
									break;
								}

							}

						}

					}
					if (addedDependenciesNode != null) {
						attributes = addedDependenciesNode.getAttributes();
						nodeAttr = attributes
								.getNamedItem(WDArchiveEntities.TARGETNAMEATTR);
						mDependencyString = xglDocument.getDependenciesString();
						dependencyFileName = xglUrnName;
						dependencyFile = createDependencyFile(
								mDependencyString, dependencyFileName,
								targetFolder);
						mDependencyFiles.add(dependencyFile);
						nodeAttr.setNodeValue(mWDApplicationPackageName + "." //$NON-NLS-1$
								+ dependencyFileName);
					}
				}

				// get the attributes

				// TODO: change this value, must be unique
				defaultNode = document.getElementsByTagName(
						WDArchiveEntities.WDAPPXGLCOMPTAG).item(0);
				attributes = defaultNode.getAttributes();
				nodeAttr = attributes.getNamedItem(WDArchiveEntities.NAMEATTR);
				//CSN 1445892:DC Name to support '/' character 
				/*newDeployableArchiveName is constructed to retain the package name with the same
				format as older archive*/
				String newDeployableArchiveName = null;
				if(isPrefix)
					nodeAttr.setNodeValue(mWDApplicationPackageName + "." + mPrefix.replace('~', '.') + "." + mDeployableArchiveName); //$NON-NLS-1$ //$NON-NLS-2$
				else {
					 newDeployableArchiveName = mDeployableArchiveName.replace('~', '.');
					 nodeAttr.setNodeValue(mWDApplicationPackageName + "." + newDeployableArchiveName); //$NON-NLS-1$
				}

				// version number
				nodeAttr = attributes
						.getNamedItem(WDArchiveEntities.VERSIONATTR);
				nodeAttr.setNodeValue(WDArchiveEntities.VERSION_NUMBER);

				// dc name
				nodeAttr = attributes
						.getNamedItem(WDArchiveEntities.DCNAMEATTR);
				nodeAttr.setNodeValue(mXGLModelName);

				// vendor name
				nodeAttr = attributes
						.getNamedItem(WDArchiveEntities.VENDORNAMEATTR);
				nodeAttr.setNodeValue(mVendorName);

				if (mMainUnitsMap == null || mMainUnitsMap.isEmpty()) {
					defaultNode = document.getElementsByTagName(
							WDArchiveEntities.WDAPPXGLMAINUNITTAG).item(0);
					defaultNode.getParentNode().removeChild(defaultNode);
				} else {
					Iterator<String> iterator = mMainUnitsMap.keySet()
							.iterator();
					boolean firstTime = true;
					// to increment the 'wdrr:orderIndex' value
					int counter = 0;

					while (iterator.hasNext()) {
						// get the WD application name
						mainUnitID = iterator.next();
						wdAppName = mMainUnitsMap.get(mainUnitID);

						if (firstTime) {
							// fill the values for the default node
							defaultNode = document.getElementsByTagName(
									WDArchiveEntities.WDAPPXGLMAINUNITTAG)
									.item(0);
							addedNode = defaultNode;
							firstTime = false;
						} else {
							// add a new child node to the 'wdrr:aggregation'
							// node
							addedNode = defaultNode.cloneNode(true);
							defaultNode.getParentNode().appendChild(addedNode);
							counter++;
						}

						// get the attributes
						attributes = addedNode.getAttributes();

						// update the attribute 'ID' representing the mainUnitID
						nodeAttr = attributes
								.getNamedItem(WDArchiveEntities.MAINUNITIDATTR);
						nodeAttr.setNodeValue(mainUnitID);
						// update the attribute 'Name' representing the display
						// Name of the IView
						nodeAttr = attributes
								.getNamedItem(WDArchiveEntities.MAINUNITNAMEATTR);
						nodeAttr.setNodeValue(wdAppName);
						// update the attribute 'name' representing the Name of
						// this Node
						nodeAttr = attributes
								.getNamedItem(WDArchiveEntities.NAMEATTR);
						nodeAttr.setNodeValue(wdAppName);
						// update the attribute 'urn' representing the URN of
						// this Node
						nodeAttr = attributes
								.getNamedItem(WDArchiveEntities.URN);
						nodeAttr.setNodeValue(mainUnitID);
						// update the attribute 'wdrr:orderIndex'
						nodeAttr = attributes
								.getNamedItem(WDArchiveEntities.ORDERINDEXTAG);
						nodeAttr.setNodeValue(counter + ""); //$NON-NLS-1$

					}
				}
				// write it back to file
				writeDOMtoFile(document, componentModelXML.getAbsolutePath());

			} catch (SAXException e) {
				message = "Error while updating configuration model details " //$NON-NLS-1$
						+ componentModelXML + "\n Details: " //$NON-NLS-1$
						+ e.getLocalizedMessage();
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (IOException e) {
				message = "Error while updating configuration model details " //$NON-NLS-1$
						+ componentModelXML + "\n Details: " //$NON-NLS-1$
						+ e.getLocalizedMessage();
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (ParserConfigurationException e) {
				message = "Error while updating configuration model details " //$NON-NLS-1$
						+ componentModelXML + "\n Details: " //$NON-NLS-1$
						+ e.getLocalizedMessage();
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (FactoryConfigurationError e) {
				message = "Error while updating configuration model details " //$NON-NLS-1$
						+ componentModelXML + "\n Details: " //$NON-NLS-1$
						+ e.getLocalizedMessage();
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			}
		}
	}

	private File createDependencyFile(String dependencyString, String fileName,
			String targetFolder) throws WDArchiveException {
		File resource = null;
		String urn = null;
		if (targetFolder != null) {
			String GUID = GUIDGenerator.createGUID(16);
			InputStream inputSource = resourceReader(WDArchiveEntities.TEMPLATE_FOLDER
					+ WDArchiveEntities.TEMPLATE_WD_DEPENDENCY);
			if (inputSource != null) {
				int chunkSize = 0;
				byte[] bytes = null;
				try {
					chunkSize = inputSource.available();
					bytes = new byte[chunkSize];
					inputSource.read(bytes);
				} catch (IOException e) {
					message = "Error while reading data for Configuration Model " //$NON-NLS-1$
							+ targetFolder
							+ "\n Details: " //$NON-NLS-1$
							+ e.getLocalizedMessage();
					Logger
							.log(Severity.ERROR, location, message,
									mXGLModelName);
					throw new WDArchiveException(message);
				} finally {
					try {
						inputSource.close();
					} catch (IOException ioe) {
						message = "Error while reading data for Configuration Model " //$NON-NLS-1$
								+ targetFolder
								+ "\n Details: " //$NON-NLS-1$
								+ ioe.getLocalizedMessage();
						Logger.log(Severity.ERROR, location, message,
								mXGLModelName);
						throw new WDArchiveException(message);
					}

				}

				// Replace the GUID
				bytes = replaceToken(bytes, WDArchiveEntities.GUIDSTR, GUID);

				urn = fileName;
				fileName = targetFolder + File.separator + fileName
						+ WDArchiveEntities.XML_FILE_EXTN;

				Logger.trace(Severity.INFO, location,
						"Creating the corresponding dependencies.xml[" + urn //$NON-NLS-1$
								+ ".xml]", mXGLModelName); //$NON-NLS-1$
				// write it to the corresponding dependencies.xml file
				resource = resourceWriter(bytes, fileName);

				// for every MainUnit add a corresponding 'wdapp:XGLMainUnit'
				// node under the
				// node 'wdrr:aggregation' in the ComponentModel.xml
				updateDependencyXML(fileName, mDependencyString, urn);
			}
		}
		return resource;

	}

	private void updateDependencyXML(String fileName, String mDependencyString,
			String urn) throws WDArchiveException {
		if (fileName != null && mDependencyString != null) {
			File dependencyXML = new File(fileName);

			Document document = null;
			DocumentBuilderFactory builderFactory = null;
			DocumentBuilder dBuilder = null;
			try {

				builderFactory = DocumentBuilderFactory.newInstance();
				builderFactory.setNamespaceAware(true);
				builderFactory.setValidating(false);
				dBuilder = builderFactory.newDocumentBuilder();
				document = dBuilder.parse(dependencyXML);

				Node defaultNode = null;
				NamedNodeMap attributes = null;
				Node nodeAttr = null;

				// set the DependencyString value
				defaultNode = document.getElementsByTagName(
						WDArchiveEntities.WDAPPDEPTAG).item(0);
				attributes = defaultNode.getAttributes();
				nodeAttr = attributes
						.getNamedItem(WDArchiveEntities.DEPENDENCIESSTR);
				nodeAttr.setNodeValue(mDependencyString);
				nodeAttr = attributes.getNamedItem(WDArchiveEntities.NAMEATTR);
				nodeAttr.setNodeValue(mWDApplicationPackageName + "." + urn); //$NON-NLS-1$

				// write it back to file
				writeDOMtoFile(document, dependencyXML.getAbsolutePath());

			} catch (SAXException e) {
				message = "Error while updating configuration model details " //$NON-NLS-1$
						+ dependencyXML + "\n Details: " //$NON-NLS-1$
						+ e.getLocalizedMessage();
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (IOException e) {
				message = "Error while updating configuration model details " //$NON-NLS-1$
						+ dependencyXML + "\n Details: " //$NON-NLS-1$
						+ e.getLocalizedMessage();
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (ParserConfigurationException e) {
				message = "Error while updating configuration model details " //$NON-NLS-1$
						+ dependencyXML + "\n Details: " //$NON-NLS-1$
						+ e.getLocalizedMessage();
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (FactoryConfigurationError e) {
				message = "Error while updating configuration model details " //$NON-NLS-1$
						+ dependencyXML + "\n Details: " //$NON-NLS-1$
						+ e.getLocalizedMessage();
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			}
		}
	}

	private File createManifest(String targetFolder) throws WDArchiveException {
		if (targetFolder != null) {
			InputStream inputSource = resourceReader(WDArchiveEntities.TEMPLATE_FOLDER
					+ WDArchiveEntities.TEMPLATE_MANIFEST);
			if (inputSource != null) {
				int chunkSize = 0;
				byte[] bytes = null;
				try {
					chunkSize = inputSource.available();
					bytes = new byte[chunkSize];
					inputSource.read(bytes);
				} catch (IOException e) {
					message = "Error while reading data for creating the Manifest file " //$NON-NLS-1$
							+ "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
					Logger
							.log(Severity.ERROR, location, message,
									mXGLModelName);
					throw new WDArchiveException(message);
				} finally {
					try {
						inputSource.close();
					} catch (IOException ioe) {
						message = "Error while reading data for creating the Manifest file" //$NON-NLS-1$
								+ "\n Details: " + ioe.getLocalizedMessage(); //$NON-NLS-1$
						Logger.log(Severity.ERROR, location, message,
								mXGLModelName);
						throw new WDArchiveException(message);
					}

				}

				// Replace the Vendor name
				bytes = replaceToken(bytes, WDArchiveEntities.VENDORSTR,
						mVendorName);

				// Replace the deployable object name
				bytes = replaceString(bytes,WDArchiveEntities.DEPOBJNAMESTR,mDeployableObjectName);

				// write it to the corresponding MANIFEST.MF file
				return resourceWriter(bytes, targetFolder + File.separator
						+ WDArchiveEntities.MANIFEST);
			}
		}
		return null;
	}

	private InputStream resourceReader(String resourceName) {
		return getClass().getClassLoader().getResourceAsStream(resourceName);
	}

	private File resourceWriter(InputStream iStream, String resourceName)
			throws WDArchiveException {
		File resource = null;

		if (iStream != null && resourceName != null) {
			FileOutputStream oStream = null;
			ByteArrayOutputStream byteArrayOStream = new ByteArrayOutputStream();
			try {
				int chunkSize = iStream.available();
				byte[] bytes = new byte[chunkSize];
				int count = iStream.read(bytes);
				while (count > 0) {
					byteArrayOStream.write(bytes);
					count = iStream.read(bytes);
				}

				resource = new File(resourceName);
				oStream = new FileOutputStream(resource);
				oStream.write(byteArrayOStream.toByteArray());
				oStream.flush();
				oStream.close();

				byteArrayOStream.close();
			} catch (FileNotFoundException e) {
				message = "Error while while writing data to " + resourceName //$NON-NLS-1$
						+ "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (IOException e) {
				message = "Error while while writing data to " + resourceName //$NON-NLS-1$
						+ "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} finally {
				try {
					oStream.close();
				} catch (IOException e1) {
					message = "Error while while writing data to " //$NON-NLS-1$
							+ resourceName + "\n Details: " //$NON-NLS-1$
							+ e1.getLocalizedMessage();
					Logger
							.log(Severity.ERROR, location, message,
									mXGLModelName);
					throw new WDArchiveException(message);
				}
			}
		}

		return resource;
	}

	private File resourceWriter(byte[] bytes, String resourceName)
			throws WDArchiveException {
		File resource = null;

		if (bytes != null && resourceName != null) {
			FileOutputStream oStream = null;
			try {
				resource = new File(resourceName);
				oStream = new FileOutputStream(resource);
				oStream.write(bytes);
				oStream.close();
			} catch (FileNotFoundException e) {
				message = "Error while writing data to " + resourceName //$NON-NLS-1$
						+ "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (IOException e) {
				message = "Error while writing data to " + resourceName //$NON-NLS-1$
						+ "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} finally {
				try {
					oStream.close();
				} catch (IOException e1) {
					message = "Error while writing data to " + resourceName //$NON-NLS-1$
							+ "\n Details: " + e1.getLocalizedMessage(); //$NON-NLS-1$
					Logger
							.log(Severity.ERROR, location, message,
									mXGLModelName);
					throw new WDArchiveException(message);
				}
			}
		}

		return resource;
	}

	private void writeDOMtoFile(Document document, String targetFile)
			throws WDArchiveException {
		if (document != null && targetFile != null) {
			Source source = null;
			Result result = null;
			try {

				// Create a transformer
				Transformer xformer = TransformerFactory.newInstance()
						.newTransformer();

				// Write the DOM document to a file
				source = new DOMSource(document);
				result = new StreamResult(new File(targetFile));
				xformer.transform(source, result);
			} catch (TransformerConfigurationException e) {
				message = "Error while while writing XML DOM to " + targetFile //$NON-NLS-1$
						+ "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			} catch (TransformerException e) {
				message = "Error while while writing XML DOM to " + targetFile //$NON-NLS-1$
						+ "\n Details: " + e.getLocalizedMessage(); //$NON-NLS-1$
				Logger.log(Severity.ERROR, location, message, mXGLModelName);
				throw new WDArchiveException(message);
			}
		}
	}

	private byte[] replaceToken(byte[] input, String token, String tokenValue) {
		if (input != null && token != null && tokenValue != null) {
			String inputString = new String(input); // $JL-I18N$
			inputString = inputString.replaceAll(token, tokenValue);
			return inputString.getBytes(); // $JL-I18N$
		}
		return null;
	}

	private String reverseString(String vendor) {
		if (vendor != null) {
			StringTokenizer tokenizer = new StringTokenizer(vendor, "."); //$NON-NLS-1$
			int count = tokenizer.countTokens();
			String[] tokens = new String[count];
			int index = 0;
			while (tokenizer.hasMoreElements())
				tokens[index++] = (String) tokenizer.nextElement();
			StringBuffer buffer = new StringBuffer();
			for (int i = tokens.length - 1; i >= 0; i--) {
				buffer.append(tokens[i]);
				if (i == 0)
					break;
				buffer.append('.');
			}
			return buffer.toString();
		}
		return vendor;
	}

	private boolean isVendorNameValid(String vendor) {
		if (vendor != null) {
			char[] chars = vendor.toCharArray();
			if (chars.length > 0 && !Character.isLetter(chars[0]))
				return false;
			for (int i = 0; i < chars.length; i++) {
				if (chars[i] == '.' || Character.isLetterOrDigit(chars[i]))
					continue;
				else
					return false;
			}
			return true;
		}
		return false;
	}
	
	private byte[] replaceString(byte[] input, String depObjnameStr, String deployableObjectName) {
		// TODO Auto-generated method stub

		String fullInputString = null;
		String beforeToken = null;
		String afterToken = null;
		String dummyString = null;
		String finalString = null;
		if(input != null && depObjnameStr != null && deployableObjectName != null) {
		fullInputString = new String(input); // $JL-I18N$
		beforeToken = fullInputString.substring(0, fullInputString.indexOf('#'));
		dummyString = fullInputString.substring(beforeToken.length());
		afterToken = dummyString.substring(depObjnameStr.length());
		finalString = beforeToken + deployableObjectName + afterToken ;
		
		}
		return finalString.getBytes(); // $JL-I18N$

	}


}
