/*
 * Created on Nov 30, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.impl;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler;
import com.sap.visualcomposer.wd4vc.archive.utils.WDArchiveEntities;

/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WDArchiveHandlerImpl extends WDArchivehandler {
	
	private String mPrefix;
	
	private String mXGLModelName;
	
	private String mXGLModelID;
	
	private List mXGLList;
	
	private Set<String> mXGLMainUnits;
	
	private String mDestinationFolder;
	
	private boolean mDeployWDAppWithSource;
	
	private Map<String, String> mWDApplicationProperties;
	
	private String mWDArchiveName;
	
	private String mWDSourceArchiveName;

	private Map<String, String> mWDApplicationURLs;
	
	private String mDevelopmentComponentName;
	
	private String mJ2EEDeployableObjectName;

	private String mVendorName;
	
	private Map<String, String> mWDApplicationNames;
	
	private String mWDApplicationURLParameters;
	
	public WDArchiveHandlerImpl() {		
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#getApplicationProperties()
	 */
	public Map<String, String> getApplicationProperties() {
		return mWDApplicationProperties;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#getDestinationFolder()
	 */
	public String getDestinationFolder() {
		return mDestinationFolder;
	}

	public boolean mustDeployWDAppWithSource() {
		return mDeployWDAppWithSource;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#getPrefix()
	 */
	public String getPrefix() {
		return mPrefix;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#getXGLMainUnits()
	 */
	public Set<String> getXGLMainUnits() {
		return mXGLMainUnits;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#getXGLModelID()
	 */
	public String getXGLModelID() {
		return mXGLModelID;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#getXGLModelName()
	 */
	public String getXGLModelName() {
		return mXGLModelName;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#getXGLString()
	 */
	public List getXGLList() {
		return mXGLList;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#setDevelopmentComponentName(java.lang.String)
	 */
	public void setDevelopmentComponentName(String dcName) {
		mDevelopmentComponentName = dcName;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#setVendorName(java.lang.String)
	 */
	public void setVendorName(String vendorName) {
		mVendorName = vendorName;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#setWDApplicationNames(java.util.Map)
	 */
	public void setWDApplicationNames(Map<String, String> applicationNames) {
		mWDApplicationNames = applicationNames;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#setWDApplicationURLParameters(java.lang.String)
	 */
	public void setWDApplicationURLParameters(String URLParameters) {
		mWDApplicationURLParameters = URLParameters;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#setWDApplicationURLs(java.util.Map)
	 */
	public void setWDApplicationURLs(Map<String, String> appURLs) {
		mWDApplicationURLs = appURLs;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#setWDArchiveName(java.lang.String)
	 */
	public void setWDArchiveName(String archiveName) {
		mWDArchiveName = archiveName;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#setWDSourceArchiveName(java.lang.String)
	 */
	public void setWDSourceArchiveName(String archiveName) {
		mWDSourceArchiveName = archiveName;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#getDevelopmentComponentName()
	 */
	public String getDevelopmentComponentName() {
		return mDevelopmentComponentName;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#getVendorName()
	 */
	public String getVendorName() {
		return mVendorName;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#getWDApplicationNames()
	 */
	public Map<String, String> getWDApplicationNames() {
		return mWDApplicationNames;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#getWDApplicationURLParameters()
	 */
	public String getWDApplicationURLParameters() {
		return mWDApplicationURLParameters;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#getWDApplicationURLs()
	 */
	public Map<String, String> getWDApplicationURLs() {
		return mWDApplicationURLs;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#getWDArchiveName()
	 */
	public String getWDArchiveName() {
		return mWDArchiveName;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#getWDDispatcherURI()
	 */
	public String getWDDispatcherURI() {
		return WDArchiveEntities.WEBDYNPRO_DISPATCHER;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#getWDSourceArchiveName()
	 */
	public String getWDSourceArchiveName() {
		return mWDSourceArchiveName;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#setApplicationProperties(java.util.Map)
	 */
	public void setApplicationProperties(Map<String, String> properties) {
		mWDApplicationProperties = properties;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#setDestinationFolder(java.lang.String)
	 */
	public void setDestinationFolder(String folderPath) {
		mDestinationFolder = folderPath;
	}
	
	public void setDeployWDAppWithSource(boolean option) {
		mDeployWDAppWithSource = option;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#setPrefix(java.lang.String)
	 */
	public void setPrefix(String prefix) {
		mPrefix = prefix;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#setXGLMainUnits(java.util.Set)
	 */
	public void setXGLMainUnits(Set<String> mainUnitIDs) {
		mXGLMainUnits = mainUnitIDs;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#setXGLModelID(java.lang.String)
	 */
	public void setXGLModelID(String ID) {
		mXGLModelID = ID;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#setXGLModelName(java.lang.String)
	 */
	public void setXGLModelName(String name) {
		mXGLModelName = name;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#setXGLString(java.lang.String)
	 */
	public void setXGLList(List xglList) {
		mXGLList = xglList;
	}


	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.WDArchivehandler#setJ2EEDeployableObjectName(java.lang.String)
	 */
	public void setJ2EEDeployableObjectName(String deployableObjectName) {
		mJ2EEDeployableObjectName = deployableObjectName;
	}

	/* (non-Javadoc)
	 * @see com.sap.visualcomposer.wd4vc.archive.extapi.IWDArchiveHandler#getJ2EEDeployableObjectName()
	 */
	public String getJ2EEDeployableObjectName() {
		return mJ2EEDeployableObjectName;
	}

}
