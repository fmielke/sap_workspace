/*
 * Created on Nov 30, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.utils;

/**
 * Defines the API to generate a global unique identifier.
 * 
 * @author I026466
 *
 */
public class GUIDGenerator {

	private static final char[] hexdigits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

	/**
	 * Return is a GUID of the length specified.
	 * @param len the number of characters the GUID consists of
	 * @return a GUID of the length specified
	 */
	public static String createGUID(int len) {
	  char[] buffer = new char[len];
	  randomize(buffer, 0, len);
	  return new String(buffer);
	}

	private static void randomize(char[] buffer, int pos, int len) {
	  int random = 0;
	  for (int i = 0; i < len; i++) {
		if (i % 4 == 0) {
		  random = (int) (Integer.MAX_VALUE * Math.random());
		} else {
		  random /= 16;
		}
		buffer[pos + i] = hexdigits[random % 16];
	  }
	}

}
