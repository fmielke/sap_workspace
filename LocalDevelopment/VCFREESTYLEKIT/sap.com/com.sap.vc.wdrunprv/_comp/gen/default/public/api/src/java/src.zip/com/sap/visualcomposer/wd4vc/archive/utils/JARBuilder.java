/*
 * Created on Nov 30, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.sap.visualcomposer.wd4vc.archive.exception.WDArchiveException;

/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class JARBuilder {

	private static String FILESEPARATOR =  "/" ; //$NON-NLS-1$
	public static File createJar(String jarName, Map<File, String>  fileList, boolean manifest) throws WDArchiveException {
		File archive = null;
		if(jarName != null && fileList != null) {
			try {
				archive = new File(jarName);
				JarOutputStream joStream = new JarOutputStream(new FileOutputStream(archive));
				JarEntry jEntry = null;
							
				Iterator<File> iterator = fileList.keySet().iterator();
				String filePath = null;
				File fileEntry = null;
				FileInputStream iStream = null;
				String entryName = null;
				byte[] bytes = null;			
				while (iterator.hasNext()) {
					fileEntry = iterator.next();
					filePath = fileList.get(fileEntry);
					if(filePath.equals("")) //$NON-NLS-1$
						entryName = fileEntry.getName();
					else
						entryName = filePath + FILESEPARATOR + fileEntry.getName();
//						entryName = filePath + File.separatorChar + fileEntry.getName(); 
					
					if(fileEntry.isDirectory()) {
						jEntry = new JarEntry(entryName + FILESEPARATOR);
						joStream.putNextEntry(jEntry);
					} else {
						jEntry = new JarEntry(entryName);
						joStream.putNextEntry(jEntry);
				
						iStream = new FileInputStream(fileEntry.getAbsolutePath());
						bytes = new byte[iStream.available()];
						iStream.read(bytes);
						joStream.write(bytes);
						iStream.close();
					}
					joStream.closeEntry();
					
				}
			
				joStream.close();			
			} catch (FileNotFoundException e) {
				throw new WDArchiveException("Error while creating "+jarName+"\n Details: "+e.getLocalizedMessage()); //$NON-NLS-1$ //$NON-NLS-2$
			} catch (IOException e) {
				throw new WDArchiveException("Error while creating "+jarName+"\n Details: "+e.getLocalizedMessage()); //$NON-NLS-1$ //$NON-NLS-2$
			}		
			
		}
		
		return archive; 
	}
	
	public static File createEmptyJar(String jarName, List<String> fileList) throws WDArchiveException {
		File archive = null;

		if(jarName != null && fileList != null) {
			try {
				archive = new File(jarName);
				ZipOutputStream oStream = new ZipOutputStream(new FileOutputStream(archive));			
				ZipEntry entry = null;
			
				Iterator<String> iterator = fileList.iterator();
				String fileEntry = null;
				while (iterator.hasNext()) {
					fileEntry = iterator.next();
					
					entry = new ZipEntry(fileEntry + FILESEPARATOR);
					oStream.putNextEntry(entry);				
				}
			
				oStream.close();			
			} catch (FileNotFoundException e) {
				throw new WDArchiveException("Error while creating "+jarName+"\n Details: "+e.getLocalizedMessage()); //$NON-NLS-1$ //$NON-NLS-2$
			} catch (IOException e) {
				throw new WDArchiveException("Error while creating "+jarName+"\n Details: "+e.getLocalizedMessage()); //$NON-NLS-1$ //$NON-NLS-2$
			}		
			
		}
		
		return archive; 
	}

}
