package com.sap.visualcomposer.wd4vc.archive.utils;

import com.sap.tc.logging.Category;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;

/**
 * A utility class, that logs messages for all severity levels into the
 * log and trace files 
 * 
 * @author Padmashree B
 *   
 */
public class Logger {

	private static String LOG_PREFIX = "[VCRunProvs-WD4VC]["; //$NON-NLS-1$
	public static String CATEGORY_NAME =Category.SYSTEM + "/Server/VCRunProvs/WD4VC";	 //$NON-NLS-1$
	public static final Category WD4VC_CATEGORY = Category.getCategory(Category.SYS_SERVER, CATEGORY_NAME);

	/**
	 * Logs an error The method places the message both into the Log and Trace file
	 * Use this if you want the administrator to see the error message, else if you want
	 * only the stack trace, use the trace method instead
	 * 
	 * @param severity		Severity of the message
	 * @param location		Location for logging
	 * @param message		Message to be logged
	 * @param dcName		The DC in the current context
	 * @param throwable		Reference to the throwable
	 */
	public static void log(int severity, Location location, String message,
			String dcName, Throwable throwable) {
		if (WD4VC_CATEGORY.beLogged(severity)) {
			WD4VC_CATEGORY.logThrowableT(severity, location,
					formatString(message, dcName), throwable);
		} else if(location.beLogged(severity)) {
			trace(severity, location, message, dcName,throwable);
		}
	}

	/**
	 * Logs a message into both the trace and log files
	 * 
	 * @param severity		Severity of the message	
	 * @param location		Location for logging
	 * @param message		Message to be logged
	 * @param dcName		The DC in the current context
	 */
	public static void log(int severity, Location location, String message,
			String dcName) {
		if (WD4VC_CATEGORY.beLogged(severity))
			WD4VC_CATEGORY.logT(severity, location,
					formatString(message, dcName));
	}

	/**
	 * Puts the message into the trace file only. If the severity is WARNING,
	 * ERROR or FATAL, it will also log it.
	 * 
	 * @param severity		Severity of the message	
	 * @param location		Location for logging
	 * @param message		Message to be logged
	 * @param dcName		The DC in the current context
	 */
	public static void trace(int severity, Location location, String message,
			String dcName) {
		if (location.beLogged(severity)) {
			if (severity == Severity.WARNING || severity == Severity.FATAL
					|| severity == Severity.ERROR) {
				location.logT(severity, WD4VC_CATEGORY,
						formatString(message, dcName));
			} else {
				location.logT(severity, formatString(message, dcName));
			}
		}
	}

	/**
	 * Puts the message into the trace file only. If the severity is WARNING,
	 * ERROR or FATAL, it will also log it. If you provide the exception the
	 * entire stack trace is dumped
	 * 
	 * @param severity		Severity of the message	
	 * @param locations		Location for logging
	 * @param message		Message to be logged
	 * @param dcName		The DC in the current context
	 */
	public static void trace(int severity, Location location, String message,
			String dcName, Throwable e) {
		if (location.beLogged(severity)) {
			if (severity == Severity.WARNING || severity == Severity.FATAL
					|| severity == Severity.ERROR) {
				location.traceThrowableT(severity, formatString(message,
						dcName), e);
				//It will only log the technical message//Exception trace is in the trace file only
				log(severity, location, message, dcName);
			} else {
				location.traceThrowableT(severity, formatString(message,
						dcName), e);
			}
		}
	}

	/**
	 * Formats a message according to the supportability standards
	 * 
	 * @param message		Message to be logged
	 * @param dcName		The DC in the current context
	 * @return				Returns the formatted String for logging
	 */
	private static String formatString(String message, String dcName) {
		if (dcName == null)
			dcName = ""; //$NON-NLS-1$
		return LOG_PREFIX + dcName + "]" + message; //$NON-NLS-1$
	}
}
