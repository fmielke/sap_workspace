/*
 * Created on Apr 5, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.utils;

/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class TranslationUnit {

	private String mName;
	private String mText;
	private String mType;

	public TranslationUnit(String name, String text, String type) {
		mName = name;
		mText = text;
		mType = type;
	}


	public String getName() {
		return mName;
	}
	public void setName(String name) {
		mName = name;
	}

	public String getText() {
		return mText;
	}
	public void setText(String text) {
		mText = text;
	}

	public String getType() {
		return mType;
	}
	public void setType(String type) {
		mType = type;
	}

}
