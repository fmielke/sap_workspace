/*
 * Created on Dec 5, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.utils;

import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Utils {
	private static String SEPERATOR = "."; //$NON-NLS-1$

	public static String formatText(String input) {
		if(input != null) {
			input = input.trim();
			char[] characters = input.toCharArray();
			for (int i = 0; i < characters.length; i++) {
				if(!Character.isLetterOrDigit(characters[i])) {
					//CSN #1600189 [EHP1] VC Runtime Problem
					if(characters[i] != '.' && characters[i] != '_' && characters[i] != '/' && characters[i] != '$' && characters[i] != '!'&& characters[i] != '-')
						characters[i] = '_';
				}
			}
			return new String(characters);
		}

		return input;
	}

	public static String formatToJavaIdentifier(String input) {
		if(input != null) {
			input = input.trim();
			if(input.length() == 0)
				return input;
			char[] characters = input.toCharArray();
			for (int i = 0; i < characters.length; i++) {

				if(characters[i] >= 'A' && characters[i] <= 'Z' ||
					characters[i] >= 'a' && characters[i] <= 'z' ||
					characters[i] == '_' || characters[i] == '.' ||
					Character.isDigit(characters[i]) ) {
					continue;
				} else
					characters[i] = '_';
			}
			if(!Character.isJavaIdentifierStart(characters[0]))
				return "_" + new String(characters); //$NON-NLS-1$
			else
				return new String(characters);
		}

		return input;
	}

	public static String toLower(String input) {
		if(input != null) {
			return input.trim().toLowerCase(Locale.ENGLISH);
		}

		return input;
	}

	/**
	 * Creates a timestamp String formatted "yyyy.mm.dd.hh.mm.ss" from the current time.
	 */
	public static String getTimeStamp() {
		StringBuffer lReturn = new StringBuffer();
		Calendar cal = GregorianCalendar.getInstance();
		lReturn.append(cal.get(Calendar.YEAR));
		lReturn.append(SEPERATOR);
		lReturn.append(formatNumStr(cal.get(Calendar.MONTH)+1,2));
		lReturn.append(SEPERATOR);
		lReturn.append(formatNumStr(cal.get(Calendar.DAY_OF_MONTH),2));
		lReturn.append(SEPERATOR);
		lReturn.append(formatNumStr(cal.get(Calendar.HOUR_OF_DAY),2));
		lReturn.append(SEPERATOR);
		lReturn.append(formatNumStr(cal.get(Calendar.MINUTE),2));
		lReturn.append(SEPERATOR);
		lReturn.append(formatNumStr(cal.get(Calendar.SECOND),2));
		return(lReturn.toString());
	}

	/**
	 * Returns the String reprensentation of given positive int formated to a given length.
	 * If given int is to long first chars will be removed. If to short 0's will be added in front
	 * @param i	positive integer
	 * @param length the length of the returned String.
	 * @return String representation of the given integer formatted to the given length
	 */
	private static String formatNumStr(int i, int length) {
		if(length <= 0) {
			throw(new IllegalArgumentException("Given length must be larger than zero")); //$NON-NLS-1$
		}
		if(i < 0) {
			throw (new IllegalArgumentException("Given integer must be >=0")); //$NON-NLS-1$
		}
		String lReturn = Integer.toString(i);
		if(lReturn.length() < length) {
			char[] zeros = new char[length -lReturn.length()];
			Arrays.fill(zeros,'0');
			lReturn = new String(zeros) + lReturn;
		} else if(lReturn.length() > length) {
			lReturn = lReturn.substring(lReturn.length()-length);
		}
		return(lReturn);
	}

}
