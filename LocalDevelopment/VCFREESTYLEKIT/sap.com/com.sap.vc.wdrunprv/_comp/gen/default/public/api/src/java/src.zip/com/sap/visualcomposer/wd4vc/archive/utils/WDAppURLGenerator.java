/*
 * Created on Nov 30, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WDAppURLGenerator {
//	http://localhost:50000/webdynpro/dispatcher/sap.com/ModelName/IViewName

	/**
	 * Default Vendor name for the Web Dynpro Applications
	 */
	private static String VENDOR_NAME = WDArchiveEntities.LOCAL_VENDOR_NAME;
	
	/**
	 * Default relative part of the URL for the Web Dynpro Dispatcher
	 */
	private static String DISPATCHER = "webdynpro/dispatcher"; //$NON-NLS-1$
	
	/**
	 * Name of the Web Dynpro archive, deployable object for which the
	 * application URLs are generated
	 */
	private static String mDeployableObjectName;
	
	/**
	 * Vendor Name
	 */
	private static String mVendor;
	
	private static String DELIMITER = "/" ; //$NON-NLS-1$
	
	
	/**
	 * Generates the relative URL for the Web Dynpro applications. It 
	 * generates the URLs with the specified information for vendor, 
	 * deployable object name. It also holds a collection of Web Dynpro
	 * application names for which the URLs have to be generated.
	 * 
	 * @param vendor			Name of the vendor
	 * @param deployableObject	Name of the Web Dynpro archive 
	 * @param applications		Collection of Web Dynpro applications belonging
	 * 							to the Web Dynpro archive 
	 * @return					Collection of the Web Dynpro application URLs 
	 */
	public static Map<String, String> generateURLs(String vendor, String deployableObject,
											Map<String, String> applications) {
		Map<String, String> appURLs = new HashMap<String, String>();
		if(deployableObject != null && applications != null) {
			mDeployableObjectName = deployableObject;
			
			// if vendor is null, set it to the default Vendor 'sap.com'
			if(vendor == null || vendor.equals("")) //$NON-NLS-1$
				mVendor = VENDOR_NAME;
			else
				mVendor = vendor;
				
			String mainUnitID = null;
			String applicationName = null;
			Iterator<String> iterator = applications.keySet().iterator();
			while (iterator.hasNext()) {
				mainUnitID = iterator.next();
				applicationName = applications.get(mainUnitID);
				appURLs.put(mainUnitID, generate(applicationName));				
			}	
		}			
		return appURLs;									
	}

	/**
	 * Generates the relative URL for the specified Web Dynpro application.
	 * The URL would be of the form 
	 * /webdynpro/dispacther/VENDOR/ARCHIVE_NAME/applicationName
	 * 
	 * @param applicationName	Name of the Web Dynpro application for 
	 * 							which the URL has to be generated.
	 * @return
	 */
	private static String generate(String applicationName) {
		StringBuffer URL = new StringBuffer();
		
		if(applicationName != null) {
			URL.append(DELIMITER);
			URL.append(DISPATCHER);
			URL.append(DELIMITER);
			URL.append(mVendor);
			URL.append(DELIMITER);
			URL.append(mDeployableObjectName);
			URL.append(DELIMITER);
			URL.append(applicationName);			
		}
		
		return URL.toString();
	}

}
