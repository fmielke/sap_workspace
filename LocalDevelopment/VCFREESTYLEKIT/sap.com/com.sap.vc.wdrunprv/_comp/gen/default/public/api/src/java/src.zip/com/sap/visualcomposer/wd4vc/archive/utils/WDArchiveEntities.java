/*
 * Created on Nov 30, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.utils;

/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WDArchiveEntities {

	// Default Vendor Name
	public static String LOCAL_VENDOR_NAME = "local"; //$NON-NLS-1$

	//Default Version number
	public static String VERSION_NUMBER = "2.2"; //$NON-NLS-1$
	
	// Default prefixes
	public static String DEPLOYABLE_PREFIX = "m"; //$NON-NLS-1$
	public static String WDAPPLICATION_PREFIX = "A";  //$NON-NLS-1$
	public static String WEBDYNPRO_DISPATCHER = "webdynpro/dispatcher"; //$NON-NLS-1$
	
	// Default Files to be generated
	public static String MANIFEST = "MANIFEST.MF"; //$NON-NLS-1$
	public static String SAP_MANIFEST = "SAP_MANIFEST.MF"; //$NON-NLS-1$
	public static String APPLICATION_XML = "application.xml"; //$NON-NLS-1$
	public static String APPLICATION_J2EE_ENGINE_XML = "application-j2ee-engine.xml"; //$NON-NLS-1$
	public static String WD_XML = "wd.xml";  //$NON-NLS-1$
	public static String WEBDYNPRO_XML = "webdynpro.xml"; //$NON-NLS-1$
	public static String APP_JAR = "app.jar"; //$NON-NLS-1$
	public static String TRANSLATIONS_XLF = "Translations_"; //$NON-NLS-1$
	//new code arun
	public static String WEB_XML = "web.xml"; //$NON-NLS-1$
	//ends here

	// Folders to be created
	public static String META_INF_FOLDER = "META-INF"; //$NON-NLS-1$
	public static String WEB_INF_FOLDER = "WEB-INF"; //$NON-NLS-1$
	public static String WEBDYNPRO_FOLDER = "webdynpro"; //$NON-NLS-1$
	public static String APPLICATIONS = "Applications"; //$NON-NLS-1$
	public static String COMPONENTINTERFACES = "ComponentInterfaces"; //$NON-NLS-1$
	public static String COMPONENTS = "Components"; //$NON-NLS-1$
	public static String CONFIGS = "Configs"; //$NON-NLS-1$
	public static String LIB = "lib"; //$NON-NLS-1$
	
	// Template Files to be used for generation
	public static String TEMPLATE_MANIFEST = "Template_Manifest.txt"; //$NON-NLS-1$
	public static String TEMPLATE_SAPMANIFEST = "Template_SAPManifest.txt"; //$NON-NLS-1$
	public static String TEMPLATE_APPLICATION_XML = "TemplateApplication.txt"; //$NON-NLS-1$
	public static String TEMPLATE_APPLICATION_J2EE_ENGINE_XML = "TemplateApplicationJ2EEEngine.txt"; //$NON-NLS-1$
	public static String TEMPLATE_WD_XML = "TemplateWD.txt"; //$NON-NLS-1$
	public static String TEMPLATE_WEB_XML = "TemplateWeb.txt";	 //$NON-NLS-1$
	public static String TEMPLATE_WEBDYNPRO_XML = "TemplateWebdynpro.txt"; //$NON-NLS-1$
	public static String TEMPLATE_WD_APPLICATION_RR_XML = "TemplateWDApplicationRR.txt"; //$NON-NLS-1$
	public static String TEMPLATE_XGLMODEL_XML = "TemplateComponentModel.txt"; //$NON-NLS-1$
	public static String TEMPLATE_WD_APPLICATION_XML = "TemplateWDApplication.txt"; //$NON-NLS-1$
	public static String TEMPLATE_WD_DCDEF = "TemplateDCDEF.txt"; //$NON-NLS-1$
	public static String TEMPLATE_WD_XLF = "TemplateXLF.txt"; //$NON-NLS-1$
	public static String TEMPLATE_WD_DEPENDENCY = "TemplateDependencies.txt"; //$NON-NLS-1$
	public static String TEMPLATE_DEPENDENCY_STRING = "TempleteDependencyString.txt"; //$NON-NLS-1$
	
	// Folder where the Templates are available
	public static String TEMPLATE_FOLDER = "com/sap/visualcomposer/wd4vc/templates/";  //$NON-NLS-1$
	
	// Required Archive File Extensions
	public static String WAR_FILE_EXTN = ".war"; //$NON-NLS-1$
	public static String EAR_FILE_EXTN = ".ear"; //$NON-NLS-1$
	public static String SRC_FILE_EXTN = ".zip"; //$NON-NLS-1$
	public static String XLF_FILE_EXTN = ".xlf"; //$NON-NLS-1$
	public static String JAR_FILE_EXTN = ".jar"; //$NON-NLS-1$
	public static String XML_FILE_EXTN = ".xml"; //$NON-NLS-1$
	
	//Other constants
	public static String CONNECTIVITYTYPE = "CONNECTIVITYTYPE"; //$NON-NLS-1$
	public static String CMI = "cmi"; //$NON-NLS-1$
	public static String PORTAL = "portal"; //$NON-NLS-1$
	public static String ENABLEDEBUG = "ENABLEDEBUG"; //$NON-NLS-1$
	public static String CONNECTIVITYURL = "&connectivityType="; //$NON-NLS-1$
	public static String ENABLEDEBUGURL = "&enableDebug=";  //$NON-NLS-1$
	
	public static String GUIDSTR = "#GUID#"; //$NON-NLS-1$
	public static String WDAPPNAMESTR = "#WebDynproApplicationName#"; //$NON-NLS-1$
	public static String WDRR ="wdrr.xml"; //$NON-NLS-1$
	
	public static String WDAPPINFOTAG = "wdapp:IWDApplicationInfo"; //$NON-NLS-1$
	public static String WDRRAGGRTAG = "wdrr:aggregation"; //$NON-NLS-1$
	public static String WDAPPPROPINFOTAG ="wdapp:IWDApplicationPropertyInfo"; //$NON-NLS-1$
	public static String VALUEATTR = "value"; //$NON-NLS-1$
	public static String NAMEATTR = "name"; //$NON-NLS-1$
	
	//webdynpro xml constants
	public static String APPLTAG ="applications"; //$NON-NLS-1$
	public static String PARTTAG ="part"; //$NON-NLS-1$
	public static String SHORTNAMEATTR = "shortName"; //$NON-NLS-1$
	
	//component model constants
	public static String WDAPPXGLDOCTAG = "wdapp:XGLDocument"; //$NON-NLS-1$
	public static String XGLSTRATTR = "XGLString"; //$NON-NLS-1$
	public static String URN = "URN"; //$NON-NLS-1$
	public static String WDRRENTRY = "wdrr:entry"; //$NON-NLS-1$
	public static String TARGETNAMEATTR ="targetName"; //$NON-NLS-1$
	public static String ORDERINDEXTAG = "wdrr:orderIndex"; //$NON-NLS-1$
	public static String ASSOCIATIONSTR ="association"; //$NON-NLS-1$
	public static String ENTRYSTR = "entry"; //$NON-NLS-1$
	public static String WDAPPXGLCOMPTAG = "wdapp:XGLComponent"; //$NON-NLS-1$
	public static String VERSIONATTR = "Version"; //$NON-NLS-1$
	public static String DCNAMEATTR = "DCName"; //$NON-NLS-1$
	public static String VENDORNAMEATTR = "VendorName"; //$NON-NLS-1$
	public static String WDAPPXGLMAINUNITTAG ="wdapp:XGLMainUnit"; //$NON-NLS-1$
	public static String MAINUNITIDATTR = "MainUnitID"; //$NON-NLS-1$
	public static String MAINUNITNAMEATTR = "MainUnitName"; //$NON-NLS-1$
	public static String WDAPPDEPTAG = "wdapp:Dependencies"; //$NON-NLS-1$
	public static String DEPENDENCIESSTR = "DependenciesString"; //$NON-NLS-1$
	public static String VENDORSTR = "#vendor#"; //$NON-NLS-1$
	public static String DEPOBJNAMESTR = "#DeployableObjectName#"; //$NON-NLS-1$
	
	
	public static String DEPENDENCIESATTRDC = "dc"; //$NON-NLS-1$
	public static String DEPENDENCIESATTRDCNAME = "dcname"; //$NON-NLS-1$
	public static String DEPENDENCIESATTRDCPREFIX = "dcprefix"; //$NON-NLS-1$
	public static String DEPENDENCIESATTRDCVENDOR = "dcvendor"; //$NON-NLS-1$
	public static String DEPENDENCIESATTRDISPAYNAME ="displayname"; //$NON-NLS-1$
	public static String DEPENDENCIESATTRPACKAGEPREFIX = "packageprefix"; //$NON-NLS-1$
	public static String DEPENDENCIESATTRREPOSITORY = "repository"; //$NON-NLS-1$
	public static String DEPENDENCIESATTRSC = "sc"; //$NON-NLS-1$
	public static String DEPENDENCIESATTRSCNAME = "scname"; //$NON-NLS-1$
	public static String DEPENDENCIESATTRSCVENDOR = "scvendor"; //$NON-NLS-1$
	public static String DEPENDENCIESATTRURN = "urn"; //$NON-NLS-1$
	
	//Dependency XML constants
	
	public static String SELFTAG  = "Self"; //$NON-NLS-1$
	public static String IMPORTSTAG = "Imports"; //$NON-NLS-1$
	public static String IMPORTTAG  = "import"; //$NON-NLS-1$
	public static String INTERFACETAG = "interface"; //$NON-NLS-1$
	public static String IMPLTAG = "implementation"; //$NON-NLS-1$
	
}
