package com.sap.visualcomposer.wd4vc.archive.utils;

import java.util.List;
import java.util.Properties;

public class XGLDocument {
	String xglString;
	String dependenciesString;
	boolean isMainUnit;
	String urn;
	String name;
	List translationsParser;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUrn() {
		return urn;
	}
	public void setUrn(String urn) {
		this.urn = urn;
	}
	public boolean isMainUnit() {
		return isMainUnit;
	}
	public void setMainUnit(boolean isMainUnit) {
		this.isMainUnit = isMainUnit;
	}
	public String getDependenciesString() {
		return dependenciesString;
	}
	public void setDependenciesString(String dependenciesString) {
		this.dependenciesString = dependenciesString;
	}
	public String getXglString() {
		return xglString;
	}
	public void setXglString(String xglString) {
		this.xglString = xglString;
	}
	
	public List getTranslationsParser() {
		return translationsParser;
	}
	public void setTranslationsParser(List parsers) {
		translationsParser = parsers;
	}
}
