/*
 * Created on Nov 30, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.utils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class XGLParser {
	
	private String mXGLString;
	
	private String UNICODE_ENCODING = "UTF-8" ;  //$NON-NLS-1$
	
	private String XGL_SCENARIO = "xg:Scenario" ;  //$NON-NLS-1$
	
	private String XGL_WINDOW = "xg:Window" ; //$NON-NLS-1$
	
	private String URN = "urn"; //$NON-NLS-1$
	
	private String WINDOW_TITLE  = "windowTitle";  //$NON-NLS-1$
	
	private String XGL_TRANSLATIONS  = "xg:Translations";  //$NON-NLS-1$
	
	private String XGL_TEXT  = "xg:Text";  //$NON-NLS-1$
	
	private String NAME  = "name";  //$NON-NLS-1$
	
	private String TEXT  = "text"; //$NON-NLS-1$
	

	
	public XGLParser(String xglString) {
		mXGLString = xglString;
	}
	
	
	
	public void identifyMainUnitDisplayNames(Map<String, String> mainUnitIDs) {		
		try {
			DocumentBuilder builder;
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			builder = factory.newDocumentBuilder();
			Document document = builder.parse(new ByteArrayInputStream(mXGLString.getBytes(UNICODE_ENCODING))); // $JL-I18N$
			
			NodeList componentList = document.getElementsByTagName(XGL_SCENARIO);
			NodeList childList = null;
			Node componentNode = null;
			Node windowNode = null;
			NamedNodeMap attributes = null;
			int componentCount = componentList.getLength();
			int childCount = 0;
			String componentID = null;
			String windowTitle = null;
			String wdAppName = null;
			
			for (int i = 0; i < componentCount; i++) {
				componentNode = componentList.item(i);
				attributes = componentNode.getAttributes();
				componentID = attributes.getNamedItem(URN).getNodeValue();
				//componentID = componentID.substring(3); // truncate the initial 3 characters
				if(mainUnitIDs.containsKey(componentID)) {
					childList = componentNode.getChildNodes();
					childCount = childList.getLength();
					for (int j = 0; j < childCount; j++) {
						if(childList.item(j).getNodeName().equals(XGL_WINDOW)) {
							windowNode = childList.item(j);
							attributes = windowNode.getAttributes();
							windowTitle = attributes.getNamedItem(WINDOW_TITLE).getNodeValue();
							wdAppName = identifyTranslatableText(document, windowTitle);
							mainUnitIDs.put(componentID, wdAppName);
						}
					}
				}				
			}
		} catch (ParserConfigurationException e) {
			throw new RuntimeException(e);
		} catch (SAXException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public Set<String> identifyMainUnits() {		
		Set<String> mainUnitIDs = new HashSet<String>();
		try {
			DocumentBuilder builder;
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			builder = factory.newDocumentBuilder();
			Document document = builder.parse(new ByteArrayInputStream(mXGLString.getBytes(UNICODE_ENCODING))); // $JL-I18N$
			
			NodeList componentList = document.getElementsByTagName(XGL_SCENARIO);
			Node componentNode = null;
			NamedNodeMap attributes = null;
			int componentCount = componentList.getLength();
			String componentID = null;
					
			for (int i = 0; i < componentCount; i++) {
				componentNode = componentList.item(i);
				attributes = componentNode.getAttributes();
				componentID = attributes.getNamedItem(URN).getNodeValue();
			//	componentID = componentID.substring(3); // truncate the initial 3 characters
				mainUnitIDs.add(componentID);
			}			
		} catch (ParserConfigurationException e) {
			throw new RuntimeException(e);
		} catch (SAXException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return mainUnitIDs;
	}
	
	private String identifyTranslatableText(Document document, String translationText) {
		String windowTitle = translationText;
		
		if(document != null && translationText != null) {
			NodeList translationsList = document.getElementsByTagName(XGL_TRANSLATIONS);
			NodeList childList = null;
			Node translationsNode = null;
			Node textNode = null;
			NamedNodeMap attributes = null;
			int transSectionCount = translationsList.getLength();
			int childCount = 0;
			String transGUID = null;
		
			for (int i = 0; i < transSectionCount; i++) {
				translationsNode = translationsList.item(i);
				childList = translationsNode.getChildNodes();
				childCount = childList.getLength();
				for (int j = 0; j < childCount; j++) {
					textNode = childList.item(j);
					if(textNode.getNodeName().equals(XGL_TEXT)) {
						attributes = textNode.getAttributes();
						transGUID = attributes.getNamedItem(NAME).getNodeValue();
						if(translationText.indexOf(transGUID) != -1) {
							if(translationText.equals("TRANSLATE(\""+transGUID+"\")")) //$NON-NLS-1$ //$NON-NLS-2$
								return attributes.getNamedItem(TEXT).getNodeValue();
						}
					}
				}
			}			
		}
		
		return windowTitle;
	}
	
}
