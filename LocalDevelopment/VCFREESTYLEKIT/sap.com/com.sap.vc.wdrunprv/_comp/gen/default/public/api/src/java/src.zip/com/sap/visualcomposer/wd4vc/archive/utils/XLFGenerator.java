/*
 * Created on Apr 5, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.visualcomposer.wd4vc.archive.utils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;


/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class XLFGenerator {

	private static final String SECTION_USER = "user"; //$NON-NLS-1$
	private static final String SECTION_DEFAULT = "default"; //$NON-NLS-1$
	private String UNICODE_ENCODING = "UTF-8" ;  //$NON-NLS-1$
	private String XGL_TRANSLATIONS  = "xg:Translations";  //$NON-NLS-1$
	private String SECTION = "section"; //$NON-NLS-1$
	private String XGL_TEXT  = "xg:Text";  //$NON-NLS-1$
	private String NAME  = "name";  //$NON-NLS-1$
	private String TEXT  = "text";  //$NON-NLS-1$
	private String TYPE  = "type";  //$NON-NLS-1$
	private String BODY = "body";   //$NON-NLS-1$
	private String GROUP = "group";   //$NON-NLS-1$
	private String RESTYPE = "restype"; //$NON-NLS-1$
	
	private static final Map resourceTypes = new HashMap();

	private String mXGLString;
	private String mLocation;
	private Document mDocument;
	private Document mXLFDocument;
	private File mUserXLF;
	private File mDefaultXLF;

	static {
		resourceTypes.put("XTXT", "generaltext"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XBLI", "listitem"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XBUT", "button");   //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XCKL", "checkbox");  //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XCOL", "tableColumnHeading"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XFLD", "label"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XGRP", "grouptitle"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XGLS", "term"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XLNK", "hyperlink"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XLOG", "logentry"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XLST", "listbox"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XMEN", "menu"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XMIT", "menuitem"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XMSG", "messagetext"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XRBL", "radio"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XSEL", "selectiontext"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XTBS", "tab"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XTIT", "tableTitle"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XTOL", "quickinfo"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("XTND", "treeNode"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YBLI", "list"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YDEF", "definition"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YDES", "description"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YFAQ", "faq"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YFAA", "faqa"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YGLS", "glossarydefinition"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YINS", "instruction"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YTXT", "generaltextlong"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YLOG", "logEntrylong"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YTIC", "ticker"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YMSG", "messagetextlong"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YINF", "informationtextlong"); //$NON-NLS-1$ //$NON-NLS-2$
		resourceTypes.put("YTEC", "technicaltextlong"); //$NON-NLS-1$ //$NON-NLS-2$
	}

	public XLFGenerator(String xglString, String location) {
		mXGLString = xglString;
		mLocation = location;
	}

	public void generateXLF() {
		if(mXGLString != null && mLocation != null) {
			getDocument(mXGLString);
			mUserXLF = generateXLF(SECTION_USER);
			mDefaultXLF = generateXLF(SECTION_DEFAULT);
		}
	}

	private void getDocument(String xglString) {
		DocumentBuilder builder = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		try {
			builder = factory.newDocumentBuilder();
			mDocument = builder.parse(new ByteArrayInputStream(xglString.getBytes(UNICODE_ENCODING))); // $JL-I18N$
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private File generateXLF(String sectionType) {
		if(sectionType != null) {
			List userTranslations = identifyTranslations(sectionType);
			InputStream iStream = resourceReader(WDArchiveEntities.TEMPLATE_FOLDER + 
													WDArchiveEntities.TEMPLATE_WD_XLF);
			Document transDocument = addTransUnits(iStream, userTranslations);
			String xlfFilePath = mLocation + File.separator + WDArchiveEntities.TRANSLATIONS_XLF 
								+sectionType+ WDArchiveEntities.XLF_FILE_EXTN;
			return writeDOMtoFile(transDocument, xlfFilePath);
		}
		return null;
	}

	private List identifyTranslations(String sectionType) {
		List transList = new ArrayList();
		if(sectionType != null) {
			NodeList translationsList = mDocument.getElementsByTagName(XGL_TRANSLATIONS);
			NodeList childList = null;
			Node translationsNode = null;
			Node textNode = null;
			NamedNodeMap attributes = null;
			int translationsCount = translationsList.getLength();
			int childCount = 0;
			String type = null;
			String name = null;
			String text = null;
			TranslationUnit translationUnit = null;

			for (int i = 0; i < translationsCount; i++) {
				translationsNode = translationsList.item(i);
				attributes = translationsNode.getAttributes();
				if(attributes.getNamedItem(SECTION).getNodeValue().equals(sectionType)) { 
					childList = translationsNode.getChildNodes();
					childCount = childList.getLength();
					for (int j = 0; j < childCount; j++) {
						if(childList.item(j).getNodeName().equals(XGL_TEXT)) {
							textNode = childList.item(j);
							attributes = textNode.getAttributes();
							name = attributes.getNamedItem(NAME).getNodeValue();
							text = attributes.getNamedItem(TEXT).getNodeValue();
							type = attributes.getNamedItem(TYPE).getNodeValue();
							translationUnit = new TranslationUnit(name, text, type);
							transList.add(translationUnit);
						}
					}

				}
			}

		}
		return transList;
	}

	/**
		<group restype="tableTitle">
			<trans-unit maxwidth="255" resname="DHIdcbiDnEpogbGijncBJ" id="DHIdcbiDnEpogbGijncBJ">
				<source>Bank List Grid</source>
			</trans-unit>
		</group>
	 */
	private Document addTransUnits(InputStream iStream, List translations) {
		DocumentBuilder builder = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		try {
			builder = factory.newDocumentBuilder();
			mXLFDocument = builder.parse(iStream);
			
			if(translations != null && !translations.isEmpty()) {
				Iterator iterator = translations.iterator();
				TranslationUnit translationUnit = null;
				String resType = null;
				Node bodyNode = mXLFDocument.getElementsByTagName(BODY).item(0);
				Node groupNode = null;
				
				while (iterator.hasNext()) {
					translationUnit = (TranslationUnit) iterator.next();
					resType = translationUnit.getType();										
					
					groupNode = getorCreateGroupNode(resType);
					if(groupNode != null) 
						appendTranslationUnit(groupNode, translationUnit);
				}
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mXLFDocument;
	}
	
	private Node getorCreateGroupNode(String resType) {
		Node groupNode = null;
		if(resType != null) {
			NodeList nodeList = mXLFDocument.getElementsByTagName(GROUP);
			if(nodeList != null) {
				int count = nodeList.getLength();
				for (int i = 0; i < count; i++) {
					groupNode = nodeList.item(i);
					if(groupNode.getAttributes().getNamedItem(RESTYPE).getNodeValue().equals(resType))
						return groupNode;										
				}
			}
			
			// create a new element
			Node bodyNode = mXLFDocument.getElementsByTagName(BODY).item(0);
				
			// add the first element
			groupNode = mXLFDocument.createElement(GROUP);
			((Element)groupNode).setAttribute(RESTYPE, (String)resourceTypes.get(resType));
			bodyNode.appendChild(groupNode);
		}
		return groupNode;
	}
	
	private void appendTranslationUnit(Node parentNode, TranslationUnit unit) {
		if(parentNode != null && unit != null) {
			Element transUnitElement = mXLFDocument.createElement("trans-unit"); //$NON-NLS-1$
			transUnitElement.setAttribute("maxwidth", "255"); //$NON-NLS-1$ //$NON-NLS-2$
			transUnitElement.setAttribute("resname", unit.getName()); //$NON-NLS-1$
			transUnitElement.setAttribute("id", unit.getName()); //$NON-NLS-1$
			parentNode.appendChild(transUnitElement);
				
			Element sourceElement = mXLFDocument.createElement("source"); //$NON-NLS-1$
			Text text = mXLFDocument.createTextNode(unit.getText());
			sourceElement.appendChild(text);			
			transUnitElement.appendChild(sourceElement);
		}
	}

	private InputStream resourceReader(String resourceName) {
		return XLFGenerator.class.getClassLoader().getResourceAsStream(resourceName);
	}

	private File writeDOMtoFile(Document document, String targetFile) {
		File DOMFile = null; 
		if(document != null && targetFile != null) {
			DOMFile = new File(targetFile);
			Source source = null;
			Result result = null;
			try {
				// Create a transformer
				Transformer xformer = TransformerFactory.newInstance().newTransformer();

				// Write the DOM document to a file
				source = new DOMSource(document);
				result = new StreamResult(DOMFile);
				xformer.transform(source, result);
			} catch (TransformerConfigurationException e) {
				e.printStackTrace();
			} catch (TransformerException e) {
				e.printStackTrace();
			}
		}
		return DOMFile;
	}
	
	public File getUserXLFFile() {
		return mUserXLF;
	}
	
	public File getDefaultXLFFile() {
		return mDefaultXLF;
	}

	public static void main(String[] args) {
		String XGLString = null;
		try {
			InputStream iStream = new FileInputStream("C:\\temp" + File.separator + "nested.xml"); //$NON-NLS-1$ //$NON-NLS-2$
			byte bytes[] = new byte[iStream.available()];
			iStream.read(bytes);
			XGLString = new String(bytes); // $JL-I18N$
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}
		XLFGenerator generator = new XLFGenerator(XGLString, "C:\\temp"); //$NON-NLS-1$
		generator.generateXLF();
	}

}
