package com.sap.tc.wd4vc.extapi;

import java.util.Map;

import com.sap.tc.wd4vc.extapi.info.IExternalStatusInfo;
import com.sap.tc.wd4vc.extapi.info.IExternalXGLExecutableInfo;

/**
 * A listener that can receive notifications of the execution of the interpreter.
 * The interpreter notifies the listener on two situations:
 * 		-	before the start of the execution
 * 		-	upon completion of the execution
 * The executables that are considered here are Step of ExecutionPlan 
 * and Action defined in the application. 
 *  
 * @author Padmashree B
 *
 */
public interface IExternalExecutionListener {
  
  /**
   * The listener initializes itself
   * 
   * @return  Reurns the initialization status
   */
  boolean init();
  
  /**
   * Returns the value of the parameter
   * 
   * @param key   Key for which the value has to retrieved
   * @return      Value of the parameter key
   */
  Object getParameter(String key);
  
  /**
   * Every XGL Component of the VC application has its own 
   * IExternalWD4VCEngine. The listener must be aware of and must have
   * reference of every XGLComponent's XGLEngine
   * 
   * @param URN         URN of the XGL Component
   * @param xglEngine   Reference of the IExternalWD4VCEngine
   */
  void addExternalEngineForComponent(String URN, IExternalWD4VCEngine xglEngine); 
  
	/**
	 * The notification sent before starting the execution
	 * 
	 * @param executableInfo	The executable to be executed
	 * 
	 */
	void preExecution(IExternalXGLExecutableInfo executableInfo);
	
	/**
	 * The notification sent after executing the executable
	 * 
	 * @param executableInfo	The executable being executed
	 * @param statusInfo		The status of the execution
	 */
	void postExecution(IExternalXGLExecutableInfo executableInfo, IExternalStatusInfo statusInfo);
	
	/**
	 * The notification sent to  RT Controller for terminating the debugger
	 * 
	 * 
	 */
	//boolean terminate();
	/**
	 * The notification sent to  RT Controller for terminating the debugger
	 * In case of Runtime Exception it will send the Exception message
	 * 
	 */
	boolean terminate(String message);

	void reset(Map<String, Object> parameters);
}
