package com.sap.tc.wd4vc.extapi;

import com.sap.tc.wd4vc.extapi.info.IExternalStatusInfo;
import com.sap.tc.wd4vc.extapi.info.IExternalXGLExecutableInfo;
import com.sap.tc.webdynpro.progmodel.api.IWDNode;

/**
 * 
 * 
 * DO NOT EXTEND OR IMPLEMENT THIS INTERFACE. It won't work since the WD4VC
 * Framework expects and relies on its own implementation
 * 
 * @author Padmashree B
 *
 */
public interface IExternalWD4VCEngine {
	
	/**
	 * Returns the metadata of the XGLComponent 
	 * @return		Returns the metadata of the XGLComponent
	 */
	IExternalXGLComponent getXGLComponent();
	
	/**
	 * Returns the reference of the interpreter controlling the
	 * execution of the XGLComponent this engine refers
	 * @return		Returns the reference of the XGLInterpreter
	 */
	IExternalInterpreter getXGLInterpreter();
	
	/**
	 * Displays the UI. It must be noted that the XGLComponent must be loaded
	 * before this
	 */
	void displayUI();
	
	/**
	 * Starts or initializes the XGL Component as defined in the XGL Specification
	 */
	void startComponent();
	
	/**
	 * Request to fill the data for a given infoset from the hosting environment.
	 * It must be noted that it is possible to provide initialization/external
	 * data only for InPorts. And for InPorts of type STARTPORT it can be 
	 * initialized only once during the life-cycle of the XGLComponent
	 * 
	 * TODO: Can the data be provided to IOPorts? 
	 * 
	 * @param infosetID		ID of the infoset whose data has to be re-initialized
	 * @param datNode		Context structure which holds the data
	 */
	void fillData(String infosetID, IWDNode datNode);

	/**
	 * Executes the specified XGL Executable. The executables could be
	 * Action, SignalIn, ExecutionPlan 
	 * 
	 * @param executableInfo	XGL Entity that must be executed
	 * @return					Returns the status of the execution
	 */
	IExternalStatusInfo execute(IExternalXGLExecutableInfo executableInfo);
	
	/**
	 * Returns the data held in the specified infoset
	 * 
	 * @param infosetID		ID of the Infoset whose data needs to be retrieved
	 * @return
	 */
	IWDNode getData(String infosetID);
	
	/**
	 * Terminates the XGLComponent that is being executed by this Engine
	 * 
	 * @return		Returns true if the termination is successful, false otherwise
	 */
	boolean terminateComponent();
	
	/**
	 * Returns the references of ExternalListeners, for ex: Debugger Listeners
	 * 
	 * @return   Returns an array of associated listeners, if any
	 */
	IExternalExecutionListener[] getExternalListeners();
}
