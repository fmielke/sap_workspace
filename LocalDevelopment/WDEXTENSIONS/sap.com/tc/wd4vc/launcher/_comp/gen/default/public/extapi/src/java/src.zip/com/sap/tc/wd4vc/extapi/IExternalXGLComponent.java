package com.sap.tc.wd4vc.extapi;

import java.util.List;
import java.util.Map;

import com.sap.tc.wd4vc.extapi.info.IExternalXGLInfosetInfo;
import com.sap.tc.wd4vc.extapi.info.IExternalXGLPortInfo;

/**
 * Represents the external static structural aspect of the XGL entity. 
 * <p>
 * The relevant meta data accessible through IExternalXGLComponent are:
 * <ul>
 *  <li>{@link #getDCName() DevelopmentObject name to which this XGLComponent belongs}
 *  <li>{@link #getApplicationName() Model Name if this is declared as MainUnit}
 *  <li>{@link #getURN() Unique identifier to identify the XGLComponent}
 *  <li>{@link #getType() type - Scenario or Service}
 *  <li>{@link #getInPorts() List of relays resulting as InPorts}
 *  <li>{@link #getOutPorts() List of relays resulting as OutPorts}
 *  <li>{@link #getIOPorts() List of Datashare relays}
 * </ul>
 * <p>
 * 
 * DO NOT EXTEND OR IMPLEMENT THIS INTERFACE. It won't work since the WD4VC
 * Framework expects and relies on its own implementation
 * 
 * @author Padmashree B
 * @param <IXGLInfoshapeInfo>
 * @param <IXGLInfosetInfo>
 *
 */
public interface IExternalXGLComponent<IXGLInfoshapeInfo, IXGLInfosetInfo> {

	/**
	 * Constant value indicating that the component is a Scenario
	 */
	public static final int SCENARIO = 0;
	
	/**
	 * Constant value indicating that the component is a Service
	 */
	public static final int SERVICE = 1;
	
	/**
	 * Returns the name of the DevelopmentObject to which the 
	 * XGL Component belongs to
	 * 
	 * @return	Returns the DCName
	 */
	String getDCName();
	
	/**
	 * Returns the application name of the XGL Component
	 * 
	 * @return	Returns the name of the Component
	 */
	String getApplicationName();
	
	/**
	 * Returns the URN of the XGL Component
	 * 
	 * @return	Returns the URN
	 */
	String getURN();
	
	/**
	 * Returns the type of the XGL Component
	 * 
	 * @return	Returns the type of the component
	 */
	int getType();
	
	/**
	 * Returns the list of the input ports
	 * 
	 * @return	Returns the list of input ports
	 */
	List<IExternalXGLPortInfo> getInPorts();
	
	/**
	 * Returns the list of the output ports
	 * 
	 * @return	Returns the list of output ports
	 */
	List<IExternalXGLPortInfo> getOutPorts();
	
	/**
	 * Returns the list of the io ports
	 * 
	 * @return	Returns the list of io ports
	 */
	List<IExternalXGLPortInfo> getIOPorts();
	
	/**
	 * Returns the XGL Attribute TimeStamp
	 * 
	 * @return	Returns the XGL Attribute TimeStamp
	 */
	String getLastModified() ;
	
	//Map<String,IXGLInfosetInfo> getDynamicInfoset();
	
	
}
