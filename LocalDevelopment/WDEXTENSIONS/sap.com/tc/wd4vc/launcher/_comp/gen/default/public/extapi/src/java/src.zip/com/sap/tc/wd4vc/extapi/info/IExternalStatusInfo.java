package com.sap.tc.wd4vc.extapi.info;

/**
 * API to communicate the status of execution of any XGL executable (step, 
 * action)
 *  
 * DO NOT EXTEND OR IMPLEMENT THIS INTERFACE. It won't work since the WD4VC
 * Framework expects and relies on its own implementation
 * 
 * @author Padmashree B
 *
 */
public interface IExternalStatusInfo {

	/**
	 * Returns the execution status of the executable within
	 * the application
	 * 
	 * @return		Returns true if the executable is executed successfully,
	 * 				else, false
	 */
	boolean getStepExecutionStatusInfo();
	
	/**
	 * Returns the execution status of the guardcondition, if defined,
	 * on the executable
	 * 
	 * @return		Returns true if the guardcondition,
	 * 				if defined, is executed successfully,
	 * 				else, false
	 */	
	boolean getGuardConditionExecutionStatus();
	/**
	 * Returns the execution status of the guardcondition, if defined,
	 * on the executable
	 * 
	 * @return    Returns Error messages array 
	 *        while evaluating of the service in  case somthing goes wtong 
	 *        
	 */

	String[] getMessages();
	
}
