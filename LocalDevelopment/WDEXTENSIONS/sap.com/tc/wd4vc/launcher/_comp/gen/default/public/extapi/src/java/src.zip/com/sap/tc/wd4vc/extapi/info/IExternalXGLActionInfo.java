package com.sap.tc.wd4vc.extapi.info;

import java.util.List;

/**
 * Represents the static structural aspect of the XGL Executable, Action
 * 
 * DO NOT EXTEND OR IMPLEMENT THIS INTERFACE. It won't work since the WD4VC
 * Framework expects and relies on its own implementation
 * 
 * @author Padmashree B
 *
 */
public interface IExternalXGLActionInfo extends IExternalXGLExecutableInfo {

	/**
	 * Constant value indicating that the action is declared as atomic
	 */
	public static final int ATOMIC = 0;

	/**
	 * Constant value indicating that the action is declared as alternate
	 */
	public static final int ALTERNATE = 1;
	
	/**
	 * Constant value indicating that the action is declared as sequence
	 */
	public static final int SEQUENCE = 2;
	
  /**
   * Returns the type of the Action
   * @return  Returns the type of the Action
   */
  int getActionType();
  
	/**
	 * Returns whether the described action is a SytemAction
	 * 
	 * @return	Returns true if the described action is a SystemAction
	 * 			or false otherwise
	 */
	boolean isSystemAction();
	
	/**
	 * Returns the list of child actions 
	 * If the described action is Alternate or Sequence action, it 
	 * contains a list of child actions
	 * 
	 * @return	Returns a list of child actions
	 */
	List<IExternalXGLActionInfo> getActions();
	
}
