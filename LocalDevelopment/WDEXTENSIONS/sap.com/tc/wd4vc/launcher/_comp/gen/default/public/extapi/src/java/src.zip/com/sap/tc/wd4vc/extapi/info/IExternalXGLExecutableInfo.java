package com.sap.tc.wd4vc.extapi.info;

import java.util.List;

/**
 * Represents the executable of the application. The executables can be one of 
 * Step of ExecutionPlan or Action or Signal
 * 
 * DO NOT EXTEND OR IMPLEMENT THIS INTERFACE. It won't work since the WD4VC
 * Framework expects and relies on its own implementation
 * 
 * @author Padmashree B
 *
 */
public interface IExternalXGLExecutableInfo extends IExternalXGLObjectInfo {

	/**
	 * Constant value indicating that the executable is a Signal
	 */
	public static final int SIGNAL = 0;
	
	/**
	 * Constant value indicating that the executable is a Step of 
	 * an ExecutionPlan
	 */
	public static final int STEP = 1;
	
	
	/**
	 * Constant value indicating that the executable is an Action, either
	 * System or UserDefined
	 */
	public static final int ACTION = 2;
	
	/**
	 * Returns an array of IDs of the infosets that are affected
	 * upon executing this executable
	 * 
	 * @return	Returns the list of infosets that are affected, empty array
	 * 			if there are none 			
	 */
	List<String> getAffectedInfosetIDs();

	/**
	 * Returns the index of the ExecutableInfo
	 * @return  Returns the index of the ExecutableInfo
	 */
	int getIndex();

	/**
	 * Returns the exact type of the executable such as
	 * Returns Invalidate, Map, Copy, Eval, Trans, etc if it is
	 * an executable step. In case of Eval step it also returns what it is 
	 * evaluating such as Eval FormView, Eval Infoactor, etc
	 * Returns Insert, Delete, MoveTo, CopyTo etc if it is an 
	 * system action
	 * 
	 * @return  Returns the actual type of the executable step 
	 */
	String getExecutableType();
	/*
	 * Returns the Action Name such as Start,Submit etc
	 */
	public String getActionName();
}
