package com.sap.tc.wd4vc.extapi.info;

/**
 * Represents the static structural aspect of the XGL Infoset. It has reference
 * to the Infoshape holding its metadata 
 *  
 * DO NOT EXTEND OR IMPLEMENT THIS INTERFACE. It won't work since the WD4VC
 * Framework expects and relies on its own implementation
 * 
 * @author Padmashree B
 *
 */
public interface IExternalXGLInfosetInfo extends IExternalXGLObjectInfo {

	/**
	 * Returns the metadata for this infoset
	 * 
	 * @return	Returns the metadata for this infoset
	 */
	IExternalXGLInfoshapeInfo getInfoshapeInfo();
	
}
