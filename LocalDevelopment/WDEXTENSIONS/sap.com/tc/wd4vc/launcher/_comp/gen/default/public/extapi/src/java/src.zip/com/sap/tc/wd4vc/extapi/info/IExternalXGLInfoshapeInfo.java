package com.sap.tc.wd4vc.extapi.info;

import java.util.List;

/**
 * Represents the metadata of the XGL Infoset. 
 *  
 * DO NOT EXTEND OR IMPLEMENT THIS INTERFACE. It won't work since the WD4VC
 * Framework expects and relies on its own implementation
 * 
 * @author Padmashree B
 *
 */
public interface IExternalXGLInfoshapeInfo extends IExternalXGLObjectInfo {
	
	/**
	 * Constant value indicating that the infoshape is of type Singleton
	 */
	public static final int SINGLETON = 0;
	
	/**
	 * Constant value indicating that the infoshape is of type Array
	 */
	public static final int ARRAY = 1;

	/**
	 * Constant value indicating that the infoshape is of type Cluster
	 */
	public static final int CLUSTER = 2;
	
	/**
	 * Returns the type of the described infoshape
	 * 
	 * @return	Returns the type of the infoshape
	 */
	int getInfoshapeType();	
	
	/**
	 * Returns the list of fields the described infoshape contains
	 * 
	 * @return	Returns the list of fields
	 */
	List<IExternalXGLStructureInfo> getFieldInfos();
	
	/**
	 * Returns the list of child infoshapes
	 * 
	 * @return	Returns the list of infoshapes
	 */
	List<IExternalXGLInfoshapeInfo> getInfoshapeInfos();
	
}
