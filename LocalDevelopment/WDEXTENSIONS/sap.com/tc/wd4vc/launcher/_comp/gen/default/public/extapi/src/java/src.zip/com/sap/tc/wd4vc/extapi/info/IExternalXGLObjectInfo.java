package com.sap.tc.wd4vc.extapi.info;

import com.sap.tc.wd4vc.extapi.IExternalXGLComponent;

/**
 * Represents the static structural aspect of the XGL entity. Each 
 * XGLObjectInfo has reference to the XGLComponent to which it belongs 
 * <p>
 * The relevant meta data accessible through IExternalXGLObjectInfo are:
 * <ul>
 *  <li>{@link #getID() ID}
 *  <li>{@link #getName() name}
 *  <li>{@link #getAppName() appName}
 *  <li>{@link #getType() type}
 *  <li>{@link #getParentID() parentID}
 *  <li>{@link #isExecutable() executable}
 *  <li>{@link #getXGLComponent() XGLComponent}
 * </ul>
 * <p>
 * 
 * DO NOT EXTEND OR IMPLEMENT THIS INTERFACE. It won't work since the WD4VC
 * Framework expects and relies on its own implementation
 * 
 * @author Padmashree B
 *
 */
public interface IExternalXGLObjectInfo {

	/**
	 * Returns ID of the XGLObject
	 * 
	 * @return	Returns the ID of the XGLObject
	 */
	String getID();
	
	/**
	 * Returns the name of the XGLObject as captured in the XGL
	 * 
	 * @return	Returns the name of the XGLObject
	 */
	String getName();
	
	/**
	 * Returns the type of the XGLObject. It could be Infoset, Infoshape,
	 * Step, Action, Port, Structure
	 * 
	 * @return	Returns the type of the XGLObject
	 */
	String getType();
	
	/**
	 * Returns the appName of the XGLObject as captured in the XGL
	 * 
	 * @return	Returns the appName of the XGLObject
	 */
	String getAppName();
	
	/**
	 * Returns the ID of the parent XGLObject
	 * 
	 * @return	Returns the ID of the parent, if exists, else NULL
	 */
	String getParentID();
	
	/**
	 * Returns if the XGLObject is executable. Executable objects are
	 * Steps of ExecutionPlan, Actions (both Sytem and UserDefined)
	 * 
	 * @return	Returns true if the XGLObject is executable else false
	 */
	boolean isExecutable();
	
	/**
	 * Returns the XGLComponent to which this XGLObject belongs to
	 * 
	 * @return	Returns the XGLComponent
	 */
	IExternalXGLComponent getXGLComponent();
	
}
