package com.sap.tc.wd4vc.extapi.info;

/**
 * Represents the metadata of the port in the XGL Component 
 * It must be noted that the Relays within a XGL Component is exposed as 
 * in/out/io ports in the embedding components. Same is the case when the
 * XGL Component is hosted in an external environment
 *  
 * <p>
 * Relay-Port mapping:
 * 	StartPoint - Though this is not identified as a port in the embedding 
 * 					XGL Component, it is possible to provide init data
 * 					by the hosting environment
 * 	EndPoint - Like StartPoint this is also not identified as a port in
 * 					the embedding XGL Component. Nevertheless, it is
 * 					possible to notify the hosting environment about the 
 * 					termination of the XGL Component and pass the data
 * 	SignalIn/DataIn - Inports
 * 	SignalOut/DataOut - Outports	 
 * </p>
 * 
 * 
 * DO NOT EXTEND OR IMPLEMENT THIS INTERFACE. It won't work since the WD4VC
 * Framework expects and relies on its own implementation
 * 
 * @author Padmashree B
 *
 */
public interface IExternalXGLPortInfo extends IExternalXGLObjectInfo {
	
	/**
	 * Constant value indicating that it is an INPORT
	 */
	public static final int INPORT = 0;

	/**
	 * Constant value indicating that it is an OUTPORT
	 */
	public static final int OUTPORT = 1;
	
	/**
	 * Constant value indicating that it is an IOPORT
	 */
	public static final int IOPORT = 2;

	/**
	 * Constant value indicating that it is a STARTPORT
	 */
	public static final int STARTPORT = 3;
	
	/**
	 * Constant value indicating that it is an ENDPORT
	 */
	public static final int ENDPORT = 4;
	
	/**
	 * Returns the type of the port
	 * @return	Returns the type of the port
	 */
	int getPortType();
	
	/**
	 * Not all ports have events. Only the OutPorts which refer to the 
	 * SignalOut relays of the XGL Component 
	 *  
	 * @return	Returns true if the PORT has event, false otherwise
	 */
	boolean hasEvent();

	/**
	 * Returns the event name if the port has one
	 * 
	 * @return	Returns the event name
	 */
	String getEventName();
	
	/**
	 * Returns the ID of the infoset referred by the PORT
	 * 
	 * @return	Returns the ID of the Infoset 
	 */
	String getInfosetID();
	
}
