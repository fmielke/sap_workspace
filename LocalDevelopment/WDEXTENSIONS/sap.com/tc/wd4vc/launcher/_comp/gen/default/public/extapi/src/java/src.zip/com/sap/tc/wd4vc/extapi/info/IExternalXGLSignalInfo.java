package com.sap.tc.wd4vc.extapi.info;

/**
 * Represents the static structural aspect of the XGL Executable, Signal
 * 
 * DO NOT EXTEND OR IMPLEMENT THIS INTERFACE. It won't work since the WD4VC
 * Framework expects and relies on its own implementation
 * 
 * @author Padmashree B
 *
 */
public interface IExternalXGLSignalInfo extends IExternalXGLExecutableInfo {

	/**
	 * Returns the ID of the infoset that the executable refers to
	 * 
	 * @return	Returns the ID of the infoset
	 */
	String getInfosetID();
	
}
