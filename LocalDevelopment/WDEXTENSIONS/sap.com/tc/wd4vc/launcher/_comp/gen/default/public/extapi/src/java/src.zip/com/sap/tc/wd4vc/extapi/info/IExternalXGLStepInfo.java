package com.sap.tc.wd4vc.extapi.info;

import java.util.List;

/**
 * Represents the static structural aspect of the XGL Executable, Step
 * 
 * DO NOT EXTEND OR IMPLEMENT THIS INTERFACE. It won't work since the WD4VC
 * Framework expects and relies on its own implementation
 * 
 * @author Padmashree B
 *
 */
public interface IExternalXGLStepInfo extends IExternalXGLExecutableInfo {

	/**
	 * Constant value indicating that the described step is invalidate
	 */
	public static final int INVALIDATE = 0;

	/**
	 * Constant value indicating that the described step is copy
	 */
	public static final int COPY = 1;
	
	/**
	 * Constant value indicating that the described step is map
	 */
	public static final int MAP = 2;
	
	/**
	 * Constant value indicating that the described step is eval
	 */
	public static final int EVAL = 3;

	/**
	 * Constant value indicating that the described step is trans
	 */
	public static final int TRANS = 4;
	
	/**
	 * Returns the type of the executable step
	 * 
	 * @return	Returns the type of the executable step
	 */
	String getStepType();
	
	/**
	 * Returns the ID of the execution plan to which the described 
	 * step belongs to
	 * 
	 * @return	Returns the execution plan ID
	 */
	String getExecutionPlanID();
	
	/**
	 * Returns the index of the described executable step within
	 * the ExecutionPlan to which it belongs
	 * 
	 * @return	Returns the index of the described step
	 */
	int getStepIndex();
	
	/**
	 * Returns the ID of the source Infoset considered in the 
	 * described step
	 * Depending on the type of the Step, the Source ID may or may not
	 * exist. There is no source infoset if it is an EVAL Step   
	 * 
	 * @return	Returns the ID of the Source Infoset, if any,
	 * 			else NULL
	 */
	String getSourceID();
	
	/**
	 * Returns the list of Infoset IDs forming the targets of 
	 * the described step
	 * 
	 * @return	Returns the list of target Infoset IDs
	 */
	List<String> getTargetIDs();
	
	/**
	 * The guardcondition is an expression that can be defined 
	 * to enable or disable the executable step dynamically
	 * 
	 * @return	Returns the guardcondition if any, else NULL
	 */
	String getGuardCondition();
	/*
	 * Returns the Action Name such as Start,Submit etc
	 */
	
	String getActionName();
	
}
