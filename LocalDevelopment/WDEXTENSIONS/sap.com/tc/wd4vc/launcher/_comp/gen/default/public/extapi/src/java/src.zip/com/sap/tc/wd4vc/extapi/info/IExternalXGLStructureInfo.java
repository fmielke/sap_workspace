package com.sap.tc.wd4vc.extapi.info;

import java.util.List;

/**
 * Represents the metadata of the field of an infoshape
 * 
 * DO NOT EXTEND OR IMPLEMENT THIS INTERFACE. It won't work since the WD4VC
 * Framework expects and relies on its own implementation
 * 
 * @author Padmashree B
 *
 */
public interface IExternalXGLStructureInfo extends IExternalXGLObjectInfo {

	/**
	 * Constant value indicating that the structure is of type Field
	 */
	public static final int FIELD = 0;

	/**
	 * Constant value indicating that the structure is of type StructuredField
	 */
	public static final int STRUCTUREDFIELD = 1;
	
	/**
	 * Constant value indicating that the datatype of the field is Boolean
	 */
	public static final int BOOLEAN = 2;
	
	/**
	 * Constant value indicating that the datatype of the field is String
	 */
	public static final int STRING = 3;
	
	/**
	 * Constant value indicating that the datatype of the field is Number
	 */
	public static final int NUMBER = 4;
	
	/**
	 * Constant value indicating that the datatype of the field is Date
	 */
	public static final int DATE = 5;
	
	/**
	 * Constant value indicating that the datatype of the field is Time
	 */
	public static final int TIME = 6;

	/**
	 * Constant value indicating that the datatype of the field is Datetime
	 */
	public static final int DATETIME = 7;
	
	/**
	 * Returns the type of the described structure
	 * 
	 * @return	Returns the type of the structure
	 */
	int getStructureType();
	
	/**
	 * Returns the datatype of the described structure
	 * 
	 * @return	Returns the datatype
	 */
	int getDataType();
	
	/**
	 * Returns the list of child Structures
	 * 
	 * @return	Returns the list of child structures
	 */
	List<IExternalXGLStructureInfo> getStructureInfos();
	
}
