/*
 * Created on Apr 12, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.tc.wd4vc.launcher.java;

/**
 * @author I026466
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface ILauncherParameters {

	public static String APPLICATION_ID = "applicationID";
	public static String INPUT_DATA = "inputData";
	public static String XGL_DOCUMENT = "XGL_DOCUMENT";
	
	public static String URL_PARAM_COMPLEX_DATA = "_paramsXmlStr_";
	public static String RUNNING_EMBEDDED_IN_PROCESS = "runningEmbeddedInProcess";
	public static String DISABLECACHE = "disableCache";
}
