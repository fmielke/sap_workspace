package tr119.de.htwberlin.tr_119_product.bl.caf.modeled.bonode.tr_119_order.tr_119_order;

public interface TR_119_OrderServiceLocal extends tr119.de.htwberlin.tr_119_product.bl.caf.modeled.bonode.tr_119_order.tr_119_order.TR_119_OrderService, com.sap.caf.rt.bol.IBusinessObjectNodeServiceBase{
}