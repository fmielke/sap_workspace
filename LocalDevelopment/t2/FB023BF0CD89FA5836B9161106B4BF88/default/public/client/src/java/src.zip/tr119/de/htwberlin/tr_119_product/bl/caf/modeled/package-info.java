@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.sap.com/caf/htwberlin.de.tr119/tr_119_product.bl.caf/modeled")
package tr119.de.htwberlin.tr_119_product.bl.caf.modeled;
